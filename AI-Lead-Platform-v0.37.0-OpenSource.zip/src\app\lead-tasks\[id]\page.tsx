'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  downloadLeadTaskText,
  findSavedLeadTask,
  generateLeadTaskExecutionPreview,
  mapSearchCandidatesToTaskCandidates,
  seedCandidateLeadsFromTask,
  updateSavedLeadTaskStatus,
  type LeadTaskCandidate,
  type SavedLeadTask,
} from '@/lib/lead-wizard';
import type { LeadSearchResult } from '@/lib/integrations/lead-search-provider';
import {
  ArrowLeft,
  CheckCircle2,
  Clock3,
  Database,
  Download,
  ExternalLink,
  Loader2,
  PlayCircle,
  Search,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

const statusMeta = {
  draft: { label: '草稿', className: 'bg-slate-500/15 text-slate-300 border-slate-500/25' },
  pending: { label: '待执行', className: 'bg-amber-500/15 text-amber-300 border-amber-500/25' },
  running: { label: '执行中', className: 'bg-blue-500/15 text-blue-300 border-blue-500/25' },
  completed: { label: '已完成', className: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25' },
};

const providerName: Record<string, string> = {
  serpapi: 'SerpAPI',
  bing: 'Bing',
  google: 'Google',
  mock: '演示降级',
  auto: '自动选择',
};

const stepIconMap = {
  keywords: Sparkles,
  search: Search,
  parse: ExternalLink,
  verify: ShieldCheck,
  deposit: Database,
};

export default function LeadTaskRunnerPage() {
  const params = useParams<{ id: string }>();
  const [task, setTask] = useState<SavedLeadTask | null>(null);
  const [seededMessage, setSeededMessage] = useState('');
  const [realSearch, setRealSearch] = useState<LeadSearchResult | null>(null);
  const [realCandidates, setRealCandidates] = useState<LeadTaskCandidate[]>([]);
  const [searching, setSearching] = useState(false);
  const [searchError, setSearchError] = useState('');

  useEffect(() => {
    setTask(findSavedLeadTask(params.id));
  }, [params.id]);

  const preview = useMemo(() => (task ? generateLeadTaskExecutionPreview(task) : null), [task]);
  const activeCandidates = realCandidates.length > 0 ? realCandidates : preview?.candidates || [];

  const markRunning = () => {
    if (!task) return;
    const tasks = updateSavedLeadTaskStatus(task.id, 'running');
    setTask(tasks.find((item) => item.id === task.id) ?? task);
  };

  const markCompleted = () => {
    if (!task) return;
    const tasks = updateSavedLeadTaskStatus(task.id, 'completed');
    setTask(tasks.find((item) => item.id === task.id) ?? task);
  };

  const runRealSearch = async () => {
    if (!task) return;
    setSearching(true);
    setSearchError('');
    setSeededMessage('');
    markRunning();
    try {
      const response = await fetch('/api/integrations/lead-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          product: task.input.product,
          country: task.input.country,
          customerType: task.input.customerType,
          quantity: task.input.quantity,
          provider: 'auto',
        }),
      });
      const payload = await response.json();
      if (!response.ok || !payload.success) {
        throw new Error(payload.error || '真实搜索运行失败。');
      }
      const data = payload.data as LeadSearchResult;
      const mapped = mapSearchCandidatesToTaskCandidates(task.id, data.candidates);
      setRealSearch(data);
      setRealCandidates(mapped);
      const tasks = updateSavedLeadTaskStatus(task.id, 'completed');
      setTask(tasks.find((item) => item.id === task.id) ?? task);
    } catch (error) {
      setSearchError(error instanceof Error ? error.message : '真实搜索运行失败。');
    } finally {
      setSearching(false);
    }
  };

  const seedCandidates = () => {
    if (!task) return;
    seedCandidateLeadsFromTask(task, activeCandidates);
    setSeededMessage(`已沉淀 ${activeCandidates.length} 个候选客户到候选池`);
  };

  if (!task || !preview) {
    return (
      <MainLayout title="任务执行台">
        <div className="rounded-lg border border-dashed border-[#2d3548] bg-[#121823] p-10 text-center">
          <Clock3 className="mx-auto h-10 w-10 text-[#64748b]" />
          <h2 className="mt-4 text-xl font-semibold text-[#f8fafc]">没有找到这条本地任务</h2>
          <p className="mt-2 text-sm text-[#94a3b8]">任务记录保存在当前浏览器本地。请先从获客向导保存任务，再进入执行台。</p>
          <div className="mt-6 flex justify-center gap-3">
            <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
              <Link href="/lead-tasks">返回任务记录</Link>
            </Button>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/lead-wizard">新建任务</Link>
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  const status = statusMeta[task.status];

  return (
    <MainLayout title="任务执行台">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.37.0</Badge>
            <Badge className={`border ${status.className}`}>{status.label}</Badge>
            {realSearch ? (
              <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">
                搜索源：{providerName[realSearch.provider] || realSearch.provider}
              </Badge>
            ) : null}
          </div>
          <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">{task.title}</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                这里可以运行真实搜索源。系统会自动尝试 SerpAPI、Bing、Google；如果未配置或失败，会降级为演示候选客户，任务不会中断。
              </p>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap xl:justify-end">
              <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                <Link href="/lead-tasks">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  返回记录
                </Link>
              </Button>
              <Button type="button" className="bg-blue-600 text-white hover:bg-blue-500" onClick={runRealSearch} disabled={searching}>
                {searching ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                运行真实搜索
              </Button>
              <Button type="button" variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]" onClick={markRunning}>
                <PlayCircle className="mr-2 h-4 w-4" />
                标记执行中
              </Button>
              <Button type="button" className="bg-emerald-600 text-white hover:bg-emerald-500" onClick={markCompleted}>
                <CheckCircle2 className="mr-2 h-4 w-4" />
                标记完成
              </Button>
              <Button type="button" variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]" onClick={() => downloadLeadTaskText(task)}>
                <Download className="mr-2 h-4 w-4" />
                导出
              </Button>
              <Button type="button" className="bg-violet-600 text-white hover:bg-violet-500" onClick={seedCandidates} disabled={activeCandidates.length === 0}>
                <Database className="mr-2 h-4 w-4" />
                沉淀到候选池
              </Button>
            </div>
          </div>
          {searchError ? (
            <div className="mt-4 rounded-lg border border-red-500/25 bg-red-500/10 p-3 text-sm text-red-200">{searchError}</div>
          ) : null}
          {seededMessage ? (
            <div className="mt-4 rounded-lg border border-emerald-500/25 bg-emerald-500/10 p-3 text-sm text-emerald-200">
              {seededMessage}
              <Link href="/candidate-leads" className="ml-2 text-emerald-100 underline underline-offset-4">
                查看候选客户池
              </Link>
            </div>
          ) : null}
        </section>

        <section className="grid gap-4 lg:grid-cols-4">
          <Card className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">目标国家</p><p className="mt-2 text-xl font-semibold text-[#f8fafc]">{task.input.country}</p></CardContent></Card>
          <Card className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">目标数量</p><p className="mt-2 text-xl font-semibold text-[#f8fafc]">{task.input.quantity} 个</p></CardContent></Card>
          <Card className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">候选客户</p><p className="mt-2 text-xl font-semibold text-[#f8fafc]">{activeCandidates.length} 个</p></CardContent></Card>
          <Card className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">当前来源</p><p className="mt-2 text-xl font-semibold text-[#f8fafc]">{realSearch ? providerName[realSearch.provider] || realSearch.provider : '本地预览'}</p></CardContent></Card>
        </section>

        {realSearch ? (
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader><CardTitle className="text-[#f8fafc]">真实搜索结果摘要</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm text-[#94a3b8]">搜索词：<span className="text-blue-300">{realSearch.query}</span></p>
              {realSearch.warnings.length ? realSearch.warnings.map((warning) => (
                <div key={warning} className="rounded-lg border border-amber-500/25 bg-amber-500/10 p-3 text-sm text-amber-200">{warning}</div>
              )) : (
                <div className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 p-3 text-sm text-emerald-200">真实搜索运行完成，未返回警告。</div>
              )}
            </CardContent>
          </Card>
        ) : null}

        <section className="grid gap-4 xl:grid-cols-[1fr_420px]">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader><CardTitle className="text-[#f8fafc]">执行步骤</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {preview.steps.map((step) => {
                const Icon = stepIconMap[step.id as keyof typeof stepIconMap] ?? Clock3;
                const done = realSearch || step.status === 'completed';
                const tone = done ? 'border-emerald-500/25 bg-emerald-500/10 text-emerald-300' : step.status === 'running' ? 'border-blue-500/25 bg-blue-500/10 text-blue-300' : 'border-slate-500/25 bg-slate-500/10 text-slate-300';
                return (
                  <div key={step.id} className="flex gap-4 rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                    <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border ${tone}`}><Icon className="h-5 w-5" /></div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-medium text-[#f8fafc]">{step.title}</h3>
                        <Badge className={`border ${tone}`}>{done ? '已完成' : step.status === 'running' ? '运行中' : '等待中'}</Badge>
                      </div>
                      <p className="mt-2 text-sm leading-6 text-[#94a3b8]">{step.detail}</p>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader><CardTitle className="text-[#f8fafc]">运行日志</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {(realSearch ? [
                { time: '00:00', level: 'info', message: `任务启动：${task.title}` },
                { time: '00:03', level: 'success', message: `搜索源：${providerName[realSearch.provider] || realSearch.provider}` },
                { time: '00:08', level: 'success', message: `生成 ${activeCandidates.length} 个候选客户，可沉淀到候选池。` },
              ] : preview.logs).map((log) => {
                const tone = log.level === 'success' ? 'text-emerald-300' : log.level === 'warning' ? 'text-amber-300' : 'text-blue-300';
                return (
                  <div key={`${log.time}-${log.message}`} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                    <div className="flex items-center justify-between gap-3"><span className="text-xs text-[#64748b]">{log.time}</span><span className={`text-xs ${tone}`}>{log.level.toUpperCase()}</span></div>
                    <p className="mt-2 text-sm leading-6 text-[#cbd5e1]">{log.message}</p>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader><CardTitle className="text-[#f8fafc]">候选客户结果预览</CardTitle></CardHeader>
          <CardContent className="grid gap-4 lg:grid-cols-2">
            {activeCandidates.map((candidate) => (
              <div key={candidate.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{candidate.priority} 级</Badge>
                      <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">{candidate.score} 分</Badge>
                    </div>
                    <h3 className="mt-3 font-semibold text-[#f8fafc]">{candidate.company}</h3>
                    <p className="mt-1 break-all text-sm text-blue-300">{candidate.website}</p>
                  </div>
                  <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                    <Link href="/candidate-leads">进入候选池</Link>
                  </Button>
                </div>
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  <p className="text-sm text-[#94a3b8]">国家 / 城市：{candidate.country} / {candidate.city}</p>
                  <p className="text-sm text-[#94a3b8]">客户类型：{candidate.customerType}</p>
                  <p className="text-sm text-[#94a3b8]">联系方式：{candidate.contactStatus}</p>
                  <p className="text-sm text-[#94a3b8]">建议：{candidate.recommendation}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
