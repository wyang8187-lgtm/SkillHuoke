# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进、报价、订单、单据、出货、邮件发送和接口配置诊断。

当前版本：`v0.37.0`

## v0.37.0 更新

- 获客任务执行台接入真实搜索 API。
- 在任务详情页新增“运行真实搜索”按钮。
- 运行后显示实际搜索源：SerpAPI、Bing、Google 或演示降级。
- 显示搜索 warning，例如某个搜索源失败后自动降级。
- 真实搜索结果会转换成候选客户预览，并可一键沉淀到候选客户池。
- 修复任务执行台主要中文文案，页面更适合演示和交付。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

进入后点击“演示模式进入工作台”。

## 真实获客搜索流程

1. 打开 `http://127.0.0.1:5000/settings/api-keys`，优先配置 SerpAPI、Bing 或 Google。
2. 打开 `/lead-wizard` 创建获客任务。
3. 进入 `/lead-tasks`，打开某个任务详情。
4. 点击“运行真实搜索”。
5. 查看搜索源、搜索词、warning 和候选客户预览。
6. 点击“沉淀到候选池”，再到 `/candidate-leads` 继续核验和转 CRM。

未配置真实搜索源时，系统会自动降级为演示候选客户，保证流程不断。

## 主要页面

- 登录页：`/login`
- 版本体验中心：`/release`
- 接口配置向导：`/settings/api-keys`
- 获客任务向导：`/lead-wizard`
- 获客任务记录：`/lead-tasks`
- 候选客户池：`/candidate-leads`
- CRM 客户池：`/crm-customers`

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 开源协议

MIT
