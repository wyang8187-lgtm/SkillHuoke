import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.37.0',
  title: '获客任务执行台接入真实搜索',
  date: '2026-06-30',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.37.0-OpenSource.zip',
  githubRemark: 'v0.37.0：获客任务执行台接入真实搜索结果，支持一键沉淀到候选客户池',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '获客任务执行台新增“运行真实搜索”按钮，可直接调用后端真实搜索 API。',
  '页面会显示实际使用的搜索源：SerpAPI、Bing、Google 或演示降级。',
  '搜索 warning 会在任务页面展示，方便判断是否需要检查接口配置或网络。',
  '真实搜索结果会转换成候选客户预览，并可一键沉淀到候选客户池。',
];

export const releaseReviewPages = [
  {
    title: '获客任务记录',
    href: '/lead-tasks',
    description: '打开任意任务详情，点击“运行真实搜索”，查看候选客户预览。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '先创建一个获客任务，再进入任务执行台运行真实搜索。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '查看从任务执行台沉淀过来的候选客户，并继续核验或转 CRM。',
  },
  {
    title: '接口配置向导',
    href: '/settings/api-keys',
    description: '配置 SerpAPI、Bing 或 Google，检查真实搜索源连接状态。',
  },
  {
    title: '获客搜索 API',
    href: '/api/integrations/lead-search',
    description: '后端接口支持真实搜索源自动选择和降级。',
  },
  {
    title: '版本体验中心',
    href: '/release',
    description: '查看本次版本更新、上传包名称、GitHub 备注和重点检查页面。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '点击“演示模式进入工作台”即可查看当前版本。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看 CRM 客户、跟进时间线和英文开发动作。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看批量获客任务、候选客户核验和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '进入获客任务向导，保存一个任务。',
  '打开获客任务记录，进入任务执行台。',
  '点击“运行真实搜索”，确认页面显示搜索源、搜索词、warning 和候选客户。',
  '点击“沉淀到候选池”，再打开候选客户池查看结果。',
];
