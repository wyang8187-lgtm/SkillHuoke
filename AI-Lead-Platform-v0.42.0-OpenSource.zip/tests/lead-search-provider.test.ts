import assert from 'node:assert/strict';
import { buildSearchQueries, searchLeadCandidates } from '../src/lib/integrations/lead-search-provider';

const input = {
  product: 'custom cabinets',
  country: 'Australia',
  customerType: 'Builder + Kitchen Company',
  quantity: 3,
};

function serpResult(index: number, query: string) {
  return {
    title: `Australia Cabinet Company ${index} Contact`,
    link: `https://cabinet-company-${index}.example.com/contact`,
    snippet: `${query} custom cabinetry projects. Contact by phone and email.`,
  };
}

async function main() {
  const queries = buildSearchQueries({ ...input, query: 'manual query' });
  assert.equal(queries[0], 'manual query');
  assert.ok(queries.some((query) => query.includes('official website')));
  assert.ok(queries.some((query) => query.includes('WhatsApp')));

  const bulkQueries = buildSearchQueries({
    product: 'custom cabinets, wardrobes, wood doors',
    country: 'Australia',
    customerType: 'Builder + Designer + Kitchen Company + Importer',
    quantity: 50,
  });
  assert.ok(bulkQueries.length > queries.length);
  assert.ok(bulkQueries.some((query) => query.includes('Sydney')));
  assert.ok(bulkQueries.some((query) => query.includes('Designer')));

  const calls: string[] = [];
  const serpapi = await searchLeadCandidates(input, {
    env: { SERPAPI_KEY: 'serp-secret' },
    enrichContacts: false,
    fetcher: async (url) => {
      calls.push(String(url));
      if (calls.length === 1) {
        return new Response(JSON.stringify({
          organic_results: [
            {
              title: 'Kitchen Installer Jobs Australia',
              link: 'https://jobs.example.com/kitchen-installer',
              snippet: 'Hiring kitchen installers and cabinet makers.',
            },
          ],
        }), { status: 200 });
      }
      return new Response(JSON.stringify({
        organic_results: [
          {
            title: 'Sydney Custom Kitchens Contact',
            link: 'https://sydneycustomkitchens.example.com/contact',
            snippet: 'Kitchen company in Sydney. Contact our showroom by phone and email for custom cabinetry projects.',
          },
          {
            title: 'Houzz Sydney Custom Kitchens',
            link: 'https://www.houzz.com.au/pro/sydneycustomkitchens',
            snippet: 'Custom cabinetry and kitchen renovation profile.',
          },
        ],
      }), { status: 200 });
    },
  });
  assert.equal(serpapi.provider, 'serpapi');
  assert.ok(calls.length > 1);
  assert.ok(serpapi.attempts && serpapi.attempts.length > 1);
  assert.equal(serpapi.candidates[0].priority, 'A');
  assert.equal(serpapi.candidates[0].emailStatus, 'found');
  assert.ok(serpapi.batchSummary);
  assert.equal(serpapi.batchSummary?.targetQuantity, 3);

  const bulk = await searchLeadCandidates({
    product: 'custom cabinets, wardrobes, wood doors',
    country: 'Australia',
    customerType: 'Builder + Designer + Kitchen Company + Importer',
    quantity: 50,
  }, {
    env: { SERPAPI_KEY: 'serp-secret' },
    enrichContacts: false,
    fetcher: async (url) => {
      const q = new URL(String(url)).searchParams.get('q') || '';
      const seed = Math.abs(q.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0));
      const start = seed % 1000;
      return new Response(JSON.stringify({
        organic_results: Array.from({ length: 10 }, (_, index) => serpResult(start + index, q)),
      }), { status: 200 });
    },
    timeoutMs: 1000,
  });
  assert.equal(bulk.candidates.length, 50);
  assert.equal(bulk.batchSummary?.targetQuantity, 50);
  assert.equal(bulk.batchSummary?.reachedTarget, true);
  assert.ok((bulk.attempts?.length || 0) >= 5);

  const timeoutFallback = await searchLeadCandidates(input, {
    env: { SERPAPI_KEY: 'slow', BING_SEARCH_API_KEY: 'bing-secret' },
    enrichContacts: false,
    timeoutMs: 5,
    fetcher: async (url) => {
      if (String(url).includes('serpapi.com')) {
        await new Promise((resolve) => setTimeout(resolve, 20));
        return new Response('{}', { status: 200 });
      }
      return new Response(JSON.stringify({
        webPages: {
          value: [
            {
              name: 'Melbourne Joinery Group About',
              url: 'https://melbournejoinery.example.com/about',
              snippet: 'Builder supplier and joinery company for residential custom cabinet projects. Phone and email available.',
            },
          ],
        },
      }), { status: 200 });
    },
  });
  assert.ok(timeoutFallback.attempts?.some((attempt) => attempt.status === 'failed'));
  assert.ok(timeoutFallback.candidates.length > 0);
  assert.match(timeoutFallback.warnings.join('\n'), /请求失败/);

  const unconfigured = await searchLeadCandidates(input, {
    env: {},
    fetcher: async () => {
      throw new Error('fetch should not run');
    },
  });
  assert.equal(unconfigured.provider, 'auto');
  assert.match(unconfigured.warnings.join('\n'), /未配置可用的真实搜索源/);
  assert.equal(unconfigured.candidates.length, 0);

  const enriched = await searchLeadCandidates({ ...input, quantity: 1 }, {
    env: { SERPAPI_KEY: 'serp-secret' },
    fetcher: async (url) => {
      const value = String(url);
      if (value.includes('serpapi.com')) {
        return new Response(JSON.stringify({
          organic_results: [{
            title: 'Acme Kitchens Contact',
            link: 'https://acmekitchens.com.au/contact',
            snippet: 'Australian kitchen company official website and showroom.',
          }],
        }), { status: 200 });
      }
      if (value === 'https://acmekitchens.com.au/') {
        return new Response(`
          <a href="/contact">Contact</a>
          <a href="mailto:sales@acmekitchens.com.au">Email</a>
        `, { status: 200, headers: { 'content-type': 'text/html' } });
      }
      return new Response(`
        <a href="tel:+61 2 9000 0000">Phone</a>
        <a href="https://wa.me/61400123456">WhatsApp</a>
        <a href="https://linkedin.com/company/acme-kitchens">LinkedIn</a>
      `, { status: 200, headers: { 'content-type': 'text/html' } });
    },
  });
  assert.equal(enriched.candidates[0]?.email, 'sales@acmekitchens.com.au');
  assert.equal(enriched.candidates[0]?.phone, '+61290000000');
  assert.equal(enriched.candidates[0]?.whatsapp, '+61400123456');
  assert.equal(enriched.batchSummary?.emailCount, 1);
  assert.equal(enriched.batchSummary?.enrichedCount, 1);

  console.log('lead-search-provider tests passed');
}

main();
