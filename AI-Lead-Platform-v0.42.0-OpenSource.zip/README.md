# AI 智能获客平台

面向外贸企业的开源 SaaS 原型。当前阶段的重点是把“真实获客”做深：搜索、筛选、真实性判断、联系方式补全和 CRM 转化。

当前版本：`v0.42.0`

## v0.42.0 更新

- 真实获客改为“发现公司 + 官网联系方式补全”两阶段流程。
- 自动解析公开官网首页、Contact、About、Team 页面。
- 保存公开邮箱、电话、WhatsApp、LinkedIn、来源页面和联系方式可信度。
- 搜索源失败时继续使用其他已配置来源，并保留此前找到的真实公司。
- 未配置真实搜索源或没有结果时不再自动生成演示客户补数。
- 批量摘要会显示目标缺口、官网补全数量和各类联系方式数量。
- 精简 AI 获客中心入口，关闭暂时不进入主流程的模拟渠道窗口。
- 暂时关闭行业资源库、品牌商标库、TikTok、Facebook、LinkedIn、地图获客、关键词建议、决策人深挖和客户动态入口。
- 暂时关闭客户分析、销售分析和 CRM 分析入口，保留获客效率。
- 被关闭的页面代码仍然保留，后续需要开发时可以重新打开。
- 新增批量获客搜索引擎能力，目标数量上限从 20 提升到 50。
- 高数量任务会自动生成更多关键词，覆盖产品、客户类型、国家、城市、官网、Contact、LinkedIn、WhatsApp 等方向。
- 搜索请求增加超时保护，单个搜索源或关键词卡住时不会拖垮整次任务。
- 搜索过程会保留部分结果：即使没有达到 50 个，也会返回已找到的可核验客户。
- 新增批量摘要：目标数量、关键词数量、搜索源数量、尝试次数、读取结果数、可用结果数、去重数量和最终保留数量。
- 继续保留 v0.40.0 的噪音过滤、来源分类和多搜索源自动降级策略。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

进入后点击“演示模式进入工作台”。

## 当前主流程

1. 打开 `/dashboard`，配置 OpenAI / DeepSeek / SerpAPI / Google 等接口。
2. 打开 `/lead-wizard`，输入产品、国家、客户类型和目标数量。
3. 打开 `/lead-tasks`，运行真实搜索任务。
4. 系统按多组关键词批量搜索、过滤、去重并沉淀候选客户。
5. 打开 `/candidate-leads`，查看候选客户、真实性评分、联系方式状态和下一步动作。
6. 把合适客户加入 `/crm-customers` 做转化跟进。

## 主要页面

- 登录页：`/login`
- 工作台首页：`/dashboard`
- API 设置页：`/settings/api-keys`
- 获客任务向导：`/lead-wizard`
- 获客任务记录：`/lead-tasks`
- 候选客户池：`/candidate-leads`
- CRM 客户池：`/crm-customers`
- 版本体验中心：`/release`

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 开源协议

MIT
