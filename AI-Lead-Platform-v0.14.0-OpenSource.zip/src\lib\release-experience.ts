import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.14.0',
  title: '版本体验中心 + 演示账号说明',
  date: '2026-06-26',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.14.0-OpenSource.zip',
  githubRemark: 'v0.14.0：新增版本体验中心、登录说明和演示角色查看入口',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '新增版本体验中心，集中展示当前版本、登录方式、重点检查页面和上传包说明。',
  '登录页增加老板、管理员、销售、运营四种演示身份说明。',
  '侧边栏新增“版本体验”入口，方便部署后直接查看本次效果。',
  'README 增加 v0.14.0 更新说明，方便开源项目访问者理解版本变化。',
];

export const releaseReviewPages = [
  {
    title: '版本体验中心',
    href: '/release',
    description: '先看这里，确认当前版本、登录方式、演示身份、上传包和 GitHub 备注。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '查看演示模式入口和四种角色说明。',
  },
  {
    title: '团队管理',
    href: '/team',
    description: '检查 v0.13.0 新增的成员、角色和工作量展示。',
  },
  {
    title: '权限矩阵',
    href: '/team/permissions',
    description: '检查老板、管理员、销售、运营的权限差异。',
  },
  {
    title: '团队设置',
    href: '/settings/team',
    description: '检查 SaaS 团队设置入口和后续接入清单。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '看自己负责的客户、CRM 跟进和开发信流程。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '看批量获客任务、线索核验、模板和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '进入版本体验中心，按页面列出的入口逐个查看。',
  '确认本次版本功能、GitHub 备注和上传包名称。',
  '上传压缩包到开源仓库，并使用版本备注作为提交说明。',
];
