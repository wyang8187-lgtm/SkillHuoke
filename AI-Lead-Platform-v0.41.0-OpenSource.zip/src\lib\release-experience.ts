import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.41.0',
  title: '批量获客搜索引擎',
  date: '2026-06-30',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.41.0-OpenSource.zip',
  githubRemark: 'v0.41.0：升级批量获客搜索引擎，支持 50 个目标、多关键词扩展、超时保护和部分结果保留',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '批量获客目标数量上限从 20 提升到 50。',
  '高数量任务会自动扩展产品、客户类型、国家、城市、官网、Contact、LinkedIn、WhatsApp 等多组关键词。',
  '搜索请求增加超时保护，单个关键词或搜索源卡住时不会拖垮整次任务。',
  '没有达到目标数量时，系统会保留已找到的可核验客户，而不是整次失败。',
  '新增批量摘要：目标数量、关键词数量、搜索源数量、尝试次数、读取结果数、可用结果数、去重数量和最终保留数量。',
  '继续保留搜索噪音过滤、来源分类、官网域名去重和多搜索源自动降级策略。',
  '当前阶段继续聚焦真实获客和转化，不扩展报价、出货、海关等旁支流程。',
];

export const releaseReviewPages = [
  {
    title: '获客任务记录',
    href: '/lead-tasks',
    description: '运行真实搜索任务，观察批量关键词尝试、搜索源降级和候选客户沉淀。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和目标数量，创建批量获客任务。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '查看批量搜索沉淀的候选客户、真实性评分、联系方式状态和下一步动作。',
  },
  {
    title: 'API 设置页',
    href: '/settings/api-keys',
    description: '确认 OpenAI、DeepSeek、SerpAPI、Google 或 Bing 是否已配置。',
  },
  {
    title: '工作台首页',
    href: '/dashboard',
    description: '查看 API 快速接入入口和当前获客工作台。',
  },
  {
    title: '版本体验中心',
    href: '/release',
    description: '查看本次版本更新、上传包名称、GitHub 备注和重点检查页面。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '点击“演示模式进入工作台”即可查看当前版本。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看 CRM 客户、跟进时间线和英文开发动作。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看批量获客任务、候选客户核验和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '确认 API 设置页里至少配置一个真实搜索源，优先 SerpAPI。',
  '创建一个目标数量为 30-50 的获客任务。',
  '进入获客任务记录，运行真实搜索。',
  '查看搜索警告和批量摘要，确认系统没有因为单个失败就丢弃全部结果。',
  '进入候选客户池，查看沉淀客户并筛选 A/B/C 级客户。',
];
