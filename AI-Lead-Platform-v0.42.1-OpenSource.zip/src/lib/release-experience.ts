import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.42.1',
  title: '真实搜索失败诊断',
  date: '2026-07-01',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.42.1-OpenSource.zip',
  githubRemark: 'v0.42.1：新增真实搜索失败诊断，显示各搜索源错误原因和处理建议，认证或额度错误后立即停止重复请求。',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '任务执行台新增搜索源诊断，分别显示 SerpAPI、Google 和 Bing 的成功、失败及结果数量。',
  '常见错误会翻译为中文：密钥无效、权限不足、额度不足、连接超时、网络失败或服务异常。',
  '认证、权限或额度错误发生后立即停止该搜索源的重复请求，继续尝试其他来源。',
  '真实结果为零时显示“执行失败”，部分结果显示“部分完成”，达到目标显示“执行完成”。',
  '诊断卡片提供处理建议和 API 设置入口，不会显示完整密钥或原始敏感响应。',
  '真实搜索采用“发现公司 + 官网补全”两阶段流程，先扩大公司数量，再补全公开联系方式。',
  '自动解析官网首页、Contact、About 和 Team 页面，提取邮箱、电话、WhatsApp 与 LinkedIn。',
  '联系方式保存公开来源和可信度，未找到时不会生成或猜测不存在的数据。',
  '未配置搜索源或真实搜索无结果时不再使用演示客户补数，并明确显示数量缺口原因。',
  '批量摘要新增官网补全、邮箱、电话、WhatsApp、LinkedIn 和补全失败数量。',
  '关闭 AI 获客中心里暂时不进入主流程的入口：行业资源库、品牌商标库、TikTok、Facebook、LinkedIn、地图获客、关键词建议、决策人深挖和客户动态。',
  '关闭客户分析、销售分析和 CRM 分析入口，保留“获客效率”作为当前阶段最有用的分析入口。',
  '多渠道获客展示先隐藏，避免用户误以为这些模拟渠道已经能真实抓取。',
  '所有被关闭的页面代码都保留，后续需要开发时可以重新打开入口。',
  '批量获客目标数量上限从 20 提升到 50。',
  '高数量任务会自动扩展产品、客户类型、国家、城市、官网、Contact、LinkedIn、WhatsApp 等多组关键词。',
  '搜索请求增加超时保护，单个关键词或搜索源卡住时不会拖垮整次任务。',
  '没有达到目标数量时，系统会保留已找到的可核验客户，而不是整次失败。',
  '新增批量摘要：目标数量、关键词数量、搜索源数量、尝试次数、读取结果数、可用结果数、去重数量和最终保留数量。',
  '继续保留搜索噪音过滤、来源分类、官网域名去重和多搜索源自动降级策略。',
  '当前阶段继续聚焦真实获客和转化，不扩展报价、出货、海关等旁支流程。',
];

export const releaseReviewPages = [
  {
    title: '获客任务记录',
    href: '/lead-tasks',
    description: '运行真实搜索任务，观察批量关键词尝试、搜索源降级和候选客户沉淀。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和目标数量，创建批量获客任务。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '查看批量搜索沉淀的候选客户、真实性评分、联系方式状态和下一步动作。',
  },
  {
    title: 'API 设置页',
    href: '/settings/api-keys',
    description: '确认 OpenAI、DeepSeek、SerpAPI、Google 或 Bing 是否已配置。',
  },
  {
    title: '工作台首页',
    href: '/dashboard',
    description: '查看 API 快速接入入口和当前获客工作台。',
  },
  {
    title: '版本体验中心',
    href: '/release',
    description: '查看本次版本更新、上传包名称、GitHub 备注和重点检查页面。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '点击“演示模式进入工作台”即可查看当前版本。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看 CRM 客户、跟进时间线和英文开发动作。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看批量获客任务、候选客户核验和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '确认 API 设置页里至少配置一个真实搜索源，优先 SerpAPI。',
  '创建一个目标数量为 30-50 的获客任务。',
  '进入获客任务记录，运行真实搜索。',
  '查看搜索警告和批量摘要，确认系统没有因为单个失败就丢弃全部结果。',
  '进入候选客户池，查看沉淀客户并筛选 A/B/C 级客户。',
];
