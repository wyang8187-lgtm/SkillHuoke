import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.36.0',
  title: '真实获客搜索源接入',
  date: '2026-06-30',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.36.0-OpenSource.zip',
  githubRemark: 'v0.36.0：获客搜索接入真实搜索源，支持 SerpAPI/Bing/Google 自动降级与候选客户沉淀',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '获客搜索后端从纯演示数据升级为真实搜索源优先。',
  '自动选择顺序为 SerpAPI、Bing、Google，失败时继续尝试下一个搜索源。',
  '真实搜索结果会转成候选客户格式，包含官网、来源链接、评分、优先级和下一步建议。',
  '当真实搜索源未配置或全部失败时，系统会用中文原因提示并降级到演示候选客户。',
];

export const releaseReviewPages = [
  {
    title: '接口配置向导',
    href: '/settings/api-keys',
    description: '先确认 SerpAPI、Bing 或 Google 至少配置一个真实搜索源。',
  },
  {
    title: '获客搜索 API',
    href: '/api/integrations/lead-search',
    description: '后端接口已支持真实搜索源自动选择和降级。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和数量，生成获客任务。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '管理任务沉淀的候选客户，并把适合开发的客户加入 CRM。',
  },
  {
    title: 'CRM 客户池',
    href: '/crm-customers',
    description: '查看客户阶段、评分、优先级、联系方式和下一步动作。',
  },
  {
    title: '版本体验中心',
    href: '/release',
    description: '查看本次版本更新、上传包名称、GitHub 备注和重点检查页面。',
  },
  {
    title: '数据备份',
    href: '/data-backup',
    description: '导出或恢复本地 CRM、报价、订单、单据、出货和邮件记录。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '点击“演示模式进入工作台”即可查看当前版本。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看 CRM 客户、跟进时间线和英文开发动作。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看批量获客任务、候选客户核验和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '进入接口配置向导，确认至少配置 SerpAPI、Bing 或 Google 其中一个。',
  '调用获客搜索 API，确认真实搜索源优先，失败时会自动降级。',
  '检查候选客户结果包含官网、来源链接、评分、优先级和中文建议。',
  '确认版本体验中心显示 v0.36.0、上传包名称和 GitHub 备注。',
];
