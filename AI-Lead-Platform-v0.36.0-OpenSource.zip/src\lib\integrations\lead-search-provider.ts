export type LeadSearchProvider = 'auto' | 'mock' | 'google' | 'serpapi' | 'bing';

export interface LeadSearchInput {
  product: string;
  country: string;
  customerType: string;
  quantity?: number;
  provider?: LeadSearchProvider;
  query?: string;
}

export interface LeadSearchCandidate {
  companyName: string;
  website?: string;
  country: string;
  city?: string;
  customerType: string;
  sourceUrl?: string;
  emailStatus: 'found' | 'not_found' | 'needs_verification';
  phoneStatus: 'found' | 'not_found' | 'needs_verification';
  whatsappStatus: 'found' | 'not_found' | 'needs_verification';
  linkedinStatus: 'found' | 'not_found' | 'needs_verification';
  matchScore: number;
  priority: 'A' | 'B' | 'C' | 'D';
  confidence: number;
  riskSignals: string[];
  nextAction: string;
}

export interface LeadSearchResult {
  provider: LeadSearchProvider;
  query: string;
  candidates: LeadSearchCandidate[];
  warnings: string[];
}

interface SearchProviderOptions {
  env?: NodeJS.ProcessEnv | Record<string, string | undefined>;
  fetcher?: typeof fetch;
}

interface RawSearchResult {
  title: string;
  url: string;
  snippet: string;
  provider: Exclude<LeadSearchProvider, 'auto' | 'mock'>;
}

function envValue(env: NodeJS.ProcessEnv | Record<string, string | undefined>, key: string) {
  return env[key]?.trim() || '';
}

function buildDefaultQuery(input: LeadSearchInput) {
  return [
    input.country,
    input.product,
    input.customerType,
    'company website contact email LinkedIn WhatsApp',
  ]
    .filter(Boolean)
    .join(' ');
}

function configuredProviders(env: NodeJS.ProcessEnv | Record<string, string | undefined>) {
  return {
    serpapi: Boolean(envValue(env, 'SERPAPI_KEY') || envValue(env, 'SERPAPI_API_KEY')),
    bing: Boolean(envValue(env, 'BING_SEARCH_API_KEY')),
    google: Boolean(envValue(env, 'GOOGLE_SEARCH_API_KEY') && envValue(env, 'GOOGLE_SEARCH_CX')),
  };
}

function providerOrder(provider: LeadSearchProvider, env: NodeJS.ProcessEnv | Record<string, string | undefined>) {
  const configured = configuredProviders(env);
  if (provider === 'mock') return [];
  if (provider !== 'auto') return configured[provider] ? [provider] : [];
  return (['serpapi', 'bing', 'google'] as const).filter((item) => configured[item]);
}

function splitCustomerTypes(customerType: string) {
  return customerType
    .split(/[,+，、/]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function createMockCandidates(input: LeadSearchInput, query: string): LeadSearchCandidate[] {
  const quantity = Math.min(Math.max(input.quantity || 5, 1), 20);
  const customerTypes = splitCustomerTypes(input.customerType);

  return Array.from({ length: quantity }, (_, index) => {
    const type = customerTypes[index % Math.max(customerTypes.length, 1)] || input.customerType;
    const score = Math.max(62, 92 - index * 3);
    return {
      companyName: `${input.country} ${type} Lead ${index + 1}`,
      website: `https://example-${index + 1}.com`,
      country: input.country,
      city: input.country.toLowerCase().includes('australia') || input.country.includes('澳') ? 'Sydney' : undefined,
      customerType: type,
      sourceUrl: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      emailStatus: 'needs_verification',
      phoneStatus: 'needs_verification',
      whatsappStatus: 'needs_verification',
      linkedinStatus: 'needs_verification',
      matchScore: score,
      priority: score >= 85 ? 'A' : score >= 75 ? 'B' : 'C',
      confidence: score - 8,
      riskSignals: ['mock_data', 'needs_public_source_verification'],
      nextAction: '先核验官网、LinkedIn、邮箱和电话，再加入正式 CRM 跟进。',
    };
  });
}

function isNoiseResult(result: RawSearchResult) {
  const text = `${result.title} ${result.url} ${result.snippet}`.toLowerCase();
  return [
    'jobs',
    'career',
    '招聘',
    'pdf',
    'facebook.com',
    'instagram.com',
    'tiktok.com',
    'pinterest.',
    'yellowpages',
    'yelp.',
    'directory',
    'wikipedia',
  ].some((signal) => text.includes(signal));
}

function extractDomain(url: string) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, '');
  } catch {
    return '';
  }
}

function cleanCompanyName(title: string, domain: string) {
  const cleaned = title
    .replace(/\s*[-|–].*$/, '')
    .replace(/\b(Home|Contact|About Us|Official Website)\b/gi, '')
    .trim();
  if (cleaned.length >= 3) return cleaned;
  return domain.split('.')[0]?.replace(/[-_]/g, ' ') || 'Unknown Company';
}

function scoreResult(result: RawSearchResult, input: LeadSearchInput, index: number) {
  const text = `${result.title} ${result.snippet}`.toLowerCase();
  let score = 78 - index * 3;
  const productTokens = input.product.toLowerCase().split(/\s+/).filter((token) => token.length > 3);
  const typeTokens = input.customerType.toLowerCase().split(/\s+|\+/).filter((token) => token.length > 3);
  if (productTokens.some((token) => text.includes(token))) score += 8;
  if (typeTokens.some((token) => text.includes(token))) score += 8;
  if (text.includes('contact') || text.includes('email')) score += 4;
  if (text.includes('linkedin')) score += 3;
  return Math.max(58, Math.min(94, score));
}

function toCandidate(result: RawSearchResult, input: LeadSearchInput, index: number): LeadSearchCandidate {
  const domain = extractDomain(result.url);
  const score = scoreResult(result, input, index);
  const text = `${result.title} ${result.snippet}`.toLowerCase();
  return {
    companyName: cleanCompanyName(result.title, domain),
    website: domain ? `https://${domain}` : result.url,
    country: input.country,
    city: undefined,
    customerType: splitCustomerTypes(input.customerType)[index % Math.max(splitCustomerTypes(input.customerType).length, 1)] || input.customerType,
    sourceUrl: result.url,
    emailStatus: text.includes('email') ? 'found' : 'needs_verification',
    phoneStatus: text.includes('phone') || text.includes('tel') ? 'found' : 'needs_verification',
    whatsappStatus: text.includes('whatsapp') ? 'found' : 'needs_verification',
    linkedinStatus: text.includes('linkedin') ? 'found' : 'needs_verification',
    matchScore: score,
    priority: score >= 85 ? 'A' : score >= 74 ? 'B' : 'C',
    confidence: Math.max(52, score - 7),
    riskSignals: ['needs_public_source_verification'],
    nextAction: score >= 85
      ? '优先核验官网和联系人，可准备第一封英文开发信。'
      : '先补全联系人、邮箱、电话或 LinkedIn，再进入 CRM 跟进。',
  };
}

function dedupeCandidates(candidates: LeadSearchCandidate[]) {
  const seen = new Set<string>();
  const output: LeadSearchCandidate[] = [];
  for (const candidate of candidates) {
    const key = candidate.website || candidate.companyName.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    output.push(candidate);
  }
  return output;
}

async function fetchJson(fetcher: typeof fetch, url: string, init?: RequestInit) {
  const response = await fetcher(url, init);
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 120)}`);
  }
  return text ? JSON.parse(text) : {};
}

async function searchSerpApi(query: string, env: NodeJS.ProcessEnv | Record<string, string | undefined>, fetcher: typeof fetch): Promise<RawSearchResult[]> {
  const url = new URL('https://serpapi.com/search.json');
  url.searchParams.set('api_key', envValue(env, 'SERPAPI_KEY') || envValue(env, 'SERPAPI_API_KEY'));
  url.searchParams.set('engine', 'google');
  url.searchParams.set('q', query);
  url.searchParams.set('num', '10');
  const data = await fetchJson(fetcher, url.toString());
  const items = Array.isArray(data.organic_results) ? data.organic_results : [];
  return items.map((item: Record<string, unknown>) => ({
    provider: 'serpapi',
    title: String(item.title || ''),
    url: String(item.link || ''),
    snippet: String(item.snippet || ''),
  })).filter((item: RawSearchResult) => item.title && item.url);
}

async function searchBing(query: string, env: NodeJS.ProcessEnv | Record<string, string | undefined>, fetcher: typeof fetch): Promise<RawSearchResult[]> {
  const endpoint = envValue(env, 'BING_SEARCH_ENDPOINT') || 'https://api.bing.microsoft.com/v7.0/search';
  const url = new URL(endpoint);
  url.searchParams.set('q', query);
  url.searchParams.set('count', '10');
  const data = await fetchJson(fetcher, url.toString(), {
    headers: { 'Ocp-Apim-Subscription-Key': envValue(env, 'BING_SEARCH_API_KEY') },
  });
  const items = Array.isArray(data.webPages?.value) ? data.webPages.value : [];
  return items.map((item: Record<string, unknown>) => ({
    provider: 'bing',
    title: String(item.name || ''),
    url: String(item.url || ''),
    snippet: String(item.snippet || ''),
  })).filter((item: RawSearchResult) => item.title && item.url);
}

async function searchGoogle(query: string, env: NodeJS.ProcessEnv | Record<string, string | undefined>, fetcher: typeof fetch): Promise<RawSearchResult[]> {
  const url = new URL('https://www.googleapis.com/customsearch/v1');
  url.searchParams.set('key', envValue(env, 'GOOGLE_SEARCH_API_KEY'));
  url.searchParams.set('cx', envValue(env, 'GOOGLE_SEARCH_CX'));
  url.searchParams.set('q', query);
  url.searchParams.set('num', '10');
  const data = await fetchJson(fetcher, url.toString());
  const items = Array.isArray(data.items) ? data.items : [];
  return items.map((item: Record<string, unknown>) => ({
    provider: 'google',
    title: String(item.title || ''),
    url: String(item.link || ''),
    snippet: String(item.snippet || ''),
  })).filter((item: RawSearchResult) => item.title && item.url);
}

async function runProvider(
  provider: Exclude<LeadSearchProvider, 'auto' | 'mock'>,
  query: string,
  env: NodeJS.ProcessEnv | Record<string, string | undefined>,
  fetcher: typeof fetch
) {
  if (provider === 'serpapi') return searchSerpApi(query, env, fetcher);
  if (provider === 'bing') return searchBing(query, env, fetcher);
  return searchGoogle(query, env, fetcher);
}

export async function searchLeadCandidates(
  input: LeadSearchInput,
  options: SearchProviderOptions = {}
): Promise<LeadSearchResult> {
  const env = options.env || process.env;
  const fetcher = options.fetcher || fetch;
  const query = input.query?.trim() || buildDefaultQuery(input);
  const requestedProvider = input.provider || 'auto';
  const warnings: string[] = [];
  const order = providerOrder(requestedProvider, env);

  if (requestedProvider !== 'auto' && requestedProvider !== 'mock' && order.length === 0) {
    warnings.push(`${requestedProvider} 未配置，已降级为演示数据。`);
  }

  if (order.length === 0) {
    warnings.push('未配置真实搜索源，当前使用演示候选客户。请先在接口配置向导中接入 SerpAPI、Bing 或 Google。');
    return {
      provider: 'mock',
      query,
      candidates: createMockCandidates(input, query),
      warnings,
    };
  }

  for (const provider of order) {
    try {
      const rawResults = await runProvider(provider, query, env, fetcher);
      const cleanResults = rawResults.filter((result) => !isNoiseResult(result));
      const candidates = dedupeCandidates(cleanResults.map((result, index) => toCandidate(result, input, index)))
        .filter((candidate) => candidate.priority !== 'D')
        .slice(0, Math.min(Math.max(input.quantity || 10, 1), 20));
      if (candidates.length > 0) {
        if (cleanResults.length < rawResults.length) {
          warnings.push(`已过滤 ${rawResults.length - cleanResults.length} 条目录页、招聘页、PDF 或社媒噪音结果。`);
        }
        return { provider, query, candidates, warnings };
      }
      warnings.push(`${providerLabel(provider)} 没有返回可用公司结果，继续尝试下一个搜索源。`);
    } catch (error) {
      const message = error instanceof Error ? error.message : '未知错误';
      warnings.push(`${providerLabel(provider)} 搜索失败：${message}。已自动尝试下一个搜索源。`);
    }
  }

  warnings.push('真实搜索源都未返回可用结果，已降级为演示候选客户。');
  return {
    provider: 'mock',
    query,
    candidates: createMockCandidates(input, query),
    warnings,
  };
}

function providerLabel(provider: Exclude<LeadSearchProvider, 'auto' | 'mock'>) {
  if (provider === 'serpapi') return 'SerpAPI';
  if (provider === 'bing') return 'Bing';
  return 'Google';
}
