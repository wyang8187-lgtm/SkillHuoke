import assert from 'node:assert/strict';
import { searchLeadCandidates } from '../src/lib/integrations/lead-search-provider';

const input = {
  product: 'custom cabinets',
  country: 'Australia',
  customerType: 'Builder + Kitchen Company',
  quantity: 6,
};

async function main() {
  const calls: string[] = [];
  const serpapi = await searchLeadCandidates(input, {
    env: { SERPAPI_KEY: 'serp-secret' },
    fetcher: async (url) => {
      calls.push(String(url));
      return new Response(JSON.stringify({
        organic_results: [
          {
            title: 'Sydney Custom Kitchens',
            link: 'https://sydneycustomkitchens.example.com',
            snippet: 'Kitchen company in Sydney offering custom cabinetry and renovation projects.',
          },
          {
            title: 'Kitchen Jobs Australia',
            link: 'https://jobs.example.com/kitchen-installer',
            snippet: 'Hiring kitchen installers.',
          },
        ],
      }), { status: 200 });
    },
  });
  assert.equal(serpapi.provider, 'serpapi');
  assert.equal(calls[0].startsWith('https://serpapi.com/search.json'), true);
  assert.equal(serpapi.candidates.length, 1);
  assert.equal(serpapi.candidates[0].priority, 'A');
  assert.equal(serpapi.candidates[0].riskSignals.includes('noise_result'), false);

  const fallbackCalls: string[] = [];
  const fallback = await searchLeadCandidates(input, {
    env: { SERPAPI_KEY: 'bad-serp', BING_SEARCH_API_KEY: 'bing-secret' },
    fetcher: async (url) => {
      fallbackCalls.push(String(url));
      if (String(url).includes('serpapi.com')) {
        return new Response(JSON.stringify({ error: 'quota exhausted' }), { status: 429 });
      }
      return new Response(JSON.stringify({
        webPages: {
          value: [
            {
              name: 'Melbourne Joinery Group',
              url: 'https://melbournejoinery.example.com',
              snippet: 'Builder supplier and joinery company for residential projects.',
            },
          ],
        },
      }), { status: 200 });
    },
  });
  assert.equal(fallback.provider, 'bing');
  assert.equal(fallbackCalls.some((url) => url.includes('serpapi.com')), true);
  assert.equal(fallbackCalls.some((url) => url.includes('bing.microsoft.com')), true);
  assert.match(fallback.warnings.join('\n'), /SerpAPI/);

  const mock = await searchLeadCandidates(input, {
    env: {},
    fetcher: async () => {
      throw new Error('fetch should not run');
    },
  });
  assert.equal(mock.provider, 'mock');
  assert.match(mock.warnings.join('\n'), /未配置真实搜索源/);
  assert.ok(mock.candidates.length > 0);
  assert.ok(mock.candidates.every((candidate) => candidate.priority !== 'D'));

  console.log('lead-search-provider tests passed');
}

main();
