# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进、报价、订单、单据、出货、邮件发送和接口配置诊断。

当前版本：`v0.36.0`

## v0.36.0 更新

- `/api/integrations/lead-search` 接入真实搜索源。
- 自动选择顺序：`SerpAPI > Bing > Google > Mock 演示降级`。
- 搜索失败不会中断任务，会用中文 warning 说明失败原因并继续尝试下一个搜索源。
- 搜索结果会转换成候选客户格式，包含公司名、官网、来源链接、评分、优先级、风险提示和下一步建议。
- 过滤招聘页、目录页、PDF、部分社媒噪音结果，避免低质量结果进入候选池。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

进入后点击“演示模式进入工作台”。

## 接口配置方式

1. 打开 `http://127.0.0.1:5000/settings/api-keys`。
2. 优先配置 `SERPAPI_KEY`，或者配置 `BING_SEARCH_API_KEY` / `GOOGLE_SEARCH_API_KEY + GOOGLE_SEARCH_CX`。
3. 保存 `.env` 后重启后端服务。
4. 回到接口配置向导，点击“刷新配置”和“测试连接”。
5. 调用获客搜索 API 或继续使用获客任务流程。

重要说明：不要把真实 API Key 提交到 GitHub。上传开源包时只保留 `.env.example`，不要上传 `.env` 或 `.env.local`。

## 获客搜索 API

```text
POST /api/integrations/lead-search
```

示例请求：

```json
{
  "product": "custom cabinets",
  "country": "Australia",
  "customerType": "Builder + Kitchen Company",
  "quantity": 10,
  "provider": "auto"
}
```

## 主要页面

- 登录页：`/login`
- 版本体验中心：`/release`
- 接口配置向导：`/settings/api-keys`
- 获客任务向导：`/lead-wizard`
- 候选客户池：`/candidate-leads`
- CRM 客户池：`/crm-customers`
- 邮件中心：`/email-center`

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 开源协议

MIT
