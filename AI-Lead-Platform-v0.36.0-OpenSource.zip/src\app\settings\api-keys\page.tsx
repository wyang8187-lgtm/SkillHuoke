'use client';

import { useEffect, useMemo, useState } from 'react';
import type React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Copy,
  Database,
  KeyRound,
  Loader2,
  Mail,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  WifiOff,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type TestStatus = 'success' | 'failed' | 'unconfigured';

interface ServiceField {
  name: string;
  label: string;
  required: boolean;
  configured: boolean;
  secret: boolean;
  value: string;
}

interface IntegrationStatus {
  id: string;
  name: string;
  category: string;
  description: string;
  docsUrl: string;
  configured: boolean;
  missingEnv: string[];
  fields: ServiceField[];
  setupGuide: string;
  setupSteps: string[];
  envTemplate: string;
  testable: boolean;
  mode: string;
}

interface TestResult {
  serviceId: string;
  status: TestStatus;
  category: string;
  message: string;
  suggestion: string;
  httpStatus?: number;
  latencyMs: number;
  testedAt: string;
}

interface ProxySummary {
  hasProxy: boolean;
  preferredSource: string;
  note: string;
  items: Array<{ name: string; configured: boolean; value: string }>;
}

const STORAGE_KEY = 'skillhuoke_integration_diagnostics_v035';

const categoryIcon: Record<string, React.ReactNode> = {
  'AI 模型': <Sparkles className="h-4 w-4" />,
  搜索服务: <Search className="h-4 w-4" />,
  邮件服务: <Mail className="h-4 w-4" />,
  数据库: <Database className="h-4 w-4" />,
};

const statusStyle: Record<TestStatus, string> = {
  success: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200',
  failed: 'border-red-500/30 bg-red-500/10 text-red-200',
  unconfigured: 'border-amber-500/30 bg-amber-500/10 text-amber-200',
};

function formatTime(value?: string) {
  if (!value) return '尚未测试';
  return new Date(value).toLocaleString('zh-CN', { hour12: false });
}

function safeStoredResults(value: string | null) {
  if (!value) return {};
  try {
    const parsed = JSON.parse(value) as Record<string, TestResult>;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export default function ApiKeysPage() {
  const [services, setServices] = useState<IntegrationStatus[]>([]);
  const [proxy, setProxy] = useState<ProxySummary | null>(null);
  const [envTemplate, setEnvTemplate] = useState('');
  const [results, setResults] = useState<Record<string, TestResult>>({});
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [testing, setTesting] = useState<Record<string, boolean>>({});
  const [testingAll, setTestingAll] = useState(false);
  const [notice, setNotice] = useState('');
  const [copied, setCopied] = useState('');

  useEffect(() => {
    setResults(safeStoredResults(localStorage.getItem(STORAGE_KEY)));
    refreshStatus();
  }, []);

  useEffect(() => {
    const safeResults = Object.fromEntries(
      Object.entries(results).map(([key, value]) => [
        key,
        {
          serviceId: value.serviceId,
          status: value.status,
          category: value.category,
          message: value.message,
          suggestion: value.suggestion,
          httpStatus: value.httpStatus,
          latencyMs: value.latencyMs,
          testedAt: value.testedAt,
        },
      ])
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(safeResults));
  }, [results]);

  async function copyText(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(''), 1800);
    } catch {
      setNotice('复制失败，请手动选择代码片段复制。');
    }
  }

  async function refreshStatus() {
    setLoadingStatus(true);
    setNotice('');
    try {
      const response = await fetch('/api/integrations/status', { cache: 'no-store' });
      const data = await response.json();
      setServices(data.services || []);
      setProxy(data.proxy || null);
      setEnvTemplate(data.envTemplate || '');
    } catch {
      setNotice('读取接口配置失败，请确认后端服务已启动。');
    } finally {
      setLoadingStatus(false);
    }
  }

  async function testOne(serviceId: string) {
    setTesting((current) => ({ ...current, [serviceId]: true }));
    try {
      const response = await fetch('/api/integrations/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serviceId }),
      });
      const data = await response.json();
      setResults((current) => ({ ...current, [serviceId]: data }));
    } catch {
      setResults((current) => ({
        ...current,
        [serviceId]: {
          serviceId,
          status: 'failed',
          category: 'network_error',
          message: '无法连接本地后端诊断接口。',
          suggestion: '请确认 npm start 或 npm run dev 正在运行，然后刷新页面。',
          latencyMs: 0,
          testedAt: new Date().toISOString(),
        },
      }));
    } finally {
      setTesting((current) => ({ ...current, [serviceId]: false }));
    }
  }

  async function testAll() {
    setTestingAll(true);
    const queue = services.map((item) => item.id);
    let index = 0;
    const worker = async () => {
      while (index < queue.length) {
        const serviceId = queue[index];
        index += 1;
        await testOne(serviceId);
      }
    };
    await Promise.all([worker(), worker()]);
    setTestingAll(false);
  }

  const summary = useMemo(() => {
    const values = Object.values(results);
    return {
      configured: services.filter((item) => item.configured).length,
      missing: services.filter((item) => !item.configured).length,
      success: values.filter((item) => item.status === 'success').length,
      failed: values.filter((item) => item.status === 'failed').length,
    };
  }, [services, results]);

  const metricCards: Array<{ label: string; value: number; color: string }> = [
    { label: '已配置接口', value: summary.configured, color: 'text-emerald-300' },
    { label: '缺少配置', value: summary.missing, color: 'text-amber-300' },
    { label: '测试成功', value: summary.success, color: 'text-blue-300' },
    { label: '测试失败', value: summary.failed, color: 'text-red-300' },
  ];

  return (
    <div className="space-y-6">
      <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
        <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm text-blue-300">
              <ShieldCheck className="h-4 w-4" />
              v0.35.0 接口配置向导
            </div>
            <h1 className="mt-3 text-2xl font-semibold text-[#f8fafc]">接口配置与连接诊断中心</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
              页面只读取服务器 `.env` 的配置状态，不保存完整密钥。你可以复制模板、按步骤配置、重启后端，再回到这里测试连接。
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={() => copyText(envTemplate, '全部模板')} disabled={!envTemplate}>
              <Copy className="mr-2 h-4 w-4" />
              复制全部 .env 模板
            </Button>
            <Button variant="outline" onClick={refreshStatus} disabled={loadingStatus}>
              {loadingStatus ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
              刷新配置
            </Button>
            <Button onClick={testAll} disabled={testingAll || loadingStatus || services.length === 0}>
              {testingAll ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <WifiOff className="mr-2 h-4 w-4" />}
              一键检测全部
            </Button>
          </div>
        </div>
      </section>

      {copied ? (
        <div className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 p-4 text-sm text-emerald-200">
          已复制：{copied}
        </div>
      ) : null}
      {notice ? (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">{notice}</div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {metricCards.map(({ label, value, color }) => (
          <Card key={label} className="border-[#2d3548] bg-[#121823]">
            <CardContent className="p-5">
              <p className="text-sm text-[#94a3b8]">{label}</p>
              <p className={`mt-2 text-3xl font-semibold ${color}`}>{value}</p>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="rounded-lg border border-amber-500/25 bg-amber-500/10 p-4 text-sm leading-6 text-amber-100">
        配置方法：先复制对应服务的 `.env` 片段，填入项目根目录的 `.env` 文件，保存后重启后端服务，然后点击“刷新配置”和“测试连接”。不要把 `.env` 上传到 GitHub。
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        {services.map((service) => {
          const result = results[service.id];
          return (
            <Card key={service.id} className="border-[#2d3548] bg-[#121823]">
              <CardHeader className="space-y-3">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                      {categoryIcon[service.category] || <KeyRound className="h-4 w-4" />}
                      {service.name}
                    </CardTitle>
                    <p className="mt-2 text-sm leading-6 text-[#94a3b8]">{service.description}</p>
                  </div>
                  <Badge className={service.configured ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/15 text-amber-300'}>
                    {service.configured ? '已配置' : '缺少配置'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="rounded-md border border-[#2d3548] bg-[#0f1419] p-4">
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="text-sm font-semibold text-[#f8fafc]">配置步骤</h3>
                    <a href={service.docsUrl} target="_blank" rel="noreferrer" className="text-sm text-blue-300 hover:text-blue-200">
                      官方入口
                    </a>
                  </div>
                  <ol className="mt-3 space-y-2">
                    {service.setupSteps.map((step, index) => (
                      <li key={step} className="flex gap-3 text-sm leading-6 text-[#cbd5e1]">
                        <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-blue-500/15 text-xs font-semibold text-blue-300">
                          {index + 1}
                        </span>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ol>
                </div>

                <div className="rounded-md border border-[#2d3548] bg-[#0f1419] p-4">
                  <div className="mb-3 flex items-center justify-between gap-3">
                    <h3 className="text-sm font-semibold text-[#f8fafc]">复制到 .env 的片段</h3>
                    <Button size="sm" variant="outline" onClick={() => copyText(service.envTemplate, service.name)}>
                      <Copy className="mr-2 h-4 w-4" />
                      复制
                    </Button>
                  </div>
                  <pre className="overflow-x-auto rounded-md bg-[#05070c] p-3 text-xs leading-5 text-emerald-200">
                    <code>{service.envTemplate}</code>
                  </pre>
                </div>

                <div className="grid gap-2">
                  {service.fields.map((field) => (
                    <div key={field.name} className="flex flex-col gap-1 rounded-md border border-[#2d3548] bg-[#0f1419] p-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="text-sm font-medium text-[#e2e8f0]">{field.name}</p>
                        <p className="text-xs text-[#64748b]">{field.label}{field.required ? ' · 必填' : ' · 可选'}</p>
                      </div>
                      <span className={field.configured ? 'text-sm text-emerald-300' : 'text-sm text-amber-300'}>
                        {field.configured ? field.value || '已配置' : '未填写'}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="rounded-md border border-[#2d3548] bg-[#0f1419] p-4">
                  <p className="text-sm text-[#e2e8f0]">{service.setupGuide}</p>
                  {service.missingEnv.length ? (
                    <p className="mt-2 text-sm text-amber-300">缺少：{service.missingEnv.join('、')}</p>
                  ) : (
                    <p className="mt-2 text-sm text-emerald-300">{service.mode}</p>
                  )}
                </div>

                {result ? (
                  <div className={`rounded-md border p-4 ${statusStyle[result.status]}`}>
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        {result.status === 'success' ? <CheckCircle2 className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                        {result.message}
                      </div>
                      <span className="text-xs">{result.latencyMs}ms</span>
                    </div>
                    <p className="mt-2 text-sm opacity-90">{result.suggestion}</p>
                    <p className="mt-2 flex items-center gap-1 text-xs opacity-75">
                      <Clock className="h-3 w-3" />
                      {formatTime(result.testedAt)} · {result.category}{result.httpStatus ? ` · HTTP ${result.httpStatus}` : ''}
                    </p>
                  </div>
                ) : (
                  <div className="rounded-md border border-[#2d3548] bg-[#0f1419] p-4 text-sm text-[#94a3b8]">
                    尚未测试。点击单项测试或一键检测全部后，会在这里显示最新结果。
                  </div>
                )}

                <div className="flex justify-end">
                  <Button variant="outline" onClick={() => testOne(service.id)} disabled={testing[service.id] || testingAll}>
                    {testing[service.id] ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <WifiOff className="mr-2 h-4 w-4" />}
                    测试连接
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">代理诊断</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-[#94a3b8]">{proxy?.note || '正在读取代理状态。'}</p>
            <p className="text-sm text-blue-300">当前优先来源：{proxy?.preferredSource || '未检测'}</p>
            <div className="grid gap-2">
              {(proxy?.items || []).map((item) => (
                <div key={item.name} className="flex items-center justify-between rounded-md border border-[#2d3548] bg-[#0f1419] p-3 text-sm">
                  <span className="text-[#e2e8f0]">{item.name}</span>
                  <span className={item.configured ? 'text-emerald-300' : 'text-[#64748b]'}>
                    {item.configured ? item.value : '未设置'}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">安全说明</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm leading-6 text-[#94a3b8]">
            <p>本页面不会让你输入真实密钥，也不会把完整密钥返回到浏览器。</p>
            <p>历史测试结果只保存状态、延迟、错误分类和中文建议，不保存密钥或原始响应。</p>
            <p>上传 GitHub 或发开源包时，只能上传 `.env.example`，不要上传 `.env`、`.env.local` 或任何真实密钥截图。</p>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
