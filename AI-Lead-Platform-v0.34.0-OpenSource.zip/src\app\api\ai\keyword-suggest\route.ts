import { NextRequest, NextResponse } from 'next/server';

// AI拓词建议 - 推荐相关搜索词
// 真实实现需要接入搜索引擎关键词API

interface KeywordSuggestion {
  keyword: string;
  relevance: number; // 相关度 0-100
  search_volume: string; // 搜索热度估算
  competition: string; // 竞争程度
  category: string;
}

interface KeywordResult {
  input_keyword: string;
  suggestions: KeywordSuggestion[];
  related_industries: string[];
  search_tips: string;
}

// 行业关键词库
const keywordDatabase: Record<string, KeywordSuggestion[]> = {
  '全屋定制': [
    { keyword: '整木定制', relevance: 95, search_volume: '高', competition: '中', category: '行业术语' },
    { keyword: '全屋木作', relevance: 90, search_volume: '中', competition: '低', category: '行业术语' },
    { keyword: '定制家居', relevance: 85, search_volume: '高', competition: '高', category: '行业术语' },
    { keyword: '整体家居', relevance: 80, search_volume: '中', competition: '中', category: '行业术语' },
    { keyword: '一体化定制', relevance: 75, search_volume: '低', competition: '低', category: '行业术语' },
    { keyword: '深圳全屋定制', relevance: 70, search_volume: '中', competition: '中', category: '地域+行业' },
    { keyword: '广州全屋定制', relevance: 70, search_volume: '中', competition: '中', category: '地域+行业' },
    { keyword: '佛山全屋定制工厂', relevance: 65, search_volume: '中', competition: '低', category: '地域+行业' },
  ],
  '建材外贸': [
    { keyword: '陶瓷出口', relevance: 95, search_volume: '高', competition: '高', category: '产品类' },
    { keyword: '建材出口商', relevance: 90, search_volume: '中', competition: '中', category: '行业术语' },
    { keyword: '家具外贸', relevance: 85, search_volume: '高', competition: '中', category: '产品类' },
    { keyword: '卫浴出口', relevance: 80, search_volume: '中', competition: '中', category: '产品类' },
    { keyword: '建材国际贸易', relevance: 75, search_volume: '低', competition: '低', category: '行业术语' },
    { keyword: '佛山建材外贸', relevance: 70, search_volume: '中', competition: '低', category: '地域+行业' },
    { keyword: '中国建材供应商', relevance: 65, search_volume: '高', competition: '高', category: '供应商类' },
  ],
  '全案设计师': [
    { keyword: '室内设计师', relevance: 95, search_volume: '高', competition: '高', category: '职业类' },
    { keyword: '家装设计师', relevance: 90, search_volume: '高', competition: '中', category: '职业类' },
    { keyword: '工装设计师', relevance: 85, search_volume: '中', competition: '中', category: '职业类' },
    { keyword: '室内设计公司', relevance: 80, search_volume: '高', competition: '高', category: '企业类' },
    { keyword: '设计工作室', relevance: 75, search_volume: '中', competition: '低', category: '企业类' },
    { keyword: '深圳设计师', relevance: 70, search_volume: '中', competition: '中', category: '地域+职业' },
    { keyword: '广州设计师', relevance: 70, search_volume: '中', competition: '中', category: '地域+职业' },
  ],
};

// 根据输入关键词生成推荐
function generateKeywordSuggestions(inputKeyword: string): KeywordResult {
  let suggestions: KeywordSuggestion[] = [];
  let relatedIndustries: string[] = [];

  // 查找匹配的关键词库
  for (const [key, values] of Object.entries(keywordDatabase)) {
    if (inputKeyword.includes(key) || key.includes(inputKeyword)) {
      suggestions = [...values];
      relatedIndustries.push(key);
    }
  }

  // 如果没有匹配，生成通用建议
  if (suggestions.length === 0) {
    suggestions = [
      { keyword: `${inputKeyword}公司`, relevance: 80, search_volume: '中', competition: '中', category: '企业类' },
      { keyword: `${inputKeyword}供应商`, relevance: 75, search_volume: '中', competition: '低', category: '供应商类' },
      { keyword: `${inputKeyword}深圳`, relevance: 70, search_volume: '中', competition: '中', category: '地域类' },
      { keyword: `${inputKeyword}广州`, relevance: 70, search_volume: '中', competition: '中', category: '地域类' },
      { keyword: `${inputKeyword}佛山`, relevance: 65, search_volume: '低', competition: '低', category: '地域类' },
    ];
    relatedIndustries = ['综合行业'];
  }

  const searchTips = `建议使用"地域+行业"组合搜索，如"深圳${inputKeyword}"，可获取更精准的本地客户信息`;

  return {
    input_keyword: inputKeyword,
    suggestions,
    related_industries: relatedIndustries,
    search_tips: searchTips,
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyword } = body;

    if (!keyword) {
      return NextResponse.json({ error: '请提供关键词' }, { status: 400 });
    }

    const result = generateKeywordSuggestions(keyword);

    return NextResponse.json({
      success: true,
      data: result,
      note: '基于行业关键词库生成，接入搜索API后可获取实时热度数据'
    });
  } catch (error) {
    console.error('Keyword suggest API error:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}