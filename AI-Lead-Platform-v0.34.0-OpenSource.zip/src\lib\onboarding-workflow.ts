export const onboardingWorkflow = [
  {
    step: '01',
    title: '配置基础能力',
    owner: '老板 / 管理员',
    description: '先确认公司工作空间、API Key、搜索源、OpenAI 接口和团队角色。',
    output: '系统具备搜索、补全、生成话术和数据隔离的基础条件。',
    href: '/settings',
    action: '打开系统设置',
  },
  {
    step: '02',
    title: '创建获客任务',
    owner: '运营',
    description: '输入产品、国家、客户类型和数量，让系统生成搜索关键词和渠道策略。',
    output: '得到 Google、LinkedIn、Facebook、TikTok 等渠道的搜索指令。',
    href: '/acquisition/search',
    action: '进入智能搜索',
  },
  {
    step: '03',
    title: '沉淀候选客户',
    owner: '运营',
    description: '把搜索结果沉淀到候选池，过滤目录页、社媒噪音和低质量结果。',
    output: '形成可核验的候选客户名单，并保留来源链接。',
    href: '/leads',
    action: '查看线索池',
  },
  {
    step: '04',
    title: '核验真实性',
    owner: '运营 / 销售',
    description: '核验官网、邮箱、电话、WhatsApp、LinkedIn、联系人和业务匹配度。',
    output: '得到真实性评分、联系方式可信度、风险提醒和开发优先级。',
    href: '/customers/list',
    action: '进入客户列表',
  },
  {
    step: '05',
    title: '生成开发动作',
    owner: '销售',
    description: '按客户类型生成英文开发信、WhatsApp 开场白和 LinkedIn 触达建议。',
    output: '得到可复制的英文开发信、二次跟进模板和报价邀请模板。',
    href: '/marketing/email',
    action: '打开邮件营销',
  },
  {
    step: '06',
    title: 'CRM 跟进和导出',
    owner: '销售 / 老板',
    description: '记录跟进状态、备注、标签和时间线，必要时导出中文字段 CSV。',
    output: '客户进入持续跟进节奏，可交给团队复盘或上传到其他 CRM。',
    href: '/customers',
    action: '查看客户管理',
  },
];

export const leadWizardPreview = {
  product: '全屋定制、橱柜、衣柜、木门、家具出口',
  country: 'Australia',
  customerType: 'Builder + Designer + Kitchen Company + Importer',
  quantity: 50,
  generatedKeywords: [
    'Australia custom cabinets builder contact email',
    'Australia kitchen company importer LinkedIn',
    'site:au custom wardrobe designer contact',
    'Australia joinery company WhatsApp email',
  ],
  recommendedChannels: ['Google Custom Search', 'LinkedIn', '官网 Contact 页面', '行业目录人工核验'],
  nextActions: [
    '优先搜索官网和 LinkedIn 公司页。',
    '先核验邮箱、电话、WhatsApp 是否来自官网或公开页面。',
    'A/B 级客户进入 CRM，C 级客户先补资料，D 级噪音结果过滤。',
  ],
};

export const onboardingChecklist = [
  '确认演示模式可以进入工作台。',
  '确认系统设置里 API Key 和搜索源有预留入口。',
  '用获客任务向导整理产品、国家、客户类型和数量。',
  '把候选客户加入客户池前先看真实性评分和联系方式可信度。',
  '开发前选择邮件、WhatsApp 或 LinkedIn 触达模板。',
  '每次跟进后更新 CRM 状态、标签和备注。',
];
