# v0.32.0 Ocean Shipments Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add multi-shipment FCL ocean logistics tracking from booking through customer pickup, including timeline, ETA alerts, order links, and backup v7.

**Architecture:** A standalone `shipments` domain owns snapshots, date validation, alert calculation, numbering, and localStorage persistence. List and detail pages consume that domain, while order details only provide creation and related-shipment links. Backup v7 adds shipments without changing older records.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, localStorage, shadcn/Radix UI, Tailwind CSS, Node assert tests through `tsx`.

---

### Task 1: Shipment Domain

**Files:**
- Create: `tests/shipments.test.ts`
- Create: `src/lib/shipments.ts`

- [ ] Write a failing test for `calculateShipmentTiming`, `createShipmentFromOrder`, and `validateShipment`.
- [ ] Verify RED with `.\node_modules\.bin\tsx.cmd tests\shipments.test.ts`.
- [ ] Define `ShipmentStatus`, `ContainerType`, and `SavedShipment` with all fields from the approved specification.
- [ ] Implement numbering, order/customer snapshot creation, date-day calculations, `upcoming` and `delayed` flags, email and date relationship validation.
- [ ] Implement `loadSavedShipments`, `saveShipments`, `saveShipment`, `deleteShipment`, and `loadShipmentsForOrder` using `skillhuoke_shipments_v032`.
- [ ] Verify GREEN and re-run existing order tests.

### Task 2: Shipment Center and Order Entry

**Files:**
- Create: `src/app/shipments/page.tsx`
- Create: `src/app/shipments/new/page.tsx`
- Modify: `src/app/crm-orders/[id]/page.tsx`
- Modify: `src/components/layout/sidebar.tsx`

- [ ] Build shipment metrics for total, booking pending, in transit, arriving within seven days, and possibly delayed.
- [ ] Add keyword, status, carrier, and destination-port filters.
- [ ] Render route, vessel/voyage, container, ETD/ETA, status, alert, and detail action.
- [ ] Build an order-bound creation page that rejects missing orders and creates a blank FCL shipment snapshot.
- [ ] Add “创建出货” and related-shipment links on order detail.
- [ ] Add a `海运出货` sidebar item after `外贸单据`.

### Task 3: Shipment Detail and Timeline

**Files:**
- Create: `src/components/shipments/shipment-form.tsx`
- Create: `src/components/shipments/shipment-timeline.tsx`
- Create: `src/app/shipments/[id]/page.tsx`

- [ ] Build editable booking, forwarder, carrier, vessel, voyage, ports, container, seal, bill-of-lading, status, dates, and notes fields.
- [ ] Show custom container text only when container type is `CUSTOM`.
- [ ] Validate unique shipment number, email, ETD/ETA, departure/arrival, and arrival/pickup relationships before save.
- [ ] Render the six-node timeline: booking, loading, customs, departure, arrival, pickup.
- [ ] Show estimated transit, actual transit, remaining days, upcoming, and delay indicators.
- [ ] Add safe empty state and links to shipment center, order, and customer.

### Task 4: Backup v7

**Files:**
- Create: `tests/data-backup-v7.test.ts`
- Modify: `src/lib/data-backup.ts`
- Modify: `src/app/data-backup/page.tsx`

- [ ] Write a failing test proving v6 backups normalize `shipments` to `[]` and v7 preserves a shipment.
- [ ] Set `BACKUP_VERSION = 7` and add `shipments` to `BackupData` and `BackupSummary`.
- [ ] Accept versions 1 through 7 and normalize missing shipments for versions below 7.
- [ ] Include shipments in load, save, merge, overwrite, undo, preview, and counts.
- [ ] Update the backup badge to v7 and display shipment counts.
- [ ] Run v5, v6, and v7 backup compatibility tests.

### Task 5: Release and Verification

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `README.md`
- Modify: `package.json`
- Create: `AI-Lead-Platform-v0.32.0-OpenSource.zip`

- [ ] Set version `v0.32.0`, title `海运出货管理中心`, package name `AI-Lead-Platform-v0.32.0-OpenSource.zip`, and GitHub remark `v0.32.0：新增整柜海运、出货时间线、ETA 到港与延误提醒`.
- [ ] Run all domain tests, `ts-check`, `lint:build`, and `build`.
- [ ] Browser-check `/shipments`, missing order creation, missing shipment detail, order detail, backup, and release on desktop and 390×844 mobile.
- [ ] Package while excluding `node_modules`, `.next`, `.git`, `.env*`, logs, and TypeScript build cache.
- [ ] Verify required shipment files/tests exist and forbidden-file count is zero.
