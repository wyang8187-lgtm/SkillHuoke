import { NextRequest, NextResponse } from 'next/server';

// 预置行业标签 - 全屋定制及建材细分行业（共24个）
const INDUSTRY_TAGS = [
  // 基础建材类
  { name: '建材外贸', keywords: ['建材', '建筑材料', '石材', '板材', '木材', '竹材', '水泥', '砂浆', '防水材料', '保温材料', 'building materials'] },
  { name: '家具出口', keywords: ['家具', '家居', '沙发', '床', '桌', '椅', '柜', '书架', '茶几', '餐桌', 'furniture', 'home furniture'] },
  { name: '全屋定制', keywords: ['全屋定制', '整屋定制', '定制家具', '整体家居', '一体化装修', '定制装修', 'whole house customization'] },
  { name: '橱柜衣柜', keywords: ['橱柜', '衣柜', '衣帽间', '鞋柜', '酒柜', '书柜', '储物柜', '吊柜', '地柜', 'cabinet', 'wardrobe'] },
  // 新增细分行业 - 灯饰照明
  { name: '灯饰照明', keywords: ['灯饰', '照明', '灯具', '吊灯', '壁灯', '筒灯', '射灯', '吸顶灯', '台灯', '落地灯', '户外灯', 'LED灯', '灯带', '水晶灯', 'lighting', 'lamp', 'chandelier', 'LED lighting', 'pendant light', 'wall lamp'] },
  // 新增细分行业 - 油漆涂料
  { name: '油漆涂料', keywords: ['油漆', '涂料', '木器漆', '墙面漆', '防水涂料', '艺术涂料', '乳胶漆', 'PU漆', 'PE漆', 'UV漆', '环保涂料', '防火涂料', 'paint', 'coating', 'varnish', 'waterproof coating', 'wood paint', 'wall paint'] },
  // 新增细分行业 - 岩板大板
  { name: '岩板大板', keywords: ['岩板', '大板', '岩板台面', '大板瓷砖', '薄板', '陶瓷大板', '石英岩板', '烧结石材', 'sintered stone', 'slab', 'porcelain slab', 'large format tile', 'thin slab', 'stone slab'] },
  // 新增细分行业 - 橱柜定制
  { name: '橱柜定制', keywords: ['整体橱柜', '橱柜定制', '橱柜门板', '橱柜台面', '厨房橱柜', '定制厨柜', '橱柜设计', '橱柜安装', 'kitchen cabinet', 'custom cabinet', 'cabinet door', 'countertop'] },
  // 新增细分行业 - 门业出口
  { name: '门业出口', keywords: ['木门', '防盗门', '铝合金门', '折叠门', '推拉门', '实木门', '复合门', '防火门', '入户门', '室内门', 'door', 'wooden door', 'security door', 'aluminum door', 'folding door', 'sliding door'] },
  // 新增细分行业 - 玻璃制品
  { name: '玻璃制品', keywords: ['玻璃', '钢化玻璃', '艺术玻璃', '淋浴房玻璃', '玻璃隔断', '玻璃门', '玻璃台面', '玻璃幕墙', '镀膜玻璃', 'tempered glass', 'art glass', 'shower glass', 'glass partition'] },
  // 新增细分行业 - 石材出口
  { name: '石材出口', keywords: ['石材', '大理石', '花岗岩', '人造石', '石英石', '石灰石', '砂岩', '板岩', '墓碑石', '景观石', 'stone', 'marble', 'granite', 'artificial stone', 'quartz stone'] },
  // 新增细分行业 - 硅胶密封
  { name: '硅胶密封', keywords: ['硅胶', '密封胶', '结构胶', '美缝剂', '防水胶', '玻璃胶', '硅酮胶', 'MS胶', '密封条', '密封垫', 'sealant', 'structural adhesive', 'grout', 'silicone', 'sealing strip'] },
  // 其他行业
  { name: '陶瓷卫浴', keywords: ['陶瓷', '瓷砖', '地砖', '墙砖', '卫浴', '浴室', '马桶', '洗手盆', '淋浴', '浴缸', '龙头', 'ceramic', 'tile', 'sanitary ware'] },
  { name: '五金配件', keywords: ['五金', '五金配件', '拉手', '铰链', '滑轨', '锁具', '螺丝', '螺栓', '合页', '门锁', 'hardware', 'hinge', 'handle', 'lock'] },
  { name: '地板门窗', keywords: ['地板', '木地板', '瓷砖地板', '门窗', '木门', '铝合金门窗', '推拉门', '折叠门', '防盗门', 'flooring', 'wood floor', 'door window'] },
  { name: '机械装备', keywords: ['机械', '设备', '装备', '生产线', '加工设备', '数控', '自动化', '机器人', '切割机', 'machinery', 'equipment', 'automation'] },
  { name: '纺织服装', keywords: ['纺织', '面料', '布料', '服装', '窗帘', '床品', '布艺', '软装', '家纺', '地毯', 'textile', 'fabric', 'curtain'] },
  { name: '家电出口', keywords: ['家电', '电器', '冰箱', '洗衣机', '空调', '电视', '热水器', '油烟机', '消毒柜', 'home appliance', 'electrical'] },
  { name: '跨境电商', keywords: ['跨境电商', '电商', '外贸平台', '亚马逊', 'eBay', '速卖通', '独立站', 'B2C', 'cross-border e-commerce'] },
  { name: '进出口贸易', keywords: ['进出口', '贸易', '外贸', '出口', '进口', '报关', '清关', '物流贸易', 'import export', 'trade'] },
  { name: '国际物流', keywords: ['物流', '货运', '海运', '空运', '陆运', '仓储', '配送', '供应链', '货代', 'logistics', 'shipping', 'freight'] },
];

// 预置区域分类 - 海外按大洲/国家，国内按省份/城市/区镇
const REGION_TAGS = {
  overseas: {
    continents: [
      { name: '亚洲', countries: ['日本', '韩国', '新加坡', '马来西亚', '泰国', '越南', '印尼', '菲律宾', '印度', '中东'] },
      { name: '欧洲', countries: ['德国', '英国', '法国', '意大利', '西班牙', '荷兰', '比利时', '瑞士', '北欧'] },
      { name: '北美', countries: ['美国', '加拿大', '墨西哥'] },
      { name: '南美', countries: ['巴西', '阿根廷', '智利', '哥伦比亚'] },
      { name: '非洲', countries: ['南非', '尼日利亚', '埃及', '肯尼亚'] },
      { name: '大洋洲', countries: ['澳大利亚', '新西兰'] },
    ],
  },
  domestic: {
    provinces: {
      广东: {
        cities: {
          广州: ['天河区', '白云区', '番禺区', '南沙区', '黄埔区', '增城区', '花都区', '从化区'],
          深圳: ['福田区', '罗湖区', '南山区', '盐田区', '宝安区', '龙岗区', '龙华区', '坪山区', '光明区'],
          佛山: {
            '顺德区': ['大良', '容桂', '乐从', '龙江', '北滘', '陈村', '均安', '勒流', '杏坛'],
            '南海区': ['桂城', '大沥', '里水', '狮山', '九江', '丹灶', '西樵'],
            '禅城区': ['石湾', '张槎', '南庄'],
            '三水区': ['西南', '云东海', '白坭', '乐平', '芦苞', '大塘', '南山'],
            '高明区': ['荷城', '杨和', '明城', '更合'],
          },
          东莞: ['莞城', '南城', '东城', '万江', '厚街', '虎门', '长安', '常平', '大朗', '塘厦', '凤岗', '清溪', '樟木头', '大岭山', '寮步', '茶山', '石排', '石龙', '高埗', '中堂', '麻涌', '道滘', '洪梅', '望牛墩', '沙田', '横沥', '企石', '桥头', '谢岗'],
          中山: ['石岐', '东区', '西区', '南区', '五桂山', '火炬开发区', '小榄', '古镇', '东凤', '南头', '阜沙', '黄圃', '三角', '民众', '港口', '横栏', '板芙', '神湾', '坦洲', '三乡', '沙溪', '大涌'],
          珠海: ['香洲区', '金湾区', '斗门区', '横琴新区'],
          惠州: ['惠城区', '惠阳区', '博罗县', '惠东县', '龙门县'],
          江门: ['蓬江区', '江海区', '新会区', '台山市', '开平市', '鹤山市', '恩平市'],
          肇庆: ['端州区', '鼎湖区', '高要区', '四会市', '广宁县', '德庆县', '封开县', '怀集县'],
        },
      },
      浙江: {
        cities: {
          杭州: ['上城区', '下城区', '拱墅区', '西湖区', '滨江区', '萧山区', '余杭区', '富阳区', '临安区', '建德市', '桐庐县', '淳安县'],
          宁波: ['海曙区', '江北区', '鄞州区', '镇海区', '北仑区', '奉化区', '余姚市', '慈溪市', '象山县', '宁海县'],
          温州: ['鹿城区', '龙湾区', '瓯海区', '洞头区', '瑞安市', '乐清市', '永嘉县', '平阳县', '苍南县', '文成县', '泰顺县'],
          嘉兴: ['南湖区', '秀洲区', '海宁市', '平湖市', '桐乡市', '嘉善县', '海盐县'],
          湖州: ['吴兴区', '南浔区', '德清县', '长兴县', '安吉县'],
          绍兴: ['越城区', '柯桥区', '上虞区', '诸暨市', '嵊州市', '新昌县'],
          金华: ['婺城区', '金东区', '兰溪市', '义乌市', '东阳市', '永康市', '浦江县', '武义县', '磐安县'],
          台州: ['椒江区', '黄岩区', '路桥区', '临海市', '温岭市', '玉环市', '天台县', '仙居县', '三门县'],
          衢州: ['柯城区', '衢江区', '江山市', '常山县', '开化县', '龙游县'],
          丽水: ['莲都区', '龙泉市', '青田县', '缙云县', '遂昌县', '松阳县', '云和县', '庆元县', '景宁县'],
        },
      },
      江苏: {
        cities: {
          南京: ['玄武区', '秦淮区', '建邺区', '鼓楼区', '浦口区', '栖霞区', '雨花台区', '江宁区', '六合区', '溧水区', '高淳区'],
          苏州: ['姑苏区', '虎丘区', '吴中区', '相城区', '吴江区', '昆山市', '太仓市', '常熟市', '张家港市'],
          无锡: ['梁溪区', '锡山区', '惠山区', '滨湖区', '新吴区', '江阴市', '宜兴市'],
          常州: ['天宁区', '钟楼区', '新北区', '武进区', '金坛区', '溧阳市'],
          南通: ['崇川区', '港闸区', '通州区', '海安市', '如皋市', '如东县', '海门区', '启东市'],
          盐城: ['亭湖区', '盐都区', '大丰区', '东台市', '建湖县', '射阳县', '阜宁县', '滨海县', '响水县'],
          扬州: ['广陵区', '邗江区', '江都区', '仪征市', '高邮市', '宝应县'],
          镇江: ['京口区', '润州区', '丹徒区', '丹阳市', '扬中市', '句容市'],
          泰州: ['海陵区', '高港区', '姜堰区', '兴化市', '靖江市', '泰兴市'],
          徐州: ['云龙区', '鼓楼区', '泉山区', '铜山区', '贾汪区', '新沂市', '邳州市', '睢宁县', '沛县', '丰县'],
          连云港: ['连云区', '海州区', '赣榆区', '东海县', '灌云县', '灌南县'],
          淮安: ['淮安区', '淮阴区', '清江浦区', '洪泽区', '涟水县', '盱眙县', '金湖县'],
        },
      },
      福建: {
        cities: {
          厦门: ['思明区', '湖里区', '集美区', '海沧区', '同安区', '翔安区'],
          福州: ['鼓楼区', '台江区', '仓山区', '马尾区', '晋安区', '长乐区', '福清市', '闽侯县', '连江县', '罗源县', '闽清县', '永泰县', '平潭县'],
          泉州: ['鲤城区', '丰泽区', '洛江区', '泉港区', '晋江市', '石狮市', '南安市', '惠安县', '安溪县', '永春县', '德化县', '金门县'],
          漳州: ['芗城区', '龙文区', '龙海市', '漳浦县', '云霄县', '诏安县', '东山县', '平和县', '南靖县', '长泰县', '华安县'],
          莆田: ['荔城区', '城厢区', '涵江区', '秀屿区', '仙游县'],
          三明: ['梅列区', '三元区', '永安市', '明溪县', '清流县', '宁化县', '大田县', '尤溪县', '沙县', '将乐县', '泰宁县', '建宁县'],
        },
      },
      山东: {
        cities: {
          青岛: ['市南区', '市北区', '黄岛区', '崂山区', '李沧区', '城阳区', '即墨区', '胶州市', '平度市', '莱西市'],
          济南: ['历下区', '市中区', '槐荫区', '天桥区', '历城区', '长清区', '章丘区', '济阳区', '莱芜区', '钢城区', '平阴县', '商河县'],
          烟台: ['芝罘区', '福山区', '牟平区', '莱山区', '蓬莱区', '龙口市', '莱阳市', '莱州市', '招远市', '栖霞市', '海阳市'],
          潍坊: ['潍城区', '寒亭区', '坊子区', '奎文区', '昌乐县', '青州市', '诸城市', '寿光市', '安丘市', '高密市', '昌邑市'],
          淄博: ['淄川区', '张店区', '博山区', '周村区', '临淄区', '桓台县', '高青县', '沂源县'],
          临沂: ['兰山区', '罗庄区', '河东区', '沂南县', '郯城县', '沂水县', '兰陵县', '费县', '平邑县', '莒南县', '蒙阴县', '临沭县'],
        },
      },
      上海: ['黄浦区', '徐汇区', '长宁区', '静安区', '普陀区', '虹口区', '杨浦区', '闵行区', '宝山区', '嘉定区', '浦东新区', '金山区', '松江区', '青浦区', '奉贤区', '崇明区'],
      北京: ['东城区', '西城区', '朝阳区', '丰台区', '石景山区', '海淀区', '门头沟区', '房山区', '通州区', '顺义区', '昌平区', '大兴区', '怀柔区', '平谷区', '密云区', '延庆区'],
    },
  },
};

// 客户规模分类
const SCALE_TAGS = [
  { name: '大型企业', keywords: ['集团', '股份公司', '上市公司', '500强', '大型', '跨国'] },
  { name: '中型企业', keywords: ['中型', '规模', '制造'] },
  { name: '小型企业', keywords: ['小', '工作室', '个体', '门店', '店铺'] },
];

// 合作意向度分类
const INTENT_LEVELS = [
  { name: 'A级', description: '高意向客户', keywords: ['有意向', '正在谈', '准备合作', '急需', '紧急'] },
  { name: 'B级', description: '中等意向客户', keywords: ['了解', '咨询', '感兴趣', '考虑'] },
  { name: 'C级', description: '低意向客户', keywords: ['暂无需求', '观望', '对比', '了解行情'] },
  { name: 'D级', description: '无意向客户', keywords: ['拒绝', '不需要', '没兴趣', '已合作'] },
];

// 根据公司名和业务描述识别行业
function identifyIndustry(companyName: string, businessDesc: string = ''): string[] {
  const text = `${companyName} ${businessDesc}`.toLowerCase();
  const matchedIndustries: string[] = [];
  
  for (const industry of INDUSTRY_TAGS) {
    for (const keyword of industry.keywords) {
      if (text.includes(keyword.toLowerCase())) {
        matchedIndustries.push(industry.name);
        break;
      }
    }
  }
  
  // 如果没有匹配到，根据关键词推断
  if (matchedIndustries.length === 0) {
    if (text.includes('外贸') || text.includes('export') || text.includes('trade')) {
      matchedIndustries.push('进出口贸易');
    }
    if (text.includes('设计') || text.includes('design')) {
      matchedIndustries.push('全屋定制');
    }
  }
  
  return matchedIndustries.length > 0 ? matchedIndustries : ['其他'];
}

// 根据地址识别区域
function identifyRegion(address: string): { 
  type: 'domestic' | 'overseas';
  region: string;
  detail: string;
} {
  const addressLower = address.toLowerCase();
  
  // 判断是否海外客户
  const overseasKeywords = ['usa', '美国', 'uk', '英国', 'germany', '德国', 'japan', '日本', 
    'korea', '韩国', 'singapore', '新加坡', 'malaysia', '马来西亚', 'thailand', '泰国',
    'vietnam', '越南', 'indonesia', '印尼', 'india', '印度', 'australia', '澳大利亚',
    'canada', '加拿大', 'brazil', '巴西', 'france', '法国', 'italy', '意大利', 
    'spain', '西班牙', 'netherlands', '荷兰', 'middle east', '中东', 'africa', '非洲'];
  
  for (const keyword of overseasKeywords) {
    if (addressLower.includes(keyword)) {
      // 找到对应大洲
      for (const continent of REGION_TAGS.overseas.continents) {
        if (continent.countries.some(c => addressLower.includes(c.toLowerCase()))) {
          return { type: 'overseas', region: continent.name, detail: keyword };
        }
      }
      return { type: 'overseas', region: '海外', detail: keyword };
    }
  }
  
  // 国内客户
  const provinces = Object.keys(REGION_TAGS.domestic.provinces);
  for (const province of provinces) {
    if (addressLower.includes(province.toLowerCase()) || address.includes(province)) {
      const provinceData = REGION_TAGS.domestic.provinces[province as keyof typeof REGION_TAGS.domestic.provinces];
      
      if (typeof provinceData === 'object' && !Array.isArray(provinceData)) {
        const cities = Object.keys(provinceData);
        for (const city of cities) {
          if (addressLower.includes(city.toLowerCase()) || address.includes(city)) {
            const cityData = provinceData[city as keyof typeof provinceData];
            
            // 检查是否有区镇信息
            if (typeof cityData === 'object' && !Array.isArray(cityData)) {
              const districts = Object.keys(cityData);
              for (const district of districts) {
                if (addressLower.includes(district.toLowerCase()) || address.includes(district)) {
                  const towns = cityData[district as keyof typeof cityData];
                  if (Array.isArray(towns)) {
                    for (const town of towns as string[]) {
                      if (addressLower.includes(town.toLowerCase()) || address.includes(town)) {
                        return { type: 'domestic', region: `${province}-${city}-${district}`, detail: town };
                      }
                    }
                  }
                  return { type: 'domestic', region: `${province}-${city}`, detail: district };
                }
              }
            } else if (Array.isArray(cityData)) {
              for (const district of cityData) {
                if (addressLower.includes(district.toLowerCase()) || address.includes(district)) {
                  return { type: 'domestic', region: `${province}-${city}`, detail: district };
                }
              }
            }
            return { type: 'domestic', region: province, detail: city };
          }
        }
      } else if (Array.isArray(provinceData)) {
        for (const district of provinceData) {
          if (addressLower.includes(district.toLowerCase()) || address.includes(district)) {
            return { type: 'domestic', region: province, detail: district };
          }
        }
      }
      return { type: 'domestic', region: province, detail: '' };
    }
  }
  
  return { type: 'domestic', region: '其他', detail: '' };
}

// 根据公司名识别规模
function identifyScale(companyName: string): string {
  const nameLower = companyName.toLowerCase();
  
  for (const scale of SCALE_TAGS) {
    for (const keyword of scale.keywords) {
      if (nameLower.includes(keyword.toLowerCase())) {
        return scale.name;
      }
    }
  }
  
  return '中型企业'; // 默认中型
}

// 根据备注识别意向度
function identifyIntent(notes: string = ''): string {
  const notesLower = notes.toLowerCase();
  
  for (const level of INTENT_LEVELS) {
    for (const keyword of level.keywords) {
      if (notesLower.includes(keyword.toLowerCase())) {
        return level.name;
      }
    }
  }
  
  return 'B级'; // 默认中等意向
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { customers } = body;
    
    if (!customers || !Array.isArray(customers)) {
      return NextResponse.json({ error: '请提供客户列表' }, { status: 400 });
    }
    
    const classifiedCustomers = customers.map((customer: {
      id: string;
      companyName: string;
      address?: string;
      businessDesc?: string;
      notes?: string;
    }) => {
      // 自动识别行业
      const industries = identifyIndustry(customer.companyName, customer.businessDesc || '');
      
      // 自动识别区域
      const regionInfo = identifyRegion(customer.address || customer.companyName);
      
      // 自动识别规模
      const scale = identifyScale(customer.companyName);
      
      // 自动识别意向度
      const intent = identifyIntent(customer.notes || '');
      
      return {
        id: customer.id,
        companyName: customer.companyName,
        autoTags: {
          industries,
          region: regionInfo,
          scale,
          intent,
        },
        suggestedLabels: [
          ...industries,
          regionInfo.region,
          scale,
          intent,
        ],
      };
    });
    
    return NextResponse.json({
      success: true,
      data: classifiedCustomers,
      summary: {
        totalClassified: customers.length,
        industryDistribution: getClassificationStats(classifiedCustomers, 'industries'),
        regionDistribution: getRegionStats(classifiedCustomers),
        scaleDistribution: getClassificationStats(classifiedCustomers, 'scale'),
        intentDistribution: getClassificationStats(classifiedCustomers, 'intent'),
      },
    });
  } catch (error) {
    console.error('Auto classify error:', error);
    return NextResponse.json({ error: '自动分类失败' }, { status: 500 });
  }
}

function getClassificationStats(
  customers: { autoTags: { industries?: string[]; scale?: string; intent?: string } }[],
  field: 'industries' | 'scale' | 'intent'
): Record<string, number> {
  const stats: Record<string, number> = {};
  
  customers.forEach(c => {
    if (field === 'industries') {
      c.autoTags.industries?.forEach(ind => {
        stats[ind] = (stats[ind] || 0) + 1;
      });
    } else {
      const value = c.autoTags[field];
      if (value) {
        stats[value] = (stats[value] || 0) + 1;
      }
    }
  });
  
  return stats;
}

function getRegionStats(
  customers: { autoTags: { region: { type: string; region: string } } }[]
): Record<string, number> {
  const stats: Record<string, number> = { '海外': 0, '国内': 0 };
  
  customers.forEach(c => {
    const type = c.autoTags.region.type;
    const region = c.autoTags.region.region;
    
    if (type === 'overseas') {
      stats['海外'] = (stats['海外'] || 0) + 1;
      stats[region] = (stats[region] || 0) + 1;
    } else {
      stats['国内'] = (stats['国内'] || 0) + 1;
      // 统计省份
      const province = region.split('-')[0];
      stats[province] = (stats[province] || 0) + 1;
    }
  });
  
  return stats;
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const type = searchParams.get('type') || 'industry';
  
  let data;
  
  switch (type) {
    case 'industry':
      data = INDUSTRY_TAGS.map(t => ({ name: t.name, keywords: t.keywords }));
      break;
    case 'region':
      data = REGION_TAGS;
      break;
    case 'scale':
      data = SCALE_TAGS.map(t => ({ name: t.name, keywords: t.keywords }));
      break;
    case 'intent':
      data = INTENT_LEVELS.map(t => ({ name: t.name, description: t.description, keywords: t.keywords }));
      break;
    default:
      data = { industry: INDUSTRY_TAGS, region: REGION_TAGS, scale: SCALE_TAGS, intent: INTENT_LEVELS };
  }
  
  return NextResponse.json({ success: true, data });
}