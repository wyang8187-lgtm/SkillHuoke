// 单个邮件模板 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient, getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 获取单个模板详情
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');
  const { id } = await params;

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const serviceClient = getSupabaseServiceRoleClient();
    
    const { data, error } = await serviceClient
      .from('email_templates')
      .select('*')
      .eq('id', id)
      .eq('user_id', user.id)
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return NextResponse.json({ error: '模板不存在' }, { status: 404 });
      }
      throw error;
    }

    return NextResponse.json({ data });
  } catch (error) {
    console.error('获取模板详情失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取模板失败' 
    }, { status: 500 });
  }
}

// 更新模板
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');
  const { id } = await params;

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, category, subject, content, style } = body;

    const serviceClient = getSupabaseServiceRoleClient();
    
    const updateData: Record<string, string | undefined> = {
      updated_at: new Date().toISOString(),
    };
    
    if (name) updateData.name = name;
    if (category) updateData.category = category;
    if (subject) updateData.subject = subject;
    if (content) updateData.content = content;
    if (style) updateData.style = style;

    const { data, error } = await serviceClient
      .from('email_templates')
      .update(updateData)
      .eq('id', id)
      .eq('user_id', user.id)
      .select()
      .single();

    if (error) {
      if (error.code === 'PGRST116') {
        return NextResponse.json({ error: '模板不存在' }, { status: 404 });
      }
      throw error;
    }

    return NextResponse.json({ data });
  } catch (error) {
    console.error('更新模板失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '更新模板失败' 
    }, { status: 500 });
  }
}

// 删除模板
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');
  const { id } = await params;

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const serviceClient = getSupabaseServiceRoleClient();
    
    const { error } = await serviceClient
      .from('email_templates')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id);

    if (error) {
      throw error;
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('删除模板失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '删除模板失败' 
    }, { status: 500 });
  }
}