import { NextRequest, NextResponse } from 'next/server';

// LinkedIn获客模拟API
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyword, location } = body;

    if (!keyword) {
      return NextResponse.json({ error: '请输入搜索关键词' }, { status: 400 });
    }

    // 模拟LinkedIn搜索结果
    const mockResults = [
      {
        id: 'li_001',
        type: 'person',
        name: '张伟',
        title: '总经理',
        company: '深圳市某某家居设计有限公司',
        location: location || '深圳',
        industry: '室内设计',
        connections: 500,
        profile_url: 'https://linkedin.com/in/zhangwei',
        phone: '13912345678',
        email: 'zhangwei@example.com',
        introduction: '专注于全屋定制设计，15年行业经验',
        verified: true,
      },
      {
        id: 'li_002',
        type: 'person',
        name: '李娜',
        title: '设计总监',
        company: '广州某某装饰工程有限公司',
        location: location || '广州',
        industry: '建筑装饰',
        connections: 380,
        profile_url: 'https://linkedin.com/in/lina',
        phone: '13812345679',
        email: 'lina@example.com',
        introduction: '擅长商业空间和住宅设计，多次获得设计奖项',
        verified: true,
      },
      {
        id: 'li_003',
        type: 'company',
        name: '佛山某某建材贸易有限公司',
        company: '佛山某某建材贸易有限公司',
        location: '佛山',
        industry: '建材贸易',
        employees: '50-100人',
        profile_url: 'https://linkedin.com/company/foshan-material',
        phone: '13712345680',
        email: 'info@foshanmaterial.com',
        description: '专业建材进出口贸易，主营全屋定制材料',
        verified: true,
      },
      {
        id: 'li_004',
        type: 'person',
        name: '王强',
        title: '采购经理',
        company: '东莞某某家具制造有限公司',
        location: '东莞',
        industry: '家具制造',
        connections: 200,
        profile_url: 'https://linkedin.com/in/wangqiang',
        phone: '13612345681',
        email: 'wangqiang@example.com',
        introduction: '负责公司原材料采购，寻找优质供应商',
        verified: true,
      },
      {
        id: 'li_005',
        type: 'person',
        name: '陈晓',
        title: '创始人',
        company: '深圳某某设计工作室',
        location: '深圳',
        industry: '室内设计',
        connections: 450,
        profile_url: 'https://linkedin.com/in/chenxiao',
        phone: '13512345682',
        email: 'chenxiao@example.com',
        introduction: '独立设计师工作室，专注高端住宅定制设计',
        verified: true,
      },
    ];

    // 根据关键词过滤（模拟）
    const filteredResults = mockResults.filter(result => {
      const searchText = `${result.name} ${result.company} ${result.industry} ${result.title}`.toLowerCase();
      return searchText.includes(keyword.toLowerCase());
    });

    // 过滤无手机号的结果
    const validResults = filteredResults.filter(r => r.phone && r.phone.length === 11);

    return NextResponse.json({
      success: true,
      data: validResults.length > 0 ? validResults : mockResults.filter(r => r.phone && r.phone.length === 11),
      total: validResults.length > 0 ? validResults.length : mockResults.filter(r => r.phone && r.phone.length === 11).length,
      platform: 'LinkedIn',
      note: '当前为模拟数据，接入真实API后可获取实时LinkedIn数据',
    });
  } catch (error) {
    console.error('LinkedIn搜索失败:', error);
    return NextResponse.json({ error: '搜索失败，请稍后重试' }, { status: 500 });
  }
}