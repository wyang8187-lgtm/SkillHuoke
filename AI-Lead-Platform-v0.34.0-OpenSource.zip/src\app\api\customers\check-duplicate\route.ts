// 客户查重 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 查重客户
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { phone, company_name } = body;

    if (!phone && !company_name) {
      return NextResponse.json({ error: '请提供手机号或公司名' }, { status: 400 });
    }

    // 获取所有客户
    const customersResult = await dbService.getCustomers(user.id, undefined, 1, 1000);
    const leadsResult = await dbService.getLeads(user.id, undefined, 1, 1000);
    const teamMembers = await dbService.getTeamMembers(user.id);

    const customers = customersResult.data;
    const leads = leadsResult.data;

    // 查重结果
    const duplicates: {
      id: string;
      company_name: string;
      contact_name: string;
      phone: string;
      type: 'customer' | 'lead';
      assignee_name: string | null;
      grade: string;
      status: string;
      created_at: string;
    }[] = [];

    // 按手机号查重
    if (phone) {
      customers.forEach(c => {
        if (c.phone === phone) {
          const assigneeName = c.assignee_id 
            ? teamMembers.find(m => m.id === c.assignee_id)?.name || '未知'
            : null;
          duplicates.push({
            id: c.id,
            company_name: c.company_name,
            contact_name: c.contact_name,
            phone: c.phone,
            type: 'customer',
            assignee_name: assigneeName,
            grade: c.grade || 'C',
            status: c.status,
            created_at: c.created_at,
          });
        }
      });

      leads.forEach(l => {
        if (l.phone === phone) {
          duplicates.push({
            id: l.id,
            company_name: l.company_name,
            contact_name: l.contact_name || '',
            phone: l.phone || '',
            type: 'lead',
            assignee_name: null,
            grade: l.grade || 'C',
            status: l.status,
            created_at: l.created_at,
          });
        }
      });
    }

    // 按公司名查重（如果提供）
    if (company_name && duplicates.length === 0) {
      const companyNameLower = company_name.toLowerCase();
      customers.forEach(c => {
        if (c.company_name.toLowerCase().includes(companyNameLower) || 
            companyNameLower.includes(c.company_name.toLowerCase())) {
          const assigneeName = c.assignee_id 
            ? teamMembers.find(m => m.id === c.assignee_id)?.name || '未知'
            : null;
          duplicates.push({
            id: c.id,
            company_name: c.company_name,
            contact_name: c.contact_name,
            phone: c.phone,
            type: 'customer',
            assignee_name: assigneeName,
            grade: c.grade || 'C',
            status: c.status,
            created_at: c.created_at,
          });
        }
      });
    }

    // 合并重复客户 API
    return NextResponse.json({
      has_duplicate: duplicates.length > 0,
      duplicates,
      suggestion: duplicates.length > 0 
        ? '发现重复客户，建议合并或放弃新建' 
        : '无重复客户，可以新建',
    });
  } catch (error) {
    console.error('查重失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '查重失败' 
    }, { status: 500 });
  }
}

// 合并重复客户
export async function PUT(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { primary_id, secondary_ids } = body;

    if (!primary_id || !secondary_ids || secondary_ids.length === 0) {
      return NextResponse.json({ error: '请提供要合并的客户ID' }, { status: 400 });
    }

    // 获取主要客户信息
    const { data: primaryCustomer, error: fetchError } = await client
      .from('customers')
      .select('*')
      .eq('id', primary_id)
      .single();

    if (fetchError || !primaryCustomer) {
      return NextResponse.json({ error: '找不到主要客户' }, { status: 404 });
    }

    // 获取次要客户的跟进记录
    const { data: secondaryFollowUps } = await client
      .from('follow_up_records')
      .select('*')
      .in('customer_id', secondary_ids);

    // 将次要客户的跟进记录转移到主要客户
    if (secondaryFollowUps && secondaryFollowUps.length > 0) {
      await client
        .from('follow_up_records')
        .update({ customer_id: primary_id })
        .in('customer_id', secondary_ids);
    }

    // 删除次要客户
    await client
      .from('customers')
      .delete()
      .in('id', secondary_ids);

    // 更新主要客户的备注
    const mergeNote = `\n[合并记录] ${new Date().toLocaleDateString('zh-CN')} 合并了 ${secondary_ids.length} 个重复客户`;
    await client
      .from('customers')
      .update({ 
        remarks: (primaryCustomer.remarks || '') + mergeNote,
        updated_at: new Date().toISOString(),
      })
      .eq('id', primary_id);

    return NextResponse.json({ 
      success: true, 
      message: `成功合并 ${secondary_ids.length + 1} 个客户` 
    });
  } catch (error) {
    console.error('合并失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '合并失败' 
    }, { status: 500 });
  }
}