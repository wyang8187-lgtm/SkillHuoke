import { NextRequest, NextResponse } from 'next/server';

// AI决策人深挖 - 分析关键决策人
// 真实实现需要接入企业数据API、LinkedIn API等

interface DecisionMaker {
  name: string;
  position: string;
  department: string;
  estimated_contact: string;
  confidence: number; // 置信度 0-100
  source: string;
  is_key_decision_maker: boolean;
}

interface DecisionMakerResult {
  company_name: string;
  decision_makers: DecisionMaker[];
  analysis_summary: string;
  recommended_approach: string;
}

// 模拟决策人数据生成
function generateMockDecisionMakers(companyName: string, industryType: string): DecisionMakerResult {
  // 根据行业类型生成不同的决策人
  const baseMakers: DecisionMaker[] = [
    {
      name: '张总',
      position: '总经理/创始人',
      department: '管理层',
      estimated_contact: '138****5678',
      confidence: 85,
      source: '公开信息推测',
      is_key_decision_maker: true,
    },
    {
      name: '李经理',
      position: '采购经理',
      department: '采购部',
      estimated_contact: '139****1234',
      confidence: 70,
      source: '招聘信息推测',
      is_key_decision_maker: industryType === '建材外贸',
    },
    {
      name: '王总监',
      position: '设计总监',
      department: '设计部',
      estimated_contact: '136****9876',
      confidence: 60,
      source: '项目信息推测',
      is_key_decision_maker: industryType === '全案设计师',
    },
    {
      name: '陈助理',
      position: '行政助理',
      department: '行政部',
      estimated_contact: '135****4567',
      confidence: 40,
      source: '工商信息推测',
      is_key_decision_maker: false,
    },
  ];

  // 根据置信度排序
  baseMakers.sort((a, b) => b.confidence - a.confidence);

  const analysisSummary = industryType === '全案设计师' 
    ? `${companyName}是一家设计型公司，关键决策人为设计总监或总经理，建议通过设计合作切入。`
    : `${companyName}是一家贸易型公司，关键决策人为采购经理或总经理，建议通过产品报价切入。`;

  const recommendedApproach = industryType === '全案设计师'
    ? '建议先联系设计总监介绍合作案例，再向总经理汇报合作方案'
    : '建议先发送产品目录给采购经理，再预约总经理商谈年度合作';

  return {
    company_name: companyName,
    decision_makers: baseMakers,
    analysis_summary: analysisSummary,
    recommended_approach: recommendedApproach,
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { company_name, industry_type } = body;

    if (!company_name) {
      return NextResponse.json({ error: '请提供公司名称' }, { status: 400 });
    }

    const result = generateMockDecisionMakers(company_name, industry_type || '全案设计师');

    return NextResponse.json({
      success: true,
      data: result,
      note: '当前为模拟数据，接入真实API后可获取真实决策人信息'
    });
  } catch (error) {
    console.error('Decision maker API error:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}