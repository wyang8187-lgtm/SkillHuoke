'use client';

import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@/components/ui/empty-state';
import { Search, User, Briefcase, Phone, Mail, Building, Linkedin, RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';

interface DecisionMaker {
  name: string;
  position: string;
  department: string;
  confidence: 'high' | 'medium' | 'low';
  contact_probability: string;
  possible_contacts: ContactInfo[];
  background: string;
  linkedin_url?: string;
}

interface ContactInfo {
  type: '手机' | '邮箱' | '微信';
  value: string;
  confidence: string;
}

interface DecisionMakerResult {
  company_name: string;
  company_id: string;
  decision_makers: DecisionMaker[];
  analysis_summary: string;
  recommended_approach: string;
}

export default function DecisionMakerPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<DecisionMakerResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setError(null);
    setResult(null);
    
    try {
      const response = await fetch('/api/ai/decision-maker', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ company_name: searchQuery.trim() })
      });
      
      if (!response.ok) {
        throw new Error('分析失败');
      }
      
      const data = await response.json();
      setResult(data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : '分析失败，请重试');
    } finally {
      setIsSearching(false);
    }
  };

  const getConfidenceColor = (confidence: string) => {
    switch (confidence) {
      case 'high': return 'bg-green-500/20 text-green-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'low': return 'bg-gray-500/20 text-gray-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getConfidenceIcon = (confidence: string) => {
    switch (confidence) {
      case 'high': return <CheckCircle className="w-4 h-4" />;
      case 'medium': return <AlertCircle className="w-4 h-4" />;
      case 'low': return <AlertCircle className="w-4 h-4" />;
      default: return null;
    }
  };

  return (
    <MainLayout 
      title="AI决策人深挖"
      breadcrumbs={[
        { label: 'AI获客中心', href: '/acquisition' },
        { label: 'AI决策人深挖' }
      ]}
    >
      <div className="space-y-6">
        {/* 页面说明 */}
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc] flex items-center gap-2">
              <User className="w-5 h-5 text-[#3b82f6]" />
              AI决策人深挖
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              输入企业名称，AI智能分析可能的关键决策人，包括职位、联系方式推测、背景信息等，帮助您精准触达目标客户
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="输入企业名称，如：深圳市某某家居有限公司"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc] placeholder:text-[#64748b]"
                />
              </div>
              <Button 
                onClick={handleSearch}
                disabled={isSearching || !searchQuery.trim()}
                className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] hover:from-[#2563eb] hover:to-[#1e40af]"
              >
                {isSearching ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    正在分析...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    开始深挖
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* 错误提示 */}
        {error && (
          <Card className="bg-[#1a1f2c] border-red-500/30">
            <CardContent className="py-6">
              <p className="text-red-400">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* 加载状态 */}
        {isSearching && (
          <Card className="bg-[#1a1f2c] border-[#2d3548]">
            <CardContent className="py-6 space-y-4">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        )}

        {/* 分析结果 */}
        {result && !isSearching && (
          <div className="space-y-4">
            {/* 分析摘要 */}
            <Card className="bg-[#1a1f2c] border-[#2d3548]">
              <CardHeader className="pb-3">
                <CardTitle className="text-[#f8fafc] flex items-center gap-2">
                  <Building className="w-5 h-5 text-[#3b82f6]" />
                  {result.company_name} - 决策人分析报告
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-[#0f1419] p-4 rounded-lg border border-[#2d3548]">
                  <h4 className="text-sm font-medium text-[#3b82f6] mb-2">分析摘要</h4>
                  <p className="text-sm text-[#94a3b8]">{result.analysis_summary}</p>
                </div>
                <div className="bg-[#0f1419] p-4 rounded-lg border border-green-500/30">
                  <h4 className="text-sm font-medium text-green-400 mb-2">推荐触达策略</h4>
                  <p className="text-sm text-[#94a3b8]">{result.recommended_approach}</p>
                </div>
                <Badge className="bg-[#3b82f6]/20 text-[#3b82f6]">
                  共识别 {result.decision_makers.length} 位关键决策人
                </Badge>
              </CardContent>
            </Card>

            {/* 决策人列表 */}
            <div className="space-y-3">
              {result.decision_makers.map((maker, index) => (
                <Card key={index} className="bg-[#1a1f2c] border-[#2d3548] hover:border-[#3b82f6]/30 transition-colors">
                  <CardContent className="py-4">
                    <div className="flex items-start gap-4">
                      {/* 头像区域 */}
                      <div className="w-12 h-12 rounded-full bg-[#3b82f6]/20 flex items-center justify-center">
                        <User className="w-6 h-6 text-[#3b82f6]" />
                      </div>
                      
                      {/* 信息区域 */}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="text-[#f8fafc] font-medium">{maker.name}</h4>
                          <Badge className={`${getConfidenceColor(maker.confidence)} text-xs flex items-center gap-1`}>
                            {getConfidenceIcon(maker.confidence)}
                            {maker.confidence === 'high' ? '高置信度' : maker.confidence === 'medium' ? '中置信度' : '推测'}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center gap-3 mb-2">
                          <div className="flex items-center gap-1 text-sm text-[#94a3b8]">
                            <Briefcase className="w-4 h-4" />
                            {maker.position}
                          </div>
                          <span className="text-xs text-[#64748b]">{maker.department}</span>
                        </div>
                        
                        <p className="text-sm text-[#94a3b8] mb-3">{maker.background}</p>
                        
                        {/* 联系方式 */}
                        {maker.possible_contacts.length > 0 && (
                          <div className="space-y-2">
                            <h5 className="text-xs font-medium text-[#64748b]">推测联系方式</h5>
                            <div className="flex flex-wrap gap-2">
                              {maker.possible_contacts.map((contact, cIndex) => (
                                <div key={cIndex} className="flex items-center gap-1 text-sm bg-[#0f1419] px-3 py-1 rounded border border-[#2d3548]">
                                  {contact.type === '手机' && <Phone className="w-4 h-4 text-[#3b82f6]" />}
                                  {contact.type === '邮箱' && <Mail className="w-4 h-4 text-[#3b82f6]" />}
                                  {contact.type === '微信' && <span className="text-xs text-[#3b82f6]">微</span>}
                                  <span className="text-[#f8fafc]">{contact.value}</span>
                                  <Badge className={`${getConfidenceColor(contact.confidence as 'high'|'medium'|'low')} text-xs ml-1`}>
                                    {contact.confidence}
                                  </Badge>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                        
                        {/* LinkedIn */}
                        {maker.linkedin_url && (
                          <Button size="sm" variant="outline" className="mt-3 border-[#2d3548] text-[#94a3b8] hover:bg-[#1a1f2c]">
                            <Linkedin className="w-4 h-4 mr-1" />
                            查看 LinkedIn
                          </Button>
                        )}
                      </div>
                      
                      {/* 操作按钮 */}
                      <div className="flex flex-col gap-2">
                        <Button size="sm" className="bg-[#3b82f6] hover:bg-[#2563eb]">
                          添加到客户
                        </Button>
                        <Button size="sm" variant="outline" className="border-[#2d3548] text-[#94a3b8]">
                          发送开发信
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* 空状态 */}
        {!result && !isSearching && !error && (
          <EmptyState
            icon={<User className="w-12 h-12" />}
            title="输入企业名称开始深挖"
            description="AI将分析企业架构、招聘信息、工商数据等，推测关键决策人及其联系方式"
          />
        )}
      </div>
    </MainLayout>
  );
}