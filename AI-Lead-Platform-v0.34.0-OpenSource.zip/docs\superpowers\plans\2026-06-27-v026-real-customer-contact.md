# v0.26.0 Real Customer and Contact Management Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Allow users to create and edit real CRM customers with validated primary contact information and duplicate warnings.

**Architecture:** Extend the backward-compatible CRM record, keep validation and duplicate detection in a focused helper module, and share one form component between create and edit routes.

**Tech Stack:** Next.js 16, React 19, TypeScript, localStorage, shadcn UI.

---

### Task 1: Extend CRM data and validation

**Files:**
- Modify: `src/lib/lead-wizard.ts`
- Create: `src/lib/crm-customer-editor.ts`

- [ ] Add optional contact and source fields with old-record normalization.
- [ ] Add manual customer create and full update helpers.
- [ ] Implement URL, email, phone, WhatsApp, LinkedIn, score, and required-field validation.
- [ ] Implement domain and company-country duplicate detection.

### Task 2: Build shared create/edit experience

**Files:**
- Create: `src/components/crm/customer-editor-form.tsx`
- Create: `src/app/crm-customers/new/page.tsx`
- Create: `src/app/crm-customers/[id]/edit/page.tsx`

- [ ] Render complete company and contact forms.
- [ ] Show field errors and duplicate warning.
- [ ] Support explicit duplicate override and redirect after save.
- [ ] Handle missing edit customer safely.

### Task 3: Connect CRM detail and AI context

**Files:**
- Modify: `src/app/crm-customers/page.tsx`
- Modify: `src/app/crm-customers/[id]/page.tsx`
- Modify: `src/lib/integrations/openai-provider.ts`

- [ ] Add create and edit navigation.
- [ ] Display primary contact and verification status.
- [ ] Pass real contact name/title into AI generation and address the person when available.

### Task 4: Release, verify, and package

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `package.json`
- Modify: `README.md`
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.26.0-OpenSource.zip`

- [ ] Set v0.26.0 release metadata.
- [ ] Run TypeScript, ESLint, production build, page checks, and package inspection.
