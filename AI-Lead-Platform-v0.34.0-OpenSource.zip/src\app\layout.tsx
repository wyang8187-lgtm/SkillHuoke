import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import { SupabaseConfigProvider } from '@/lib/supabase-config-inject';
import { ThemeProvider } from '@/lib/theme-context';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: 'AI智能获客平台',
    template: '%s | AI智能获客平台',
  },
  description: '面向外贸企业的 AI 获客、客户核验、开发信生成和 CRM 跟进工作台。',
  keywords: [
    'AI获客',
    '外贸获客',
    '客户开发',
    'CRM',
    'LinkedIn获客',
    'WhatsApp营销',
    'OpenAI',
    'SkillHuoke',
  ],
  authors: [{ name: 'SkillHuoke Open Source' }],
  generator: 'Next.js',
  openGraph: {
    title: 'AI智能获客平台',
    description: '面向外贸企业的 AI 获客、客户核验、开发信生成和 CRM 跟进工作台。',
    siteName: 'AI智能获客平台',
    locale: 'zh_CN',
    type: 'website',
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="zh-CN" className="dark">
      <body className="antialiased">
        <ThemeProvider>
          <SupabaseConfigProvider>
            {isDev && <Inspector />}
            {children}
          </SupabaseConfigProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
