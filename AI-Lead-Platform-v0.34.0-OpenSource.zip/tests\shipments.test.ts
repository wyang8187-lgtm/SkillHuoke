import assert from 'node:assert/strict';
import { calculateShipmentTiming, createShipmentFromOrder, validateShipment } from '../src/lib/shipments';
import type { SavedCrmOrder } from '../src/lib/crm-orders';
const order={id:'order-1',number:'SO-1',customerId:'c1',customerName:'Builder Co',contactName:'Alex',opportunityId:'',quotationId:'q1',quotationNumber:'Q1',currency:'USD',items:[],subtotal:0,discount:0,shipping:0,tax:0,total:0,tradeTerm:'FOB',paymentTerms:'',deliveryTime:'',quotationNote:'',depositPercent:30,depositReceived:0,depositReceivedAt:'',balanceReceived:0,balanceReceivedAt:'',expectedDeliveryDate:'',deliveredAt:'',status:'shipping_pending',internalNote:'',createdAt:'',updatedAt:''} as SavedCrmOrder;
assert.deepEqual(calculateShipmentTiming({etd:'2026-07-01',actualDepartureDate:'',eta:'2026-07-20',actualArrivalDate:'',status:'in_transit'},'2026-07-15'),{estimatedTransitDays:19,actualTransitDays:null,remainingDays:5,upcoming:true,delayed:false});
assert.equal(calculateShipmentTiming({etd:'2026-07-01',actualDepartureDate:'',eta:'2026-07-10',actualArrivalDate:'',status:'in_transit'},'2026-07-15').delayed,true);
const shipment=createShipmentFromOrder(order);assert.equal(shipment.orderId,'order-1');assert.equal(shipment.customerName,'Builder Co');
assert.deepEqual(validateShipment({...shipment,etd:'2026-07-20',eta:'2026-07-10'},[]),['预计到港日期不能早于预计开船日期。']);
console.log('shipments tests passed');
