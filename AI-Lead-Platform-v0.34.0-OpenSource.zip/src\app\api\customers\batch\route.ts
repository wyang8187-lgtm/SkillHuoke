// 客户批量操作 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient, getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 批量更新客户
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { action, customerIds, data } = body;

    if (!customerIds || customerIds.length === 0) {
      return NextResponse.json({ error: '请选择至少一个客户' }, { status: 400 });
    }

    const serviceClient = getSupabaseServiceRoleClient();

    switch (action) {
      case 'assign':
        // 批量分配
        const assignResult = await serviceClient
          .from('customers')
          .update({
            owner_id: data.ownerId,
            owner_name: data.ownerName,
            updated_at: new Date().toISOString(),
          })
          .in('id', customerIds);
        
        if (assignResult.error) {
          throw assignResult.error;
        }
        return NextResponse.json({ 
          success: true, 
          message: `成功分配 ${customerIds.length} 个客户` 
        });

      case 'tag':
        // 批量打标签 - 为每个客户添加标签
        for (const customerId of customerIds) {
          // 先获取当前客户的标签
          const { data: customer } = await serviceClient
            .from('customers')
            .select('tags')
            .eq('id', customerId)
            .single();
          
          if (customer) {
            const currentTags = customer.tags || [];
            const newTags = [...new Set([...currentTags, ...data.tags])];
            
            await serviceClient
              .from('customers')
              .update({
                tags: newTags,
                updated_at: new Date().toISOString(),
              })
              .eq('id', customerId);
          }
        }
        return NextResponse.json({ 
          success: true, 
          message: `成功为 ${customerIds.length} 个客户添加标签` 
        });

      case 'grade':
        // 批量设置等级
        const gradeResult = await serviceClient
          .from('customers')
          .update({
            grade: data.grade,
            updated_at: new Date().toISOString(),
          })
          .in('id', customerIds);
        
        if (gradeResult.error) {
          throw gradeResult.error;
        }
        return NextResponse.json({ 
          success: true, 
          message: `成功设置 ${customerIds.length} 个客户的等级` 
        });

      case 'delete':
        // 批量删除
        const deleteResult = await serviceClient
          .from('customers')
          .delete()
          .in('id', customerIds);
        
        if (deleteResult.error) {
          throw deleteResult.error;
        }
        return NextResponse.json({ 
          success: true, 
          message: `成功删除 ${customerIds.length} 个客户` 
        });

      default:
        return NextResponse.json({ error: '未知操作类型' }, { status: 400 });
    }
  } catch (error) {
    console.error('批量操作失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '批量操作失败' 
    }, { status: 500 });
  }
}