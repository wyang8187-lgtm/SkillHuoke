'use client';

import { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Upload, Download, FileText, CheckCircle, XCircle, AlertCircle,
  History, Settings, FileDown, Trash2, Eye
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ImportResult {
  total: number;
  success: number;
  failed: number;
  skipped: number;
  errors: { row: number; field: string; message: string }[];
  imported_ids: string[];
}

interface ExportHistory {
  id: string;
  dataType: string;
  total: number;
  format: string;
  created_at: string;
  operator: string;
}

export default function DataImportExportPage() {
  const [activeTab, setActiveTab] = useState('import');
  const [dataType, setDataType] = useState('customers');
  const [file, setFile] = useState<File | null>(null);
  const [fieldMapping, setFieldMapping] = useState<Record<string, string>>({});
  const [previewData, setPreviewData] = useState<string[][]>([]);
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [exportFields, setExportFields] = useState<string[]>([]);
  const [exportHistory, setExportHistory] = useState<ExportHistory[]>([]);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const dataTypeOptions = [
    { value: 'customers', label: '客户数据' },
    { value: 'leads', label: '线索数据' },
    { value: 'opportunities', label: '商机数据' },
  ];

  const defaultFields: Record<string, string[]> = {
    customers: ['客户名称', '手机号', '公司名称', '地区', '客户类型', '客户等级', '备注'],
    leads: ['线索名称', '手机号', '公司名称', '来源', '地区', '备注'],
    opportunities: ['商机名称', '客户名称', '金额', '阶段', '预计成交日期', '备注'],
  };

  // 处理文件上传
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const uploadedFile = e.target.files?.[0];
    if (uploadedFile) {
      setFile(uploadedFile);
      parseFile(uploadedFile);
    }
  };

  // 解析CSV文件
  const parseFile = async (uploadedFile: File) => {
    try {
      const content = await uploadedFile.text();
      const lines = content.split('\n').filter(line => line.trim());
      
      if (lines.length > 0) {
        const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
        const rows = lines.slice(1, 6).map(line => 
          line.split(',').map(v => v.trim().replace(/^"|"$/g, ''))
        );
        
        setPreviewData([headers, ...rows]);
        
        // 初始化字段映射
        const mapping: Record<string, string> = {};
        headers.forEach(header => {
          // 尝试自动匹配字段
          const matchedField = defaultFields[dataType]?.find(
            f => f.toLowerCase().includes(header.toLowerCase()) || 
                 header.toLowerCase().includes(f.toLowerCase())
          );
          mapping[header] = matchedField || header;
        });
        setFieldMapping(mapping);
      }
    } catch (error) {
      console.error('解析文件失败:', error);
      alert('文件解析失败，请检查文件格式');
    }
  };

  // 导入数据
  const handleImport = async () => {
    if (!file) {
      alert('请先上传文件');
      return;
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('dataType', dataType);
      formData.append('fieldMapping', JSON.stringify(fieldMapping));

      const res = await fetch('/api/data/import', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();
      if (data.success) {
        setImportResult(data.data);
      } else {
        alert(data.error || '导入失败');
      }
    } catch (error) {
      console.error('导入失败:', error);
      alert('导入处理失败');
    } finally {
      setLoading(false);
    }
  };

  // 导出数据
  const handleExport = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/data/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dataType,
          fields: exportFields.length > 0 ? exportFields : defaultFields[dataType],
          format: 'csv',
        }),
      });

      const data = await res.json();
      if (data.success) {
        // 模拟下载
        const blob = new Blob([data.data.content], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = data.data.filename;
        link.click();
        URL.revokeObjectURL(link.href);
        
        loadExportHistory();
      }
    } catch (error) {
      console.error('导出失败:', error);
      alert('导出失败');
    } finally {
      setLoading(false);
    }
  };

  // 加载导出历史
  const loadExportHistory = async () => {
    try {
      const res = await fetch('/api/data/export');
      const data = await res.json();
      if (data.success) {
        setExportHistory(data.data);
      }
    } catch (error) {
      console.error('加载历史失败:', error);
    }
  };

  // 下载导入模板
  const downloadTemplate = async () => {
    try {
      const res = await fetch(`/api/data/import?dataType=${dataType}`);
      const data = await res.json();
      if (data.success) {
        const blob = new Blob([data.data.template], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `${dataType}_import_template.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
      }
    } catch (error) {
      console.error('下载模板失败:', error);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div>
        <h1 className="text-2xl font-bold text-[var(--text-primary)]">数据导入导出</h1>
        <p className="text-[var(--text-muted)] mt-1">批量导入和导出客户、线索、商机数据</p>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-[var(--bg-card)]">
          <TabsTrigger value="import">
            <Upload className="w-4 h-4 mr-2" />
            数据导入
          </TabsTrigger>
          <TabsTrigger value="export">
            <Download className="w-4 h-4 mr-2" />
            数据导出
          </TabsTrigger>
          <TabsTrigger value="history">
            <History className="w-4 h-4 mr-2" />
            导出历史
          </TabsTrigger>
        </TabsList>

        {/* 导入 */}
        <TabsContent value="import" className="space-y-4">
          {/* 数据类型选择 */}
          <Card className="bg-[var(--bg-card)]">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">选择导入类型</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                {dataTypeOptions.map(option => (
                  <Button
                    key={option.value}
                    variant={dataType === option.value ? 'default' : 'outline'}
                    onClick={() => setDataType(option.value)}
                    className="gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    {option.label}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 上传文件 */}
          <Card className="bg-[var(--bg-card)]">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-[var(--text-primary)]">上传文件</CardTitle>
                <Button variant="outline" size="sm" onClick={downloadTemplate}>
                  <FileDown className="w-4 h-4 mr-2" />
                  下载模板
                </Button>
              </div>
              <CardDescription className="text-[var(--text-muted)]">
                支持 CSV 和 Excel 文件格式，文件大小不超过 5MB
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div 
                className="border-2 border-dashed border-[var(--border-color)] rounded-lg p-8 text-center cursor-pointer hover:border-blue-500 transition-colors"
                onClick={() => fileInputRef.current?.click()}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".csv,.xlsx,.xls"
                  className="hidden"
                  onChange={handleFileUpload}
                />
                {file ? (
                  <div className="flex items-center justify-center gap-3">
                    <FileText className="w-8 h-8 text-blue-500" />
                    <div>
                      <p className="text-[var(--text-primary)] font-medium">{file.name}</p>
                      <p className="text-sm text-[var(--text-muted)]">
                        {(file.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        setFile(null);
                        setPreviewData([]);
                        setImportResult(null);
                      }}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ) : (
                  <div>
                    <Upload className="w-12 h-12 mx-auto text-[var(--text-muted)] mb-4" />
                    <p className="text-[var(--text-primary)] mb-2">点击或拖拽上传文件</p>
                    <p className="text-sm text-[var(--text-muted)]">CSV / Excel 格式</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* 数据预览 */}
          {previewData.length > 0 && (
            <Card className="bg-[var(--bg-card)]">
              <CardHeader>
                <CardTitle className="text-[var(--text-primary)]">数据预览</CardTitle>
                <CardDescription className="text-[var(--text-muted)]">
                  显示前5行数据，请确认字段映射正确
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-[var(--border-color)]">
                        {previewData[0].map((header, idx) => (
                          <TableHead key={idx} className="text-[var(--text-secondary)]">
                            <div className="flex flex-col gap-1">
                              <span className="font-medium">{header}</span>
                              <span className="text-xs text-blue-400">
                                → {fieldMapping[header] || header}
                              </span>
                            </div>
                          </TableHead>
                        ))}
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {previewData.slice(1).map((row, rowIdx) => (
                        <TableRow key={rowIdx} className="border-[var(--border-color)]">
                          {row.map((cell, cellIdx) => (
                            <TableCell key={cellIdx} className="text-[var(--text-secondary)]">
                              {cell}
                            </TableCell>
                          ))}
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <Button
                  className="mt-4 w-full"
                  onClick={handleImport}
                  disabled={loading}
                >
                  {loading ? (
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                  ) : (
                    <Upload className="w-4 h-4 mr-2" />
                  )}
                  开始导入
                </Button>
              </CardContent>
            </Card>
          )}

          {/* 导入结果 */}
          {importResult && (
            <Card className="bg-[var(--bg-card)]">
              <CardHeader>
                <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
                  {importResult.failed > 0 ? (
                    <AlertCircle className="w-5 h-5 text-orange-400" />
                  ) : (
                    <CheckCircle className="w-5 h-5 text-green-400" />
                  )}
                  导入结果
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-4 mb-4">
                  <div className="text-center p-4 bg-[var(--bg-secondary)] rounded-lg">
                    <p className="text-2xl font-bold text-[var(--text-primary)]">{importResult.total}</p>
                    <p className="text-sm text-[var(--text-muted)]">总行数</p>
                  </div>
                  <div className="text-center p-4 bg-green-500/10 rounded-lg">
                    <p className="text-2xl font-bold text-green-400">{importResult.success}</p>
                    <p className="text-sm text-[var(--text-muted)]">成功</p>
                  </div>
                  <div className="text-center p-4 bg-red-500/10 rounded-lg">
                    <p className="text-2xl font-bold text-red-400">{importResult.failed}</p>
                    <p className="text-sm text-[var(--text-muted)]">失败</p>
                  </div>
                  <div className="text-center p-4 bg-gray-500/10 rounded-lg">
                    <p className="text-2xl font-bold text-gray-400">{importResult.skipped}</p>
                    <p className="text-sm text-[var(--text-muted)]">跳过</p>
                  </div>
                </div>

                {importResult.errors.length > 0 && (
                  <div className="mt-4">
                    <h4 className="font-medium text-[var(--text-primary)] mb-2">错误详情</h4>
                    <div className="max-h-40 overflow-y-auto space-y-2">
                      {importResult.errors.map((error, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-sm">
                          <Badge className="bg-red-500/20 text-red-400">行{error.row}</Badge>
                          <span className="text-[var(--text-secondary)]">{error.field}</span>
                          <span className="text-[var(--text-muted)]">{error.message}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* 导出 */}
        <TabsContent value="export" className="space-y-4">
          <Card className="bg-[var(--bg-card)]">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">选择导出类型</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4 mb-6">
                {dataTypeOptions.map(option => (
                  <Button
                    key={option.value}
                    variant={dataType === option.value ? 'default' : 'outline'}
                    onClick={() => setDataType(option.value)}
                    className="gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    {option.label}
                  </Button>
                ))}
              </div>

              <h4 className="font-medium text-[var(--text-primary)] mb-3">选择导出字段</h4>
              <div className="grid grid-cols-3 gap-3 mb-6">
                {defaultFields[dataType]?.map(field => (
                  <div key={field} className="flex items-center gap-2">
                    <Checkbox
                      checked={exportFields.includes(field) || exportFields.length === 0}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setExportFields(prev => [...prev, field]);
                        } else {
                          setExportFields(prev => prev.filter(f => f !== field));
                        }
                      }}
                    />
                    <Label className="text-[var(--text-secondary)]">{field}</Label>
                  </div>
                ))}
              </div>

              <Button onClick={handleExport} disabled={loading} className="w-full">
                {loading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2" />
                ) : (
                  <Download className="w-4 h-4 mr-2" />
                )}
                导出CSV
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 导出历史 */}
        <TabsContent value="export" className="space-y-4">
          <Card className="bg-[var(--bg-card)]">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">导出历史记录</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-[var(--border-color)]">
                    <TableHead className="text-[var(--text-secondary)]">导出类型</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">数量</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">格式</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">导出时间</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">操作人</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {exportHistory.map(record => (
                    <TableRow key={record.id} className="border-[var(--border-color)]">
                      <TableCell className="text-[var(--text-secondary)]">
                        {dataTypeOptions.find(t => t.value === record.dataType)?.label || record.dataType}
                      </TableCell>
                      <TableCell className="text-[var(--text-secondary)]">{record.total}条</TableCell>
                      <TableCell className="text-[var(--text-secondary)]">
                        <Badge className="bg-blue-500/20 text-blue-400">{record.format}</Badge>
                      </TableCell>
                      <TableCell className="text-[var(--text-secondary)]">
                        {new Date(record.created_at).toLocaleString('zh-CN')}
                      </TableCell>
                      <TableCell className="text-[var(--text-secondary)]">{record.operator}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Eye className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}