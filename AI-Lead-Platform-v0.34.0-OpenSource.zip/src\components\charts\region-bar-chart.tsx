'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface RegionData {
  region: string;
  designers: number;
  traders: number;
}

interface RegionBarChartProps {
  data: RegionData[];
  title?: string;
}

export function RegionBarChart({ data, title = '地区分布' }: RegionBarChartProps) {
  return (
    <div className="bg-[#1a1f2c] rounded-lg p-4 border border-[#2d3548]">
      <h3 className="text-base font-semibold text-[#f8fafc] mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height={260}>
        <BarChart data={data} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2d3548" vertical={false} />
          <XAxis 
            dataKey="region" 
            stroke="#64748b" 
            fontSize={12}
            tickLine={false}
            axisLine={{ stroke: '#2d3548' }}
          />
          <YAxis 
            stroke="#64748b" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1a1f2c',
              border: '1px solid #2d3548',
              borderRadius: '8px',
              color: '#f8fafc',
            }}
            cursor={{ fill: 'rgba(59, 130, 246, 0.1)' }}
          />
          <Legend 
            wrapperStyle={{ paddingTop: '10px' }}
            formatter={(value) => <span style={{ color: '#94a3b8' }}>{value}</span>}
          />
          <Bar 
            dataKey="designers" 
            name="全案设计师"
            fill="#3b82f6" 
            radius={[4, 4, 0, 0]}
            barSize={20}
          />
          <Bar 
            dataKey="traders" 
            name="建材外贸"
            fill="#f97316" 
            radius={[4, 4, 0, 0]}
            barSize={20}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}