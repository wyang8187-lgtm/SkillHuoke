# v0.11 Chinese UX Cleanup Design

## Goal

V0.11 fixes the first-screen product experience for Chinese users by removing visible mojibake, clarifying the demo login path, and making the dashboard read like a professional AI lead-generation SaaS workspace.

## Scope

- Keep the current Next.js app structure and port `5000`.
- Keep demo mode available without requiring Supabase.
- Clean the visible Chinese copy on the login page, sidebar navigation, dashboard metrics, recommendations, and activity feed.
- Refresh dashboard demo data so it matches the foreign-trade AI lead-generation product direction.
- Avoid database schema changes and broad API rewrites in this release.

## Architecture

The UI remains a client-rendered Next.js app. Dashboard data continues to come from `/api/dashboard/stats`, but the demo payload is rewritten with clear Chinese strings and matching field names. The sidebar is kept as one navigation component so existing routes continue to work.

## Success Criteria

- `/login` shows readable Chinese and the demo entry is obvious.
- Clicking demo mode enters `/dashboard`.
- `/dashboard` shows readable Chinese metrics, charts, follow-up recommendations, and recent activity.
- `pnpm run ts-check` and `pnpm run build` pass.
