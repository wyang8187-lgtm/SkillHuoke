// 线索详情 API - GET获取详情, PUT更新, DELETE删除
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取线索详情
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const lead = await dbService.getLeadById(user.id, id);

    if (!lead) {
      return NextResponse.json({ error: '线索不存在' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: lead });
  } catch (error) {
    console.error('获取线索详情失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '获取线索详情失败' 
    }, { status: 500 });
  }
}

// 更新线索
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const body = await req.json();
    const lead = await dbService.updateLead(user.id, id, body);

    return NextResponse.json({ 
      success: true, 
      data: lead,
      message: '线索更新成功'
    });
  } catch (error) {
    console.error('更新线索失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '更新线索失败' 
    }, { status: 400 });
  }
}

// 删除线索
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    await dbService.deleteLead(user.id, id);

    return NextResponse.json({ 
      success: true, 
      message: '线索删除成功'
    });
  } catch (error) {
    console.error('删除线索失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '删除线索失败' 
    }, { status: 400 });
  }
}