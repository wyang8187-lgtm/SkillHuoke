'use client';

import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Cell } from 'recharts';

interface StageData {
  stage: string;
  count: number;
  amount: number;
}

interface StageDistributionChartProps {
  data: StageData[];
  title?: string;
}

const STAGE_COLORS: Record<string, string> = {
  '初步接触': '#3b82f6',
  '需求确认': '#8b5cf6',
  '方案报价': '#f97316',
  '谈判': '#ef4444',
  '成交': '#22c55e',
  '输单': '#6b7280',
};

export function StageDistributionChart({ data, title = '商机阶段分布' }: StageDistributionChartProps) {
  return (
    <div className="bg-[#1a1f2c] rounded-lg p-4 border border-[#2d3548]">
      <h3 className="text-base font-semibold text-[#f8fafc] mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height={280}>
        <BarChart data={data} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2d3548" vertical={false} />
          <XAxis 
            dataKey="stage" 
            stroke="#64748b" 
            fontSize={11}
            tickLine={false}
            axisLine={{ stroke: '#2d3548' }}
            angle={-15}
            textAnchor="end"
            height={40}
          />
          <YAxis 
            yAxisId="left"
            stroke="#64748b" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
            orientation="left"
          />
          <YAxis 
            yAxisId="right"
            stroke="#64748b" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
            orientation="right"
            tickFormatter={(value: number) => `${value}万`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1a1f2c',
              border: '1px solid #2d3548',
              borderRadius: '8px',
              color: '#f8fafc',
            }}
            cursor={{ fill: 'rgba(59, 130, 246, 0.1)' }}
          />
          <Legend 
            wrapperStyle={{ paddingTop: '10px' }}
            formatter={(value) => <span style={{ color: '#94a3b8' }}>{value}</span>}
          />
          <Bar 
            yAxisId="left"
            dataKey="count" 
            name="商机数量"
            radius={[4, 4, 0, 0]}
            barSize={24}
          >
            {data.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={STAGE_COLORS[entry.stage] || '#3b82f6'}
              />
            ))}
          </Bar>
          <Bar 
            yAxisId="right"
            dataKey="amount" 
            name="金额(万)"
            fill="#22c55e" 
            radius={[4, 4, 0, 0]}
            barSize={24}
            opacity={0.6}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}