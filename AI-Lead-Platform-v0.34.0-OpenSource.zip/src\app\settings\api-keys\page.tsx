'use client';

import { useEffect, useMemo, useState } from 'react';
import type React from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Clock,
  Database,
  KeyRound,
  Loader2,
  Mail,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles,
  WifiOff,
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

type TestStatus = 'success' | 'failed' | 'unconfigured';

interface ServiceField {
  name: string;
  label: string;
  required: boolean;
  configured: boolean;
  secret: boolean;
  value: string;
}

interface IntegrationStatus {
  id: string;
  name: string;
  category: string;
  description: string;
  docsUrl: string;
  configured: boolean;
  missingEnv: string[];
  fields: ServiceField[];
  setupGuide: string;
  testable: boolean;
  mode: string;
}

interface TestResult {
  serviceId: string;
  status: TestStatus;
  category: string;
  message: string;
  suggestion: string;
  httpStatus?: number;
  latencyMs: number;
  testedAt: string;
}

interface ProxySummary {
  hasProxy: boolean;
  preferredSource: string;
  note: string;
  items: Array<{ name: string; configured: boolean; value: string }>;
}

const STORAGE_KEY = 'skillhuoke_integration_diagnostics_v034';

const categoryIcon: Record<string, React.ReactNode> = {
  'AI 模型': <Sparkles className="h-4 w-4" />,
  搜索服务: <Search className="h-4 w-4" />,
  邮件服务: <Mail className="h-4 w-4" />,
  数据库: <Database className="h-4 w-4" />,
};

const statusStyle: Record<TestStatus, string> = {
  success: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200',
  failed: 'border-red-500/30 bg-red-500/10 text-red-200',
  unconfigured: 'border-amber-500/30 bg-amber-500/10 text-amber-200',
};

function formatTime(value?: string) {
  if (!value) return '尚未测试';
  return new Date(value).toLocaleString('zh-CN', { hour12: false });
}

function safeStoredResults(value: string | null) {
  if (!value) return {};
  try {
    const parsed = JSON.parse(value) as Record<string, TestResult>;
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export default function ApiKeysPage() {
  const [services, setServices] = useState<IntegrationStatus[]>([]);
  const [proxy, setProxy] = useState<ProxySummary | null>(null);
  const [results, setResults] = useState<Record<string, TestResult>>({});
  const [loadingStatus, setLoadingStatus] = useState(true);
  const [testing, setTesting] = useState<Record<string, boolean>>({});
  const [testingAll, setTestingAll] = useState(false);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    setResults(safeStoredResults(localStorage.getItem(STORAGE_KEY)));
    refreshStatus();
  }, []);

  useEffect(() => {
    const safeResults = Object.fromEntries(
      Object.entries(results).map(([key, value]) => [
        key,
        {
          serviceId: value.serviceId,
          status: value.status,
          category: value.category,
          message: value.message,
          suggestion: value.suggestion,
          httpStatus: value.httpStatus,
          latencyMs: value.latencyMs,
          testedAt: value.testedAt,
        },
      ])
    );
    localStorage.setItem(STORAGE_KEY, JSON.stringify(safeResults));
  }, [results]);

  async function refreshStatus() {
    setLoadingStatus(true);
    setNotice('');
    try {
      const response = await fetch('/api/integrations/status', { cache: 'no-store' });
      const data = await response.json();
      setServices(data.services || []);
      setProxy(data.proxy || null);
    } catch {
      setNotice('读取接口配置失败，请确认后端服务已启动。');
    } finally {
      setLoadingStatus(false);
    }
  }

  async function testOne(serviceId: string) {
    setTesting((current) => ({ ...current, [serviceId]: true }));
    try {
      const response = await fetch('/api/integrations/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serviceId }),
      });
      const data = await response.json();
      setResults((current) => ({ ...current, [serviceId]: data }));
    } catch {
      setResults((current) => ({
        ...current,
        [serviceId]: {
          serviceId,
          status: 'failed',
          category: 'network_error',
          message: '无法连接本地后端诊断接口。',
          suggestion: '请确认 npm start 或 npm run dev 正在运行，然后刷新页面。',
          latencyMs: 0,
          testedAt: new Date().toISOString(),
        },
      }));
    } finally {
      setTesting((current) => ({ ...current, [serviceId]: false }));
    }
  }

  async function testAll() {
    setTestingAll(true);
    const queue = services.map((item) => item.id);
    let index = 0;
    const worker = async () => {
      while (index < queue.length) {
        const serviceId = queue[index];
        index += 1;
        await testOne(serviceId);
      }
    };
    await Promise.all([worker(), worker()]);
    setTestingAll(false);
  }

  const summary = useMemo(() => {
    const values = Object.values(results);
    return {
      configured: services.filter((item) => item.configured).length,
      missing: services.filter((item) => !item.configured).length,
      success: values.filter((item) => item.status === 'success').length,
      failed: values.filter((item) => item.status === 'failed').length,
    };
  }, [services, results]);

  const metricCards: Array<{ label: string; value: number; color: string }> = [
    { label: '已配置接口', value: summary.configured, color: 'text-emerald-300' },
    { label: '缺少配置', value: summary.missing, color: 'text-amber-300' },
    { label: '测试成功', value: summary.success, color: 'text-blue-300' },
    { label: '测试失败', value: summary.failed, color: 'text-red-300' },
  ];

  return (
    <div className="space-y-6">
      <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm text-blue-300">
              <ShieldCheck className="h-4 w-4" />
              v0.34.0 接口配置与连接诊断中心
            </div>
            <h1 className="mt-3 text-2xl font-semibold text-[#f8fafc]">安全检测后端 .env 接口配置</h1>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
              这里不再粘贴或保存完整密钥。系统只从服务器 .env 读取配置，前端只显示掩码摘要、缺失字段和连接测试结果。
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button variant="outline" onClick={refreshStatus} disabled={loadingStatus}>
              {loadingStatus ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
              刷新配置
            </Button>
            <Button onClick={testAll} disabled={testingAll || loadingStatus || services.length === 0}>
              {testingAll ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <WifiOff className="mr-2 h-4 w-4" />}
              一键检测全部
            </Button>
          </div>
        </div>
      </section>

      {notice ? (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">{notice}</div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {metricCards.map(({ label, value, color }) => (
          <Card key={label} className="border-[#2d3548] bg-[#121823]">
            <CardContent className="p-5">
              <p className="text-sm text-[#94a3b8]">{label}</p>
              <p className={`mt-2 text-3xl font-semibold ${color}`}>{value}</p>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        {services.map((service) => {
          const result = results[service.id];
          return (
            <Card key={service.id} className="border-[#2d3548] bg-[#121823]">
              <CardHeader className="space-y-3">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                      {categoryIcon[service.category] || <KeyRound className="h-4 w-4" />}
                      {service.name}
                    </CardTitle>
                    <p className="mt-2 text-sm leading-6 text-[#94a3b8]">{service.description}</p>
                  </div>
                  <Badge className={service.configured ? 'bg-emerald-500/15 text-emerald-300' : 'bg-amber-500/15 text-amber-300'}>
                    {service.configured ? '已配置' : '缺少配置'}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-2">
                  {service.fields.map((field) => (
                    <div key={field.name} className="flex flex-col gap-1 rounded-md border border-[#2d3548] bg-[#0f1419] p-3 sm:flex-row sm:items-center sm:justify-between">
                      <div>
                        <p className="text-sm font-medium text-[#e2e8f0]">{field.name}</p>
                        <p className="text-xs text-[#64748b]">{field.label}{field.required ? ' · 必填' : ' · 可选'}</p>
                      </div>
                      <span className={field.configured ? 'text-sm text-emerald-300' : 'text-sm text-amber-300'}>
                        {field.configured ? field.value || '已配置' : '未填写'}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="rounded-md border border-[#2d3548] bg-[#0f1419] p-4">
                  <p className="text-sm text-[#e2e8f0]">{service.setupGuide}</p>
                  {service.missingEnv.length ? (
                    <p className="mt-2 text-sm text-amber-300">缺少：{service.missingEnv.join('、')}</p>
                  ) : (
                    <p className="mt-2 text-sm text-emerald-300">{service.mode}</p>
                  )}
                </div>

                {result ? (
                  <div className={`rounded-md border p-4 ${statusStyle[result.status]}`}>
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2 text-sm font-medium">
                        {result.status === 'success' ? <CheckCircle2 className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
                        {result.message}
                      </div>
                      <span className="text-xs">{result.latencyMs}ms</span>
                    </div>
                    <p className="mt-2 text-sm opacity-90">{result.suggestion}</p>
                    <p className="mt-2 flex items-center gap-1 text-xs opacity-75">
                      <Clock className="h-3 w-3" />
                      {formatTime(result.testedAt)} · {result.category}{result.httpStatus ? ` · HTTP ${result.httpStatus}` : ''}
                    </p>
                  </div>
                ) : (
                  <div className="rounded-md border border-[#2d3548] bg-[#0f1419] p-4 text-sm text-[#94a3b8]">
                    尚未测试。点击单项测试或一键检测全部后，会在这里显示最新结果。
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-2">
                  <a href={service.docsUrl} target="_blank" rel="noreferrer" className="text-sm text-blue-300 hover:text-blue-200">
                    查看官方申请入口
                  </a>
                  <Button variant="outline" onClick={() => testOne(service.id)} disabled={testing[service.id] || testingAll}>
                    {testing[service.id] ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <WifiOff className="mr-2 h-4 w-4" />}
                    测试连接
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">代理诊断</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-[#94a3b8]">{proxy?.note || '正在读取代理状态。'}</p>
            <p className="text-sm text-blue-300">当前优先来源：{proxy?.preferredSource || '未检测'}</p>
            <div className="grid gap-2">
              {(proxy?.items || []).map((item) => (
                <div key={item.name} className="flex items-center justify-between rounded-md border border-[#2d3548] bg-[#0f1419] p-3 text-sm">
                  <span className="text-[#e2e8f0]">{item.name}</span>
                  <span className={item.configured ? 'text-emerald-300' : 'text-[#64748b]'}>
                    {item.configured ? item.value : '未设置'}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">怎么修改配置</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm leading-6 text-[#94a3b8]">
            <p>请在项目根目录的 `.env` 文件里填写接口变量，不要在网页里粘贴完整密钥。</p>
            <p>修改 `.env` 后必须重启后端服务，否则页面仍会读取旧配置。</p>
            <p>本页面的历史测试结果只保存在浏览器 localStorage，并且只保存状态、延迟、错误分类和中文建议，不保存密钥或原始响应。</p>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
