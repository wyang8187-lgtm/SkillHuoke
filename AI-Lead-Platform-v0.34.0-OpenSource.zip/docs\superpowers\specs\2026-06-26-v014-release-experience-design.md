# v0.14.0 Release Experience Design

## Goal

Add a release experience center so non-developer users can quickly know how to log in, which pages to review, what changed in the current version, and what to upload to GitHub after each release.

## User Value

- 用户每次部署后不用翻聊天记录，就能在系统里看到登录方式和重点查看页面。
- 开源项目访问者可以理解当前版本能力和演示入口。
- 后续版本可以持续把“本次改了什么、应该看哪里”沉淀到同一个页面。

## Scope

- Add shared release experience data.
- Add `/release` page.
- Add release center entry to sidebar.
- Add demo role account explanation to login page.
- Update README and package version to `0.14.0`.

## Out Of Scope

- Real role-based authentication.
- Real user switching across persisted accounts.
- GitHub upload automation.

## Acceptance Criteria

- `/release` lists current version, login URL, demo mode, key pages, role previews, upload package naming rule, and GitHub note.
- Login page shows four demo identities: owner, admin, sales, operator.
- Sidebar exposes the release experience page.
- Type check, lint, build, and HTTP checks pass.
