// 单个客户 API - GET获取详情, PUT更新, DELETE删除
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取客户详情（包含跟进记录）
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const customer = await dbService.getCustomerById(user.id, id);
    const followUpRecords = await dbService.getFollowUpRecords(user.id, id);

    return NextResponse.json({
      success: true,
      data: {
        ...customer,
        followUpRecords
      }
    });
  } catch (error) {
    console.error('获取客户详情失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '客户不存在或无权访问' 
    }, { status: 404 });
  }
}

// 更新客户
export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const body = await req.json();

    const customer = await dbService.updateCustomer(user.id, id, {
      company_name: body.company_name,
      customer_type: body.customer_type || body.type,
      contact_name: body.contact_name,
      phone: body.phone,
      region: body.region,
      address: body.address,
      grade: body.grade,
      status: body.status,
      tags: body.tags,
      notes: body.notes,
      last_follow_up_time: body.last_follow_up_time,
      next_follow_up_time: body.next_follow_up_time,
    });

    return NextResponse.json({ 
      success: true, 
      data: customer,
      message: '客户更新成功'
    });
  } catch (error) {
    console.error('更新客户失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '更新客户失败' 
    }, { status: 400 });
  }
}

// 删除客户
export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    await dbService.deleteCustomer(user.id, id);

    return NextResponse.json({ 
      success: true, 
      message: '客户已删除'
    });
  } catch (error) {
    console.error('删除客户失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '删除客户失败' 
    }, { status: 500 });
  }
}