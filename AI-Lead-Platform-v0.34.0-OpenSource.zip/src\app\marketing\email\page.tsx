'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Mail,
  Sparkles,
  Send,
  Calendar,
  Eye,
  MousePointerClick,
  Plus,
  Edit,
  Trash2,
  FileText,
  Users,
  CheckCircle,
  AlertCircle,
  Clock,
  TrendingUp,
  X,
  Loader2,
} from 'lucide-react';

// 类型定义
interface EmailTemplate {
  id: string;
  name: string;
  category: string;
  subject: string;
  content: string;
  style: string;
  is_default: boolean;
  usage_count: number;
  created_at: string;
  updated_at?: string;
}

interface EmailRecord {
  id: string;
  customer_id: string;
  recipient_email: string;
  recipient_name: string;
  subject: string;
  content: string;
  status: string;
  sent_at?: string;
  opened_at?: string;
  clicked_at?: string;
  scheduled_at?: string;
  created_at: string;
  customer?: {
    id: string;
    company_name: string;
    contact_name: string;
  };
}

interface Customer {
  id: string;
  company_name: string;
  contact_name: string;
  email?: string;
  customer_type?: string;
}

interface EmailStats {
  total: number;
  sent: number;
  opened: number;
  clicked: number;
  failed: number;
  scheduled: number;
  openRate: number;
  clickRate: number;
}

// AI写信模态框
function AIWriteEmailDialog({ 
  open, 
  onClose, 
  onSave 
}: { 
  open: boolean; 
  onClose: () => void;
  onSave: (email: { subject: string; content: string }) => void;
}) {
  const [productDesc, setProductDesc] = useState('');
  const [customerType, setCustomerType] = useState<'designer' | 'exporter'>('designer');
  const [style, setStyle] = useState<'正式' | '友好' | '简洁'>('正式');
  const [generatedEmail, setGeneratedEmail] = useState('');
  const [generatedSubject, setGeneratedSubject] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setGeneratedEmail('');
    setGeneratedSubject('');
    
    try {
      const response = await fetch('/api/ai/write-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          productDescription: productDesc,
          customerType: customerType === 'designer' ? '全案设计师' : '建材外贸公司',
          style,
        }),
      });

      const data = await response.json();

      if (data.success) {
        // 解析主题和内容
        const lines = data.email.split('\n');
        let subject = '';
        let content = '';
        
        // 尝试提取主题（第一行或包含Subject的行）
        for (let i = 0; i < lines.length; i++) {
          const line = lines[i].trim();
          if (line.startsWith('主题：') || line.startsWith('Subject:') || line.startsWith('标题：')) {
            subject = line.replace(/^(主题：|Subject:|标题：)\s*/i, '');
            content = lines.slice(i + 1).join('\n');
            break;
          }
          if (i === 0 && !line.includes('尊敬的')) {
            subject = line;
            content = lines.slice(1).join('\n');
            break;
          }
        }
        
        if (!subject) {
          subject = '合作邀请';
          content = data.email;
        }
        
        setGeneratedSubject(subject);
        setGeneratedEmail(content.trim());
      } else {
        setGeneratedEmail(`生成失败：${data.error || '请稍后重试'}`);
      }
    } catch (error) {
      console.error('AI写信错误:', error);
      setGeneratedEmail('服务暂时不可用，请稍后重试');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSave = () => {
    onSave({ subject: generatedSubject, content: generatedEmail });
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-[#3b82f6]" />
            AI写信助手
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm text-[#94a3b8] mb-2 block">目标客户类型</label>
              <Select value={customerType} onValueChange={(v) => setCustomerType(v as 'designer' | 'exporter')}>
                <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                  <SelectItem value="designer">全案设计师</SelectItem>
                  <SelectItem value="exporter">建材外贸公司</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-2 block">邮件风格</label>
              <Select value={style} onValueChange={(v) => setStyle(v as '正式' | '友好' | '简洁')}>
                <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                  <SelectItem value="正式">正式风格</SelectItem>
                  <SelectItem value="友好">友好风格</SelectItem>
                  <SelectItem value="简洁">简洁风格</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">产品/服务描述</label>
            <Textarea
              placeholder="描述您的产品或服务特点，AI将自动生成专业开发信..."
              value={productDesc}
              onChange={(e) => setProductDesc(e.target.value)}
              className="h-24 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
            />
          </div>
          
          <Button 
            onClick={handleGenerate}
            disabled={isGenerating || !productDesc}
            className="w-full bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
          >
            {isGenerating ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Sparkles className="h-4 w-4 mr-2" />
            )}
            {isGenerating ? '生成中...' : 'AI生成邮件'}
          </Button>
          
          {generatedEmail && (
            <div className="space-y-4">
              <div>
                <label className="text-sm text-[#94a3b8] mb-2 block">邮件主题</label>
                <Input
                  value={generatedSubject}
                  onChange={(e) => setGeneratedSubject(e.target.value)}
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
                />
              </div>
              <div>
                <label className="text-sm text-[#94a3b8] mb-2 block">邮件内容</label>
                <Textarea
                  value={generatedEmail}
                  onChange={(e) => setGeneratedEmail(e.target.value)}
                  className="h-48 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSave} className="flex-1 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
                  <FileText className="h-4 w-4 mr-2" />
                  保存为模板
                </Button>
                <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]" onClick={onClose}>
                  取消
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// 发送邮件模态框
function SendEmailDialog({
  open,
  onClose,
  templates,
  customers,
  onSend,
}: {
  open: boolean;
  onClose: () => void;
  templates: EmailTemplate[];
  customers: Customer[];
  onSend: (data: { customerIds: string[]; templateId?: string; customSubject?: string; customContent?: string }) => Promise<void>;
}) {
  const [selectedCustomers, setSelectedCustomers] = useState<string[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [customSubject, setCustomSubject] = useState('');
  const [customContent, setCustomContent] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [isSending, setIsSending] = useState(false);

  const handleTemplateChange = (templateId: string) => {
    setSelectedTemplate(templateId);
    if (templateId && templateId !== 'custom') {
      const template = templates.find(t => t.id === templateId);
      if (template) {
        setCustomSubject(template.subject);
        setCustomContent(template.content);
      }
    } else {
      setCustomSubject('');
      setCustomContent('');
    }
  };

  const handleSend = async () => {
    if (selectedCustomers.length === 0) {
      alert('请选择收件人');
      return;
    }
    
    setIsSending(true);
    try {
      await onSend({
        customerIds: selectedCustomers,
        templateId: selectedTemplate !== 'custom' ? selectedTemplate : undefined,
        customSubject,
        customContent,
      });
      onClose();
    } finally {
      setIsSending(false);
    }
  };

  // 过滤有邮箱的客户
  const customersWithEmail = customers.filter(c => c.email);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Send className="h-5 w-5 text-[#3b82f6]" />
            发送邮件
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          {/* 选择收件人 */}
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">选择收件人（已选 {selectedCustomers.length} 人）</label>
            <div className="max-h-48 overflow-y-auto bg-[#0f1419] border-[#2d3548] rounded-md p-2">
              {customersWithEmail.length === 0 ? (
                <p className="text-[#94a3b8] text-center py-4">暂无有邮箱的客户</p>
              ) : (
                customersWithEmail.map(customer => (
                  <div key={customer.id} className="flex items-center gap-2 p-2 hover:bg-[#1a1f2c] rounded">
                    <Checkbox
                      checked={selectedCustomers.includes(customer.id)}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          setSelectedCustomers([...selectedCustomers, customer.id]);
                        } else {
                          setSelectedCustomers(selectedCustomers.filter(id => id !== customer.id));
                        }
                      }}
                    />
                    <span className="text-[#f8fafc]">{customer.company_name}</span>
                    <span className="text-[#94a3b8] text-sm">({customer.email})</span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* 选择模板 */}
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">选择模板</label>
            <Select value={selectedTemplate} onValueChange={handleTemplateChange}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                <SelectValue placeholder="选择邮件模板或自定义" />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="custom">自定义内容</SelectItem>
                {templates.map(template => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.name} ({template.category})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 邮件内容 */}
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">邮件主题</label>
            <Input
              value={customSubject}
              onChange={(e) => setCustomSubject(e.target.value)}
              placeholder="输入邮件主题..."
              className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
            />
          </div>
          
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">邮件内容</label>
            <Textarea
              value={customContent}
              onChange={(e) => setCustomContent(e.target.value)}
              placeholder="输入邮件内容..."
              className="h-32 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
            />
          </div>

          {/* 定时发送 */}
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">定时发送（可选）</label>
            <Input
              type="datetime-local"
              value={scheduledTime}
              onChange={(e) => setScheduledTime(e.target.value)}
              className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]" onClick={onClose}>
            取消
          </Button>
          <Button 
            onClick={handleSend} 
            disabled={isSending || selectedCustomers.length === 0}
            className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
          >
            {isSending ? (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            ) : (
              <Send className="h-4 w-4 mr-2" />
            )}
            {isSending ? '发送中...' : '立即发送'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// 主页面组件
function MarketingEmailPageContent() {
  const [activeTab, setActiveTab] = useState<'templates' | 'send' | 'records'>('templates');
  const [templates, setTemplates] = useState<EmailTemplate[]>([]);
  const [emailRecords, setEmailRecords] = useState<EmailRecord[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [emailStats, setEmailStats] = useState<EmailStats | null>(null);
  const [loading, setLoading] = useState(true);
  
  // 模态框状态
  const [showAIWrite, setShowAIWrite] = useState(false);
  const [showSendDialog, setShowSendDialog] = useState(false);
  const [showTemplateDialog, setShowTemplateDialog] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);
  const [deletingTemplateId, setDeletingTemplateId] = useState<string | null>(null);
  
  // 新建/编辑模板表单
  const [templateForm, setTemplateForm] = useState({
    name: '',
    category: '初次接触',
    subject: '',
    content: '',
    style: '正式',
  });

  // 加载数据
  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const headers: Record<string, string> = session ? { 'x-session': session } : {};
      
      // 加载模板
      const templatesRes = await fetch('/api/email-templates', { headers });
      if (templatesRes.ok) {
        const templatesData = await templatesRes.json();
        setTemplates(templatesData.data || []);
      }
      
      // 加载邮件记录
      const recordsRes = await fetch('/api/email-records', { headers });
      if (recordsRes.ok) {
        const recordsData = await recordsRes.json();
        setEmailRecords(recordsData.data || []);
        setEmailStats(recordsData.stats);
      }
      
      // 加载客户（用于发送选择）
      const customersRes = await fetch('/api/customers?pageSize=100', { headers });
      if (customersRes.ok) {
        const customersData = await customersRes.json();
        setCustomers(customersData.data || []);
      }
    } catch (error) {
      console.error('加载数据失败:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
  }, [loadData]);

  // 保存模板（新建或编辑）
  const handleSaveTemplate = async () => {
    try {
      const session = localStorage.getItem('supabase_session');
      const headers = { 
        'Content-Type': 'application/json',
        'x-session': session || ''
      };
      
      if (editingTemplate) {
        // 编辑
        const res = await fetch(`/api/email-templates/${editingTemplate.id}`, {
          method: 'PUT',
          headers,
          body: JSON.stringify(templateForm),
        });
        if (res.ok) {
          console.log('模板已更新');
        } else {
          throw new Error('更新失败');
        }
      } else {
        // 新建
        const res = await fetch('/api/email-templates', {
          method: 'POST',
          headers,
          body: JSON.stringify(templateForm),
        });
        if (res.ok) {
          console.log('模板已创建');
        } else {
          throw new Error('创建失败');
        }
      }
      
      setShowTemplateDialog(false);
      setEditingTemplate(null);
      setTemplateForm({ name: '', category: '初次接触', subject: '', content: '', style: '正式' });
      loadData();
    } catch (error) {
      console.error('操作失败:', error);
    }
  };

  // 删除模板
  const handleDeleteTemplate = async () => {
    if (!deletingTemplateId) return;
    
    try {
      const session = localStorage.getItem('supabase_session');
      const res = await fetch(`/api/email-templates/${deletingTemplateId}`, {
        method: 'DELETE',
        headers: { 'x-session': session || '' },
      });
      
      if (res.ok) {
        console.log('模板已删除');
        setDeletingTemplateId(null);
        loadData();
      } else {
        throw new Error('删除失败');
      }
    } catch (error) {
      console.error('删除失败:', error);
    }
  };

  // 发送邮件
  const handleSendEmail = async (data: { customerIds: string[]; templateId?: string; customSubject?: string; customContent?: string }) => {
    try {
      const session = localStorage.getItem('supabase_session');
      const res = await fetch('/api/email/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': session || '',
        },
        body: JSON.stringify(data),
      });
      
      const result = await res.json();
      if (res.ok && result.success) {
        console.log('邮件已发送:', result.message);
        loadData();
      } else {
        throw new Error(result.error || '发送失败');
      }
    } catch (error) {
      console.error('发送失败:', error);
    }
  };

  // AI生成后保存为模板
  const handleSaveAIEmail = async (email: { subject: string; content: string }) => {
    setTemplateForm({
      name: 'AI生成模板',
      category: '产品介绍',
      subject: email.subject,
      content: email.content,
      style: '正式',
    });
    setShowTemplateDialog(true);
  };

  const statusConfig: Record<string, { color: string; icon: React.ReactNode }> = {
    'sent': { color: 'bg-[#3b82f6]', icon: <CheckCircle className="h-4 w-4" /> },
    'opened': { color: 'bg-[#f97316]', icon: <Eye className="h-4 w-4" /> },
    'clicked': { color: 'bg-[#8b5cf6]', icon: <MousePointerClick className="h-4 w-4" /> },
    'failed': { color: 'bg-[#ef4444]', icon: <AlertCircle className="h-4 w-4" /> },
    'scheduled': { color: 'bg-[#6b7280]', icon: <Clock className="h-4 w-4" /> },
  };

  const categoryOptions = ['初次接触', '产品介绍', '合作邀请', '价格咨询', '跟进提醒'];

  return (
    <MainLayout title="邮件营销">
      {/* 统计卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card className="stat-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#3b82f6]/20">
                <Mail className="h-5 w-5 text-[#3b82f6]" />
              </div>
              <div>
                <p className="text-sm text-[#94a3b8]">总发送</p>
                <p className="text-xl font-semibold text-[#f8fafc]">{emailStats?.total || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="stat-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#f97316]/20">
                <Eye className="h-5 w-5 text-[#f97316]" />
              </div>
              <div>
                <p className="text-sm text-[#94a3b8]">打开率</p>
                <p className="text-xl font-semibold text-[#f8fafc]">{emailStats?.openRate || 0}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="stat-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#8b5cf6]/20">
                <MousePointerClick className="h-5 w-5 text-[#8b5cf6]" />
              </div>
              <div>
                <p className="text-sm text-[#94a3b8]">点击率</p>
                <p className="text-xl font-semibold text-[#f8fafc]">{emailStats?.clickRate || 0}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="stat-card">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-lg bg-[#6b7280]/20">
                <Clock className="h-5 w-5 text-[#6b7280]" />
              </div>
              <div>
                <p className="text-sm text-[#94a3b8]">待发送</p>
                <p className="text-xl font-semibold text-[#f8fafc]">{emailStats?.scheduled || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 操作按钮 */}
      <div className="flex gap-2 mb-6 flex-wrap">
        <Button 
          onClick={() => setShowAIWrite(true)}
          className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
        >
          <Sparkles className="h-4 w-4 mr-2" />
          AI写信
        </Button>
        <Button 
          onClick={() => setShowSendDialog(true)}
          className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
        >
          <Send className="h-4 w-4 mr-2" />
          发送邮件
        </Button>
        <Button 
          onClick={() => {
            setEditingTemplate(null);
            setTemplateForm({ name: '', category: '初次接触', subject: '', content: '', style: '正式' });
            setShowTemplateDialog(true);
          }}
          variant="outline" 
          className="border-[#2d3548] text-[#94a3b8]"
        >
          <Plus className="h-4 w-4 mr-2" />
          新建模板
        </Button>
      </div>

      {/* 标签页 */}
      <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as 'templates' | 'send' | 'records')}>
        <TabsList className="bg-[#1a1f2c] border-[#2d3548]">
          <TabsTrigger value="templates" className="data-[state=active]:bg-[#3b82f6]">
            <FileText className="h-4 w-4 mr-2" />
            邮件模板 ({templates.length})
          </TabsTrigger>
          <TabsTrigger value="records" className="data-[state=active]:bg-[#3b82f6]">
            <Mail className="h-4 w-4 mr-2" />
            发送记录 ({emailRecords.length})
          </TabsTrigger>
        </TabsList>

        {/* 邮件模板 */}
        <TabsContent value="templates" className="mt-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
            </div>
          ) : templates.length === 0 ? (
            <Card className="stat-card">
              <CardContent className="py-8 text-center">
                <FileText className="h-12 w-12 text-[#94a3b8] mx-auto mb-4" />
                <p className="text-[#94a3b8]">暂无邮件模板</p>
                <Button 
                  onClick={() => setShowTemplateDialog(true)}
                  className="mt-4 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  创建第一个模板
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {templates.map(template => (
                <Card key={template.id} className="stat-card hover:border-[#3b82f6] transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge className="bg-[#3b82f6]/20 text-[#3b82f6] border border-[#3b82f6]/30">
                            {template.category}
                          </Badge>
                          <Badge className="bg-[#6b7280]/20 text-[#6b7280] border border-[#6b7280]/30">
                            {template.style}
                          </Badge>
                          {template.is_default && (
                            <Badge className="bg-[#22c55e]/20 text-[#22c55e] border border-[#22c55e]/30">
                              预设
                            </Badge>
                          )}
                        </div>
                        <h3 className="text-[#f8fafc] font-medium mb-1">{template.name}</h3>
                        <p className="text-sm text-[#94a3b8] mb-2">{template.subject}</p>
                        <p className="text-xs text-[#64748b]">使用次数: {template.usage_count || 0}</p>
                      </div>
                      <div className="flex gap-1">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 px-2 text-[#94a3b8] hover:text-[#f8fafc]"
                          onClick={() => {
                            setEditingTemplate(template);
                            setTemplateForm({
                              name: template.name,
                              category: template.category,
                              subject: template.subject,
                              content: template.content,
                              style: template.style,
                            });
                            setShowTemplateDialog(true);
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        {!template.is_default && (
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="h-8 px-2 text-[#ef4444] hover:text-[#ef4444]"
                            onClick={() => setDeletingTemplateId(template.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* 发送记录 */}
        <TabsContent value="records" className="mt-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
            </div>
          ) : (
            <Card className="stat-card">
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="border-[#2d3548]">
                      <TableHead className="text-[#94a3b8]">收件人</TableHead>
                      <TableHead className="text-[#94a3b8]">主题</TableHead>
                      <TableHead className="text-[#94a3b8]">状态</TableHead>
                      <TableHead className="text-[#94a3b8]">发送时间</TableHead>
                      <TableHead className="text-[#94a3b8]">打开时间</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {emailRecords.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-[#94a3b8] py-8">
                          暂无发送记录
                        </TableCell>
                      </TableRow>
                    ) : (
                      emailRecords.map(record => {
                        const config = statusConfig[record.status] || statusConfig['sent'];
                        return (
                          <TableRow key={record.id} className="border-[#2d3548]">
                            <TableCell>
                              <div className="text-[#f8fafc]">{record.recipient_name}</div>
                              <div className="text-xs text-[#94a3b8]">{record.recipient_email}</div>
                            </TableCell>
                            <TableCell className="text-[#f8fafc] max-w-xs truncate">
                              {record.subject}
                            </TableCell>
                            <TableCell>
                              <Badge className={`${config.color} text-white`}>
                                <span className="flex items-center gap-1">
                                  {config.icon}
                                  {record.status === 'sent' ? '已发送' : 
                                   record.status === 'opened' ? '已打开' :
                                   record.status === 'clicked' ? '已点击' :
                                   record.status === 'scheduled' ? '待发送' : '发送失败'}
                                </span>
                              </Badge>
                            </TableCell>
                            <TableCell className="text-[#94a3b8]">
                              {record.sent_at ? new Date(record.sent_at).toLocaleString('zh-CN') : 
                               record.scheduled_at ? `定时: ${new Date(record.scheduled_at).toLocaleString('zh-CN')}` : '-'}
                            </TableCell>
                            <TableCell className="text-[#94a3b8]">
                              {record.opened_at ? new Date(record.opened_at).toLocaleString('zh-CN') : '-'}
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* AI写信模态框 */}
      <AIWriteEmailDialog 
        open={showAIWrite} 
        onClose={() => setShowAIWrite(false)}
        onSave={handleSaveAIEmail}
      />

      {/* 发送邮件模态框 */}
      <SendEmailDialog
        open={showSendDialog}
        onClose={() => setShowSendDialog(false)}
        templates={templates}
        customers={customers}
        onSend={handleSendEmail}
      />

      {/* 新建/编辑模板模态框 */}
      <Dialog open={showTemplateDialog} onOpenChange={setShowTemplateDialog}>
        <DialogContent className="max-w-2xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
          <DialogHeader>
            <DialogTitle>{editingTemplate ? '编辑模板' : '新建模板'}</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-sm text-[#94a3b8] mb-2 block">模板名称</label>
                <Input
                  value={templateForm.name}
                  onChange={(e) => setTemplateForm({...templateForm, name: e.target.value})}
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
                />
              </div>
              <div>
                <label className="text-sm text-[#94a3b8] mb-2 block">分类</label>
                <Select value={templateForm.category} onValueChange={(v) => setTemplateForm({...templateForm, category: v})}>
                  <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                    {categoryOptions.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div>
              <label className="text-sm text-[#94a3b8] mb-2 block">邮件风格</label>
              <Select value={templateForm.style} onValueChange={(v) => setTemplateForm({...templateForm, style: v})}>
                <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                  <SelectItem value="正式">正式风格</SelectItem>
                  <SelectItem value="友好">友好风格</SelectItem>
                  <SelectItem value="简洁">简洁风格</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm text-[#94a3b8] mb-2 block">邮件主题</label>
              <Input
                value={templateForm.subject}
                onChange={(e) => setTemplateForm({...templateForm, subject: e.target.value})}
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            
            <div>
              <label className="text-sm text-[#94a3b8] mb-2 block">邮件内容（支持占位符：{'{contact_name}'}, {'{company_name}'}, {'{sender_name}'}）</label>
              <Textarea
                value={templateForm.content}
                onChange={(e) => setTemplateForm({...templateForm, content: e.target.value})}
                className="h-48 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]" onClick={() => setShowTemplateDialog(false)}>
              取消
            </Button>
            <Button 
              onClick={handleSaveTemplate}
              disabled={!templateForm.name || !templateForm.subject || !templateForm.content}
              className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
            >
              {editingTemplate ? '保存' : '创建'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* 删除确认 */}
      <AlertDialog open={!!deletingTemplateId} onOpenChange={() => setDeletingTemplateId(null)}>
        <AlertDialogContent className="bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription className="text-[#94a3b8]">
              确定要删除此邮件模板吗？删除后无法恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2d3548] text-[#94a3b8]">取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteTemplate} className="bg-[#ef4444]">
              删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}

// 导出页面
export default function MarketingEmailPage() {
  return <MarketingEmailPageContent />;
}