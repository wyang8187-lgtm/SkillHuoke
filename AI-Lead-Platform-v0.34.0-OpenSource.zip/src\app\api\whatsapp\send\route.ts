// WhatsApp发送消息 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { customer_id, customer_name, customer_phone, template_id, content } = body;

    if (!customer_phone || !content) {
      return NextResponse.json({ error: '请提供客户手机号和消息内容' }, { status: 400 });
    }

    // 模拟发送过程
    // 实际接入WhatsApp Business API时，需要调用WhatsApp的发送接口
    
    // 创建发送记录
    const record = {
      id: `record_${Date.now()}`,
      template_id: template_id || '',
      template_name: '', // 从模板表获取
      customer_name: customer_name || '',
      customer_phone,
      content,
      status: 'delivered', // 模拟发送成功
      sent_time: new Date().toISOString(),
    };

    // 保存发送记录到数据库
    const { error: insertError } = await client
      .from('whatsapp_records')
      .insert({
        user_id: user.id,
        ...record,
      });

    if (insertError) {
      console.error('保存发送记录失败:', insertError);
    }

    // 如果使用了模板，更新模板使用次数
    if (template_id) {
      await client
        .from('whatsapp_templates')
        .update({ usage_count: 1 }) // 实际应该累加
        .eq('id', template_id);
    }

    return NextResponse.json({ 
      success: true,
      record,
      message: '消息发送成功！（模拟）'
    });
  } catch (error) {
    console.error('发送WhatsApp消息失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '发送失败' 
    }, { status: 500 });
  }
}