// 跟进记录 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取跟进记录列表（按客户筛选）
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const customerId = searchParams.get('customerId');

    if (!customerId) {
      return NextResponse.json({ error: '请指定客户ID' }, { status: 400 });
    }

    const records = await dbService.getFollowUpRecords(user.id, customerId);

    return NextResponse.json({
      success: true,
      data: records,
    });
  } catch (error) {
    console.error('获取跟进记录失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '获取跟进记录失败' 
    }, { status: 500 });
  }
}

// 创建跟进记录
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    
    // 验证必填字段
    if (!body.customerId) {
      return NextResponse.json({ error: '请指定客户ID' }, { status: 400 });
    }
    if (!body.content) {
      return NextResponse.json({ error: '请填写跟进内容' }, { status: 400 });
    }

    const record = await dbService.createFollowUpRecord(user.id, {
      customer_id: body.customerId,
      content: body.content,
      next_action: body.nextPlan,
      next_time: body.nextTime,
      type: body.type || 'call', // 'call' | 'email' | 'visit' | 'wechat' | 'other'
    });

    // 同时更新客户的最近跟进时间
    await dbService.updateCustomer(user.id, body.customerId, {
      last_follow_up_time: new Date().toISOString(),
    });

    return NextResponse.json({
      success: true,
      data: record,
      message: '跟进记录添加成功'
    });
  } catch (error) {
    console.error('创建跟进记录失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '创建跟进记录失败' 
    }, { status: 400 });
  }
}