'use client';

import { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  Building2, 
  User, 
  Phone, 
  Mail, 
  MapPin, 
  ExternalLink, 
  Users, 
  Video, 
  Heart,
  Briefcase,
  Plus,
  CheckCircle2
} from 'lucide-react';

interface SocialMediaResult {
  id: string;
  type: 'person' | 'company' | 'page' | 'account';
  name: string;
  title?: string;
  company?: string;
  username?: string;
  location?: string;
  industry?: string;
  category?: string;
  phone?: string;
  email?: string;
  profile_url?: string;
  page_url?: string;
  website?: string;
  description?: string;
  introduction?: string;
  verified?: boolean;
  // LinkedIn特有
  connections?: number;
  // Facebook特有
  followers?: number;
  likes?: number;
  // TikTok特有
  videos?: number;
}

interface SocialSearchResultCardProps {
  result: SocialMediaResult;
  platform: 'LinkedIn' | 'Facebook' | 'TikTok';
  onAddToLeads?: (result: SocialMediaResult) => void;
  onAddToCustomer?: (result: SocialMediaResult) => void;
}

export function SocialSearchResultCard({ 
  result, 
  platform,
  onAddToLeads,
  onAddToCustomer 
}: SocialSearchResultCardProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [addedType, setAddedType] = useState<'lead' | 'customer' | null>(null);

  const handleAdd = async (type: 'lead' | 'customer') => {
    setIsAdding(true);
    try {
      if (type === 'lead' && onAddToLeads) {
        await onAddToLeads(result);
      } else if (type === 'customer' && onAddToCustomer) {
        await onAddToCustomer(result);
      }
      setAddedType(type);
    } catch (error) {
      console.error('添加失败:', error);
    } finally {
      setIsAdding(false);
    }
  };

  const getPlatformIcon = () => {
    switch (platform) {
      case 'LinkedIn':
        return <Briefcase className="h-4 w-4" />;
      case 'Facebook':
        return <Users className="h-4 w-4" />;
      case 'TikTok':
        return <Video className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getPlatformColor = () => {
    switch (platform) {
      case 'LinkedIn':
        return 'bg-blue-600';
      case 'Facebook':
        return 'bg-blue-500';
      case 'TikTok':
        return 'bg-black';
      default:
        return 'bg-gray-500';
    }
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return `${(num / 1000000).toFixed(1)}M`;
    } else if (num >= 1000) {
      return `${(num / 1000).toFixed(1)}K`;
    }
    return num.toString();
  };

  return (
    <Card className="bg-[var(--card)] border-[var(--border)] hover:border-[var(--primary)] transition-all">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {/* 头像/图标 */}
          <div className={`w-12 h-12 rounded-lg ${getPlatformColor()} flex items-center justify-center text-white`}>
            {result.type === 'person' || result.type === 'account' ? (
              <User className="h-6 w-6" />
            ) : (
              <Building2 className="h-6 w-6" />
            )}
          </div>

          {/* 主要信息 */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h3 className="font-semibold text-[var(--foreground)] truncate">
                {result.name}
              </h3>
              {result.verified && (
                <CheckCircle2 className="h-4 w-4 text-green-500" />
              )}
              <Badge variant="outline" className="text-xs">
                {getPlatformIcon()}
              </Badge>
            </div>

            {/* LinkedIn: 职位+公司 */}
            {platform === 'LinkedIn' && result.title && (
              <p className="text-sm text-[var(--muted-foreground)] mb-1">
                {result.title} · {result.company}
              </p>
            )}

            {/* TikTok: 用户名 */}
            {platform === 'TikTok' && result.username && (
              <p className="text-sm text-[var(--muted-foreground)] mb-1">
                {result.username}
              </p>
            )}

            {/* 类别/行业 */}
            {(result.category || result.industry) && (
              <p className="text-xs text-[var(--muted-foreground)] mb-2">
                {result.category || result.industry}
              </p>
            )}

            {/* 统计数据 */}
            <div className="flex items-center gap-3 text-xs text-[var(--muted-foreground)] mb-2">
              {platform === 'LinkedIn' && result.connections && (
                <span className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {result.connections}+  connections
                </span>
              )}
              {platform === 'Facebook' && result.followers && (
                <span className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {formatNumber(result.followers)} 粉丝
                </span>
              )}
              {platform === 'Facebook' && result.likes && (
                <span className="flex items-center gap-1">
                  <Heart className="h-3 w-3" />
                  {formatNumber(result.likes)} 赞
                </span>
              )}
              {platform === 'TikTok' && result.followers && (
                <span className="flex items-center gap-1">
                  <Users className="h-3 w-3" />
                  {formatNumber(result.followers)} 粉丝
                </span>
              )}
              {platform === 'TikTok' && result.videos && (
                <span className="flex items-center gap-1">
                  <Video className="h-3 w-3" />
                  {result.videos} 视频
                </span>
              )}
              {result.location && (
                <span className="flex items-center gap-1">
                  <MapPin className="h-3 w-3" />
                  {result.location}
                </span>
              )}
            </div>

            {/* 简介 */}
            {(result.description || result.introduction) && (
              <p className="text-sm text-[var(--muted-foreground)] line-clamp-2 mb-2">
                {result.description || result.introduction}
              </p>
            )}

            {/* 联系方式 */}
            <div className="flex items-center gap-3 text-sm">
              {result.phone && (
                <span className="flex items-center gap-1 text-[var(--foreground)]">
                  <Phone className="h-3 w-3 text-green-500" />
                  {result.phone}
                </span>
              )}
              {result.email && (
                <span className="flex items-center gap-1 text-[var(--muted-foreground)]">
                  <Mail className="h-3 w-3" />
                  {result.email}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* 操作按钮 */}
        <div className="flex items-center gap-2 mt-3 pt-3 border-t border-[var(--border)]">
          {(result.profile_url || result.page_url) && (
            <Button 
              variant="ghost" 
              size="sm"
              className="text-[var(--muted-foreground)]"
              onClick={() => window.open(result.profile_url || result.page_url, '_blank')}
            >
              <ExternalLink className="h-4 w-4 mr-1" />
              查看
            </Button>
          )}
          
          {!addedType ? (
            <>
              <Button 
                variant="outline" 
                size="sm"
                disabled={isAdding || !result.phone}
                onClick={() => handleAdd('lead')}
              >
                <Plus className="h-4 w-4 mr-1" />
                转线索
              </Button>
              <Button 
                variant="default" 
                size="sm"
                disabled={isAdding || !result.phone}
                onClick={() => handleAdd('customer')}
              >
                <Plus className="h-4 w-4 mr-1" />
                转客户
              </Button>
            </>
          ) : (
            <Badge variant="default" className="bg-green-500">
              <CheckCircle2 className="h-3 w-3 mr-1" />
              已转为{addedType === 'lead' ? '线索' : '客户'}
            </Badge>
          )}
        </div>
      </CardContent>
    </Card>
  );
}