'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Video, AlertCircle, Loader2 } from 'lucide-react';
import { SocialSearchResultCard } from '@/components/ui/social-search-card';
import { EmptyState } from '@/components/ui/empty-state';

export default function TikTokAcquisitionPage() {
  const [keyword, setKeyword] = useState('');
  const [category, setCategory] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    if (!keyword.trim()) {
      setError('请输入搜索关键词');
      return;
    }

    setLoading(true);
    setError('');
    setResults([]);

    try {
      const response = await fetch('/api/social-media/tiktok', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword, category }),
      });

      const data = await response.json();
      
      if (data.success) {
        setResults(data.data);
        setSearched(true);
      } else {
        setError(data.error || '搜索失败');
      }
    } catch (err) {
      setError('网络错误，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToLeads = async (result: any) => {
    console.log('添加到线索池:', result);
  };

  const handleAddToCustomer = async (result: any) => {
    console.log('添加到客户:', result);
  };

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="p-6">
        {/* 页面标题 */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Video className="h-6 w-6 text-black dark:text-white" />
            <h1 className="text-2xl font-bold text-[var(--foreground)]">TikTok获客</h1>
          </div>
          <p className="text-[var(--muted-foreground)]">
            搜索TikTok账号，查找家居设计师和建材商家
          </p>
        </div>

        {/* 搜索区域 */}
        <Card className="bg-[var(--card)] border-[var(--border)] mb-6">
          <CardHeader>
            <CardTitle className="text-[var(--foreground)]">搜索条件</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="block text-sm font-medium text-[var(--muted-foreground)] mb-2">
                  搜索关键词
                </label>
                <Input
                  placeholder="输入账号名称或关键词..."
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  className="bg-[var(--background)] border-[var(--border)]"
                />
              </div>
              <div className="w-48">
                <label className="block text-sm font-medium text-[var(--muted-foreground)] mb-2">
                  类别筛选
                </label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger className="bg-[var(--background)] border-[var(--border)]">
                    <SelectValue placeholder="不限类别" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">不限类别</SelectItem>
                    <SelectItem value="家居设计">家居设计</SelectItem>
                    <SelectItem value="建材零售">建材零售</SelectItem>
                    <SelectItem value="家具制造">家具制造</SelectItem>
                    <SelectItem value="装修分享">装修分享</SelectItem>
                    <SelectItem value="全屋定制">全屋定制</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleSearch}
                disabled={loading}
                className="bg-black hover:bg-gray-800"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                搜索
              </Button>
            </div>

            {error && (
              <div className="mt-4 flex items-center gap-2 text-red-500">
                <AlertCircle className="h-4 w-4" />
                <span>{error}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 搜索结果 */}
        {searched && (
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-black/10 text-black dark:text-white border-black dark:border-white">
                <Video className="h-3 w-3 mr-1" />
                TikTok
              </Badge>
              <span className="text-[var(--muted-foreground)]">
                共找到 {results.length} 条有效结果（已过滤无手机号）
              </span>
            </div>
          </div>
        )}

        {/* 结果列表 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {results.map((result) => (
            <SocialSearchResultCard
              key={result.id}
              result={result}
              platform="TikTok"
              onAddToLeads={handleAddToLeads}
              onAddToCustomer={handleAddToCustomer}
            />
          ))}
        </div>

        {/* 空状态 */}
        {searched && results.length === 0 && !loading && (
          <EmptyState
            icon={<Video className="h-12 w-12 text-[var(--muted-foreground)]" />}
            title="未找到匹配结果"
            description="请尝试调整搜索关键词或筛选条件"
          />
        )}

        {/* 提示信息 */}
        <Card className="bg-[var(--card)] border-[var(--border)] mt-6">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
              <div className="text-sm text-[var(--muted-foreground)]">
                <p className="font-medium text-[var(--foreground)] mb-1">TikTok获客说明</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>当前为模拟数据演示，接入真实API后可获取实时TikTok数据</li>
                  <li>搜索账号获取粉丝数、视频数等信息</li>
                  <li>搜索结果已自动过滤无手机号的记录</li>
                  <li>建议搜索关键词：家居设计、建材、全屋定制、装修等</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}