import { NextResponse } from 'next/server';
import { runIntegrationTest } from '@/lib/integration-test-runner';

export async function POST(req: Request) {
  try {
    const body = await req.json().catch(() => ({}));
    const serviceId = typeof body.serviceId === 'string' ? body.serviceId : '';
    const result = await runIntegrationTest(serviceId);
    const status = result.category === 'unknown' && result.status === 'failed' ? 400 : 200;
    return NextResponse.json(result, { status });
  } catch {
    return NextResponse.json(
      {
        serviceId: '',
        status: 'failed',
        category: 'service_error',
        message: '接口诊断服务暂时不可用。',
        suggestion: '请重启后端服务后再试。',
        latencyMs: 0,
        testedAt: new Date().toISOString(),
      },
      { status: 500 }
    );
  }
}
