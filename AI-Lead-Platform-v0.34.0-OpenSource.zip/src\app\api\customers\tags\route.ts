// 客户标签 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 预设标签组
const presetTags = {
  grade: [
    { id: 'grade_a', name: 'A类客户', color: '#22c55e', category: '客户等级', description: '重点客户，高意向' },
    { id: 'grade_b', name: 'B类客户', color: '#f97316', category: '客户等级', description: '培育客户，中等意向' },
    { id: 'grade_c', name: 'C类客户', color: '#6b7280', category: '客户等级', description: '潜在客户，低意向' },
    { id: 'grade_d', name: 'D类客户', color: '#ef4444', category: '客户等级', description: '无效客户，无意向' },
  ],
  type: [
    { id: 'type_designer', name: '全案设计师', color: '#3b82f6', category: '客户类型', description: '室内设计师' },
    { id: 'type_trade', name: '建材外贸', color: '#f97316', category: '客户类型', description: '建材贸易公司' },
    { id: 'type_factory', name: '家具工厂', color: '#8b5cf6', category: '客户类型', description: '家具生产厂家' },
    { id: 'type_developer', name: '房地产开发商', color: '#ec4899', category: '客户类型', description: '开发商采购' },
  ],
  region: [
    { id: 'region_sz', name: '深圳', color: '#3b82f6', category: '地区', description: '深圳地区' },
    { id: 'region_gz', name: '广州', color: '#22c55e', category: '地区', description: '广州地区' },
    { id: 'region_fs', name: '佛山', color: '#f97316', category: '地区', description: '佛山地区' },
    { id: 'region_dg', name: '东莞', color: '#8b5cf6', category: '地区', description: '东莞地区' },
    { id: 'region_zh', name: '珠海', color: '#ec4899', category: '地区', description: '珠海地区' },
    { id: 'region_hz', name: '惠州', color: '#14b8a6', category: '地区', description: '惠州地区' },
  ],
  status: [
    { id: 'status_new', name: '新客户', color: '#3b82f6', category: '合作状态', description: '刚接触' },
    { id: 'status_following', name: '跟进中', color: '#f97316', category: '合作状态', description: '正在跟进' },
    { id: 'status_negotiating', name: '洽谈中', color: '#8b5cf6', category: '合作状态', description: '商谈合作' },
    { id: 'status_cooperating', name: '合作中', color: '#22c55e', category: '合作状态', description: '已合作' },
    { id: 'status_paused', name: '暂停合作', color: '#6b7280', category: '合作状态', description: '暂时停止' },
    { id: 'status_ended', name: '合作结束', color: '#ef4444', category: '合作状态', description: '不再合作' },
  ],
};

// 获取所有标签
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    // 获取自定义标签
    const { data: customTags, error } = await client
      .from('customer_tags')
      .select('*')
      .eq('user_id', user.id);

    if (error) {
      console.error('获取自定义标签失败:', error);
    }

    // 合并预设标签和自定义标签
    const allTags = {
      ...presetTags,
      custom: customTags?.map(t => ({
        id: t.id,
        name: t.name,
        color: t.color,
        category: '自定义标签',
        description: t.description || '',
      })) || [],
    };

    return NextResponse.json({
      presetTags,
      customTags: customTags || [],
      allTags,
    });
  } catch (error) {
    console.error('获取标签失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取标签失败' 
    }, { status: 500 });
  }
}

// 创建自定义标签
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, color, description } = body;

    if (!name) {
      return NextResponse.json({ error: '请提供标签名称' }, { status: 400 });
    }

    // 创建自定义标签
    const { data: newTag, error: createError } = await client
      .from('customer_tags')
      .insert({
        user_id: user.id,
        name,
        color: color || '#3b82f6',
        description: description || '',
        created_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (createError) {
      console.error('创建标签失败:', createError);
      return NextResponse.json({ error: '创建标签失败' }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      tag: newTag,
    });
  } catch (error) {
    console.error('创建标签失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建标签失败' 
    }, { status: 500 });
  }
}

// 更新标签
export async function PUT(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { id, name, color, description } = body;

    if (!id) {
      return NextResponse.json({ error: '请提供标签ID' }, { status: 400 });
    }

    // 更新标签
    const { data: updatedTag, error: updateError } = await client
      .from('customer_tags')
      .update({
        name,
        color,
        description,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id)
      .eq('user_id', user.id)
      .select()
      .single();

    if (updateError) {
      console.error('更新标签失败:', updateError);
      return NextResponse.json({ error: '更新标签失败' }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      tag: updatedTag,
    });
  } catch (error) {
    console.error('更新标签失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '更新标签失败' 
    }, { status: 500 });
  }
}

// 删除标签
export async function DELETE(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: '请提供标签ID' }, { status: 400 });
    }

    // 删除标签
    const { error: deleteError } = await client
      .from('customer_tags')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id);

    if (deleteError) {
      console.error('删除标签失败:', deleteError);
      return NextResponse.json({ error: '删除标签失败' }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: '标签已删除',
    });
  } catch (error) {
    console.error('删除标签失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '删除标签失败' 
    }, { status: 500 });
  }
}