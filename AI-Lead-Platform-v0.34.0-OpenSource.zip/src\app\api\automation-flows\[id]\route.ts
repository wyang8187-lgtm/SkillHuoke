import { NextRequest, NextResponse } from 'next/server';
import * as dbService from '@/lib/db-service';

// 获取单个自动化规则详情
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // 从请求头获取用户信息
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    // 解析用户ID
    const supabase = dbService.getSupabaseAdmin();
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    
    if (authError || !user) {
      return NextResponse.json({ error: '无效的登录状态' }, { status: 401 });
    }

    // 获取规则详情
    const flow = await dbService.getAutomationFlowById(user.id, id);

    if (!flow) {
      return NextResponse.json({ error: '规则不存在' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: flow
    });

  } catch (error) {
    console.error('获取自动化规则详情错误:', error);
    return NextResponse.json({
      error: '获取规则详情失败',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}

// 更新自动化规则
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // 从请求头获取用户信息
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    // 解析用户ID
    const supabase = dbService.getSupabaseAdmin();
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    
    if (authError || !user) {
      return NextResponse.json({ error: '无效的登录状态' }, { status: 401 });
    }

    // 解析请求体
    const body = await request.json();
    const { name, trigger_type, trigger_config, action_type, action_config } = body;

    // 构建更新数据
    const updates: Partial<{
      name: string;
      trigger_type: string;
      trigger_config: Record<string, unknown>;
      action_type: string;
      action_config: Record<string, unknown>;
    }> = {};

    if (name) updates.name = name;
    if (trigger_type) updates.trigger_type = trigger_type;
    if (trigger_config) updates.trigger_config = trigger_config;
    if (action_type) updates.action_type = action_type;
    if (action_config) updates.action_config = action_config;

    // 更新规则
    const flow = await dbService.updateAutomationFlow(user.id, id, updates);

    if (!flow) {
      return NextResponse.json({ error: '更新失败，规则不存在' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: flow,
      message: '规则更新成功'
    });

  } catch (error) {
    console.error('更新自动化规则错误:', error);
    return NextResponse.json({
      error: '更新规则失败',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}

// 删除自动化规则（软删除）
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // 从请求头获取用户信息
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    // 解析用户ID
    const supabase = dbService.getSupabaseAdmin();
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    
    if (authError || !user) {
      return NextResponse.json({ error: '无效的登录状态' }, { status: 401 });
    }

    // 删除规则
    const success = await dbService.deleteAutomationFlow(user.id, id);

    if (!success) {
      return NextResponse.json({ error: '删除失败' }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: '规则已删除'
    });

  } catch (error) {
    console.error('删除自动化规则错误:', error);
    return NextResponse.json({
      error: '删除规则失败',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}