'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Settings, Clock, Shield, Edit3, Save, Loader2, CheckCircle, AlertTriangle } from 'lucide-react';

export default function SystemParamsPage() {
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);

  // 公海规则配置
  const [poolRules, setPoolRules] = useState({
    inactiveDays: 30,
    autoRelease: true,
    releaseNotify: true,
    claimLimit: 5
  });

  // 查重规则配置
  const [duplicateRules, setDuplicateRules] = useState({
    checkPhone: true,
    checkEmail: true,
    checkCompany: false,
    allowMerge: true
  });

  // 开发信签名设置
  const [signature, setSignature] = useState({
    content: `张三
销售经理 | XX全屋定制有限公司
电话：138-0013-8000
邮箱：zhangsan@example.com
地址：广东省深圳市XX区XX路XX号`,
    autoAppend: true
  });

  // 保存配置
  const handleSave = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSaved(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold flex items-center gap-2">
        <Settings className="w-6 h-6" />
        系统参数设置
      </h1>

      {/* 公海池规则 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            公海池规则配置
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label>自动释放天数</Label>
              <div className="text-sm text-muted-foreground mb-2">
                客户超过该天数未跟进将自动释放到公海池
              </div>
              <div className="flex items-center gap-4">
                <Slider
                  value={[poolRules.inactiveDays]}
                  onValueChange={(value) => setPoolRules({ ...poolRules, inactiveDays: value[0] })}
                  min={7}
                  max={90}
                  step={1}
                  className="flex-1"
                />
                <Badge variant="outline" className="text-lg">
                  {poolRules.inactiveDays}天
                </Badge>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">启用自动释放</div>
                <div className="text-sm text-muted-foreground">超过规定天数自动释放客户</div>
              </div>
              <Switch
                checked={poolRules.autoRelease}
                onCheckedChange={(checked) => setPoolRules({ ...poolRules, autoRelease: checked })}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <div className="font-medium">释放前通知</div>
                <div className="text-sm text-muted-foreground">客户即将释放前通知负责人</div>
              </div>
              <Switch
                checked={poolRules.releaseNotify}
                onCheckedChange={(checked) => setPoolRules({ ...poolRules, releaseNotify: checked })}
              />
            </div>

            <div>
              <Label>单人认领上限</Label>
              <div className="text-sm text-muted-foreground mb-2">
                每人最多可同时认领的客户数量
              </div>
              <Input
                type="number"
                value={poolRules.claimLimit}
                onChange={(e) => setPoolRules({ ...poolRules, claimLimit: parseInt(e.target.value) || 5 })}
                className="w-32"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 客户查重规则 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            客户查重规则
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">手机号查重</div>
              <div className="text-sm text-muted-foreground">新增客户时检查手机号是否已存在</div>
            </div>
            <Switch
              checked={duplicateRules.checkPhone}
              onCheckedChange={(checked) => setDuplicateRules({ ...duplicateRules, checkPhone: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">邮箱查重</div>
              <div className="text-sm text-muted-foreground">新增客户时检查邮箱是否已存在</div>
            </div>
            <Switch
              checked={duplicateRules.checkEmail}
              onCheckedChange={(checked) => setDuplicateRules({ ...duplicateRules, checkEmail: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">公司名查重</div>
              <div className="text-sm text-muted-foreground">新增客户时检查公司名是否已存在</div>
            </div>
            <Switch
              checked={duplicateRules.checkCompany}
              onCheckedChange={(checked) => setDuplicateRules({ ...duplicateRules, checkCompany: checked })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">允许合并重复客户</div>
              <div className="text-sm text-muted-foreground">发现重复时提示合并而非禁止添加</div>
            </div>
            <Switch
              checked={duplicateRules.allowMerge}
              onCheckedChange={(checked) => setDuplicateRules({ ...duplicateRules, allowMerge: checked })}
            />
          </div>

          <div className="bg-muted/10 rounded-lg p-4 mt-4">
            <div className="flex items-center gap-2 text-sm">
              <AlertTriangle className="w-4 h-4 text-orange-500" />
              <span className="text-muted-foreground">
                建议：开启手机号和邮箱查重可有效防止撞单
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 开发信签名 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Edit3 className="w-5 h-5" />
            开发信默认签名
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>签名内容</Label>
            <div className="text-sm text-muted-foreground mb-2">
              此签名将自动附加到所有开发信末尾
            </div>
            <textarea
              className="w-full h-32 rounded-md border bg-background px-3 py-2 text-sm"
              value={signature.content}
              onChange={(e) => setSignature({ ...signature, content: e.target.value })}
            />
          </div>

          <div className="flex items-center justify-between">
            <div>
              <div className="font-medium">自动附加签名</div>
              <div className="text-sm text-muted-foreground">发送开发信时自动附加此签名</div>
            </div>
            <Switch
              checked={signature.autoAppend}
              onCheckedChange={(checked) => setSignature({ ...signature, autoAppend: checked })}
            />
          </div>
        </CardContent>
      </Card>

      {/* 保存按钮 */}
      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={loading} size="lg">
          {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
          保存全部设置
        </Button>
      </div>

      {/* 保存成功提示 */}
      {saved && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 shadow-lg">
          <CheckCircle className="w-5 h-5" />
          设置已保存
        </div>
      )}
    </div>
  );
}