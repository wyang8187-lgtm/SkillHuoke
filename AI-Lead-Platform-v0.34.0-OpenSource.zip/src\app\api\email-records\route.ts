// 邮件记录列表 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient, getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 获取邮件记录列表
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '20');
    const status = searchParams.get('status');
    const customerId = searchParams.get('customerId');

    const serviceClient = getSupabaseServiceRoleClient();
    
    let query = serviceClient
      .from('email_records')
      .select(`
        *,
        customer:customers(id, company_name, contact_name)
      `, { count: 'exact' })
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (status) {
      query = query.eq('status', status);
    }

    if (customerId) {
      query = query.eq('customer_id', customerId);
    }

    // 分页
    const offset = (page - 1) * pageSize;
    query = query.range(offset, offset + pageSize - 1);

    const { data, error, count } = await query;

    if (error) {
      throw error;
    }

    // 计算统计数据
    const { data: allRecords } = await serviceClient
      .from('email_records')
      .select('status')
      .eq('user_id', user.id);

    const stats = {
      total: allRecords?.length || 0,
      sent: allRecords?.filter(r => r.status === 'sent').length || 0,
      opened: allRecords?.filter(r => r.status === 'opened' || r.status === 'clicked').length || 0,
      clicked: allRecords?.filter(r => r.status === 'clicked').length || 0,
      failed: allRecords?.filter(r => r.status === 'failed').length || 0,
      scheduled: allRecords?.filter(r => r.status === 'scheduled').length || 0,
      openRate: (allRecords?.length ?? 0) > 0 
        ? Math.round(((allRecords?.filter(r => r.status === 'opened' || r.status === 'clicked').length ?? 0) / (allRecords?.filter(r => r.status !== 'scheduled').length ?? 1)) * 100) 
        : 0,
      clickRate: (allRecords?.length ?? 0) > 0 
        ? Math.round(((allRecords?.filter(r => r.status === 'clicked').length ?? 0) / (allRecords?.filter(r => r.status !== 'scheduled').length ?? 1)) * 100) 
        : 0,
    };

    return NextResponse.json({
      data,
      total: count || 0,
      page,
      pageSize,
      stats,
    });
  } catch (error) {
    console.error('获取邮件记录失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取邮件记录失败' 
    }, { status: 500 });
  }
}