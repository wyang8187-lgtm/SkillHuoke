import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 保存API密钥（加密存储）
export async function POST(request: NextRequest) {
  try {
    const { keyId, value } = await request.json();

    if (!keyId || !value) {
      return NextResponse.json({ error: '缺少参数' }, { status: 400 });
    }

    const supabase = getSupabaseServiceRoleClient();

    // 获取当前用户ID（从session或header）
    // 这里暂时使用模拟用户ID
    const userId = 'default-user';

    // 检查是否已存在该密钥记录
    const { data: existing } = await supabase
      .from('api_keys')
      .select('id')
      .eq('user_id', userId)
      .eq('key_name', keyId)
      .single();

    // 加密存储：使用简单的base64编码（实际生产环境应使用AES加密）
    const encryptedValue = Buffer.from(value).toString('base64');

    if (existing) {
      // 更新
      const { error } = await supabase
        .from('api_keys')
        .update({
          key_value: encryptedValue,
          updated_at: new Date().toISOString()
        })
        .eq('id', existing.id);

      if (error) {
        console.error('更新API密钥失败:', error);
        return NextResponse.json({ error: '保存失败' }, { status: 500 });
      }
    } else {
      // 新建
      const { error } = await supabase
        .from('api_keys')
        .insert({
          user_id: userId,
          key_name: keyId,
          key_value: encryptedValue,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });

      if (error) {
        // 如果表不存在，创建表结构
        if (error.code === '42P01') {
          console.log('api_keys表不存在，创建表结构...');
          await createApiKeysTable(supabase);
          
          // 再次尝试插入
          const { error: retryError } = await supabase
            .from('api_keys')
            .insert({
              user_id: userId,
              key_name: keyId,
              key_value: encryptedValue,
              created_at: new Date().toISOString(),
              updated_at: new Date().toISOString()
            });

          if (retryError) {
            console.error('重试插入失败:', retryError);
            return NextResponse.json({ error: '保存失败' }, { status: 500 });
          }
        } else {
          console.error('插入API密钥失败:', error);
          return NextResponse.json({ error: '保存失败' }, { status: 500 });
        }
      }
    }

    return NextResponse.json({ success: true, message: '密钥已保存' });
  } catch (error) {
    console.error('保存API密钥错误:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}

// 获取所有API密钥
export async function GET(request: NextRequest) {
  try {
    const supabase = getSupabaseServiceRoleClient();
    const userId = 'default-user';

    const { data, error } = await supabase
      .from('api_keys')
      .select('key_name, key_value, created_at, updated_at')
      .eq('user_id', userId);

    if (error) {
      console.error('获取API密钥错误详情:', error);
      // 如果表不存在、列不存在或其他数据库错误，返回空数据
      // PostgreSQL错误代码: 42P01(表不存在), 42703(列不存在), 42P07(列重复)
      // PostgREST错误代码: PGRST116(无结果), PGRST205(表不存在于schema cache)
      const pgErrors = ['42P01', '42703', '42P07', 'PGRST116', 'PGRST205'];
      if (pgErrors.includes(error.code || '') || !error.code) {
        return NextResponse.json({ success: true, keys: {} });
      }
      console.error('获取API密钥失败:', error);
      return NextResponse.json({ error: '获取失败' }, { status: 500 });
    }

    // 解密并返回
    const keys: Record<string, string> = {};
    data?.forEach((item: { key_name: string; key_value: string }) => {
      if (item.key_value) {
        keys[item.key_name] = Buffer.from(item.key_value, 'base64').toString('utf-8');
      }
    });

    return NextResponse.json({ success: true, keys });
  } catch (error) {
    console.error('获取API密钥错误:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}

// 创建api_keys表
async function createApiKeysTable(supabase: any) {
  // 注意：Supabase通常通过dashboard创建表，这里通过SQL创建
  try {
    const createTableSQL = `
      CREATE TABLE IF NOT EXISTS api_keys (
        id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
        user_id TEXT NOT NULL,
        key_name TEXT NOT NULL,
        key_value TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(user_id, key_name)
      );
    `;
    
    await supabase.rpc('exec_sql', { sql: createTableSQL });
  } catch (error) {
    console.error('创建表失败（可能需要在Supabase Dashboard手动创建）:', error);
  }
}