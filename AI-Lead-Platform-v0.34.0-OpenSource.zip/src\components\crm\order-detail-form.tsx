'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { calculateOrderPayments, orderStatusOptions, saveCrmOrder, validateOrder, type SavedCrmOrder } from '@/lib/crm-orders';
import { Save } from 'lucide-react';

const fieldClass = 'border-[#2d3548] bg-[#0f1419] text-[#f8fafc]';

export function OrderDetailForm({ order }: { order: SavedCrmOrder }) {
  const router = useRouter();
  const [value, setValue] = useState(order);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const payments = calculateOrderPayments(value.total, value.depositPercent, value.depositReceived, value.balanceReceived);
  const patch = <K extends keyof SavedCrmOrder>(key: K, next: SavedCrmOrder[K]) => setValue((current) => ({ ...current, [key]: next }));

  const save = () => {
    const errors = validateOrder(value);
    if (errors.length) {
      setError(errors[0]);
      setMessage('');
      return;
    }
    const saved = saveCrmOrder(value);
    setValue(saved);
    setMessage('订单跟进信息已保存。');
    setError('');
    router.refresh();
  };

  const fields: Array<[string, keyof SavedCrmOrder, 'number' | 'date']> = [
    ['定金比例（%）', 'depositPercent', 'number'],
    ['已收定金', 'depositReceived', 'number'],
    ['定金收款日期', 'depositReceivedAt', 'date'],
    ['已收尾款', 'balanceReceived', 'number'],
    ['尾款收款日期', 'balanceReceivedAt', 'date'],
    ['预计交付日期', 'expectedDeliveryDate', 'date'],
    ['实际交付日期', 'deliveredAt', 'date'],
  ];

  return (
    <div className="space-y-6">
      {message ? <div className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 p-4 text-sm text-emerald-200">{message}</div> : null}
      {error ? <div className="rounded-lg border border-red-500/25 bg-red-500/10 p-4 text-sm text-red-200">{error}</div> : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {[
          ['订单总额', value.total],
          ['应收定金', payments.depositDue],
          ['已收金额', payments.received],
          ['未收金额', payments.outstanding],
        ].map(([label, amount]) => <Card key={label} className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">{label}</p><p className="mt-2 text-xl font-semibold text-blue-300">{value.currency} {Number(amount).toFixed(2)}</p></CardContent></Card>)}
      </section>

      <Card className="border-[#2d3548] bg-[#121823]">
        <CardHeader><CardTitle className="text-[#f8fafc]">产品明细快照</CardTitle></CardHeader>
        <CardContent className="overflow-x-auto">
          <table className="min-w-[720px] w-full text-sm"><thead><tr className="border-b border-[#2d3548] text-left text-[#94a3b8]"><th className="p-3">产品</th><th className="p-3">规格</th><th className="p-3">数量</th><th className="p-3">单位</th><th className="p-3">单价</th><th className="p-3">金额</th></tr></thead><tbody>{value.items.map((item) => <tr key={item.id} className="border-b border-[#222a38] text-[#e2e8f0]"><td className="p-3">{item.product}</td><td className="p-3">{item.specification || '-'}</td><td className="p-3">{item.quantity}</td><td className="p-3">{item.unit}</td><td className="p-3">{item.unitPrice.toFixed(2)}</td><td className="p-3">{(item.quantity * item.unitPrice).toFixed(2)}</td></tr>)}</tbody></table>
        </CardContent>
      </Card>

      <Card className="border-[#2d3548] bg-[#121823]">
        <CardHeader><CardTitle className="text-[#f8fafc]">收款与履约跟进</CardTitle></CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {fields.map(([label, key, type]) => <div key={key} className="space-y-2"><Label className="text-[#cbd5e1]">{label}</Label><Input type={type} min={type === 'number' ? 0 : undefined} max={key === 'depositPercent' ? 100 : undefined} className={fieldClass} value={String(value[key] ?? '')} onChange={(event) => patch(key, (type === 'number' ? Number(event.target.value) : event.target.value) as never)} /></div>)}
          <div className="space-y-2"><Label className="text-[#cbd5e1]">订单状态</Label><Select value={value.status} onValueChange={(next) => patch('status', next as SavedCrmOrder['status'])}><SelectTrigger className={fieldClass}><SelectValue /></SelectTrigger><SelectContent>{orderStatusOptions.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select></div>
          <div className="space-y-2 md:col-span-2 xl:col-span-3"><Label className="text-[#cbd5e1]">内部备注</Label><Textarea className={fieldClass} value={value.internalNote} onChange={(event) => patch('internalNote', event.target.value)} /></div>
          <div><Button onClick={save} className="bg-blue-600 text-white hover:bg-blue-500"><Save className="mr-2 h-4 w-4" />保存订单</Button></div>
        </CardContent>
      </Card>
    </div>
  );
}
