import { NextRequest, NextResponse } from 'next/server';

// 团队成员管理API
export async function GET(request: NextRequest) {
  try {
    // 模拟团队成员数据
    const mockMembers = [
      {
        id: 'member_001',
        name: '张经理',
        email: 'zhangmanager@example.com',
        phone: '13912345678',
        role: 'admin',
        role_name: '管理员',
        status: 'active',
        avatar: '/avatars/avatar1.png',
        created_at: '2024-01-01',
        last_login: '2024-12-15',
        customer_count: 50,
        team: '管理层',
      },
      {
        id: 'member_002',
        name: '李主管',
        email: 'lileader@example.com',
        phone: '13812345679',
        role: 'team_leader',
        role_name: '销售主管',
        status: 'active',
        avatar: '/avatars/avatar2.png',
        created_at: '2024-02-15',
        last_login: '2024-12-14',
        customer_count: 30,
        team: 'A组',
      },
      {
        id: 'member_003',
        name: '王销售',
        email: 'wangsales@example.com',
        phone: '13712345680',
        role: 'sales',
        role_name: '销售',
        status: 'active',
        avatar: '/avatars/avatar3.png',
        created_at: '2024-03-01',
        last_login: '2024-12-13',
        customer_count: 15,
        team: 'A组',
      },
      {
        id: 'member_004',
        name: '赵销售',
        email: 'zhaosales@example.com',
        phone: '13612345681',
        role: 'sales',
        role_name: '销售',
        status: 'active',
        avatar: '/avatars/avatar4.png',
        created_at: '2024-04-01',
        last_login: '2024-12-12',
        customer_count: 10,
        team: 'B组',
      },
      {
        id: 'member_005',
        name: '刘主管',
        email: 'liuleader@example.com',
        phone: '13512345682',
        role: 'team_leader',
        role_name: '销售主管',
        status: 'active',
        avatar: '/avatars/avatar5.png',
        created_at: '2024-05-01',
        last_login: '2024-12-11',
        customer_count: 25,
        team: 'B组',
      },
      {
        id: 'member_006',
        name: '陈销售',
        email: 'chensales@example.com',
        phone: '13412345683',
        role: 'sales',
        role_name: '销售',
        status: 'disabled',
        avatar: '/avatars/avatar6.png',
        created_at: '2024-06-01',
        last_login: '2024-10-01',
        customer_count: 0,
        team: 'A组',
      },
    ];

    return NextResponse.json({
      success: true,
      data: mockMembers,
      total: mockMembers.length,
    });
  } catch (error) {
    console.error('获取团队成员失败:', error);
    return NextResponse.json({ error: '获取失败' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, member_id, role, status } = body;

    // 模拟处理各种操作
    switch (action) {
      case 'invite':
        return NextResponse.json({
          success: true,
          message: '邀请邮件已发送',
          data: { invite_id: 'invite_' + Date.now() },
        });
      case 'update_role':
        return NextResponse.json({
          success: true,
          message: '角色已更新',
          data: { member_id, new_role: role },
        });
      case 'update_status':
        return NextResponse.json({
          success: true,
          message: status === 'active' ? '账号已启用' : '账号已禁用',
          data: { member_id, new_status: status },
        });
      default:
        return NextResponse.json({ error: '未知操作' }, { status: 400 });
    }
  } catch (error) {
    console.error('团队成员操作失败:', error);
    return NextResponse.json({ error: '操作失败' }, { status: 500 });
  }
}