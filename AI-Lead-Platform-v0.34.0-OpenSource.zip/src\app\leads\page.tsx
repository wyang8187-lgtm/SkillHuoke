'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  Search,
  Plus,
  Eye,
  Trash2,
  ChevronRight,
  UserPlus,
  Building2,
  Phone,
  MapPin,
  Target,
  CheckCircle,
  ArrowRight,
  Clock,
  Sparkles,
  Loader2,
  Users,
} from 'lucide-react';

// 类型定义
interface Lead {
  id: string;
  company_name: string;
  contact_name: string;
  phone: string;
  region: string;
  address: string;
  type: string;
  source: string;
  status: string;
  match_score: number;
  user_id: string;
  create_time: string;
  update_time: string;
}

interface LeadListResponse {
  leads: Lead[];
  total: number;
  page: number;
  pageSize: number;
}

// 线索详情模态框
function LeadDetailDialog({ 
  leadId, 
  open, 
  onClose,
  onConvert,
  onAssign 
}: {
  leadId: string | null;
  open: boolean;
  onClose: () => void;
  onConvert: () => void;
  onAssign: () => void;
}) {
  const [lead, setLead] = useState<Lead | null>(null);
  const [loading, setLoading] = useState(false);
  const [converting, setConverting] = useState(false);

  useEffect(() => {
    if (leadId && open) {
      loadLeadDetail();
    }
  }, [leadId, open]);

  const loadLeadDetail = async () => {
    if (!leadId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/leads/${leadId}`);
      if (!res.ok) throw new Error('加载失败');
      const data = await res.json();
      setLead(data);
    } catch (error) {
      toast.error('加载线索详情失败');
    } finally {
      setLoading(false);
    }
  };

  const handleConvert = async () => {
    if (!leadId) return;
    setConverting(true);
    try {
      const res = await fetch(`/api/leads/${leadId}/convert`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || '转换失败');
      }
      toast.success('线索已转为客户');
      onConvert();
      onClose();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : '转换失败');
    } finally {
      setConverting(false);
    }
  };

  if (!lead && !loading) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-[#3b82f6]" />
            {loading ? '加载中...' : lead?.company_name}
            {lead && (
              <Badge className="bg-[#3b82f6]/20 text-[#3b82f6] border border-[#3b82f6]/30">
                匹配度 {lead.match_score}%
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>
        
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
          </div>
        ) : lead && (
          <div className="grid grid-cols-2 gap-6 py-4">
            {/* 基本信息 */}
            <div className="space-y-4">
              <h3 className="text-sm text-[#94a3b8] uppercase">基本信息</h3>
              <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548] space-y-3">
                <div className="flex items-center gap-2">
                  <UserPlus className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">联系人：</span>
                  <span className="text-[#f8fafc]">{lead.contact_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">手机号：</span>
                  <span className="text-[#3b82f6]">{lead.phone}</span>
                  <CheckCircle className="h-3 w-3 text-[#22c55e]" />
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">地区：</span>
                  <span className="text-[#f8fafc]">{lead.region}</span>
                </div>
                {lead.address && (
                  <div className="flex items-center gap-2">
                    <Building2 className="h-4 w-4 text-[#64748b]" />
                    <span className="text-[#94a3b8]">地址：</span>
                    <span className="text-[#f8fafc]">{lead.address}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">来源：</span>
                  <span className="text-[#f8fafc]">{lead.source}</span>
                </div>
              </div>
            </div>
            
            {/* 状态信息 */}
            <div className="space-y-4">
              <h3 className="text-sm text-[#94a3b8] uppercase">线索状态</h3>
              <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548] space-y-3">
                <div className="flex items-center gap-2">
                  <Target className="h-4 w-4 text-[#f97316]" />
                  <span className="text-[#94a3b8]">状态：</span>
                  <Badge className="bg-[#f97316]/20 text-[#f97316] border border-[#f97316]/30">
                    {lead.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">录入时间：</span>
                  <span className="text-[#f8fafc]">{lead.create_time}</span>
                </div>
              </div>
              
              {/* 操作按钮 */}
              <div className="flex gap-2">
                <Button 
                  onClick={handleConvert}
                  disabled={converting || lead.status === '已转客户'}
                  className="flex-1 bg-gradient-to-r from-[#22c55e] to-[#16a34a]"
                >
                  {converting ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : (
                    <ArrowRight className="h-4 w-4 mr-2" />
                  )}
                  转为客户
                </Button>
                <Button 
                  variant="outline" 
                  onClick={onAssign}
                  disabled={lead.status === '已转客户'}
                  className="border-[#2d3548] text-[#94a3b8]"
                >
                  <Users className="h-4 w-4 mr-2" />
                  分配给
                </Button>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

// 新增线索模态框
function AddLeadDialog({ 
  open, 
  onClose,
  onSuccess 
}: {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    company_name: '',
    contact_name: '',
    phone: '',
    region: '深圳',
    address: '',
    type: '全案设计师',
    source: '智能搜索',
  });

  const handleSubmit = async () => {
    if (!formData.company_name || !formData.contact_name || !formData.phone) {
      toast.error('请填写必填信息');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/leads', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || '创建失败');
      }
      toast.success('线索已创建');
      setFormData({
        company_name: '',
        contact_name: '',
        phone: '',
        region: '深圳',
        address: '',
        type: '全案设计师',
        source: '智能搜索',
      });
      onSuccess();
      onClose();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : '创建线索失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle>新增线索</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-4 py-4">
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">公司名称 *</label>
            <Input
              value={formData.company_name}
              onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">联系人 *</label>
            <Input
              value={formData.contact_name}
              onChange={(e) => setFormData({ ...formData, contact_name: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">手机号 *</label>
            <Input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">地区</label>
            <Select value={formData.region} onValueChange={(v) => setFormData({ ...formData, region: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="深圳">深圳</SelectItem>
                <SelectItem value="广州">广州</SelectItem>
                <SelectItem value="佛山">佛山</SelectItem>
                <SelectItem value="东莞">东莞</SelectItem>
                <SelectItem value="珠海">珠海</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <label className="text-sm text-[#94a3b8] mb-2 block">详细地址</label>
            <Input
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">客户类型</label>
            <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="全案设计师">全案设计师</SelectItem>
                <SelectItem value="建材外贸公司">建材外贸公司</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">来源渠道</label>
            <Select value={formData.source} onValueChange={(v) => setFormData({ ...formData, source: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="智能搜索">智能搜索</SelectItem>
                <SelectItem value="企查查">企查查</SelectItem>
                <SelectItem value="天眼查">天眼查</SelectItem>
                <SelectItem value="展会名录">展会名录</SelectItem>
                <SelectItem value="设计师平台">设计师平台</SelectItem>
                <SelectItem value="手动录入">手动录入</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="border-[#2d3548]">
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={loading} className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
            {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            创建线索
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// 分配线索模态框
function AssignLeadDialog({
  leadId,
  open,
  onClose,
  onSuccess,
}: {
  leadId: string | null;
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [userId, setUserId] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [teamMembers, setTeamMembers] = useState<{ id: string; name: string; email: string }[]>([]);

  useEffect(() => {
    if (open) {
      loadTeamMembers();
    }
  }, [open]);

  const loadTeamMembers = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/team');
      if (!res.ok) throw new Error('加载失败');
      const data = await res.json();
      setTeamMembers(data.members || []);
    } catch (error) {
      toast.error('加载团队成员失败');
    } finally {
      setLoading(false);
    }
  };

  const handleAssign = async () => {
    if (!leadId || !userId) {
      toast.error('请选择团队成员');
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch(`/api/leads/${leadId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user_id: userId }),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || '分配失败');
      }
      toast.success('线索已分配');
      onSuccess();
      onClose();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : '分配失败');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle>分配线索</DialogTitle>
        </DialogHeader>
        
        {loading ? (
          <div className="flex items-center justify-center py-4">
            <Loader2 className="h-6 w-6 animate-spin text-[#3b82f6]" />
          </div>
        ) : (
          <div className="space-y-4 py-4">
            <Select value={userId} onValueChange={setUserId}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue placeholder="选择团队成员" />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                {teamMembers.map(member => (
                  <SelectItem key={member.id} value={member.id}>
                    {member.name} ({member.email})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={onClose} className="border-[#2d3548]">
                取消
              </Button>
              <Button onClick={handleAssign} disabled={submitting || !userId} className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
                {submitting ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                确认分配
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedSource, setSelectedSource] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [showAssign, setShowAssign] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const loadLeads = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        pageSize: pageSize.toString(),
      });
      if (searchKeyword) params.append('keyword', searchKeyword);
      if (selectedStatus !== 'all') params.append('status', selectedStatus);
      if (selectedSource !== 'all') params.append('source', selectedSource);
      if (selectedType !== 'all') params.append('type', selectedType);

      const res = await fetch(`/api/leads?${params.toString()}`);
      if (!res.ok) throw new Error('加载失败');
      const data: LeadListResponse = await res.json();
      setLeads(data.leads);
      setTotal(data.total);
    } catch (error) {
      toast.error('加载线索列表失败');
    } finally {
      setLoading(false);
    }
  }, [currentPage, searchKeyword, selectedStatus, selectedSource, selectedType]);

  useEffect(() => {
    loadLeads();
  }, [loadLeads]);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/leads/${deleteId}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('删除失败');
      toast.success('线索已删除');
      setDeleteId(null);
      loadLeads();
    } catch (error) {
      toast.error('删除线索失败');
    }
  };

  const totalPages = Math.ceil(total / pageSize);

  const statusColors: Record<string, string> = {
    '新线索': '#3b82f6',
    '跟进中': '#f97316',
    '已转客户': '#22c55e',
    '已关闭': '#6b7280',
  };

  const typeColors: Record<string, string> = {
    '全案设计师': '#3b82f6',
    '建材外贸公司': '#f97316',
  };

  return (
    <MainLayout title="线索池">
      {/* 操作栏 */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        {/* 搜索 */}
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#64748b]" />
          <Input
            placeholder="搜索线索公司、联系人..."
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            className="pl-12 h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]"
          />
        </div>
        
        {/* 篮选 */}
        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
          <SelectTrigger className="w-[120px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="线索状态" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部状态</SelectItem>
            <SelectItem value="新线索" className="text-[#f8fafc]">新线索</SelectItem>
            <SelectItem value="跟进中" className="text-[#f8fafc]">跟进中</SelectItem>
            <SelectItem value="已转客户" className="text-[#f8fafc]">已转客户</SelectItem>
            <SelectItem value="已关闭" className="text-[#f8fafc]">已关闭</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={selectedSource} onValueChange={setSelectedSource}>
          <SelectTrigger className="w-[120px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="来源渠道" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部来源</SelectItem>
            <SelectItem value="智能搜索" className="text-[#f8fafc]">智能搜索</SelectItem>
            <SelectItem value="企查查" className="text-[#f8fafc]">企查查</SelectItem>
            <SelectItem value="天眼查" className="text-[#f8fafc]">天眼查</SelectItem>
            <SelectItem value="展会名录" className="text-[#f8fafc]">展会名录</SelectItem>
            <SelectItem value="设计师平台" className="text-[#f8fafc]">设计师平台</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-[140px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="客户类型" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部类型</SelectItem>
            <SelectItem value="全案设计师" className="text-[#f8fafc]">全案设计师</SelectItem>
            <SelectItem value="建材外贸公司" className="text-[#f8fafc]">建材外贸公司</SelectItem>
          </SelectContent>
        </Select>
        
        <Button 
          onClick={() => setShowAdd(true)}
          className="h-12 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] px-6"
        >
          <Plus className="h-5 w-5 mr-2" />
          新增线索
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#f8fafc]">{total}</div>
            <div className="text-sm text-[#94a3b8]">线索总数</div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#3b82f6]">
              {leads.filter(l => l.status === '新线索').length}
            </div>
            <div className="text-sm text-[#94a3b8]">新线索</div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#f97316]">
              {leads.filter(l => l.status === '跟进中').length}
            </div>
            <div className="text-sm text-[#94a3b8]">跟进中</div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#22c55e]">
              {leads.filter(l => l.status === '已转客户').length}
            </div>
            <div className="text-sm text-[#94a3b8]">已转客户</div>
          </CardContent>
        </Card>
      </div>

      {/* 线索表格 */}
      <Card className="bg-[#1a1f2c] border-[#2d3548]">
        <CardHeader>
          <CardTitle className="text-[#f8fafc]">线索列表</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-[#2d3548]">
                  <TableHead className="text-[#94a3b8]">公司名称</TableHead>
                  <TableHead className="text-[#94a3b8]">类型</TableHead>
                  <TableHead className="text-[#94a3b8]">联系人</TableHead>
                  <TableHead className="text-[#94a3b8]">手机号</TableHead>
                  <TableHead className="text-[#94a3b8]">地区</TableHead>
                  <TableHead className="text-[#94a3b8]">来源</TableHead>
                  <TableHead className="text-[#94a3b8]">状态</TableHead>
                  <TableHead className="text-[#94a3b8]">匹配度</TableHead>
                  <TableHead className="text-[#94a3b8]">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {leads.length > 0 ? (
                  leads.map((lead) => (
                    <TableRow key={lead.id} className="border-[#2d3548]">
                      <TableCell className="text-[#f8fafc] font-medium">
                        {lead.company_name}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className="text-xs"
                          style={{
                            backgroundColor: `${typeColors[lead.type] || '#3b82f6'}20`,
                            color: typeColors[lead.type] || '#3b82f6',
                          }}
                        >
                          {lead.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#f8fafc]">
                        {lead.contact_name}
                      </TableCell>
                      <TableCell className="text-[#3b82f6]">
                        {lead.phone}
                      </TableCell>
                      <TableCell className="text-[#f8fafc]">
                        {lead.region}
                      </TableCell>
                      <TableCell className="text-[#94a3b8]">
                        {lead.source}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className="text-xs"
                          style={{
                            backgroundColor: `${statusColors[lead.status]}20`,
                            color: statusColors[lead.status],
                          }}
                        >
                          {lead.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Target className="h-3 w-3 text-[#3b82f6]" />
                          <span className="text-sm text-[#f8fafc]">{lead.match_score}%</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => {
                              setSelectedLeadId(lead.id);
                              setShowDetail(true);
                            }}
                            className="text-[#3b82f6] hover:text-[#3b82f6] hover:bg-[#3b82f6]/10"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => setDeleteId(lead.id)}
                            className="text-[#ef4444] hover:text-[#ef4444] hover:bg-[#ef4444]/10"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8 text-[#64748b]">
                      暂无线索数据
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
          
          {/* 分页 */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-[#94a3b8]">
                共 {total} 条，第 {currentPage}/{totalPages} 页
              </div>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage(p => p - 1)}
                  className="border-[#2d3548]"
                >
                  上一页
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage(p => p + 1)}
                  className="border-[#2d3548]"
                >
                  下一页
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 线索详情模态框 */}
      <LeadDetailDialog
        leadId={selectedLeadId}
        open={showDetail}
        onClose={() => setShowDetail(false)}
        onConvert={loadLeads}
        onAssign={() => {
          setShowDetail(false);
          setShowAssign(true);
        }}
      />

      {/* 新增线索模态框 */}
      <AddLeadDialog
        open={showAdd}
        onClose={() => setShowAdd(false)}
        onSuccess={loadLeads}
      />

      {/* 分配线索模态框 */}
      <AssignLeadDialog
        leadId={selectedLeadId}
        open={showAssign}
        onClose={() => setShowAssign(false)}
        onSuccess={loadLeads}
      />

      {/* 删除确认 */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription className="text-[#94a3b8]">
              此操作将永久删除该线索，无法恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2d3548]">取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-[#ef4444]">
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}