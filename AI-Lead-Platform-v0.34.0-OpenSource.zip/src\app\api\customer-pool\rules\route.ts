// 公海池规则 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 更新规则状态
export async function PUT(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { id, is_active } = body;

    if (!id) {
      return NextResponse.json({ error: '缺少规则ID' }, { status: 400 });
    }

    // 模拟规则更新（实际项目中应该存储在数据库）
    // 这里返回成功响应
    return NextResponse.json({ 
      success: true, 
      message: `规则${is_active ? '已启用' : '已禁用'}` 
    });
  } catch (error) {
    console.error('更新规则失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '更新规则失败' 
    }, { status: 500 });
  }
}