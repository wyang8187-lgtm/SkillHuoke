// AI 7x24 自动获客 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 模拟的自动获客任务数据
const mockTasks = [
  {
    id: 'task_001',
    name: '深圳设计师获客',
    keywords: ['全屋定制', '室内设计'],
    regions: ['深圳'],
    customer_types: ['全案设计师'],
    frequency: 'daily',
    status: 'running',
    last_run_time: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    next_run_time: new Date(Date.now() + 18 * 60 * 60 * 1000).toISOString(),
    total_results: 45,
    created_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'task_002',
    name: '佛山建材外贸获客',
    keywords: ['建材外贸', '木材贸易'],
    regions: ['佛山'],
    customer_types: ['建材外贸公司'],
    frequency: 'weekly',
    status: 'paused',
    last_run_time: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    next_run_time: null,
    total_results: 23,
    created_at: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'task_003',
    name: '广州全屋定制获客',
    keywords: ['全屋定制', '定制家居'],
    regions: ['广州'],
    customer_types: ['全案设计师', '家具工厂'],
    frequency: 'daily',
    status: 'running',
    last_run_time: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    next_run_time: new Date(Date.now() + 22 * 60 * 60 * 1000).toISOString(),
    total_results: 67,
    created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

// 模拟的执行记录
const mockRecords = [
  {
    id: 'record_001',
    task_id: 'task_001',
    task_name: '深圳设计师获客',
    run_time: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    duration: 45,
    results_count: 8,
    new_leads: 5,
    duplicates_filtered: 3,
    status: 'success',
  },
  {
    id: 'record_002',
    task_id: 'task_001',
    task_name: '深圳设计师获客',
    run_time: new Date(Date.now() - 30 * 60 * 60 * 1000).toISOString(),
    duration: 38,
    results_count: 12,
    new_leads: 7,
    duplicates_filtered: 5,
    status: 'success',
  },
  {
    id: 'record_003',
    task_id: 'task_002',
    task_name: '佛山建材外贸获客',
    run_time: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    duration: 52,
    results_count: 15,
    new_leads: 10,
    duplicates_filtered: 5,
    status: 'success',
  },
  {
    id: 'record_004',
    task_id: 'task_003',
    task_name: '广州全屋定制获客',
    run_time: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    duration: 41,
    results_count: 10,
    new_leads: 6,
    duplicates_filtered: 4,
    status: 'success',
  },
  {
    id: 'record_005',
    task_id: 'task_003',
    task_name: '广州全屋定制获客',
    run_time: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
    duration: 55,
    results_count: 18,
    new_leads: 12,
    duplicates_filtered: 6,
    status: 'success',
  },
];

// 获取任务列表和执行记录
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    // 尝试从数据库获取，如果没有则返回模拟数据
    const { data: dbTasks, error } = await client
      .from('auto_acquisition_tasks')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    let tasks = mockTasks;
    if (dbTasks && dbTasks.length > 0) {
      tasks = dbTasks.map(t => ({
        id: t.id,
        name: t.name,
        keywords: t.keywords || [],
        regions: t.regions || [],
        customer_types: t.customer_types || [],
        frequency: t.frequency || 'daily',
        status: t.status || 'paused',
        last_run_time: t.last_run_time,
        next_run_time: t.next_run_time,
        total_results: t.total_results || 0,
        created_at: t.created_at,
      }));
    }

    const { data: dbRecords } = await client
      .from('auto_acquisition_records')
      .select('*')
      .eq('user_id', user.id)
      .order('run_time', { ascending: false })
      .limit(20);

    let records = mockRecords;
    if (dbRecords && dbRecords.length > 0) {
      records = dbRecords.map(r => ({
        id: r.id,
        task_id: r.task_id,
        task_name: r.task_name,
        run_time: r.run_time,
        duration: r.duration || 0,
        results_count: r.results_count || 0,
        new_leads: r.new_leads || 0,
        duplicates_filtered: r.duplicates_filtered || 0,
        status: r.status || 'success',
        error_message: r.error_message,
      }));
    }

    return NextResponse.json({ tasks, records });
  } catch (error) {
    console.error('获取自动获客数据失败:', error);
    // 返回模拟数据作为兜底
    return NextResponse.json({ tasks: mockTasks, records: mockRecords });
  }
}

// 创建新任务
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, keywords, regions, customer_types, frequency } = body;

    if (!name || !keywords || keywords.length === 0) {
      return NextResponse.json({ error: '请提供任务名称和关键词' }, { status: 400 });
    }

    const newTask = {
      id: `task_${Date.now()}`,
      name,
      keywords,
      regions: regions || [],
      customer_types: customer_types || [],
      frequency: frequency || 'daily',
      status: 'running',
      last_run_time: null,
      next_run_time: new Date(Date.now() + getNextRunDelay(frequency)).toISOString(),
      total_results: 0,
      created_at: new Date().toISOString(),
    };

    // 尝试保存到数据库
    const { error: insertError } = await client
      .from('auto_acquisition_tasks')
      .insert({
        user_id: user.id,
        ...newTask,
      });

    if (insertError) {
      console.error('保存任务失败:', insertError);
      // 继续返回成功，模拟数据会在下次请求时使用
    }

    return NextResponse.json({ task: newTask });
  } catch (error) {
    console.error('创建任务失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建失败' 
    }, { status: 500 });
  }
}

// 删除任务
export async function DELETE(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const taskId = searchParams.get('task_id');

    if (!taskId) {
      return NextResponse.json({ error: '请提供任务ID' }, { status: 400 });
    }

    await client
      .from('auto_acquisition_tasks')
      .delete()
      .eq('id', taskId)
      .eq('user_id', user.id);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('删除任务失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '删除失败' 
    }, { status: 500 });
  }
}

// 计算下次执行时间延迟
function getNextRunDelay(frequency: string): number {
  switch (frequency) {
    case 'hourly': return 60 * 60 * 1000;
    case 'daily': return 24 * 60 * 60 * 1000;
    case 'weekly': return 7 * 24 * 60 * 60 * 1000;
    default: return 24 * 60 * 60 * 1000;
  }
}