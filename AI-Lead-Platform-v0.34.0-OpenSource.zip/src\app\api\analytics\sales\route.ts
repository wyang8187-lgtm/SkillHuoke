import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 销售数据分析API
export async function GET(request: NextRequest) {
  try {
    const supabase = getSupabaseServiceRoleClient();

    // 1. 获取商机数据
    const { data: opportunities, error: oppError } = await supabase
      .from('opportunities')
      .select('id, stage, amount, created_at, updated_at, customer_id')
      .order('created_at', { ascending: true });

    if (oppError) {
      console.error('获取商机数据失败:', oppError);
    }

    // 2. 获取线索数据
    const { data: leads, error: leadsError } = await supabase
      .from('leads')
      .select('id, status, created_at')
      .order('created_at', { ascending: true });

    if (leadsError) {
      console.error('获取线索数据失败:', leadsError);
    }

    // 3. 获取邮件记录 - 只查询存在的列
    const { data: emails, error: emailsError } = await supabase
      .from('email_records')
      .select('id, status, created_at')
      .order('created_at', { ascending: true });

    if (emailsError) {
      console.error('获取邮件数据失败:', emailsError);
    }

    // 4. 计算商机漏斗
    const funnelData = calculateFunnel(opportunities || [], leads || []);

    // 5. 月度销售业绩趋势
    const salesTrend = calculateSalesTrend(opportunities || []);

    // 6. 开发信统计
    const emailStats = calculateEmailStats(emails || []);

    // 7. 成交率统计
    const conversionRate = calculateConversionRate(opportunities || [], leads || []);

    return NextResponse.json({
      success: true,
      data: {
        funnel: funnelData,
        salesTrend: salesTrend,
        emailStats: emailStats,
        conversionRate: conversionRate,
        totalOpportunities: opportunities?.length || 0,
        totalLeads: leads?.length || 0
      }
    });
  } catch (error) {
    console.error('销售数据分析错误:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}

// 计算商机漏斗
function calculateFunnel(opportunities: any[], leads: any[]) {
  const stages = ['线索', '已联系', '有意向', '报价', '谈判', '成交', '流失'];
  const stageCounts: Record<string, number> = {};
  
  // 统计线索
  stageCounts['线索'] = leads.length;
  
  // 统计商机各阶段
  opportunities.forEach(opp => {
    const stage = opp.stage || '有意向';
    stageCounts[stage] = (stageCounts[stage] || 0) + 1;
  });

  // 计算转化率
  const funnel = stages.map((stage, index) => {
    const count = stageCounts[stage] || 0;
    const prevCount = index === 0 ? leads.length : (stageCounts[stages[index - 1]] || 0);
    const rate = prevCount > 0 ? Math.round((count / prevCount) * 100) : 0;
    return {
      stage,
      count,
      rate: index === 0 ? 100 : rate
    };
  });

  return funnel;
}

// 计算销售趋势
function calculateSalesTrend(opportunities: any[]) {
  const months: Record<string, { count: number; amount: number }> = {};
  
  opportunities.forEach(opp => {
    if (opp.stage === '成交' && opp.created_at) {
      const month = new Date(opp.created_at).toISOString().slice(0, 7);
      if (!months[month]) {
        months[month] = { count: 0, amount: 0 };
      }
      months[month].count++;
      months[month].amount += opp.amount || 0;
    }
  });

  // 转换为数组
  return Object.entries(months)
    .map(([month, data]) => ({
      month,
      count: data.count,
      amount: data.amount
    }))
    .sort((a, b) => a.month.localeCompare(b.month))
    .slice(-12); // 最近12个月
}

// 计算邮件统计
function calculateEmailStats(emails: any[]) {
  const total = emails.length;
  const opened = emails.filter(e => e.opened_at).length;
  const clicked = emails.filter(e => e.clicked_at).length;
  const replied = emails.filter(e => e.status === '已回复').length;

  return {
    total,
    sent: total,
    opened,
    clicked,
    replied,
    openRate: total > 0 ? Math.round((opened / total) * 100) : 0,
    clickRate: total > 0 ? Math.round((clicked / total) * 100) : 0,
    replyRate: total > 0 ? Math.round((replied / total) * 100) : 0
  };
}

// 计算转化率
function calculateConversionRate(opportunities: any[], leads: any[]) {
  const totalLeads = leads.length;
  const wonOpps = opportunities.filter(o => o.stage === '成交').length;
  const lostOpps = opportunities.filter(o => o.stage === '流失').length;

  return {
    totalLeads,
    wonOpps,
    lostOpps,
    winRate: totalLeads > 0 ? Math.round((wonOpps / totalLeads) * 100) : 0,
    lossRate: totalLeads > 0 ? Math.round((lostOpps / totalLeads) * 100) : 0
  };
}