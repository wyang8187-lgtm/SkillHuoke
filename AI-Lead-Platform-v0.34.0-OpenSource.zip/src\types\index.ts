// 客户类型
export type CustomerType = '全案设计师' | '建材外贸公司';

// 客户分级
export type CustomerGrade = 'A' | 'B' | 'C' | 'D';

// 跟进状态
export type FollowUpStatus = '初步接触' | '需求确认' | '方案报价' | '谈判中' | '已成交' | '已输单' | '待跟进';

// 线索状态
export type LeadStatus = '新线索' | '已跟进' | '已转客户' | '已放弃';

// 商机阶段
export type OpportunityStage = '初步接触' | '需求确认' | '方案报价' | '谈判' | '成交' | '输单';

// 获客渠道
export type LeadSource = '智能搜索' | 'Google搜索' | '百度搜索' | '抖音' | '小红书' | '微信搜一搜' | 'Instagram' | 'Facebook' | '企查查' | '天眼查' | '展会名录' | '设计师平台' | 'AI自动获客' | '手动录入';

// 客户标签类型
export interface CustomerTag {
  id: string;
  name: string;
  color: string;
}

// 客户数据
export interface Customer {
  id: string;
  name: string; // 公司名
  type: CustomerType;
  contactName: string; // 联系人
  phone: string; // 手机号（已验证）
  region: string; // 地区
  address: string; // 详细地址
  grade: CustomerGrade;
  status: FollowUpStatus;
  source: LeadSource;
  tags: CustomerTag[];
  lastFollowUpTime: string; // 最近跟进时间
  nextFollowUpTime?: string; // 下次跟进计划
  createTime: string; // 创建时间
  notes: FollowUpNote[]; // 跟进记录
  ownerId: string; // 负责人ID
}

// 跟进记录
export interface FollowUpNote {
  id: string;
  content: string;
  createTime: string;
  userId: string;
  userName: string;
  nextPlan?: string;
}

// 线索数据
export interface Lead {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  region: string;
  source: LeadSource;
  status: LeadStatus;
  matchScore: number; // 匹配度评分 0-100
  createTime: string;
  assigneeId?: string;
  assigneeName?: string;
  address?: string;
}

// 商机数据
export interface Opportunity {
  id: string;
  customerId: string;
  customerName: string;
  stage: OpportunityStage;
  amount: number; // 预估金额
  expectedCloseDate: string; // 预计成交日期
  probability: number; // 成功概率
  ownerId: string;
  ownerName: string;
  createTime: string;
  lostReason?: string; // 输单原因
}

// 团队成员
export interface TeamMember {
  id: string;
  name: string;
  email: string;
  role: '管理员' | '销售经理' | '销售员' | '运营';
  avatar?: string;
  status: '在职' | '离职';
  createTime: string;
}

// 邮件模板
export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  content: string;
  category: '开发信' | '产品介绍' | '案例分享' | '跟进信' | '节日问候';
  createTime: string;
}

// 邮件记录
export interface EmailRecord {
  id: string;
  customerId: string;
  customerName: string;
  templateId?: string;
  subject: string;
  content: string;
  status: '已发送' | '已送达' | '已打开' | '已点击' | '发送失败';
  sentTime: string;
  openTime?: string;
  clickTime?: string;
}

// 营销活动
export interface MarketingCampaign {
  id: string;
  name: string;
  type: '邮件营销' | '社媒营销' | 'WhatsApp营销' | '自动化流程';
  status: '草稿' | '进行中' | '已完成' | '已暂停';
  targetCount: number; // 目标客户数
  sentCount: number; // 已发送数
  openRate?: number; // 打开率
  clickRate?: number; // 点击率
  createTime: string;
  startTime?: string;
  endTime?: string;
}

// 自动化营销流程
export interface AutomationFlow {
  id: string;
  name: string;
  trigger: '新线索入库' | '客户打开邮件' | '客户点击链接' | '客户标签变更' | '定时触发';
  triggerCondition?: string;
  steps: AutomationStep[];
  status: '启用' | '禁用';
  createTime: string;
}

// 自动化步骤
export interface AutomationStep {
  id: string;
  type: '发送邮件' | '添加标签' | '分配跟进人' | '创建任务' | '等待';
  delay?: number; // 延迟小时数
  config: Record<string, unknown>;
}

// 任务
export interface Task {
  id: string;
  title: string;
  customerId?: string;
  customerName?: string;
  type: '跟进客户' | '发送邮件' | '电话联系' | '拜访' | '其他';
  status: '待完成' | '已完成' | '已过期';
  dueTime: string;
  userId: string;
  userName: string;
  createTime: string;
}

// 数据统计
export interface DashboardStats {
  todayNewLeads: number;
  followingCustomers: number;
  closedCustomers: number;
  conversionRate: number;
  weeklyLeads: WeeklyLeadData[];
  pendingTasks: number;
  recentActivities: Activity[];
}

// 周线索数据
export interface WeeklyLeadData {
  date: string;
  count: number;
}

// 活动记录
export interface Activity {
  id: string;
  type: '新增线索' | '客户跟进' | '商机进展' | '邮件发送' | '成交';
  content: string;
  customerId?: string;
  customerName?: string;
  userId: string;
  userName: string;
  createTime: string;
}

// 搜索筛选条件

// 社媒账号
export interface SocialMediaAccount {
  id: string;
  platform: string;
  accountName: string;
  followers: number;
  posts: number;
  engagement: number;
  status: string;
}

// 社媒内容
export interface SocialMediaPost {
  id: string;
  title: string;
  content: string;
  platform: string;
  type: string;
  status: string;
  publishTime: string;
  views: number;
  likes: number;
  comments: number;
}
export interface SearchFilter {
  keyword: string;
  region?: string;
  industryType?: CustomerType;
  companySize?: '小型' | '中型' | '大型';
  customerType?: CustomerType;
}

// AI获客配置
export interface AIAcquisitionConfig {
  enabled: boolean;
  keywords: string[];
  regions: string[];
  customerTypes: CustomerType[];
  checkInterval: number; // 检查间隔（小时）
  autoAdd: boolean; // 自动入库
  notify: boolean; // 通知提醒
}

// 公海规则
export interface PoolRule {
  releaseDays: number; // 多少天未跟进自动释放
  autoAssign: boolean; // 自动分配
  assignRule?: string; // 分配规则
}