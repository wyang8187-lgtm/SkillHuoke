import assert from'node:assert/strict';import{parseBackupFile}from'../src/lib/data-backup';
const base={leadTasks:[],candidateLeads:[],crmCustomers:[],crmFollowUps:[],crmOpportunities:[],crmQuotations:[],crmOrders:[],tradeDocuments:[]};
const v6=JSON.stringify({format:'skillhuoke-backup',version:6,appVersion:'v0.31.0',exportedAt:'',summary:{},data:base});const old=parseBackupFile(v6,new Blob([v6]).size);assert.equal(old.version,8);assert.deepEqual(old.data.shipments,[]);
const v7=JSON.stringify({format:'skillhuoke-backup',version:7,appVersion:'v0.32.0',exportedAt:'',summary:{},data:{...base,shipments:[{id:'s1',updatedAt:''}]}});assert.equal(parseBackupFile(v7,new Blob([v7]).size).data.shipments[0].id,'s1');console.log('data-backup-v7 tests passed');
