'use client';
import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { OpportunityForm } from '@/components/crm/opportunity-form';
export default function NewOpportunityPage(){const [customer,setCustomer]=useState('');useEffect(()=>setCustomer(new URLSearchParams(location.search).get('customerId')||''),[]);return <MainLayout title="新建销售机会"><OpportunityForm initialCustomerId={customer}/></MainLayout>;}
