'use client';

import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, MapPin, Users, Building, Star, ExternalLink, AlertCircle, Clock } from 'lucide-react';

interface Exhibition {
  id: string;
  name: string;
  name_en: string;
  start_date: string;
  end_date: string;
  location: string;
  city: string;
  country: string;
  industry: string;
  exhibitor_count: number;
  expected_visitors: number;
  status: '即将开始' | '进行中' | '已结束';
  highlights: string[];
  recommended: boolean;
}

export default function ExhibitionsPage() {
  const [exhibitions, setExhibitions] = useState<Exhibition[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [industryFilter, setIndustryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [industries, setIndustries] = useState<string[]>([]);
  const [cities, setCities] = useState<string[]>([]);

  useEffect(() => {
    fetchExhibitions();
  }, [industryFilter, statusFilter]);

  const fetchExhibitions = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const params = new URLSearchParams();
      if (industryFilter !== 'all') params.set('industry', industryFilter);
      if (statusFilter !== 'all') params.set('status', statusFilter);
      
      const response = await fetch(`/api/exhibitions?${params.toString()}`);
      
      if (!response.ok) {
        throw new Error('获取展会数据失败');
      }
      
      const data = await response.json();
      setExhibitions(data.data);
      setIndustries(data.industries || []);
      setCities(data.cities || []);
    } catch (err) {
      setError(err instanceof Error ? err.message : '获取数据失败');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case '即将开始': return 'bg-green-500/20 text-green-400';
      case '进行中': return 'bg-yellow-500/20 text-yellow-400';
      case '已结束': return 'bg-gray-500/20 text-gray-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });
  };

  const getDaysUntilStart = (startDate: string) => {
    const start = new Date(startDate);
    const now = new Date();
    const diff = Math.ceil((start.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  return (
    <MainLayout 
      title="展会信息"
      breadcrumbs={[
        { label: '外贸数据', href: '/customs' },
        { label: '展会信息' }
      ]}
    >
      <div className="space-y-6">
        {/* 页面标题和筛选 */}
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc] flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#3b82f6]" />
              行业展会信息
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm text-[#64748b]">行业筛选：</span>
                <Select value={industryFilter} onValueChange={setIndustryFilter}>
                  <SelectTrigger className="w-40 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                    <SelectValue placeholder="全部行业" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                    <SelectItem value="all" className="text-[#f8fafc]">全部行业</SelectItem>
                    {industries.map(ind => (
                      <SelectItem key={ind} value={ind} className="text-[#f8fafc]">{ind}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div className="flex items-center gap-2">
                <span className="text-sm text-[#64748b]">状态筛选：</span>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-32 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                    <SelectValue placeholder="全部状态" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                    <SelectItem value="all" className="text-[#f8fafc]">全部状态</SelectItem>
                    <SelectItem value="即将开始" className="text-[#f8fafc]">即将开始</SelectItem>
                    <SelectItem value="进行中" className="text-[#f8fafc]">进行中</SelectItem>
                    <SelectItem value="已结束" className="text-[#f8fafc]">已结束</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Badge className="bg-[#3b82f6]/20 text-[#3b82f6]">
                共 {exhibitions.length} 个展会
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* 错误提示 */}
        {error && (
          <Card className="bg-[#1a1f2c] border-red-500/30">
            <CardContent className="py-6 flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-400" />
              <p className="text-red-400">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* 加载状态 */}
        {isLoading && (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <Card key={i} className="bg-[#1a1f2c] border-[#2d3548]">
                <CardContent className="py-6 space-y-4">
                  <Skeleton className="h-4 w-1/3" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-4 w-1/4" />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* 展会列表 */}
        {!isLoading && exhibitions.length > 0 && (
          <div className="space-y-4">
            {/* 推荐展会 */}
            {exhibitions.filter(e => e.recommended && e.status === '即将开始').length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-[#f8fafc] mb-4 flex items-center gap-2">
                  <Star className="w-5 h-5 text-yellow-400" />
                  重点推荐展会
                </h3>
                <div className="space-y-4">
                  {exhibitions.filter(e => e.recommended && e.status === '即将开始').map(exhibition => (
                    <Card key={exhibition.id} className="bg-[#1a1f2c] border-[#3b82f6]/30 hover:border-[#3b82f6] transition-colors">
                      <CardContent className="py-4">
                        <div className="flex items-start justify-between">
                          <div className="space-y-3">
                            <div className="flex items-center gap-2">
                              <Badge className={getStatusColor(exhibition.status)}>
                                {exhibition.status}
                              </Badge>
                              {exhibition.recommended && (
                                <Badge className="bg-yellow-500/20 text-yellow-400">
                                  <Star className="w-3 h-3 mr-1" />
                                  推荐
                                </Badge>
                              )}
                              <Badge className="bg-[#3b82f6]/20 text-[#3b82f6]">
                                {exhibition.industry}
                              </Badge>
                            </div>
                            
                            <div>
                              <h4 className="text-lg font-semibold text-[#f8fafc]">{exhibition.name}</h4>
                              <p className="text-sm text-[#64748b]">{exhibition.name_en}</p>
                            </div>
                            
                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                              <div className="flex items-center gap-2 text-[#94a3b8]">
                                <Calendar className="w-4 h-4 text-[#3b82f6]" />
                                <span>{formatDate(exhibition.start_date)} - {formatDate(exhibition.end_date)}</span>
                              </div>
                              <div className="flex items-center gap-2 text-[#94a3b8]">
                                <MapPin className="w-4 h-4 text-[#3b82f6]" />
                                <span>{exhibition.city}, {exhibition.country}</span>
                              </div>
                              <div className="flex items-center gap-2 text-[#94a3b8]">
                                <Building className="w-4 h-4 text-[#3b82f6]" />
                                <span>{exhibition.location}</span>
                              </div>
                              <div className="flex items-center gap-2 text-[#94a3b8]">
                                <Users className="w-4 h-4 text-[#3b82f6]" />
                                <span>{exhibition.exhibitor_count}参展商 / {exhibition.expected_visitors}预期观众</span>
                              </div>
                            </div>
                            
                            {/* 展会亮点 */}
                            <div className="flex flex-wrap gap-2">
                              {exhibition.highlights.map((highlight, i) => (
                                <Badge key={i} className="bg-green-500/20 text-green-400 text-xs">
                                  {highlight}
                                </Badge>
                              ))}
                            </div>
                            
                            {/* 倒计时 */}
                            {exhibition.status === '即将开始' && (
                              <div className="flex items-center gap-2 text-sm">
                                <Clock className="w-4 h-4 text-yellow-400" />
                                <span className="text-yellow-400 font-medium">
                                  还有 {getDaysUntilStart(exhibition.start_date)} 天开幕
                                </span>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex flex-col gap-2">
                            <Button className="bg-[#3b82f6] hover:bg-[#2563eb]">
                              <ExternalLink className="w-4 h-4 mr-1" />
                              了解详情
                            </Button>
                            <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]">
                              添加提醒
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* 其他展会 */}
            <div>
              <h3 className="text-lg font-semibold text-[#f8fafc] mb-4">全部展会</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {exhibitions.map(exhibition => (
                  <Card key={exhibition.id} className="bg-[#1a1f2c] border-[#2d3548] hover:border-[#3b82f6]/30 transition-colors">
                    <CardContent className="py-4">
                      <div className="flex items-center justify-between mb-2">
                        <Badge className={getStatusColor(exhibition.status)}>
                          {exhibition.status}
                        </Badge>
                        {exhibition.recommended && (
                          <Star className="w-4 h-4 text-yellow-400" />
                        )}
                      </div>
                      
                      <h4 className="text-[#f8fafc] font-medium mb-1">{exhibition.name}</h4>
                      <p className="text-xs text-[#64748b] mb-3">{exhibition.name_en}</p>
                      
                      <div className="space-y-2 text-sm text-[#94a3b8]">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          <span>{formatDate(exhibition.start_date)}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4" />
                          <span>{exhibition.city}, {exhibition.country}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Users className="w-4 h-4" />
                          <span>{exhibition.exhibitor_count}参展商</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* 无数据状态 */}
        {!isLoading && exhibitions.length === 0 && !error && (
          <Card className="bg-[#1a1f2c] border-[#2d3548]">
            <CardContent className="py-12 text-center">
              <Calendar className="w-12 h-12 text-[#64748b] mx-auto mb-4" />
              <h3 className="text-[#f8fafc] font-medium mb-2">暂无符合条件的展会</h3>
              <p className="text-[#94a3b8]">请调整筛选条件查看其他展会</p>
            </CardContent>
          </Card>
        )}
      </div>
    </MainLayout>
  );
}