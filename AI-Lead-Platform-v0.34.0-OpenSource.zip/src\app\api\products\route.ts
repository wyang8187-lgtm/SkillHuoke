import { NextRequest, NextResponse } from 'next/server';

// 模拟产品数据
const mockProducts = [
  { id: 'P001', name: '定制衣柜', category: '柜体', spec: '高度2.4m，宽度定制', unit: '平方米', price: 800, stock: 999, status: '在售' },
  { id: 'P002', name: '定制橱柜', category: '柜体', spec: '高度0.8m，宽度定制', unit: '平方米', price: 650, stock: 999, status: '在售' },
  { id: 'P003', name: '实木门板', category: '门板', spec: '厚度18mm，多种颜色', unit: '平方米', price: 1200, stock: 500, status: '在售' },
  { id: 'P004', name: '烤漆门板', category: '门板', spec: '厚度18mm，高光/哑光', unit: '平方米', price: 900, stock: 600, status: '在售' },
  { id: 'P005', name: '石英石台面', category: '台面', spec: '厚度20mm，多种花色', unit: '平方米', price: 1500, stock: 200, status: '在售' },
  { id: 'P006', name: '岩板台面', category: '台面', spec: '厚度12mm，耐磨耐高温', unit: '平方米', price: 2800, stock: 150, status: '在售' },
  { id: 'P007', name: '进口五金铰链', category: '五金', spec: '百隆品牌，阻尼缓冲', unit: '个', price: 45, stock: 1000, status: '在售' },
  { id: 'P008', name: '国产五金铰链', category: '五金', spec: 'DTC品牌，普通款式', unit: '个', price: 15, stock: 2000, status: '在售' },
  { id: 'P009', name: '嵌入式洗碗机', category: '电器', spec: '8套容量，智能控制', unit: '台', price: 3500, stock: 50, status: '在售' },
  { id: 'P010', name: '嵌入式烤箱', category: '电器', spec: '60L容量，多功能', unit: '台', price: 4200, stock: 30, status: '在售' },
  { id: 'P011', name: '定制书柜', category: '柜体', spec: '高度定制，多层设计', unit: '平方米', price: 700, stock: 999, status: '在售' },
  { id: 'P012', name: '定制酒柜', category: '柜体', spec: '恒温设计，展示型', unit: '平方米', price: 1500, stock: 100, status: '在售' },
  { id: 'P013', name: '玻璃门板', category: '门板', spec: '透明/磨砂，铝框边', unit: '平方米', price: 1100, stock: 300, status: '在售' },
  { id: 'P014', name: '拉手配件', category: '五金', spec: '多种款式，金属材质', unit: '个', price: 25, stock: 3000, status: '在售' },
  { id: 'P015', name: '嵌入式冰箱', category: '电器', spec: '180L，双门设计', unit: '台', price: 8500, stock: 20, status: '停售' },
];

const categories = ['柜体', '门板', '台面', '五金', '电器'];

// GET - 获取产品列表
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const category = searchParams.get('category');
  const keyword = searchParams.get('keyword');
  const page = parseInt(searchParams.get('page') || '1');
  const pageSize = parseInt(searchParams.get('pageSize') || '20');

  let filteredProducts = [...mockProducts];

  // 按类别筛选
  if (category && category !== '全部') {
    filteredProducts = filteredProducts.filter(p => p.category === category);
  }

  // 按关键词搜索
  if (keyword) {
    filteredProducts = filteredProducts.filter(p => 
      p.name.toLowerCase().includes(keyword.toLowerCase()) ||
      p.spec.toLowerCase().includes(keyword.toLowerCase())
    );
  }

  // 分页
  const total = filteredProducts.length;
  const start = (page - 1) * pageSize;
  const end = start + pageSize;
  const paginatedProducts = filteredProducts.slice(start, end);

  return NextResponse.json({
    success: true,
    data: {
      products: paginatedProducts,
      categories,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize)
    }
  });
}

// POST - 创建新产品
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, category, spec, unit, price, stock } = body;

    if (!name || !category || !price) {
      return NextResponse.json({ error: '缺少必填字段' }, { status: 400 });
    }

    const newProduct = {
      id: `P${String(mockProducts.length + 1).padStart(3, '0')}`,
      name,
      category,
      spec: spec || '',
      unit: unit || '件',
      price: parseFloat(price),
      stock: parseInt(stock) || 0,
      status: '在售'
    };

    mockProducts.push(newProduct);

    return NextResponse.json({
      success: true,
      data: newProduct,
      message: '产品创建成功'
    });
  } catch {
    return NextResponse.json({ error: '请求处理失败' }, { status: 500 });
  }
}

// PUT - 更新产品
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...updates } = body;

    const productIndex = mockProducts.findIndex(p => p.id === id);
    if (productIndex === -1) {
      return NextResponse.json({ error: '产品不存在' }, { status: 404 });
    }

    mockProducts[productIndex] = { ...mockProducts[productIndex], ...updates };

    return NextResponse.json({
      success: true,
      data: mockProducts[productIndex],
      message: '产品更新成功'
    });
  } catch {
    return NextResponse.json({ error: '请求处理失败' }, { status: 500 });
  }
}

// DELETE - 删除产品
export async function DELETE(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json({ error: '缺少产品ID' }, { status: 400 });
  }

  const productIndex = mockProducts.findIndex(p => p.id === id);
  if (productIndex === -1) {
    return NextResponse.json({ error: '产品不存在' }, { status: 404 });
  }

  mockProducts.splice(productIndex, 1);

  return NextResponse.json({
    success: true,
    message: '产品删除成功'
  });
}