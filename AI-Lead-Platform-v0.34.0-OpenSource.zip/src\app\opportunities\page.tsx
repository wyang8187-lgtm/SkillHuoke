'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  Briefcase,
  TrendingUp,
  CheckCircle,
  XCircle,
  Eye,
  Plus,
  ArrowRight,
  Target,
  Calendar,
  User,
  Loader2,
  DollarSign,
  BarChart3,
} from 'lucide-react';

// 类型定义
interface Opportunity {
  id: string;
  name: string;
  customer_id: string;
  customer_name: string;
  amount: number;
  stage: string;
  expected_close_date: string | null;
  description: string;
  user_id: string;
  create_time: string;
  update_time: string;
}

interface OpportunityStats {
  totalAmount: number;
  stageDistribution: { stage: string; count: number; amount: number }[];
  winRate: number;
}

interface OpportunityListResponse {
  opportunities: Opportunity[];
  total: number;
  page: number;
  pageSize: number;
}

// 商机管道可视化
function OpportunityPipelineVisual({ opportunities }: { opportunities: Opportunity[] }) {
  const stages = ['初步接触', '需求确认', '方案报价', '谈判', '成交'];
  const stageColors: Record<string, string> = {
    '初步接触': '#6b7280',
    '需求确认': '#3b82f6',
    '方案报价': '#8b5cf6',
    '谈判': '#f97316',
    '成交': '#22c55e',
    '输单': '#ef4444',
  };

  const stageData = stages.map(stage => ({
    stage,
    opportunities: opportunities.filter(o => o.stage === stage),
    totalAmount: opportunities.filter(o => o.stage === stage).reduce((sum, o) => sum + o.amount, 0),
  }));

  const totalAmount = opportunities.reduce((sum, o) => sum + o.amount, 0);

  return (
    <div className="bg-[#0f1419] rounded-lg border border-[#2d3548] p-4">
      <div className="flex items-center gap-2 mb-4">
        <BarChart3 className="h-5 w-5 text-[#3b82f6]" />
        <span className="text-[#f8fafc] font-medium">商机管道</span>
        <span className="text-[#94a3b8] text-sm ml-auto">总金额 ¥{totalAmount.toLocaleString()}</span>
      </div>
      
      <div className="flex gap-2">
        {stageData.map((data, idx) => (
          <div 
            key={data.stage}
            className="flex-1 min-w-[120px] bg-[#1a1f2c] rounded-lg border border-[#2d3548] p-3"
          >
            <div 
              className="text-xs font-medium mb-2"
              style={{ color: stageColors[data.stage] }}
            >
              {data.stage}
            </div>
            <div className="text-xl font-bold text-[#f8fafc] mb-1">
              {data.opportunities.length}
            </div>
            <div className="text-xs text-[#94a3b8]">
              ¥{data.totalAmount.toLocaleString()}
            </div>
            {idx < stageData.length - 1 && (
              <ArrowRight className="absolute right-0 top-1/2 -translate-y-1/2 h-4 w-4 text-[#64748b]" />
            )}
          </div>
        ))}
      </div>
    </div>
  );
}

// 新增商机模态框
function AddOpportunityDialog({
  open,
  onClose,
  onSuccess,
}: {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const [customers, setCustomers] = useState<{ id: string; name: string }[]>([]);
  const [formData, setFormData] = useState({
    name: '',
    customer_id: '',
    amount: 0,
    stage: '初步接触',
    expected_close_date: '',
    description: '',
  });

  useEffect(() => {
    if (open) {
      loadCustomers();
    }
  }, [open]);

  const loadCustomers = async () => {
    try {
      const res = await fetch('/api/customers?pageSize=100');
      if (!res.ok) throw new Error('加载失败');
      const data = await res.json();
      setCustomers(data.customers || []);
    } catch (error) {
      toast.error('加载客户列表失败');
    }
  };

  const handleSubmit = async () => {
    if (!formData.name || !formData.customer_id) {
      toast.error('请填写必填信息');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/opportunities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || '创建失败');
      }
      toast.success('商机已创建');
      setFormData({
        name: '',
        customer_id: '',
        amount: 0,
        stage: '初步接触',
        expected_close_date: '',
        description: '',
      });
      onSuccess();
      onClose();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : '创建商机失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle>新增商机</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-4 py-4">
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">商机名称 *</label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">关联客户 *</label>
            <Select value={formData.customer_id} onValueChange={(v) => setFormData({ ...formData, customer_id: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue placeholder="选择客户" />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                {customers.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">金额（元）</label>
            <Input
              type="number"
              value={formData.amount}
              onChange={(e) => setFormData({ ...formData, amount: Number(e.target.value) })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">商机阶段</label>
            <Select value={formData.stage} onValueChange={(v) => setFormData({ ...formData, stage: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="初步接触">初步接触</SelectItem>
                <SelectItem value="需求确认">需求确认</SelectItem>
                <SelectItem value="方案报价">方案报价</SelectItem>
                <SelectItem value="谈判">谈判</SelectItem>
                <SelectItem value="成交">成交</SelectItem>
                <SelectItem value="输单">输单</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">预计成交日期</label>
            <Input
              type="date"
              value={formData.expected_close_date}
              onChange={(e) => setFormData({ ...formData, expected_close_date: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div className="col-span-2">
            <label className="text-sm text-[#94a3b8] mb-2 block">描述</label>
            <Input
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="商机描述..."
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="border-[#2d3548]">
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={loading} className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
            {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            创建商机
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// 推进商机阶段模态框
function AdvanceStageDialog({
  opportunity,
  open,
  onClose,
  onSuccess,
}: {
  opportunity: Opportunity | null;
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const stages = ['初步接触', '需求确认', '方案报价', '谈判', '成交', '输单'];
  
  const [newStage, setNewStage] = useState('');

  useEffect(() => {
    if (opportunity) {
      setNewStage(opportunity.stage);
    }
  }, [opportunity]);

  const handleAdvance = async () => {
    if (!opportunity || !newStage) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/opportunities/${opportunity.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stage: newStage }),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || '更新失败');
      }
      toast.success('商机阶段已更新');
      onSuccess();
      onClose();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : '更新失败');
    } finally {
      setLoading(false);
    }
  };

  if (!opportunity) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle>推进商机阶段</DialogTitle>
        </DialogHeader>
        
        <div className="py-4 space-y-4">
          <div className="text-[#94a3b8]">
            当前商机：{opportunity.name}（¥{opportunity.amount.toLocaleString()}）
          </div>
          
          <Select value={newStage} onValueChange={setNewStage}>
            <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
              <SelectValue placeholder="选择新阶段" />
            </SelectTrigger>
            <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
              {stages.map(s => (
                <SelectItem key={s} value={s}>{s}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onClose} className="border-[#2d3548]">
              取消
            </Button>
            <Button onClick={handleAdvance} disabled={loading} className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
              {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              确认
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function OpportunitiesPage() {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [stats, setStats] = useState<OpportunityStats | null>(null);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [selectedStage, setSelectedStage] = useState<string>('all');
  const [showAdd, setShowAdd] = useState(false);
  const [selectedOpportunity, setSelectedOpportunity] = useState<Opportunity | null>(null);
  const [showAdvance, setShowAdvance] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  const loadOpportunities = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        pageSize: pageSize.toString(),
      });
      if (selectedStage !== 'all') params.append('stage', selectedStage);

      const res = await fetch(`/api/opportunities?${params.toString()}`);
      if (!res.ok) throw new Error('加载失败');
      const data: OpportunityListResponse = await res.json();
      setOpportunities(data.opportunities);
      setTotal(data.total);
    } catch (error) {
      toast.error('加载商机列表失败');
    } finally {
      setLoading(false);
    }
  }, [currentPage, selectedStage]);

  const loadStats = useCallback(async () => {
    try {
      const res = await fetch('/api/opportunities?stats=true');
      if (!res.ok) throw new Error('加载失败');
      const data = await res.json();
      setStats(data.stats);
    } catch (error) {
      console.error('加载统计数据失败', error);
    }
  }, []);

  useEffect(() => {
    loadOpportunities();
    loadStats();
  }, [loadOpportunities, loadStats]);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/opportunities/${deleteId}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('删除失败');
      toast.success('商机已删除');
      setDeleteId(null);
      loadOpportunities();
      loadStats();
    } catch (error) {
      toast.error('删除商机失败');
    }
  };

  const totalPages = Math.ceil(total / pageSize);

  const stageColors: Record<string, string> = {
    '初步接触': '#6b7280',
    '需求确认': '#3b82f6',
    '方案报价': '#8b5cf6',
    '谈判': '#f97316',
    '成交': '#22c55e',
    '输单': '#ef4444',
  };

  return (
    <MainLayout title="商机管理">
      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="h-5 w-5 text-[#3b82f6]" />
              <span className="text-sm text-[#94a3b8]">商机总金额</span>
            </div>
            <div className="text-2xl font-bold text-[#f8fafc]">
              ¥{stats?.totalAmount?.toLocaleString() || 0}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="h-5 w-5 text-[#22c55e]" />
              <span className="text-sm text-[#94a3b8]">成交商机</span>
            </div>
            <div className="text-2xl font-bold text-[#22c55e]">
              {opportunities.filter(o => o.stage === '成交').length}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-5 w-5 text-[#f97316]" />
              <span className="text-sm text-[#94a3b8]">进行中</span>
            </div>
            <div className="text-2xl font-bold text-[#f97316]">
              {opportunities.filter(o => !['成交', '输单'].includes(o.stage)).length}
            </div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Target className="h-5 w-5 text-[#8b5cf6]" />
              <span className="text-sm text-[#94a3b8]">胜率</span>
            </div>
            <div className="text-2xl font-bold text-[#8b5cf6]">
              {stats?.winRate ? `${stats.winRate}%` : '0%'}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 商机管道 */}
      <div className="mb-6">
        <OpportunityPipelineVisual opportunities={opportunities} />
      </div>

      {/* 操作栏 */}
      <div className="flex gap-4 mb-6">
        <Select value={selectedStage} onValueChange={setSelectedStage}>
          <SelectTrigger className="w-[140px] h-10 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="商机阶段" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部阶段</SelectItem>
            <SelectItem value="初步接触" className="text-[#f8fafc]">初步接触</SelectItem>
            <SelectItem value="需求确认" className="text-[#f8fafc]">需求确认</SelectItem>
            <SelectItem value="方案报价" className="text-[#f8fafc]">方案报价</SelectItem>
            <SelectItem value="谈判" className="text-[#f8fafc]">谈判</SelectItem>
            <SelectItem value="成交" className="text-[#f8fafc]">成交</SelectItem>
            <SelectItem value="输单" className="text-[#f8fafc]">输单</SelectItem>
          </SelectContent>
        </Select>
        
        <Button 
          onClick={() => setShowAdd(true)}
          className="h-10 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] px-4"
        >
          <Plus className="h-4 w-4 mr-2" />
          新增商机
        </Button>
      </div>

      {/* 商机表格 */}
      <Card className="bg-[#1a1f2c] border-[#2d3548]">
        <CardHeader>
          <CardTitle className="text-[#f8fafc]">商机列表</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-[#2d3548]">
                  <TableHead className="text-[#94a3b8]">商机名称</TableHead>
                  <TableHead className="text-[#94a3b8]">关联客户</TableHead>
                  <TableHead className="text-[#94a3b8]">金额</TableHead>
                  <TableHead className="text-[#94a3b8]">阶段</TableHead>
                  <TableHead className="text-[#94a3b8]">预计成交日期</TableHead>
                  <TableHead className="text-[#94a3b8]">创建时间</TableHead>
                  <TableHead className="text-[#94a3b8]">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {opportunities.length > 0 ? (
                  opportunities.map((opp) => (
                    <TableRow key={opp.id} className="border-[#2d3548]">
                      <TableCell className="text-[#f8fafc] font-medium">
                        <div className="flex items-center gap-2">
                          <Briefcase className="h-4 w-4 text-[#3b82f6]" />
                          {opp.name}
                        </div>
                      </TableCell>
                      <TableCell className="text-[#94a3b8]">
                        <div className="flex items-center gap-2">
                          <User className="h-3 w-3" />
                          {opp.customer_name || '未关联'}
                        </div>
                      </TableCell>
                      <TableCell className="text-[#f8fafc]">
                        ¥{opp.amount.toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className="text-xs"
                          style={{
                            backgroundColor: `${stageColors[opp.stage]}20`,
                            color: stageColors[opp.stage],
                          }}
                        >
                          {opp.stage}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#94a3b8] text-sm">
                        {opp.expected_close_date || '未设置'}
                      </TableCell>
                      <TableCell className="text-[#94a3b8] text-sm">
                        {opp.create_time}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => {
                              setSelectedOpportunity(opp);
                              setShowAdvance(true);
                            }}
                            className="text-[#3b82f6] hover:text-[#3b82f6] hover:bg-[#3b82f6]/10"
                          >
                            <ArrowRight className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => setDeleteId(opp.id)}
                            className="text-[#ef4444] hover:text-[#ef4444] hover:bg-[#ef4444]/10"
                          >
                            <XCircle className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-[#64748b]">
                      暂无商机数据
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
          
          {/* 分页 */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-[#94a3b8]">
                共 {total} 条，第 {currentPage}/{totalPages} 页
              </div>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage(p => p - 1)}
                  className="border-[#2d3548]"
                >
                  上一页
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage(p => p + 1)}
                  className="border-[#2d3548]"
                >
                  下一页
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 新增商机模态框 */}
      <AddOpportunityDialog
        open={showAdd}
        onClose={() => setShowAdd(false)}
        onSuccess={() => {
          loadOpportunities();
          loadStats();
        }}
      />

      {/* 推进阶段模态框 */}
      <AdvanceStageDialog
        opportunity={selectedOpportunity}
        open={showAdvance}
        onClose={() => setShowAdvance(false)}
        onSuccess={() => {
          loadOpportunities();
          loadStats();
        }}
      />

      {/* 删除确认 */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription className="text-[#94a3b8]">
              此操作将永久删除该商机，无法恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2d3548]">取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-[#ef4444]">
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}