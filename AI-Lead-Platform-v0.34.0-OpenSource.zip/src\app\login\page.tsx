'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { ArrowRight, Eye, EyeOff, Loader2, Lock, Mail, Sparkles } from 'lucide-react';
import { getSupabaseBrowserClientAsync } from '@/lib/supabase-browser';
import { cn } from '@/lib/utils';
import { demoRoleAccounts } from '@/lib/release-experience';
import type { SupabaseClient } from '@supabase/supabase-js';

const APP_NAME = 'AI智能获客平台';
const APP_ICON_URL = 'https://coze-coding-project.tos.coze.site/default_app_icon.svg';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [supabase, setSupabase] = useState<SupabaseClient | null>(null);
  const [configReady, setConfigReady] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);

    const demoSession = localStorage.getItem('supabase_session');
    if (demoSession === 'demo-session') {
      router.push('/dashboard');
      return;
    }

    let cancelled = false;

    const initSupabase = async () => {
      try {
        const client = await getSupabaseBrowserClientAsync();
        if (cancelled) return;

        setSupabase(client);
        setConfigReady(true);

        const { data: { session } } = await client.auth.getSession();
        if (session) {
          router.push('/dashboard');
        }
      } catch (err) {
        if (cancelled) return;
        console.warn('Supabase is not configured, demo mode is still available.', err);
        setSupabase(null);
        setConfigReady(false);
      }
    };

    initSupabase();

    return () => {
      cancelled = true;
    };
  }, [router]);

  const resetMessages = () => {
    setError('');
    setSuccess('');
  };

  const handleDemoLogin = () => {
    localStorage.setItem('supabase_session', 'demo-session');
    localStorage.setItem('ai_lead_platform_demo_mode', 'true');
    router.push('/dashboard');
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!supabase) {
      setError('正式账号登录需要先配置 Supabase。你也可以先点击下方演示模式进入工作台。');
      return;
    }

    setLoading(true);
    try {
      const { error: loginError } = await supabase.auth.signInWithPassword({ email, password });
      if (loginError) {
        setError(loginError.message === 'Invalid login credentials' ? '邮箱或密码错误' : loginError.message);
        return;
      }
      router.push('/dashboard');
    } catch {
      setError('登录失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!supabase) {
      setError('注册正式账号需要先配置 Supabase。');
      return;
    }

    if (password !== confirmPassword) {
      setError('两次密码输入不一致');
      return;
    }

    if (password.length < 6) {
      setError('密码长度至少 6 位');
      return;
    }

    setLoading(true);
    try {
      const { error: registerError } = await supabase.auth.signUp({ email, password });
      if (registerError) {
        setError(registerError.message);
        return;
      }
      setSuccess('注册成功，请查收确认邮件后登录。');
      setMode('login');
    } catch {
      setError('注册失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    resetMessages();

    if (!supabase) {
      setError('重置密码需要先配置 Supabase。');
      return;
    }

    setLoading(true);
    try {
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/login?mode=reset`,
      });

      if (resetError) {
        setError(resetError.message);
        return;
      }
      setSuccess('重置邮件已发送，请查收邮箱。');
    } catch {
      setError('发送失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f1419] via-[#1a1f2c] to-[#0f1419] flex items-center justify-center p-4 md:p-8 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {mounted && (
          <>
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
          </>
        )}
      </div>

      <div className={cn('w-full max-w-md relative z-10', mounted && 'animate-in fade-in slide-in-from-bottom-4 duration-500')}>
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-4">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-orange-500 rounded-2xl blur-lg opacity-50" />
            <Image src={APP_ICON_URL} alt={APP_NAME} width={80} height={80} className="rounded-2xl relative z-10" priority />
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-orange-500" />
            <h1 className="text-2xl font-bold text-[#f8fafc]">{APP_NAME}</h1>
          </div>
          <p className="text-[#94a3b8] text-sm">智能获客 · 精准转化 · CRM 跟进</p>
        </div>

        <div className="bg-[#1a1f2c]/80 backdrop-blur-xl border border-[#2d3548] rounded-2xl p-6 shadow-2xl">
          <button
            type="button"
            onClick={handleDemoLogin}
            className="w-full mb-5 py-3 bg-gradient-to-r from-orange-500 to-amber-500 text-white font-medium rounded-xl hover:shadow-lg hover:shadow-orange-500/25 transition-all flex items-center justify-center gap-2"
          >
            演示模式进入工作台
            <ArrowRight className="w-5 h-5" />
          </button>

          <div className="mb-5 rounded-xl border border-[#2d3548] bg-[#0f1419]/70 p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="text-sm font-medium text-[#f8fafc]">演示身份说明</p>
              <span className="rounded-full bg-blue-500/15 px-2 py-1 text-xs text-blue-300">v0.14.0</span>
            </div>
            <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
              {demoRoleAccounts.map((account) => (
                <div key={account.email} className="rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium text-[#f8fafc]">{account.role}</span>
                    <span className="text-xs text-[#64748b]">密码 {account.password}</span>
                  </div>
                  <p className="mt-1 truncate text-xs text-blue-300">{account.email}</p>
                  <p className="mt-2 line-clamp-2 text-xs leading-5 text-[#94a3b8]">{account.focus}</p>
                </div>
              ))}
            </div>
            <p className="mt-3 text-xs leading-5 text-[#94a3b8]">
              当前演示模式不校验这些账号密码，点击上方按钮即可进入。账号用于说明未来 SaaS 角色权限。
            </p>
          </div>

          <div className="flex items-center gap-3 mb-5">
            <div className="h-px flex-1 bg-[#2d3548]" />
            <span className="text-xs text-[#64748b]">正式账号登录</span>
            <div className="h-px flex-1 bg-[#2d3548]" />
          </div>

          <div className="flex gap-2 mb-6">
            <button
              type="button"
              onClick={() => { setMode('login'); resetMessages(); }}
              className={cn(
                'flex-1 py-3 text-sm font-medium rounded-xl transition-all duration-200',
                mode === 'login'
                  ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white shadow-lg shadow-blue-500/25'
                  : 'bg-[#2d3548]/50 text-[#94a3b8] hover:bg-[#2d3548] hover:text-[#f8fafc]'
              )}
            >
              登录
            </button>
            <button
              type="button"
              onClick={() => { setMode('register'); resetMessages(); }}
              className={cn(
                'flex-1 py-3 text-sm font-medium rounded-xl transition-all duration-200',
                mode === 'register'
                  ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white shadow-lg shadow-blue-500/25'
                  : 'bg-[#2d3548]/50 text-[#94a3b8] hover:bg-[#2d3548] hover:text-[#f8fafc]'
              )}
            >
              注册
            </button>
          </div>

          {!configReady && (
            <div className="mb-4 p-3 bg-amber-500/10 border border-amber-500/30 rounded-lg text-amber-300 text-sm leading-relaxed">
              当前没有检测到 Supabase 配置，正式账号登录暂不可用。先用演示模式查看产品效果。
            </div>
          )}

          {success && (
            <div className="mb-4 p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-green-400 text-sm text-center">
              {success}
            </div>
          )}

          {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm text-center">
              {error}
            </div>
          )}

          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type="email"
                  placeholder="邮箱地址"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="密码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full pl-10 pr-10 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#94a3b8]"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <div className="flex justify-end">
                <button type="button" onClick={() => { setMode('forgot'); resetMessages(); }} className="text-sm text-[#3b82f6] hover:text-[#60a5fa] transition-colors">
                  忘记密码？
                </button>
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white font-medium rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '登录'}
              </button>
            </form>
          )}

          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type="email"
                  placeholder="邮箱地址"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="密码，至少 6 位"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full pl-10 pr-10 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="确认密码"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white font-medium rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '注册'}
              </button>
            </form>
          )}

          {mode === 'forgot' && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type="email"
                  placeholder="邮箱地址"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white font-medium rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '发送重置邮件'}
              </button>
              <button type="button" onClick={() => { setMode('login'); resetMessages(); }} className="w-full py-3 bg-[#2d3548]/50 text-[#94a3b8] font-medium rounded-xl hover:bg-[#2d3548] hover:text-[#f8fafc] transition-all">
                返回登录
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
