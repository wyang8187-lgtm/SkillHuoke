'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { 
  Sparkles, Users, Building2, MapPin, Phone, RefreshCw, 
  Plus, ArrowRight, TrendingUp, Target, Search
} from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface LeadRecommendation {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  address: string;
  industry: string;
  companySize: string;
  similarityScore: number;
  reasons: string[];
  source: string;
}

interface CustomerStats {
  industryDistribution: Record<string, number>;
  regionDistribution: Record<string, number>;
  sizeDistribution: Record<string, number>;
  totalCustomers: number;
}

export default function LeadDiscoveryPage() {
  const [loading, setLoading] = useState(false);
  const [recommendations, setRecommendations] = useState<LeadRecommendation[]>([]);
  const [customerStats, setCustomerStats] = useState<CustomerStats | null>(null);
  const [insights, setInsights] = useState<string[]>([]);
  const [selectedLeads, setSelectedLeads] = useState<Set<string>>(new Set());
  
  // 单客户画像模式
  const [singleMode, setSingleMode] = useState(false);
  const [customerIndustry, setCustomerIndustry] = useState('建材外贸');
  const [customerCity, setCustomerCity] = useState('佛山');
  
  // 行业选项
  const industries = [
    '建材外贸', '家具出口', '全屋定制', '橱柜衣柜', '陶瓷卫浴',
    '五金配件', '照明灯饰', '地板门窗', '涂料化工', '机械装备',
    '纺织服装', '家电出口', '跨境电商', '进出口贸易', '国际物流'
  ];
  
  // 城市选项
  const cities = ['佛山', '深圳', '广州', '东莞', '中山', '珠海'];
  
  // 获取全局推荐
  const fetchGlobalRecommendations = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/ai/lead-discovery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({})
      });
      const data = await response.json();
      if (data.success) {
        setRecommendations(data.data.recommendations);
        setCustomerStats(data.data.basedOn);
        setInsights(data.data.insights || []);
        setSingleMode(false);
      }
    } catch (error) {
      console.error('Failed to fetch recommendations:', error);
    } finally {
      setLoading(false);
    }
  };
  
  // 获取基于客户画像的推荐
  const fetchSingleRecommendations = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/ai/lead-discovery', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId: 'sample',
          industry: customerIndustry,
          city: customerCity
        })
      });
      const data = await response.json();
      if (data.success) {
        setRecommendations(data.data.recommendations);
        setInsights(data.data.basedOn?.profile ? [`基于${customerIndustry}行业、${customerCity}地区的客户画像推荐`] : []);
        setSingleMode(true);
      }
    } catch (error) {
      console.error('Failed to fetch recommendations:', error);
    } finally {
      setLoading(false);
    }
  };
  
  // 初始加载
  useEffect(() => {
    fetchGlobalRecommendations();
  }, []);
  
  // 选择/取消选择线索
  const toggleLeadSelection = (leadId: string) => {
    const newSelected = new Set(selectedLeads);
    if (newSelected.has(leadId)) {
      newSelected.delete(leadId);
    } else {
      newSelected.add(leadId);
    }
    setSelectedLeads(newSelected);
  };
  
  // 批量添加到线索池
  const addToLeads = async () => {
    if (selectedLeads.size === 0) return;
    // 实际应用中调用API添加到线索池
    alert(`已将${selectedLeads.size}条推荐线索添加到线索池（模拟操作）`);
    setSelectedLeads(new Set());
  };
  
  // 单条添加
  const addSingleToLeads = async (lead: LeadRecommendation) => {
    alert(`已将"${lead.companyName}"添加到线索池（模拟操作）`);
  };
  
  // 获取相似度颜色
  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-500';
    if (score >= 80) return 'text-blue-500';
    if (score >= 70) return 'text-yellow-500';
    return 'text-gray-500';
  };
  
  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">客户线索自动发现</h1>
          <p className="text-sm text-muted-foreground mt-1">
            AI分析已有客户画像，智能推荐相似特征的潜在客户
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={fetchGlobalRecommendations} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            刷新推荐
          </Button>
        </div>
      </div>
      
      {/* 推荐模式切换 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Target className="h-5 w-5" />
            推荐模式
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4">
            <Button 
              variant={!singleMode ? 'default' : 'outline'}
              onClick={fetchGlobalRecommendations}
            >
              <TrendingUp className="h-4 w-4 mr-2" />
              全局智能推荐
            </Button>
            <Button 
              variant={singleMode ? 'default' : 'outline'}
              onClick={fetchSingleRecommendations}
            >
              <Search className="h-4 w-4 mr-2" />
              按客户画像推荐
            </Button>
          </div>
          
          {singleMode && (
            <div className="flex gap-4 mt-4 pt-4 border-t">
              <div className="flex-1">
                <label className="text-sm text-muted-foreground mb-1 block">行业</label>
                <select 
                  className="w-full h-10 px-3 rounded-md border bg-background"
                  value={customerIndustry}
                  onChange={(e) => setCustomerIndustry(e.target.value)}
                >
                  {industries.map(ind => (
                    <option key={ind} value={ind}>{ind}</option>
                  ))}
                </select>
              </div>
              <div className="flex-1">
                <label className="text-sm text-muted-foreground mb-1 block">城市</label>
                <select 
                  className="w-full h-10 px-3 rounded-md border bg-background"
                  value={customerCity}
                  onChange={(e) => setCustomerCity(e.target.value)}
                >
                  {cities.map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </select>
              </div>
              <Button onClick={fetchSingleRecommendations} disabled={loading}>
                生成推荐
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* 数据洞察 */}
      {customerStats && !singleMode && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Sparkles className="h-5 w-5" />
              客户数据洞察
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-6 mb-4">
              <div>
                <div className="text-sm text-muted-foreground mb-2">总客户数</div>
                <div className="text-2xl font-bold">{customerStats.totalCustomers}</div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-2">主力行业</div>
                <div className="text-lg font-medium">
                  {Object.entries(customerStats.industryDistribution)
                    .sort((a, b) => b[1] - a[1])[0][0]}
                  <span className="text-muted-foreground ml-2">
                    ({Object.entries(customerStats.industryDistribution)
                      .sort((a, b) => b[1] - a[1])[0][1]}%)
                  </span>
                </div>
              </div>
              <div>
                <div className="text-sm text-muted-foreground mb-2">主力区域</div>
                <div className="text-lg font-medium">
                  {Object.entries(customerStats.regionDistribution)
                    .sort((a, b) => b[1] - a[1])[0][0]}
                </div>
              </div>
            </div>
            
            {insights.length > 0 && (
              <div className="bg-blue-500/10 rounded-lg p-4">
                <div className="text-sm font-medium mb-2">AI建议</div>
                <ul className="space-y-1">
                  {insights.map((insight, idx) => (
                    <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                      <ArrowRight className="h-4 w-4 mt-0.5" />
                      {insight}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
      
      {/* 推荐列表 */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center gap-2">
              <Users className="h-5 w-5" />
              推荐潜在客户 ({recommendations.length})
            </CardTitle>
            {selectedLeads.size > 0 && (
              <Button onClick={addToLeads}>
                <Plus className="h-4 w-4 mr-2" />
                添加{selectedLeads.size}条到线索池
              </Button>
            )}
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4, 5].map(i => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : recommendations.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              暂无推荐，请调整筛选条件或刷新
            </div>
          ) : (
            <div className="space-y-3">
              {recommendations.map((lead) => (
                <div 
                  key={lead.id}
                  className={`p-4 rounded-lg border transition-colors cursor-pointer ${
                    selectedLeads.has(lead.id) 
                      ? 'border-blue-500 bg-blue-500/5' 
                      : 'hover:border-gray-400'
                  }`}
                  onClick={() => toggleLeadSelection(lead.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <Building2 className="h-5 w-5 text-muted-foreground" />
                        <span className="font-medium">{lead.companyName}</span>
                        <Badge variant="outline" className="text-xs">{lead.industry}</Badge>
                        <Badge variant="secondary" className="text-xs">{lead.companySize}</Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                        <span className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {lead.contactName}
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="h-4 w-4" />
                          {lead.phone}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-4 w-4" />
                          {lead.address}
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        {lead.reasons.map((reason, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs bg-green-500/10 text-green-600">
                            {reason}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`text-lg font-bold ${getScoreColor(lead.similarityScore)}`}>
                        {lead.similarityScore}%
                      </div>
                      <div className="text-xs text-muted-foreground">匹配度</div>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="mt-2"
                        onClick={(e) => {
                          e.stopPropagation();
                          addSingleToLeads(lead);
                        }}
                      >
                        <Plus className="h-4 w-4 mr-1" />
                        添加
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* 底部说明 */}
      <div className="text-sm text-muted-foreground text-center">
        当前为模拟数据，接入真实客户数据后将基于实际客户画像进行智能推荐
      </div>
    </div>
  );
}