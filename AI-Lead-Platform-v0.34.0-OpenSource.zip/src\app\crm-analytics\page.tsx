'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { calculateCrmAnalytics, type DistributionItem } from '@/lib/crm-analytics';
import { loadSavedCrmCustomers, type SavedCrmCustomer } from '@/lib/lead-wizard';
import { loadSavedCrmOpportunities, summarizeOpportunityCurrencies, type SavedCrmOpportunity } from '@/lib/crm-opportunities';
import { ArrowRight, BarChart3, CircleDollarSign, MessageSquareReply, Target, TriangleAlert, UsersRound } from 'lucide-react';

function Distribution({ title, items }: { title: string; items: DistributionItem[] }) {
  return (
    <Card className="border-[#2d3548] bg-[#121823]">
      <CardHeader><CardTitle className="text-base text-[#f8fafc]">{title}</CardTitle></CardHeader>
      <CardContent className="space-y-4">
        {items.length === 0 ? <p className="text-sm text-[#64748b]">暂无数据</p> : items.map((item) => (
          <div key={item.label}>
            <div className="mb-2 flex items-center justify-between gap-3 text-sm">
              <span className="truncate text-[#cbd5e1]">{item.label}</span>
              <span className="shrink-0 text-[#94a3b8]">{item.count} · {item.percent}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-[#0f1419]">
              <div className="h-full rounded-full bg-blue-500" style={{ width: `${Math.max(item.percent, item.count > 0 ? 4 : 0)}%` }} />
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function RiskList({ title, customers, tone }: { title: string; customers: SavedCrmCustomer[]; tone: string }) {
  return (
    <Card className="border-[#2d3548] bg-[#121823]">
      <CardHeader><CardTitle className={`text-base ${tone}`}>{title} · {customers.length}</CardTitle></CardHeader>
      <CardContent className="space-y-2">
        {customers.length === 0 ? <p className="text-sm text-[#64748b]">当前没有相关客户</p> : customers.map((customer) => (
          <Link key={customer.id} href={`/crm-customers/${encodeURIComponent(customer.id)}`} className="flex items-center justify-between gap-3 rounded-md border border-[#2d3548] bg-[#0f1419] p-3 transition hover:border-blue-500/50">
            <div className="min-w-0"><p className="truncate text-sm font-medium text-[#f8fafc]">{customer.company}</p><p className="mt-1 text-xs text-[#64748b]">{customer.country} · {customer.customerType}</p></div>
            <Badge className="shrink-0 border-blue-500/25 bg-blue-500/15 text-blue-300">{customer.score} 分</Badge>
          </Link>
        ))}
      </CardContent>
    </Card>
  );
}

export default function CrmAnalyticsPage() {
  const [customers, setCustomers] = useState<SavedCrmCustomer[]>([]);
  const [opportunities, setOpportunities] = useState<SavedCrmOpportunity[]>([]);
  useEffect(() => { setCustomers(loadSavedCrmCustomers()); setOpportunities(loadSavedCrmOpportunities()); }, []);
  const analytics = useMemo(() => calculateCrmAnalytics(customers), [customers]);
  const pipeline = useMemo(() => summarizeOpportunityCurrencies(opportunities), [opportunities]);

  return (
    <MainLayout title="CRM 分析">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="flex flex-wrap gap-2"><Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.25.0</Badge><Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">真实 CRM 数据</Badge></div>
              <h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">销售漏斗与转化分析</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">从客户进入 CRM、完成开发、获得回复到形成报价，查看每个阶段的真实推进情况。</p>
            </div>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500"><Link href="/crm-customers">打开 CRM 客户池<ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
          </div>
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader><CardTitle className="text-[#f8fafc]">销售机会金额 · {opportunities.length} 个机会</CardTitle></CardHeader>
          <CardContent className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {pipeline.length === 0 ? <p className="text-sm text-[#64748b]">还没有机会金额。</p> : pipeline.map((item) => (
              <div key={item.currency} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                <p className="text-sm text-[#94a3b8]">{item.currency} 管道</p>
                <p className="mt-2 font-semibold text-blue-300">{item.total.toLocaleString()}</p>
                <p className="mt-1 text-xs text-[#64748b]">加权 {Math.round(item.weighted).toLocaleString()} · 赢单 {item.won.toLocaleString()}</p>
              </div>
            ))}
          </CardContent>
        </Card>

        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-6">
          {[
            { label: 'CRM 客户', value: analytics.total, icon: UsersRound, tone: 'text-blue-300' },
            { label: '活跃客户', value: analytics.active, icon: Target, tone: 'text-sky-300' },
            { label: '已回复', value: analytics.replied, icon: MessageSquareReply, tone: 'text-emerald-300' },
            { label: '已报价', value: analytics.quoted, icon: CircleDollarSign, tone: 'text-amber-300' },
            { label: '报价转化率', value: `${analytics.totalQuoteConversion}%`, icon: BarChart3, tone: 'text-violet-300' },
            { label: '逾期待办', value: analytics.overdue, icon: TriangleAlert, tone: 'text-red-300' },
          ].map((item) => (
            <Card key={item.label} className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><item.icon className={`h-5 w-5 ${item.tone}`} /><p className="mt-3 text-sm text-[#94a3b8]">{item.label}</p><p className={`mt-2 text-2xl font-semibold ${item.tone}`}>{item.value}</p></CardContent></Card>
          ))}
        </section>

        {customers.length === 0 ? (
          <Card className="border-[#2d3548] bg-[#121823]"><CardContent className="p-10 text-center"><UsersRound className="mx-auto h-10 w-10 text-[#64748b]" /><h3 className="mt-4 font-medium text-[#f8fafc]">还没有 CRM 客户</h3><p className="mt-2 text-sm text-[#94a3b8]">先从候选客户池加入客户，分析页面才会显示真实数据。</p><Button asChild className="mt-5 bg-blue-600 text-white hover:bg-blue-500"><Link href="/candidate-leads">打开候选客户池</Link></Button></CardContent></Card>
        ) : null}

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader><CardTitle className="text-[#f8fafc]">CRM 销售漏斗</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {analytics.funnel.map((stage, index) => (
              <Link key={stage.status} href={`/crm-customers?status=${stage.status}`} className="block rounded-lg border border-[#2d3548] bg-[#0f1419] p-4 transition hover:border-blue-500/50">
                <div className="flex flex-wrap items-center justify-between gap-3"><div><p className="font-medium text-[#f8fafc]">{stage.label}</p><p className="mt-1 text-xs text-[#64748b]">{index === 0 ? '全部非暂缓客户' : `上阶段转化率 ${stage.conversionFromPrevious}%`}</p></div><div className="text-right"><p className="text-xl font-semibold text-blue-300">{stage.count}</p><p className="text-xs text-[#64748b]">占活跃客户 {stage.percentOfActive}%</p></div></div>
                <div className="mt-3 h-3 overflow-hidden rounded-full bg-[#121823]"><div className="h-full rounded-full bg-gradient-to-r from-blue-600 to-emerald-500" style={{ width: `${stage.percentOfActive}%` }} /></div>
              </Link>
            ))}
          </CardContent>
        </Card>

        <section className="grid gap-4 lg:grid-cols-3">
          <Distribution title="A/B/C 优先级" items={analytics.priorities} />
          <Distribution title="国家分布" items={analytics.countries} />
          <Distribution title="客户类型分布" items={analytics.customerTypes} />
        </section>

        <section>
          <h2 className="mb-4 text-lg font-semibold text-[#f8fafc]">运营风险与机会</h2>
          <div className="grid gap-4 lg:grid-cols-2">
            <RiskList title="已逾期客户" customers={analytics.risks.overdue} tone="text-red-300" />
            <RiskList title="未安排跟进" customers={analytics.risks.unscheduled} tone="text-amber-300" />
            <RiskList title="高分但尚未开发" customers={analytics.risks.highScoreNew} tone="text-emerald-300" />
            <RiskList title="暂缓客户" customers={analytics.risks.paused} tone="text-slate-300" />
          </div>
        </section>
      </div>
    </MainLayout>
  );
}
