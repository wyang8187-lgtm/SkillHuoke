# v0.29.0 Company and Quotation Settings Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Configure company branding, banking details, and quotation defaults, then apply them to quotation creation and printing.

**Architecture:** Store one versioned company profile in localStorage with safe defaults. The settings page validates and compresses logos; quotation creation and print routes read the profile.

**Tech Stack:** Next.js 16, React 19, TypeScript, Canvas image resizing, localStorage, CSS print.

---

### Task 1: Company profile domain
- Create profile types, defaults, validation, load/save/reset, and logo resize helper.

### Task 2: Settings experience
- Build `/settings/company-profile` with company, bank, defaults, logo preview/delete, and language previews.

### Task 3: Quotation integration
- Apply defaults on new quotations and render configured bilingual header, logo, contact and optional bank details.

### Task 4: Backup v4, navigation, release
- Include company profile in backup v4 with old-version compatibility, update navigation/release, verify, and package.
