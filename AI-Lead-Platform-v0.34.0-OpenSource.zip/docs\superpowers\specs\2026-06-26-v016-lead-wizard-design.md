# v0.16.0 Lead Wizard Design

## Goal

Upgrade the onboarding preview into a real, fillable lead generation task wizard.

## User Value

- 用户可以输入产品、目标国家、客户类型和数量，马上得到可执行的获客任务方案。
- 系统可以自动生成搜索关键词、推荐渠道、核验规则和下一步开发动作。
- 这个页面可以成为未来自动获客任务队列的前端入口。

## Scope

- Add shared lead wizard generation logic.
- Add `/lead-wizard` page with a usable form.
- Generate keywords, channels, verification rules, outreach actions, and route links.
- Link the wizard from onboarding, release center, and sidebar.
- Update README and package version to `0.16.0`.

## Out Of Scope

- Real internet search execution.
- Persisting tasks to a database.
- Background queue processing.
- Paid search API integration.

## Acceptance Criteria

- `/lead-wizard` renders a form with product, country, customer type, and quantity.
- Changing form input updates generated keywords and recommendations.
- Page provides links to intelligent search, lead pool, customer list, and email marketing.
- Type check, lint, build, and HTTP checks pass.
