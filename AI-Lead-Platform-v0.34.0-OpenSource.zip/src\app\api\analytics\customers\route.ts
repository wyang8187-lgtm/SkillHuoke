import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 客户数据分析API
export async function GET(request: NextRequest) {
  try {
    const supabase = getSupabaseServiceRoleClient();
    const searchParams = request.nextUrl.searchParams;
    const period = searchParams.get('period') || 'month'; // day/week/month

    // 1. 获取所有客户
    const { data: customers, error: customersError } = await supabase
      .from('customers')
      .select('id, created_at, industry, region, grade, source, customer_type')
      .order('created_at', { ascending: true });

    if (customersError) {
      console.error('获取客户数据失败:', customersError);
      // 如果表不存在或列不存在，返回空数据
      // PostgreSQL错误代码: 42P01, 42703
      // PostgREST错误代码: PGRST116, PGRST205
      const pgErrors = ['42P01', '42703', 'PGRST116', 'PGRST205'];
      if (pgErrors.includes(customersError.code || '') || !customersError.code) {
        return NextResponse.json({
          success: true,
          data: {
            total: 0,
            trend: [],
            industry: [],
            region: { domestic: [], overseas: [] },
            grade: [],
            source: []
          }
        });
      }
      return NextResponse.json({ error: '获取客户数据失败' }, { status: 500 });
    }

    // 2. 计算增长趋势
    const now = new Date();
    const trendData = calculateTrend(customers || [], period, now);

    // 3. 行业分布
    const industryDistribution = calculateDistribution(customers || [], 'industry');

    // 4. 区域分布
    const regionDistribution = calculateRegionDistribution(customers || []);

    // 5. 客户分级占比
    const gradeDistribution = calculateDistribution(customers || [], 'grade');

    // 6. 来源渠道统计
    const sourceDistribution = calculateDistribution(customers || [], 'source');

    return NextResponse.json({
      success: true,
      data: {
        total: customers?.length || 0,
        trend: trendData,
        industry: industryDistribution,
        region: regionDistribution,
        grade: gradeDistribution,
        source: sourceDistribution
      }
    });
  } catch (error) {
    console.error('客户数据分析错误:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}

// 计算增长趋势
function calculateTrend(customers: any[], period: string, now: Date) {
  const trend: { date: string; newCount: number; totalCount: number }[] = [];
  
  // 根据period确定时间间隔
  let days = 30;
  let interval = 1;
  
  if (period === 'day') {
    days = 7;
    interval = 1;
  } else if (period === 'week') {
    days = 28;
    interval = 7;
  } else if (period === 'month') {
    days = 180;
    interval = 30;
  }

  // 模拟趋势数据（如果数据库有真实数据，按真实数据计算）
  let cumulative = 0;
  for (let i = days; i >= 0; i -= interval) {
    const date = new Date(now);
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    
    // 计算该时间段新增的客户数
    const startDate = new Date(date);
    startDate.setDate(startDate.getDate() - interval);
    const periodCustomers = customers.filter(c => {
      const createdDate = new Date(c.created_at);
      return createdDate >= startDate && createdDate < date;
    });
    
    cumulative += periodCustomers.length;
    
    trend.push({
      date: dateStr,
      newCount: periodCustomers.length,
      totalCount: cumulative
    });
  }

  return trend;
}

// 计算分布
function calculateDistribution(customers: any[], field: string) {
  const distribution: Record<string, number> = {};
  
  customers.forEach(c => {
    const value = c[field] || '未知';
    distribution[value] = (distribution[value] || 0) + 1;
  });

  // 转换为数组格式
  return Object.entries(distribution)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);
}

// 计算区域分布（区分国内/海外）
function calculateRegionDistribution(customers: any[]) {
  const domestic: Record<string, number> = {};
  const overseas: Record<string, number> = {};

  const domesticProvinces = ['广东', '浙江', '江苏', '上海', '北京', '福建', '山东', '四川', '湖北', '安徽'];
  
  customers.forEach(c => {
    const region = c.region || '未知';
    if (domesticProvinces.some(p => region.includes(p))) {
      domestic[region] = (domestic[region] || 0) + 1;
    } else if (region !== '未知') {
      overseas[region] = (overseas[region] || 0) + 1;
    }
  });

  return {
    domestic: Object.entries(domestic)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10),
    overseas: Object.entries(overseas)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10)
  };
}