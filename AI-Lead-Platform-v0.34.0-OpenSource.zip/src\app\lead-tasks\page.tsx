'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  deleteSavedLeadTask,
  downloadLeadTaskText,
  getLeadTaskStatusMeta,
  leadTaskStatusOptions,
  loadSavedLeadTasks,
  updateSavedLeadTaskStatus,
  type LeadTaskStatus,
  type SavedLeadTask,
} from '@/lib/lead-wizard';
import { ArrowRight, ClipboardList, Download, ListChecks, Search, Trash2 } from 'lucide-react';

export default function LeadTasksPage() {
  const [tasks, setTasks] = useState<SavedLeadTask[]>([]);
  const [statusFilter, setStatusFilter] = useState<LeadTaskStatus | 'all'>('all');

  useEffect(() => {
    setTasks(loadSavedLeadTasks());
  }, []);

  const filteredTasks = useMemo(() => {
    if (statusFilter === 'all') return tasks;
    return tasks.filter((task) => task.status === statusFilter);
  }, [statusFilter, tasks]);

  const summary = useMemo(() => {
    return leadTaskStatusOptions.map((status) => ({
      ...status,
      count: tasks.filter((task) => task.status === status.value).length,
    }));
  }, [tasks]);

  const handleStatusChange = (taskId: string, status: LeadTaskStatus) => {
    setTasks(updateSavedLeadTaskStatus(taskId, status));
  };

  const handleDelete = (taskId: string) => {
    setTasks(deleteSavedLeadTask(taskId));
  };

  return (
    <MainLayout title="获客任务记录">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.17.0</Badge>
            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">本地任务记录</Badge>
          </div>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">保存、查看和推进获客任务</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                这里展示从获客向导保存下来的任务。当前版本保存在浏览器本地，适合演示和单机测试；后续可以升级成后端任务队列。
              </p>
            </div>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/lead-wizard">
                新建获客任务
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-4">
          {summary.map((item) => (
            <Card key={item.value} className="border-[#2d3548] bg-[#121823]">
              <CardContent className="p-5">
                <Badge className={`border ${item.className}`}>{item.label}</Badge>
                <p className="mt-3 text-2xl font-semibold text-[#f8fafc]">{item.count}</p>
              </CardContent>
            </Card>
          ))}
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
              <ClipboardList className="h-5 w-5 text-blue-300" />
              任务列表
            </CardTitle>
            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as LeadTaskStatus | 'all')}>
              <SelectTrigger className="w-full border-[#2d3548] bg-[#0f1419] text-[#f8fafc] md:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                {leadTaskStatusOptions.map((status) => (
                  <SelectItem key={status.value} value={status.value}>
                    {status.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardHeader>
          <CardContent>
            {filteredTasks.length === 0 ? (
              <div className="rounded-lg border border-dashed border-[#2d3548] bg-[#0f1419] p-8 text-center">
                <ListChecks className="mx-auto h-10 w-10 text-[#64748b]" />
                <h3 className="mt-4 font-medium text-[#f8fafc]">还没有保存的获客任务</h3>
                <p className="mt-2 text-sm text-[#94a3b8]">先去获客向导填写任务，然后点击“保存为获客任务”。</p>
                <Button asChild className="mt-5 bg-blue-600 text-white hover:bg-blue-500">
                  <Link href="/lead-wizard">打开获客向导</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {filteredTasks.map((task) => {
                  const status = getLeadTaskStatusMeta(task.status);
                  return (
                    <div key={task.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                      <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <Badge className={`border ${status.className}`}>{status.label}</Badge>
                            <Badge className="border-slate-500/25 bg-slate-500/15 text-slate-300">{task.createdAt}</Badge>
                          </div>
                          <h3 className="mt-3 text-lg font-semibold text-[#f8fafc]">{task.title}</h3>
                          <p className="mt-2 text-sm leading-6 text-[#94a3b8]">
                            产品：{task.input.product}
                          </p>
                        </div>
                        <div className="flex flex-col gap-2 sm:flex-row xl:flex-col">
                          <Select value={task.status} onValueChange={(value) => handleStatusChange(task.id, value as LeadTaskStatus)}>
                            <SelectTrigger className="h-10 border-[#2d3548] bg-[#121823] text-[#f8fafc] sm:w-36">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              {leadTaskStatusOptions.map((option) => (
                                <SelectItem key={option.value} value={option.value}>
                                  {option.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button
                            type="button"
                            variant="outline"
                            className="h-10 border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]"
                            onClick={() => downloadLeadTaskText(task)}
                          >
                            <Download className="mr-2 h-4 w-4" />
                            导出
                          </Button>
                          <Button asChild className="h-10 bg-blue-600 text-white hover:bg-blue-500">
                            <Link href={`/lead-tasks/${task.id}`}>
                              执行台
                              <ArrowRight className="ml-2 h-4 w-4" />
                            </Link>
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            className="h-10 border-red-500/25 bg-transparent text-red-300 hover:bg-red-500/10"
                            onClick={() => handleDelete(task.id)}
                          >
                            <Trash2 className="mr-2 h-4 w-4" />
                            删除
                          </Button>
                        </div>
                      </div>

                      <div className="mt-4 grid gap-3 lg:grid-cols-3">
                        <div className="rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                          <p className="text-xs text-[#64748b]">任务输入</p>
                          <p className="mt-2 text-sm leading-6 text-[#cbd5e1]">国家：{task.input.country}</p>
                          <p className="text-sm leading-6 text-[#cbd5e1]">客户类型：{task.input.customerType}</p>
                          <p className="text-sm leading-6 text-[#cbd5e1]">数量：{task.input.quantity}</p>
                        </div>
                        <div className="rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                          <p className="text-xs text-[#64748b]">关键词预览</p>
                          <div className="mt-2 space-y-2">
                            {task.output.keywords.slice(0, 3).map((keyword) => (
                              <p key={keyword} className="text-sm leading-6 text-[#cbd5e1]">{keyword}</p>
                            ))}
                          </div>
                        </div>
                        <div className="rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                          <p className="text-xs text-[#64748b]">执行入口</p>
                          <div className="mt-3 grid gap-2">
                            <Button asChild variant="outline" className="justify-start border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                              <Link href="/acquisition/search">
                                <Search className="mr-2 h-4 w-4" />
                                去智能搜索
                              </Link>
                            </Button>
                            <Button asChild variant="outline" className="justify-start border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                              <Link href="/leads">进入线索池</Link>
                            </Button>
                            <Button asChild variant="outline" className="justify-start border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                              <Link href="/customers/list">进入客户列表</Link>
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
