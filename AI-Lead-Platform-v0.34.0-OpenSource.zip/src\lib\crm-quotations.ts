import { updateSavedCrmCustomer } from './lead-wizard';
import { loadSavedCrmOpportunities, saveCrmOpportunity, type OpportunityCurrency } from './crm-opportunities';

export type QuotationLanguage = 'zh' | 'en';
export type QuotationStatus = 'draft' | 'sent' | 'accepted' | 'rejected' | 'expired';
export type TradeTerm = 'EXW' | 'FOB' | 'CIF' | 'DDP';

export interface QuotationLineItem { id: string; product: string; specification: string; quantity: number; unit: string; unitPrice: number; }
export interface SavedCrmQuotation {
  id: string; number: string; language: QuotationLanguage; customerId: string; opportunityId: string;
  contactName: string; currency: OpportunityCurrency; quotationDate: string; validUntil: string;
  tradeTerm: TradeTerm; paymentTerms: string; deliveryTime: string; note: string; status: QuotationStatus;
  items: QuotationLineItem[]; discount: number; shipping: number; tax: number; createdAt: string; updatedAt: string;
}

export const CRM_QUOTATIONS_STORAGE_KEY = 'skillhuoke_crm_quotations_v028';
export const quotationStatusOptions = [
  { value: 'draft' as const, label: '草稿' }, { value: 'sent' as const, label: '已发送' },
  { value: 'accepted' as const, label: '已接受' }, { value: 'rejected' as const, label: '已拒绝' },
  { value: 'expired' as const, label: '已过期' },
];

export function loadSavedCrmQuotations(): SavedCrmQuotation[] {
  if(typeof window==='undefined') return [];
  try { const value=JSON.parse(localStorage.getItem(CRM_QUOTATIONS_STORAGE_KEY)||'[]'); return Array.isArray(value)?value:[]; } catch{return [];}
}
export function saveCrmQuotations(items:SavedCrmQuotation[]){if(typeof window!=='undefined')localStorage.setItem(CRM_QUOTATIONS_STORAGE_KEY,JSON.stringify(items));}
export function calculateQuotationTotals(q:Pick<SavedCrmQuotation,'items'|'discount'|'shipping'|'tax'>){
  const subtotal=q.items.reduce((sum,item)=>sum+Math.max(0,item.quantity)*Math.max(0,item.unitPrice),0);
  return {subtotal,total:Math.max(0,subtotal-Math.max(0,q.discount)+Math.max(0,q.shipping)+Math.max(0,q.tax))};
}
export function generateQuotationNumber(){const d=new Date();const pad=(n:number)=>String(n).padStart(2,'0');return `SH-${d.getFullYear()}${pad(d.getMonth()+1)}${pad(d.getDate())}-${d.getTime().toString(36).slice(-4).toUpperCase()}`;}
export function saveCrmQuotation(input:Omit<SavedCrmQuotation,'id'|'createdAt'|'updatedAt'>,id?:string){
  const all=loadSavedCrmQuotations(); const existing=id?all.find(x=>x.id===id):undefined; const now=new Date().toISOString();
  const item:SavedCrmQuotation={...input,id:existing?.id||`quote-${Date.now()}`,createdAt:existing?.createdAt||now,updatedAt:now};
  saveCrmQuotations(existing?all.map(x=>x.id===id?item:x):[item,...all]); updateSavedCrmCustomer(item.customerId,{status:'quoted'});
  const opportunity=loadSavedCrmOpportunities().find(x=>x.id===item.opportunityId);
  if(opportunity){const {id:oppId,createdAt,updatedAt,...rest}=opportunity;void createdAt;void updatedAt;saveCrmOpportunity({...rest,stage:'quoted',probability:50,quotationNumber:item.number,lastQuotationDate:item.quotationDate},oppId);}
  return item;
}
export function deleteCrmQuotation(id:string){const next=loadSavedCrmQuotations().filter(x=>x.id!==id);saveCrmQuotations(next);return next;}
export function copyCrmQuotation(source:SavedCrmQuotation){const {id,createdAt,updatedAt,...rest}=source;void id;void createdAt;void updatedAt;return saveCrmQuotation({...rest,number:generateQuotationNumber(),status:'draft'});}
