// 自动获客任务手动执行 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 模拟执行任务并生成结果
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { task_id } = body;

    if (!task_id) {
      return NextResponse.json({ error: '请提供任务ID' }, { status: 400 });
    }

    // 模拟执行过程
    const startTime = Date.now();
    const duration = Math.floor(30 + Math.random() * 30); // 30-60秒
    
    // 模拟搜索结果数量
    const resultsCount = Math.floor(5 + Math.random() * 15); // 5-20条
    const newLeads = Math.floor(resultsCount * 0.6); // 约60%是新线索
    const duplicatesFiltered = resultsCount - newLeads;

    // 创建执行记录
    const record = {
      id: `record_${Date.now()}`,
      task_id,
      task_name: '手动执行任务', // 实际应从任务表获取
      run_time: new Date().toISOString(),
      duration,
      results_count: resultsCount,
      new_leads: newLeads,
      duplicates_filtered: duplicatesFiltered,
      status: 'success',
    };

    // 尝试保存执行记录
    const { error: insertError } = await client
      .from('auto_acquisition_records')
      .insert({
        user_id: user.id,
        ...record,
      });

    if (insertError) {
      console.error('保存执行记录失败:', insertError);
    }

    // 更新任务统计
    await client
      .from('auto_acquisition_tasks')
      .update({
        last_run_time: new Date().toISOString(),
        total_results: resultsCount, // 实际应累加
        updated_at: new Date().toISOString(),
      })
      .eq('id', task_id)
      .eq('user_id', user.id);

    return NextResponse.json({ 
      success: true,
      record,
      message: `执行完成，发现 ${resultsCount} 条线索，新增 ${newLeads} 条`
    });
  } catch (error) {
    console.error('执行任务失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '执行失败' 
    }, { status: 500 });
  }
}