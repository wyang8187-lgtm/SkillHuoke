# v0.27.0 Sales Opportunity Pipeline Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add customer-linked sales opportunities with stages, probability, quotes, and per-currency pipeline totals.

**Architecture:** Store opportunities in a dedicated versioned localStorage domain. Share a form between create and edit routes, derive pipeline summaries with pure helpers, and include opportunities in backup v2.

**Tech Stack:** Next.js 16, React 19, TypeScript, localStorage, shadcn UI.

---

### Task 1: Opportunity data domain

**Files:** Create `src/lib/crm-opportunities.ts`

- [ ] Define stages, currencies, default probabilities, CRUD, customer linkage, and currency summaries.

### Task 2: Opportunity pages

**Files:** Create shared form plus `/crm-opportunities`, `/new`, and `/[id]/edit`.

- [ ] Build create/edit/delete, filtering, totals, stage cards, and customer links.

### Task 3: CRM and backup integration

**Files:** Modify customer detail/deletion and `src/lib/data-backup.ts`.

- [ ] Show customer opportunities, delete linked data, and support backup v2 with v1 import compatibility.

### Task 4: Analytics, release, and package

**Files:** Modify CRM analytics, navigation, release metadata, package version, and README.

- [ ] Add opportunity metrics, run full verification, and create v0.27.0 upload ZIP.
