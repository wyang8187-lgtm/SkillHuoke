# v0.15.0 Onboarding Center Design

## Goal

Add an onboarding center that teaches a non-technical foreign-trade owner how to run the platform from first login to CRM follow-up.

## User Value

- 用户第一次进入系统时，不需要理解所有菜单，只要按流程走。
- 外贸老板可以看到这套 SaaS 的真实运营路径：配置、获客、核验、开发、跟进、导出。
- 轻量带上获客任务向导入口，为后续真正自动化任务流做铺垫。

## Scope

- Add shared onboarding workflow data.
- Add `/onboarding` page.
- Include a lightweight lead task wizard entry with sample inputs and generated outputs.
- Add sidebar navigation entry.
- Link onboarding from release experience page.
- Update README and package version to `0.15.0`.

## Out Of Scope

- Real background task execution.
- Real lead search API calls.
- Persisted onboarding progress.

## Acceptance Criteria

- `/onboarding` shows a six-step operating workflow.
- Page explains what the user should do, what the system produces, and which page to open next.
- Page includes a lightweight lead task wizard preview for product, country, customer type, and quantity.
- Sidebar exposes the onboarding page.
- Type check, lint, build, and HTTP checks pass.
