'use client';

import { useState, useEffect, useRef } from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, X, User, Zap, Target, CheckSquare, ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useRouter } from 'next/navigation';

interface SearchResult {
  id: string | number;
  type: 'customer' | 'lead' | 'opportunity' | 'task';
  title: string;
  subtitle?: string;
  href: string;
}

interface GlobalSearchProps {
  isOpen?: boolean;
  onClose?: () => void;
  mobileMode?: boolean;
}

const typeIcons = {
  customer: User,
  lead: Zap,
  opportunity: Target,
  task: CheckSquare,
};

const typeColors = {
  customer: 'bg-[#3b82f6]/20 text-[#3b82f6]',
  lead: 'bg-[#f97316]/20 text-[#f97316]',
  opportunity: 'bg-[#22c55e]/20 text-[#22c55e]',
  task: 'bg-[#6b7280]/20 text-[#6b7280]',
};

const typeLabels = {
  customer: '客户',
  lead: '线索',
  opportunity: '商机',
  task: '任务',
};

export function GlobalSearch({ isOpen, onClose, mobileMode }: GlobalSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [internalOpen, setInternalOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const isDialogOpen = mobileMode ? internalOpen : (isOpen ?? false);

  useEffect(() => {
    if (isDialogOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isDialogOpen]);

  useEffect(() => {
    const delayDebounceFn = setTimeout(async () => {
      if (query.trim().length >= 1) {
        setLoading(true);
        try {
          const res = await fetch(`/api/global-search?q=${encodeURIComponent(query.trim())}`);
          const data = await res.json();
          setResults(data.results || []);
          setSelectedIndex(0);
        } catch (e) {
          console.error('Search failed:', e);
          setResults([]);
        } finally {
          setLoading(false);
        }
      } else {
        setResults([]);
      }
    }, 300);

    return () => clearTimeout(delayDebounceFn);
  }, [query]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (mobileMode) {
          setInternalOpen(true);
        } else if (onClose) {
          onClose();
        }
      }
      if (e.key === 'Escape' && isDialogOpen) {
        if (mobileMode) {
          setInternalOpen(false);
        } else if (onClose) {
          onClose();
        }
      }
      if (isDialogOpen && results.length > 0) {
        if (e.key === 'ArrowDown') {
          e.preventDefault();
          setSelectedIndex((prev) => (prev + 1) % results.length);
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          setSelectedIndex((prev) => (prev - 1 + results.length) % results.length);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          const selected = results[selectedIndex];
          if (selected) {
            router.push(selected.href);
            if (mobileMode) {
              setInternalOpen(false);
            } else if (onClose) {
              onClose();
            }
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isDialogOpen, results, selectedIndex, mobileMode, onClose, router]);

  const handleClose = () => {
    if (mobileMode) {
      setInternalOpen(false);
    } else if (onClose) {
      onClose();
    }
    setQuery('');
    setResults([]);
  };

  const handleSelect = (result: SearchResult) => {
    router.push(result.href);
    handleClose();
  };

  const getTypeIcon = (type: SearchResult['type']) => {
    const IconComponent = typeIcons[type];
    return <IconComponent className="w-4 h-4" />;
  };

  const getTypeColor = (type: SearchResult['type']) => {
    return typeColors[type];
  };

  const getTypeLabel = (type: SearchResult['type']) => {
    return typeLabels[type];
  };

  // Mobile mode: return a button that opens the dialog
  if (mobileMode) {
    return (
      <>
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setInternalOpen(true)}
          className="text-[#94a3b8] hover:text-[#f8fafc]"
        >
          <Search className="w-5 h-5" />
        </Button>
        <Dialog open={internalOpen} onOpenChange={(open) => !open && handleClose()}>
          <DialogContent className="sm:max-w-xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc] p-0">
            {/* Search Input */}
            <div className="flex items-center border-b border-[#2d3548] px-4 py-3">
              <Search className="w-5 h-5 text-[#64748b] mr-3" />
              <Input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="搜索客户、线索、商机、任务..."
                className="bg-transparent border-none text-[#f8fafc] placeholder-[#64748b] focus-visible:ring-0"
              />
              <Button variant="ghost" size="icon" onClick={handleClose} className="text-[#64748b] hover:text-[#f8fafc]">
                <X className="w-4 h-4" />
              </Button>
            </div>

            {/* Results */}
            <div className="py-2">
              {loading ? (
                <div className="py-8 text-center text-[#64748b]">
                  搜索中...
                </div>
              ) : results.length > 0 ? (
                <div className="max-h-[400px] overflow-y-auto">
                  {results.map((result, index) => (
                    <div
                      key={`${result.type}-${result.id}`}
                      onClick={() => handleSelect(result)}
                      className={`flex items-center px-4 py-3 cursor-pointer transition-colors ${
                        index === selectedIndex
                          ? 'bg-[#3b82f6]/10 border-l-2 border-[#3b82f6]'
                          : 'hover:bg-[#2d3548]/50'
                      }`}
                    >
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${getTypeColor(result.type)}`}>
                        {getTypeIcon(result.type)}
                      </div>
                      <div className="flex-1">
                        <div className="text-[#f8fafc] font-medium">{result.title}</div>
                        <div className="text-xs text-[#64748b]">
                          {result.subtitle} · {getTypeLabel(result.type)}
                        </div>
                      </div>
                      <ArrowRight className="w-4 h-4 text-[#64748b]" />
                    </div>
                  ))}
                </div>
              ) : query.trim() ? (
                <div className="py-8 text-center text-[#64748b]">
                  未找到相关结果
                </div>
              ) : (
                <div className="py-8 text-center text-[#64748b]">
                  输入关键词开始搜索
                </div>
              )}
            </div>

            {/* Keyboard hint */}
            <div className="border-t border-[#2d3548] px-4 py-2 text-xs text-[#64748b] flex items-center justify-between">
              <span>↑↓ 导航 · Enter 选择 · Esc 关闭</span>
              <span>Ctrl+K 快捷搜索</span>
            </div>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose?.()}>
      <DialogContent className="sm:max-w-xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc] p-0">
        {/* Search Input */}
        <div className="flex items-center border-b border-[#2d3548] px-4 py-3">
          <Search className="w-5 h-5 text-[#64748b] mr-3" />
          <Input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索客户、线索、商机、任务..."
            className="bg-transparent border-none text-[#f8fafc] placeholder-[#64748b] focus-visible:ring-0"
          />
          <Button variant="ghost" size="icon" onClick={onClose} className="text-[#64748b] hover:text-[#f8fafc]">
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Results */}
        <div className="py-2">
          {loading ? (
            <div className="py-8 text-center text-[#64748b]">
              搜索中...
            </div>
          ) : results.length > 0 ? (
            <div className="max-h-[400px] overflow-y-auto">
              {results.map((result, index) => (
                <div
                  key={`${result.type}-${result.id}`}
                  onClick={() => handleSelect(result)}
                  className={`flex items-center px-4 py-3 cursor-pointer transition-colors ${
                    index === selectedIndex
                      ? 'bg-[#3b82f6]/10 border-l-2 border-[#3b82f6]'
                      : 'hover:bg-[#2d3548]/50'
                  }`}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center mr-3 ${getTypeColor(result.type)}`}>
                    {getTypeIcon(result.type)}
                  </div>
                  <div className="flex-1">
                    <div className="text-[#f8fafc] font-medium">{result.title}</div>
                    <div className="text-xs text-[#64748b]">
                      {result.subtitle} · {getTypeLabel(result.type)}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-[#64748b]" />
                </div>
              ))}
            </div>
          ) : query.trim() ? (
            <div className="py-8 text-center text-[#64748b]">
              未找到相关结果
            </div>
          ) : (
            <div className="py-8 text-center text-[#64748b]">
              输入关键词开始搜索
            </div>
          )}
        </div>

        {/* Keyboard hint */}
        <div className="border-t border-[#2d3548] px-4 py-2 text-xs text-[#64748b] flex items-center justify-between">
          <span>↑↓ 导航 · Enter 选择 · Esc 关闭</span>
          <span>Ctrl+K 快捷搜索</span>
        </div>
      </DialogContent>
    </Dialog>
  );
}