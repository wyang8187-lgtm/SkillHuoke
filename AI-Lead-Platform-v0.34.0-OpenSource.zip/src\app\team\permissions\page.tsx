import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { roleHasPermission, teamDataScopes, teamPermissions, teamRoles } from '@/lib/team-access';
import { CheckCircle2, Circle, DatabaseZap, ShieldCheck } from 'lucide-react';

export default function TeamPermissionsPage() {
  const categories = Array.from(new Set(teamPermissions.map((permission) => permission.category)));

  return (
    <MainLayout title="权限矩阵">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.13 权限矩阵</Badge>
            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">SaaS 数据范围</Badge>
          </div>
          <h2 className="text-2xl font-semibold text-[#f8fafc]">谁能看什么，谁能操作什么</h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
            这个页面把老板、管理员、销售、运营的权限拆开。等后续接入正式登录后，前端菜单、API、客户数据都可以按这套角色继续收紧。
          </p>
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {teamRoles.map((role) => (
            <Card key={role.id} className="border-[#2d3548] bg-[#121823]">
              <CardContent className="p-5">
                <Badge className={`border ${role.colorClass}`}>{role.name}</Badge>
                <p className="mt-3 text-sm leading-6 text-[#94a3b8]">{role.description}</p>
                <div className="mt-4 rounded-lg border border-[#2d3548] bg-[#0f1419] p-3 text-xs text-[#cbd5e1]">
                  数据范围：{role.scope}
                </div>
              </CardContent>
            </Card>
          ))}
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
              <ShieldCheck className="h-5 w-5 text-blue-300" />
              功能权限矩阵
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {categories.map((category) => (
              <div key={category} className="overflow-hidden rounded-lg border border-[#2d3548]">
                <div className="border-b border-[#2d3548] bg-[#0f1419] px-4 py-3 text-sm font-medium text-[#f8fafc]">
                  {category}
                </div>
                <Table>
                  <TableHeader>
                    <TableRow className="border-[#2d3548] hover:bg-transparent">
                      <TableHead className="w-[34%] text-[#94a3b8]">权限项</TableHead>
                      {teamRoles.map((role) => (
                        <TableHead key={role.id} className="text-center text-[#94a3b8]">
                          {role.shortName}
                        </TableHead>
                      ))}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {teamPermissions
                      .filter((permission) => permission.category === category)
                      .map((permission) => (
                        <TableRow key={permission.id} className="border-[#2d3548] hover:bg-[#0f1419]">
                          <TableCell>
                            <p className="font-medium text-[#f8fafc]">{permission.name}</p>
                            <p className="mt-1 text-xs leading-5 text-[#94a3b8]">{permission.description}</p>
                          </TableCell>
                          {teamRoles.map((role) => {
                            const allowed = roleHasPermission(role.id, permission.id);
                            return (
                              <TableCell key={role.id} className="text-center">
                                {allowed ? (
                                  <CheckCircle2 className="mx-auto h-5 w-5 text-emerald-300" />
                                ) : (
                                  <Circle className="mx-auto h-5 w-5 text-slate-600" />
                                )}
                              </TableCell>
                            );
                          })}
                        </TableRow>
                      ))}
                  </TableBody>
                </Table>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
              <DatabaseZap className="h-5 w-5 text-emerald-300" />
              数据范围说明
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 md:grid-cols-2">
            {teamDataScopes.map((scope) => {
              const role = teamRoles.find((item) => item.id === scope.role);
              return (
                <div key={scope.role} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                  <div className="flex items-center justify-between gap-3">
                    <h3 className="font-medium text-[#f8fafc]">{scope.title}</h3>
                    {role && <Badge className={`border ${role.colorClass}`}>{role.shortName}</Badge>}
                  </div>
                  <p className="mt-2 text-sm text-blue-300">{scope.scope}</p>
                  <p className="mt-2 text-sm leading-6 text-[#94a3b8]">{scope.description}</p>
                </div>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
