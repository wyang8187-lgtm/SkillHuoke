import { getSavedCrmCustomer, updateSavedCrmCustomer } from './lead-wizard';

export type OpportunityStage = 'initial' | 'qualified' | 'quoted' | 'negotiation' | 'won' | 'lost';
export type OpportunityCurrency = 'USD' | 'AUD' | 'EUR' | 'GBP' | 'CNY';

export interface SavedCrmOpportunity {
  id: string;
  customerId: string;
  name: string;
  productRequirement: string;
  amount: number;
  currency: OpportunityCurrency;
  stage: OpportunityStage;
  probability: number;
  expectedCloseDate: string;
  quotationNumber: string;
  lastQuotationDate: string;
  note: string;
  createdAt: string;
  updatedAt: string;
}

export const CRM_OPPORTUNITIES_STORAGE_KEY = 'skillhuoke_crm_opportunities_v027';
export const opportunityStageOptions = [
  { value: 'initial' as const, label: '初步沟通', probability: 10 },
  { value: 'qualified' as const, label: '需求确认', probability: 30 },
  { value: 'quoted' as const, label: '方案报价', probability: 50 },
  { value: 'negotiation' as const, label: '谈判', probability: 70 },
  { value: 'won' as const, label: '赢单', probability: 100 },
  { value: 'lost' as const, label: '丢单', probability: 0 },
];
export const opportunityCurrencies: OpportunityCurrency[] = ['USD', 'AUD', 'EUR', 'GBP', 'CNY'];

export function loadSavedCrmOpportunities(): SavedCrmOpportunity[] {
  if (typeof window === 'undefined') return [];
  try {
    const parsed = JSON.parse(window.localStorage.getItem(CRM_OPPORTUNITIES_STORAGE_KEY) || '[]');
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}

export function saveCrmOpportunities(items: SavedCrmOpportunity[]) {
  if (typeof window !== 'undefined') window.localStorage.setItem(CRM_OPPORTUNITIES_STORAGE_KEY, JSON.stringify(items));
}

function syncCustomerStage(opportunity: SavedCrmOpportunity) {
  if (['quoted', 'negotiation', 'won'].includes(opportunity.stage) && getSavedCrmCustomer(opportunity.customerId)) {
    updateSavedCrmCustomer(opportunity.customerId, { status: 'quoted' });
  }
}

export function saveCrmOpportunity(input: Omit<SavedCrmOpportunity, 'id' | 'createdAt' | 'updatedAt'>, id?: string) {
  const items = loadSavedCrmOpportunities();
  const now = new Date().toISOString();
  const existing = id ? items.find((item) => item.id === id) : undefined;
  const opportunity: SavedCrmOpportunity = {
    ...input,
    id: existing?.id || `opp-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    createdAt: existing?.createdAt || now,
    updatedAt: now,
  };
  saveCrmOpportunities(existing ? items.map((item) => item.id === id ? opportunity : item) : [opportunity, ...items]);
  syncCustomerStage(opportunity);
  return opportunity;
}

export function deleteCrmOpportunity(id: string) {
  const next = loadSavedCrmOpportunities().filter((item) => item.id !== id);
  saveCrmOpportunities(next);
  return next;
}

export function deleteCustomerOpportunities(customerId: string) {
  saveCrmOpportunities(loadSavedCrmOpportunities().filter((item) => item.customerId !== customerId));
}

export function summarizeOpportunityCurrencies(items: SavedCrmOpportunity[]) {
  return opportunityCurrencies.map((currency) => {
    const currencyItems = items.filter((item) => item.currency === currency && item.stage !== 'lost');
    return {
      currency,
      total: currencyItems.reduce((sum, item) => sum + item.amount, 0),
      weighted: currencyItems.reduce((sum, item) => sum + item.amount * item.probability / 100, 0),
      won: currencyItems.filter((item) => item.stage === 'won').reduce((sum, item) => sum + item.amount, 0),
      quoting: currencyItems.filter((item) => ['quoted', 'negotiation'].includes(item.stage)).reduce((sum, item) => sum + item.amount, 0),
    };
  }).filter((item) => item.total > 0);
}
