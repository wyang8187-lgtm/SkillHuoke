import { NextRequest, NextResponse } from 'next/server';

// 角色权限配置API
export async function GET(request: NextRequest) {
  try {
    // 角色定义
    const roles = [
      {
        id: 'admin',
        name: '管理员',
        description: '拥有所有权限，可管理团队成员和系统设置',
        color: '#ef4444', // 红色
        level: 1,
      },
      {
        id: 'team_leader',
        name: '销售主管',
        description: '可查看和管理团队数据，分配客户给团队成员',
        color: '#f97316', // 橙色
        level: 2,
      },
      {
        id: 'sales',
        name: '销售',
        description: '仅能查看和管理自己的客户数据',
        color: '#22c55e', // 绿色
        level: 3,
      },
    ];

    // 功能权限列表
    const permissions = [
      { id: 'dashboard', name: '仪表盘', category: '数据查看' },
      { id: 'customers_list', name: '客户列表', category: '客户管理' },
      { id: 'customers_create', name: '创建客户', category: '客户管理' },
      { id: 'customers_edit', name: '编辑客户', category: '客户管理' },
      { id: 'customers_delete', name: '删除客户', category: '客户管理' },
      { id: 'customers_export', name: '导出客户', category: '客户管理' },
      { id: 'leads_list', name: '线索列表', category: '线索管理' },
      { id: 'leads_create', name: '创建线索', category: '线索管理' },
      { id: 'leads_edit', name: '编辑线索', category: '线索管理' },
      { id: 'opportunities_list', name: '商机列表', category: '商机管理' },
      { id: 'opportunities_create', name: '创建商机', category: '商机管理' },
      { id: 'opportunities_edit', name: '编辑商机', category: '商机管理' },
      { id: 'pool_view', name: '公海池查看', category: '公海池' },
      { id: 'pool_claim', name: '公海池认领', category: '公海池' },
      { id: 'pool_return', name: '退回公海池', category: '公海池' },
      { id: 'acquisition', name: 'AI获客功能', category: 'AI获客' },
      { id: 'marketing', name: '营销功能', category: '营销中心' },
      { id: 'email_send', name: '发送邮件', category: '营销中心' },
      { id: 'whatsapp_send', name: '发送WhatsApp', category: '营销中心' },
      { id: 'team_manage', name: '团队管理', category: '系统管理' },
      { id: 'team_invite', name: '邀请成员', category: '系统管理' },
      { id: 'settings', name: '系统设置', category: '系统管理' },
      { id: 'audit_log', name: '审计日志', category: '系统管理' },
    ];

    // 权限矩阵 - 各角色拥有的权限
    const permissionMatrix = {
      admin: permissions.map(p => p.id), // 管理员拥有所有权限
      team_leader: [
        'dashboard',
        'customers_list',
        'customers_create',
        'customers_edit',
        'customers_export',
        'leads_list',
        'leads_create',
        'leads_edit',
        'opportunities_list',
        'opportunities_create',
        'opportunities_edit',
        'pool_view',
        'pool_claim',
        'pool_return',
        'acquisition',
        'marketing',
        'email_send',
        'whatsapp_send',
      ],
      sales: [
        'dashboard',
        'customers_list',
        'customers_create',
        'customers_edit',
        'leads_list',
        'leads_create',
        'leads_edit',
        'opportunities_list',
        'opportunities_create',
        'opportunities_edit',
        'pool_view',
        'pool_claim',
        'acquisition',
        'marketing',
        'email_send',
      ],
    };

    // 数据范围定义
    const dataScopes = [
      {
        role: 'admin',
        scope: 'all',
        description: '查看全部数据',
        icon: '🌍',
      },
      {
        role: 'team_leader',
        scope: 'team',
        description: '查看团队数据',
        icon: '👥',
      },
      {
        role: 'sales',
        scope: 'self',
        description: '仅看自己的数据',
        icon: '👤',
      },
    ];

    return NextResponse.json({
      success: true,
      data: {
        roles,
        permissions,
        permissionMatrix,
        dataScopes,
      },
    });
  } catch (error) {
    console.error('获取权限配置失败:', error);
    return NextResponse.json({ error: '获取失败' }, { status: 500 });
  }
}