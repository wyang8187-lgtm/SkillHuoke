import { NextRequest, NextResponse } from 'next/server';

// 海关数据查询模拟 - 真实实现需接入海关数据API

interface CustomsRecord {
  id: string;
  product_name: string;
  importer_name: string;
  importer_country: string;
  exporter_name: string;
  exporter_country: string;
  trade_amount: number;
  trade_amount_unit: string;
  trade_date: string;
  hs_code: string;
  port: string;
  trade_type: '进口' | '出口';
}

interface CustomsSearchResult {
  keyword: string;
  total_records: number;
  records: CustomsRecord[];
  top_importers: { name: string; country: string; total_amount: number }[];
  top_exporters: { name: string; country: string; total_amount: number }[];
}

// 模拟海关数据生成
function generateMockCustomsData(keyword: string): CustomsSearchResult {
  const records: CustomsRecord[] = [];
  
  // 根据关键词生成相关数据
  const importers = [
    { name: '深圳市某某建材有限公司', country: '中国' },
    { name: '广州某某家居贸易有限公司', country: '中国' },
    { name: '佛山市某某木业有限公司', country: '中国' },
    { name: '东莞某某装饰材料公司', country: '中国' },
    { name: '上海某某进出口公司', country: '中国' },
    { name: '越南某某建材公司', country: '越南' },
    { name: '泰国某某家居公司', country: '泰国' },
  ];
  
  const exporters = [
    { name: '意大利某某家具集团', country: '意大利' },
    { name: '德国某某木业公司', country: '德国' },
    { name: '土耳其某某建材公司', country: '土耳其' },
    { name: '马来西亚某某木材公司', country: '马来西亚' },
    { name: '印尼某某家居集团', country: '印尼' },
    { name: '越南某某木材公司', country: '越南' },
    { name: '中国某某出口公司', country: '中国' },
  ];
  
  const ports = ['深圳港', '广州港', '上海港', '宁波港', '青岛港', '天津港'];
  
  const hsCodes: Record<string, string> = {
    '全屋定制': '9403.60',
    '家具': '9403.30',
    '建材': '6907.22',
    '木材': '4407.10',
    '木制品': '4418.90',
    '板材': '4410.11',
  };
  
  const hsCode = hsCodes[keyword] || '9403.60';
  
  // 生成10-15条记录
  const numRecords = 10 + Math.floor(Math.random() * 6);
  
  for (let i = 0; i < numRecords; i++) {
    const importerIndex = Math.floor(Math.random() * importers.length);
    const exporterIndex = Math.floor(Math.random() * exporters.length);
    const portIndex = Math.floor(Math.random() * ports.length);
    
    const tradeType = Math.random() > 0.3 ? '进口' : '出口';
    const amount = 50000 + Math.floor(Math.random() * 500000);
    
    // 生成过去12个月内的日期
    const monthsAgo = Math.floor(Math.random() * 12);
    const date = new Date();
    date.setMonth(date.getMonth() - monthsAgo);
    const tradeDate = date.toISOString().split('T')[0];
    
    records.push({
      id: `CUS-${String(i + 1).padStart(6, '0')}`,
      product_name: keyword,
      importer_name: importers[importerIndex].name,
      importer_country: importers[importerIndex].country,
      exporter_name: exporters[exporterIndex].name,
      exporter_country: exporters[exporterIndex].country,
      trade_amount: amount,
      trade_amount_unit: 'USD',
      trade_date: tradeDate,
      hs_code: hsCode,
      port: ports[portIndex],
      trade_type: tradeType,
    });
  }
  
  // 按金额排序
  records.sort((a, b) => b.trade_amount - a.trade_amount);
  
  // 计算top进口商/出口商
  const importerTotals: Record<string, { name: string; country: string; total_amount: number }> = {};
  const exporterTotals: Record<string, { name: string; country: string; total_amount: number }> = {};
  
  for (const record of records) {
    if (!importerTotals[record.importer_name]) {
      importerTotals[record.importer_name] = { 
        name: record.importer_name, 
        country: record.importer_country, 
        total_amount: 0 
      };
    }
    importerTotals[record.importer_name].total_amount += record.trade_amount;
    
    if (!exporterTotals[record.exporter_name]) {
      exporterTotals[record.exporter_name] = { 
        name: record.exporter_name, 
        country: record.exporter_country, 
        total_amount: 0 
      };
    }
    exporterTotals[record.exporter_name].total_amount += record.trade_amount;
  }
  
  const topImporters = Object.values(importerTotals)
    .sort((a, b) => b.total_amount - a.total_amount)
    .slice(0, 5);
    
  const topExporters = Object.values(exporterTotals)
    .sort((a, b) => b.total_amount - a.total_amount)
    .slice(0, 5);
  
  return {
    keyword,
    total_records: records.length,
    records,
    top_importers: topImporters,
    top_exporters: topExporters,
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyword } = body;
    
    if (!keyword) {
      return NextResponse.json(
        { error: '请输入产品关键词' },
        { status: 400 }
      );
    }
    
    // 模拟延迟
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const result = generateMockCustomsData(keyword);
    
    return NextResponse.json({
      success: true,
      data: result,
      message: `查询完成，共找到 ${result.total_records} 条海关数据记录`
    });
  } catch (error) {
    console.error('Customs data search error:', error);
    return NextResponse.json(
      { error: '海关数据查询失败，请重试' },
      { status: 500 }
    );
  }
}