'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  downloadLeadTaskText,
  findSavedLeadTask,
  generateLeadTaskExecutionPreview,
  getLeadTaskStatusMeta,
  seedCandidateLeadsFromTask,
  updateSavedLeadTaskStatus,
  type SavedLeadTask,
} from '@/lib/lead-wizard';
import {
  ArrowLeft,
  CheckCircle2,
  Clock3,
  Database,
  Download,
  ExternalLink,
  PlayCircle,
  Search,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';

const stepIconMap = {
  keywords: Sparkles,
  search: Search,
  parse: ExternalLink,
  verify: ShieldCheck,
  deposit: Database,
};

export default function LeadTaskRunnerPage() {
  const params = useParams<{ id: string }>();
  const [task, setTask] = useState<SavedLeadTask | null>(null);
  const [seededMessage, setSeededMessage] = useState('');

  useEffect(() => {
    setTask(findSavedLeadTask(params.id));
  }, [params.id]);

  const preview = useMemo(() => (task ? generateLeadTaskExecutionPreview(task) : null), [task]);

  const markRunning = () => {
    if (!task) return;
    const tasks = updateSavedLeadTaskStatus(task.id, 'running');
    setTask(tasks.find((item) => item.id === task.id) ?? task);
  };

  const markCompleted = () => {
    if (!task) return;
    const tasks = updateSavedLeadTaskStatus(task.id, 'completed');
    setTask(tasks.find((item) => item.id === task.id) ?? task);
  };

  const seedCandidates = () => {
    if (!task || !preview) return;
    seedCandidateLeadsFromTask(task, preview.candidates);
    setSeededMessage(`已沉淀 ${preview.candidates.length} 个候选客户到候选池`);
  };

  if (!task || !preview) {
    return (
      <MainLayout title="任务执行台">
        <div className="rounded-lg border border-dashed border-[#2d3548] bg-[#121823] p-10 text-center">
          <Clock3 className="mx-auto h-10 w-10 text-[#64748b]" />
          <h2 className="mt-4 text-xl font-semibold text-[#f8fafc]">没有找到这条本地任务</h2>
          <p className="mt-2 text-sm text-[#94a3b8]">任务记录保存在当前浏览器本地。请先从获客向导保存任务，再进入执行台。</p>
          <div className="mt-6 flex justify-center gap-3">
            <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
              <Link href="/lead-tasks">返回任务记录</Link>
            </Button>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/lead-wizard">新建任务</Link>
            </Button>
          </div>
        </div>
      </MainLayout>
    );
  }

  const status = getLeadTaskStatusMeta(task.status);

  return (
    <MainLayout title="任务执行台">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.19.0</Badge>
            <Badge className={`border ${status.className}`}>{status.label}</Badge>
          </div>
          <div className="flex flex-col gap-4 xl:flex-row xl:items-end xl:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">{task.title}</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                这是本地模拟执行台，用于展示未来后端自动获客任务队列的运行过程：关键词生成、搜索公开页面、解析联系方式、真实性评分和候选客户沉淀。
              </p>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                <Link href="/lead-tasks">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  返回记录
                </Link>
              </Button>
              <Button type="button" className="bg-blue-600 text-white hover:bg-blue-500" onClick={markRunning}>
                <PlayCircle className="mr-2 h-4 w-4" />
                标记执行中
              </Button>
              <Button type="button" className="bg-emerald-600 text-white hover:bg-emerald-500" onClick={markCompleted}>
                <CheckCircle2 className="mr-2 h-4 w-4" />
                标记完成
              </Button>
              <Button type="button" variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]" onClick={() => downloadLeadTaskText(task)}>
                <Download className="mr-2 h-4 w-4" />
                导出
              </Button>
              <Button type="button" className="bg-violet-600 text-white hover:bg-violet-500" onClick={seedCandidates}>
                <Database className="mr-2 h-4 w-4" />
                沉淀到候选池
              </Button>
              <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                <Link href="/candidate-leads">打开候选池</Link>
              </Button>
            </div>
          </div>
          {seededMessage && (
            <div className="mt-4 rounded-lg border border-emerald-500/25 bg-emerald-500/10 p-3 text-sm text-emerald-200">
              {seededMessage}
              <Link href="/candidate-leads" className="ml-2 text-emerald-100 underline underline-offset-4">
                查看候选客户池
              </Link>
            </div>
          )}
        </section>

        <section className="grid gap-4 lg:grid-cols-4">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="p-5">
              <p className="text-sm text-[#94a3b8]">目标国家</p>
              <p className="mt-2 text-xl font-semibold text-[#f8fafc]">{task.input.country}</p>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="p-5">
              <p className="text-sm text-[#94a3b8]">目标数量</p>
              <p className="mt-2 text-xl font-semibold text-[#f8fafc]">{task.input.quantity} 个</p>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="p-5">
              <p className="text-sm text-[#94a3b8]">候选客户预览</p>
              <p className="mt-2 text-xl font-semibold text-[#f8fafc]">{preview.candidates.length} 个</p>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="p-5">
              <p className="text-sm text-[#94a3b8]">运行日志</p>
              <p className="mt-2 text-xl font-semibold text-[#f8fafc]">{preview.logs.length} 条</p>
            </CardContent>
          </Card>
        </section>

        <section className="grid gap-4 xl:grid-cols-[1fr_420px]">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="text-[#f8fafc]">执行步骤</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {preview.steps.map((step) => {
                const Icon = stepIconMap[step.id as keyof typeof stepIconMap] ?? Clock3;
                const tone =
                  step.status === 'completed'
                    ? 'border-emerald-500/25 bg-emerald-500/10 text-emerald-300'
                    : step.status === 'running'
                      ? 'border-blue-500/25 bg-blue-500/10 text-blue-300'
                      : 'border-slate-500/25 bg-slate-500/10 text-slate-300';
                return (
                  <div key={step.id} className="flex gap-4 rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                    <div className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border ${tone}`}>
                      <Icon className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h3 className="font-medium text-[#f8fafc]">{step.title}</h3>
                        <Badge className={`border ${tone}`}>
                          {step.status === 'completed' ? '已完成' : step.status === 'running' ? '运行中' : '等待中'}
                        </Badge>
                      </div>
                      <p className="mt-2 text-sm leading-6 text-[#94a3b8]">{step.detail}</p>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="text-[#f8fafc]">运行日志</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {preview.logs.map((log) => {
                const tone =
                  log.level === 'success'
                    ? 'text-emerald-300'
                    : log.level === 'warning'
                      ? 'text-amber-300'
                      : 'text-blue-300';
                return (
                  <div key={`${log.time}-${log.message}`} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                    <div className="flex items-center justify-between gap-3">
                      <span className="text-xs text-[#64748b]">{log.time}</span>
                      <span className={`text-xs ${tone}`}>{log.level.toUpperCase()}</span>
                    </div>
                    <p className="mt-2 text-sm leading-6 text-[#cbd5e1]">{log.message}</p>
                  </div>
                );
              })}
            </CardContent>
          </Card>
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">候选客户结果预览</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-4 lg:grid-cols-2">
            {preview.candidates.map((candidate) => (
              <div key={candidate.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{candidate.priority} 级</Badge>
                      <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">{candidate.score} 分</Badge>
                    </div>
                    <h3 className="mt-3 font-semibold text-[#f8fafc]">{candidate.company}</h3>
                    <p className="mt-1 text-sm text-blue-300">{candidate.website}</p>
                  </div>
                  <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                    <Link href="/candidate-leads">进入候选池</Link>
                  </Button>
                </div>
                <div className="mt-4 grid gap-3 md:grid-cols-2">
                  <p className="text-sm text-[#94a3b8]">国家 / 城市：{candidate.country} / {candidate.city}</p>
                  <p className="text-sm text-[#94a3b8]">客户类型：{candidate.customerType}</p>
                  <p className="text-sm text-[#94a3b8]">联系方式：{candidate.contactStatus}</p>
                  <p className="text-sm text-[#94a3b8]">建议：{candidate.recommendation}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
