export type OpenAITask =
  | 'write_email'
  | 'write_whatsapp'
  | 'score_lead'
  | 'summarize_customer'
  | 'next_action'
  | 'generate_customer_outreach';

export type OutreachContentType = 'first_email' | 'follow_up_email' | 'whatsapp' | 'linkedin';
export type OutreachTone = 'professional' | 'concise' | 'friendly';

export interface OpenAIInput {
  task: OpenAITask;
  prompt: string;
  context?: Record<string, unknown>;
}

export interface OpenAIResult {
  provider: 'mock' | 'openai';
  task: OpenAITask;
  content: string;
  warnings: string[];
}

export interface CustomerOutreachContext {
  company: string;
  country: string;
  city: string;
  customerType: string;
  score: number;
  priority: string;
  contactStatus: string;
  note: string;
  nextAction: string;
  product: string;
  contactName: string;
  contactTitle: string;
  contentType: OutreachContentType;
  tone: OutreachTone;
}

export interface CustomerOutreachResult {
  source: 'openai' | 'fallback';
  subject: string;
  content: string;
  reason?: string;
  model?: string;
}

const OPENAI_RESPONSES_URL = 'https://api.openai.com/v1/responses';
const CHINESE_CHARACTER_PATTERN = /[\u3400-\u9fff]/;

function stringValue(value: unknown, fallback = '') {
  return typeof value === 'string' && value.trim() ? value.trim() : fallback;
}

function numberValue(value: unknown, fallback = 0) {
  return typeof value === 'number' && Number.isFinite(value) ? value : fallback;
}

function normalizeContext(context: Record<string, unknown> = {}): CustomerOutreachContext {
  const contentType = stringValue(context.contentType, 'first_email') as OutreachContentType;
  const tone = stringValue(context.tone, 'professional') as OutreachTone;

  return {
    company: stringValue(context.company, 'your team'),
    country: stringValue(context.country, 'your market'),
    city: stringValue(context.city),
    customerType: stringValue(context.customerType, 'building and design company'),
    score: numberValue(context.score),
    priority: stringValue(context.priority, 'B'),
    contactStatus: stringValue(context.contactStatus, 'contact details require verification'),
    note: stringValue(context.note),
    nextAction: stringValue(context.nextAction),
    product: stringValue(context.product, 'custom cabinetry, wardrobes, interior doors, and furniture'),
    contactName: stringValue(context.contactName),
    contactTitle: stringValue(context.contactTitle),
    contentType,
    tone,
  };
}

function toneInstruction(tone: OutreachTone) {
  if (tone === 'concise') return 'Keep it especially concise and direct.';
  if (tone === 'friendly') return 'Use a warm, natural, friendly business tone.';
  return 'Use a polished and professional business tone.';
}

function buildFallbackOutreach(context: CustomerOutreachContext, reason?: string): CustomerOutreachResult {
  const company = context.company;
  const market = context.city ? `${context.city}, ${context.country}` : context.country;
  const customerType = context.customerType.toLowerCase();
  const product = context.product;
  const greeting = context.contactName ? `Hi ${context.contactName},` : `Hi ${company} team,`;
  const friendlyOpening = context.tone === 'friendly' ? `I hope your week is going well. ` : '';
  const concise = context.tone === 'concise';

  if (context.contentType === 'follow_up_email') {
    return {
      source: 'fallback',
      subject: `Following up: custom project supply for ${company}`,
      content: concise
        ? `${greeting}\n\nI am following up on my earlier message about our ${product} supply for projects in ${market}. Would it be useful if I sent a short catalogue and project references?\n\nBest regards,\nSkillHuoke Export Team`
        : `${greeting}\n\n${friendlyOpening}I wanted to follow up on my earlier introduction regarding our ${product} supply for residential and commercial projects.\n\nWe would be glad to share a concise catalogue, project references, and export packing information for your review. Please let me know if this could be relevant to any current or upcoming projects.\n\nBest regards,\nSkillHuoke Export Team`,
      reason,
    };
  }

  if (context.contentType === 'whatsapp') {
    return {
      source: 'fallback',
      subject: '',
      content: concise
        ? `Hi ${company} team, we manufacture ${product} for export projects. May I send you our catalogue?`
        : `Hi ${company} team, ${friendlyOpening.toLowerCase()}I found your company while researching ${customerType} businesses in ${market}. We manufacture ${product} for export projects. May I send you a short catalogue and introduction?`,
      reason,
    };
  }

  if (context.contentType === 'linkedin') {
    return {
      source: 'fallback',
      subject: '',
      content: concise
        ? `Hi, I came across ${company} while researching ${customerType} businesses in ${market}. We supply ${product} for export projects and would be glad to connect.`
        : `Hi, ${friendlyOpening.toLowerCase()}I came across ${company} while researching ${customerType} businesses in ${market}. We manufacture ${product} for residential and commercial projects and would be glad to connect and share a brief introduction.`,
      reason,
    };
  }

  return {
    source: 'fallback',
    subject: `Custom project supply for ${company}`,
    content: concise
      ? `${greeting}\n\nWe manufacture ${product} for export projects. I found your company while researching ${customerType} businesses in ${market}. May I send you our catalogue and project references?\n\nBest regards,\nSkillHuoke Export Team`
      : `${greeting}\n\n${friendlyOpening}I came across your company while researching ${customerType} businesses in ${market}. We manufacture ${product} for residential and commercial projects, with support for drawings, material selection, production, export packing, and delivery coordination.\n\nI would be glad to share our catalogue and relevant project references. Would a short introduction be useful for your current or upcoming projects?\n\nBest regards,\nSkillHuoke Export Team`,
    reason,
  };
}

function buildOutreachPrompt(context: CustomerOutreachContext) {
  const formatInstruction =
    context.contentType === 'first_email' || context.contentType === 'follow_up_email'
      ? 'Return exactly two sections: SUBJECT: one line, then CONTENT: the email body.'
      : 'Return exactly one section: CONTENT: the message. Do not include a subject.';

  return `Write an English ${context.contentType.replaceAll('_', ' ')} for an export supplier.

Customer company: ${context.company}
Primary contact: ${context.contactName || 'Unknown'}${context.contactTitle ? `, ${context.contactTitle}` : ''}
Market: ${context.city ? `${context.city}, ` : ''}${context.country}
Customer type: ${context.customerType}
Lead score and priority: ${context.score}/100, ${context.priority}
Public contact status: ${context.contactStatus}
Product offer: ${context.product}
Known note: ${context.note || 'No additional verified note'}
Suggested next action: ${context.nextAction || 'Introduce the supplier and ask permission to share a catalogue'}

${toneInstruction(context.tone)}
Use English only. Do not invent a contact name, price, certification, delivery time, or project fact. Keep it natural and ready to send.
${formatInstruction}`;
}

function extractResponseText(payload: unknown) {
  if (!payload || typeof payload !== 'object') return '';
  const response = payload as { output_text?: unknown; output?: unknown };
  if (typeof response.output_text === 'string') return response.output_text.trim();
  if (!Array.isArray(response.output)) return '';

  const textParts: string[] = [];
  for (const item of response.output) {
    if (!item || typeof item !== 'object') continue;
    const content = (item as { content?: unknown }).content;
    if (!Array.isArray(content)) continue;
    for (const part of content) {
      if (!part || typeof part !== 'object') continue;
      const text = (part as { text?: unknown }).text;
      if (typeof text === 'string') textParts.push(text);
    }
  }
  return textParts.join('\n').trim();
}

function parseOutreachText(text: string, context: CustomerOutreachContext) {
  const subjectMatch = text.match(/SUBJECT:\s*(.+)/i);
  const contentMatch = text.match(/CONTENT:\s*([\s\S]+)/i);
  const isEmail = context.contentType === 'first_email' || context.contentType === 'follow_up_email';
  return {
    subject: isEmail ? stringValue(subjectMatch?.[1]) : '',
    content: stringValue(contentMatch?.[1], isEmail ? '' : text.replace(/^CONTENT:\s*/i, '').trim()),
  };
}

export async function generateCustomerOutreach(
  rawContext: Record<string, unknown>
): Promise<CustomerOutreachResult> {
  const context = normalizeContext(rawContext);
  const apiKey = process.env.OPENAI_API_KEY?.trim();
  if (!apiKey) return buildFallbackOutreach(context, 'OPENAI_API_KEY is not configured.');

  const model = process.env.OPENAI_MODEL?.trim() || 'gpt-5.4-mini';
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 20_000);

  try {
    const response = await fetch(OPENAI_RESPONSES_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model,
        input: buildOutreachPrompt(context),
        max_output_tokens: 700,
      }),
      signal: controller.signal,
      cache: 'no-store',
    });

    if (!response.ok) {
      return buildFallbackOutreach(context, `OpenAI request failed with status ${response.status}.`);
    }

    const text = extractResponseText(await response.json());
    const parsed = parseOutreachText(text, context);
    if (!parsed.content || ((context.contentType === 'first_email' || context.contentType === 'follow_up_email') && !parsed.subject)) {
      return buildFallbackOutreach(context, 'OpenAI returned incomplete content.');
    }
    if (CHINESE_CHARACTER_PATTERN.test(`${parsed.subject}${parsed.content}`)) {
      return buildFallbackOutreach(context, 'OpenAI output contained Chinese characters.');
    }

    return {
      source: 'openai',
      subject: parsed.subject,
      content: parsed.content,
      model,
    };
  } catch (error) {
    const reason = error instanceof Error && error.name === 'AbortError'
      ? 'OpenAI request timed out.'
      : 'OpenAI request could not be completed.';
    return buildFallbackOutreach(context, reason);
  } finally {
    clearTimeout(timeout);
  }
}

function createMockContent(input: OpenAIInput) {
  if (input.task === 'write_email') {
    return buildFallbackOutreach(normalizeContext({ ...input.context, contentType: 'first_email' })).content;
  }
  if (input.task === 'write_whatsapp') {
    return buildFallbackOutreach(normalizeContext({ ...input.context, contentType: 'whatsapp' })).content;
  }
  if (input.task === 'score_lead') {
    return 'Suggested score: 82/100. Reason: clear business match, but contact details and decision maker still need verification.';
  }
  if (input.task === 'summarize_customer') {
    return 'This customer appears to be a potential project or trade partner. Verify website, LinkedIn, email, and phone before outreach.';
  }
  return 'Next action: verify public contact sources, identify the right decision maker, then send a short personalized first-touch message.';
}

export async function runOpenAITask(input: OpenAIInput): Promise<OpenAIResult> {
  return {
    provider: 'mock',
    task: input.task,
    content: createMockContent(input),
    warnings: ['This legacy task uses the compatibility response.'],
  };
}
