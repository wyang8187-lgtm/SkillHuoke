import { NextRequest, NextResponse } from 'next/server';
import * as dbService from '@/lib/db-service';

// 获取自动化规则列表 / 创建新规则
export async function GET(request: NextRequest) {
  try {
    // 从请求头获取用户信息
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    // 解析用户ID（从session token中）
    const supabase = dbService.getSupabaseAdmin();
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    
    if (authError || !user) {
      return NextResponse.json({ error: '无效的登录状态' }, { status: 401 });
    }

    // 获取查询参数
    const searchParams = request.nextUrl.searchParams;
    const status = searchParams.get('status');
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '20');

    // 获取自动化规则列表
    const result = await dbService.getAutomationFlows(user.id, {
      status: status || undefined,
      page,
      pageSize
    });

    return NextResponse.json({
      success: true,
      data: result.data,
      total: result.total,
      page: result.page,
      pageSize: result.pageSize
    });

  } catch (error) {
    console.error('获取自动化规则错误:', error);
    return NextResponse.json({
      error: '获取自动化规则失败',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}

// 创建新的自动化规则
export async function POST(request: NextRequest) {
  try {
    // 从请求头获取用户信息
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    // 解析用户ID
    const supabase = dbService.getSupabaseAdmin();
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    
    if (authError || !user) {
      return NextResponse.json({ error: '无效的登录状态' }, { status: 401 });
    }

    // 解析请求体
    const body = await request.json();
    const { name, trigger_type, trigger_config, action_type, action_config } = body;

    if (!name || !trigger_type || !action_type) {
      return NextResponse.json({ error: '请提供规则名称、触发类型和动作类型' }, { status: 400 });
    }

    // 验证触发类型
    const validTriggerTypes = ['new_lead', 'email_opened', 'email_clicked', 'time_based', 'status_change', 'days_no_follow_up'];
    if (!validTriggerTypes.includes(trigger_type)) {
      return NextResponse.json({ error: '无效的触发类型' }, { status: 400 });
    }

    // 验证动作类型
    const validActionTypes = ['send_email', 'create_task', 'update_status', 'notify'];
    if (!validActionTypes.includes(action_type)) {
      return NextResponse.json({ error: '无效的动作类型' }, { status: 400 });
    }

    // 创建规则
    const flow = await dbService.createAutomationFlow(user.id, {
      name,
      trigger_type,
      trigger_config: trigger_config || {},
      action_type,
      action_config: action_config || {}
    });

    return NextResponse.json({
      success: true,
      data: flow,
      message: '自动化规则创建成功'
    });

  } catch (error) {
    console.error('创建自动化规则错误:', error);
    return NextResponse.json({
      error: '创建自动化规则失败',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}