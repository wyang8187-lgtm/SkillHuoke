'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { CustomerEditorForm } from '@/components/crm/customer-editor-form';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { getSavedCrmCustomer, type SavedCrmCustomer } from '@/lib/lead-wizard';

export default function EditCrmCustomerPage() {
  const params = useParams<{ id: string }>();
  const [customer, setCustomer] = useState<SavedCrmCustomer>();
  useEffect(() => setCustomer(getSavedCrmCustomer(decodeURIComponent(params.id))), [params.id]);
  if (!customer) return <MainLayout title="编辑客户"><Card className="border-[#2d3548] bg-[#121823]"><CardContent className="p-10 text-center text-[#cbd5e1]">没有找到这个客户。<div><Button asChild className="mt-5"><Link href="/crm-customers">返回客户池</Link></Button></div></CardContent></Card></MainLayout>;
  return <MainLayout title="编辑客户"><CustomerEditorForm customer={customer} /></MainLayout>;
}
