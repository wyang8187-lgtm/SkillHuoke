import { NextRequest, NextResponse } from 'next/server';

// 品牌商标库搜索模拟API
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const keyword = searchParams.get('keyword');
    const trademarkNo = searchParams.get('trademarkNo');

    if (!keyword && !trademarkNo) {
      return NextResponse.json({ error: '请输入品牌名或商标注册号' }, { status: 400 });
    }

    // 模拟商标数据库
    const mockTrademarks = [
      {
        id: 'tm_001',
        trademark_name: '某某家居',
        trademark_no: '12345678',
        registrant: '深圳市某某家居有限公司',
        registrant_address: '深圳市福田区某某路100号',
        category: '第20类-家具',
        status: '已注册',
        register_date: '2020-05-15',
        valid_until: '2030-05-15',
        logo_url: '/trademarks/logo1.png',
        phone: '13912345678',
        email: 'info@moumou-home.com',
        related_companies: [
          {
            name: '深圳市某某家居有限公司',
            type: '注册人',
            industry: '全屋定制',
            location: '深圳',
          },
        ],
      },
      {
        id: 'tm_002',
        trademark_name: '某某定制',
        trademark_no: '23456789',
        registrant: '广州某某定制家居有限公司',
        registrant_address: '广州市天河区某某路200号',
        category: '第20类-家具',
        status: '已注册',
        register_date: '2019-08-20',
        valid_until: '2029-08-20',
        logo_url: '/trademarks/logo2.png',
        phone: '13812345679',
        email: 'custom@moumou-custom.com',
        related_companies: [
          {
            name: '广州某某定制家居有限公司',
            type: '注册人',
            industry: '全屋定制',
            location: '广州',
          },
          {
            name: '佛山某某家具厂',
            type: '关联企业',
            industry: '家具制造',
            location: '佛山',
          },
        ],
      },
      {
        id: 'tm_003',
        trademark_name: '某某木作',
        trademark_no: '34567890',
        registrant: '佛山某某木业有限公司',
        registrant_address: '佛山市顺德区某某路300号',
        category: '第19类-建筑材料',
        status: '已注册',
        register_date: '2021-03-10',
        valid_until: '2031-03-10',
        logo_url: '/trademarks/logo3.png',
        phone: '13712345680',
        email: 'wood@moumou-wood.com',
        related_companies: [
          {
            name: '佛山某某木业有限公司',
            type: '注册人',
            industry: '木材加工',
            location: '佛山',
          },
        ],
      },
      {
        id: 'tm_004',
        trademark_name: '某某设计',
        trademark_no: '45678901',
        registrant: '东莞市某某设计工程有限公司',
        registrant_address: '东莞市南城区某某路400号',
        category: '第42类-设计服务',
        status: '审核中',
        register_date: '2024-01-15',
        valid_until: '-',
        logo_url: '/trademarks/logo4.png',
        phone: '13612345681',
        email: 'design@moumou-design.com',
        related_companies: [
          {
            name: '东莞市某某设计工程有限公司',
            type: '注册人',
            industry: '室内设计',
            location: '东莞',
          },
        ],
      },
      {
        id: 'tm_005',
        trademark_name: '某某建材',
        trademark_no: '56789012',
        registrant: '中山市某某建材贸易有限公司',
        registrant_address: '中山市某某路500号',
        category: '第19类-建筑材料',
        status: '已注册',
        register_date: '2018-06-25',
        valid_until: '2028-06-25',
        logo_url: '/trademarks/logo5.png',
        phone: '13512345682',
        email: 'material@moumou-material.com',
        related_companies: [
          {
            name: '中山市某某建材贸易有限公司',
            type: '注册人',
            industry: '建材贸易',
            location: '中山',
          },
          {
            name: '珠海某某装饰公司',
            type: '关联企业',
            industry: '装饰工程',
            location: '珠海',
          },
        ],
      },
    ];

    // 根据关键词或商标号过滤
    let results = mockTrademarks;
    if (keyword) {
      results = mockTrademarks.filter(tm => 
        tm.trademark_name.toLowerCase().includes(keyword.toLowerCase()) ||
        tm.registrant.toLowerCase().includes(keyword.toLowerCase())
      );
    }
    if (trademarkNo) {
      results = mockTrademarks.filter(tm => tm.trademark_no === trademarkNo);
    }

    return NextResponse.json({
      success: true,
      data: results,
      total: results.length,
      note: '当前为模拟数据，接入真实API后可获取实时商标数据',
    });
  } catch (error) {
    console.error('商标搜索失败:', error);
    return NextResponse.json({ error: '搜索失败，请稍后重试' }, { status: 500 });
  }
}