import { getCrmReminderBucket, type CrmCustomerStatus, type SavedCrmCustomer } from './lead-wizard';

export interface FunnelStage {
  status: CrmCustomerStatus;
  label: string;
  count: number;
  percentOfActive: number;
  conversionFromPrevious: number;
}

export interface DistributionItem {
  label: string;
  count: number;
  percent: number;
}

export interface CrmAnalytics {
  total: number;
  active: number;
  replied: number;
  quoted: number;
  overdue: number;
  totalQuoteConversion: number;
  funnel: FunnelStage[];
  priorities: DistributionItem[];
  countries: DistributionItem[];
  customerTypes: DistributionItem[];
  risks: {
    overdue: SavedCrmCustomer[];
    unscheduled: SavedCrmCustomer[];
    highScoreNew: SavedCrmCustomer[];
    paused: SavedCrmCustomer[];
  };
}

function percent(value: number, total: number) {
  return total > 0 ? Math.round((value / total) * 100) : 0;
}

function distribution(values: string[], limit = Number.POSITIVE_INFINITY): DistributionItem[] {
  const counts = new Map<string, number>();
  values.forEach((value) => {
    const label = value.trim() || '未填写';
    counts.set(label, (counts.get(label) || 0) + 1);
  });
  return Array.from(counts.entries())
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, limit)
    .map(([label, count]) => ({ label, count, percent: percent(count, values.length) }));
}

export function calculateCrmAnalytics(customers: SavedCrmCustomer[]): CrmAnalytics {
  const activeCustomers = customers.filter((customer) => customer.status !== 'paused');
  const active = activeCustomers.length;
  const contacted = activeCustomers.filter((customer) => ['contacted', 'replied', 'quoted'].includes(customer.status)).length;
  const replied = activeCustomers.filter((customer) => ['replied', 'quoted'].includes(customer.status)).length;
  const quoted = activeCustomers.filter((customer) => customer.status === 'quoted').length;

  const funnelData = [
    { status: 'new' as const, label: '活跃客户', count: active, previous: active },
    { status: 'contacted' as const, label: '已开发', count: contacted, previous: active },
    { status: 'replied' as const, label: '已回复', count: replied, previous: contacted },
    { status: 'quoted' as const, label: '已报价', count: quoted, previous: replied },
  ];

  const overdue = customers.filter((customer) => getCrmReminderBucket(customer) === 'overdue');
  const unscheduled = customers.filter((customer) => getCrmReminderBucket(customer) === 'unscheduled' && customer.status !== 'paused');
  const highScoreNew = customers.filter((customer) => customer.status === 'new' && customer.score >= 80);
  const paused = customers.filter((customer) => customer.status === 'paused');

  return {
    total: customers.length,
    active,
    replied,
    quoted,
    overdue: overdue.length,
    totalQuoteConversion: percent(quoted, active),
    funnel: funnelData.map((stage) => ({
      status: stage.status,
      label: stage.label,
      count: stage.count,
      percentOfActive: percent(stage.count, active),
      conversionFromPrevious: percent(stage.count, stage.previous),
    })),
    priorities: distribution(customers.map((customer) => customer.priority)),
    countries: distribution(customers.map((customer) => customer.country), 8),
    customerTypes: distribution(customers.map((customer) => customer.customerType), 8),
    risks: {
      overdue: overdue.slice(0, 6),
      unscheduled: unscheduled.slice(0, 6),
      highScoreNew: highScoreNew.sort((a, b) => b.score - a.score).slice(0, 6),
      paused: paused.slice(0, 6),
    },
  };
}
