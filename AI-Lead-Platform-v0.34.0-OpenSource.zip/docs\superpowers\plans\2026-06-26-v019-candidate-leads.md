# v0.19.0 Candidate Leads Pool Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a candidate lead pool where execution results can be reviewed, filtered, status-marked, and prepared for CRM.

**Architecture:** Extend `src/lib/lead-wizard.ts` with candidate lead storage helpers, create `/candidate-leads` as a client-side management page, and link the task runner into that page.

**Tech Stack:** Next.js App Router, React client components, TypeScript, browser localStorage, Tailwind CSS, local UI components.

---

### Task 1: Candidate Storage Helpers

**Files:**
- Modify: `src/lib/lead-wizard.ts`

- [ ] Add candidate pool status and saved candidate types.
- [ ] Add localStorage helpers for load, add, update, and delete.
- [ ] Add helper to seed candidates from a task execution preview.

### Task 2: Candidate Pool Page

**Files:**
- Create: `src/app/candidate-leads/page.tsx`

- [ ] Load candidates from localStorage.
- [ ] Render filter controls and summary cards.
- [ ] Render candidate cards with status update and join customer pool preview action.

### Task 3: Task Runner Entry

**Files:**
- Modify: `src/app/lead-tasks/[id]/page.tsx`

- [ ] Add button to save preview candidates into candidate pool.
- [ ] Add link to candidate pool.

### Task 4: Navigation And Docs

**Files:**
- Modify: `src/components/layout/sidebar.tsx`
- Modify: `src/lib/release-experience.ts`
- Modify: `package.json`
- Modify: `README.md`

- [ ] Add navigation item.
- [ ] Update version, release highlights, review pages, and README notes.

### Task 5: Verification And Package

**Files:**
- Create output zip: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.19.0-OpenSource.zip`

- [ ] Run `corepack pnpm run ts-check`.
- [ ] Run `corepack pnpm run lint:build`.
- [ ] Run `corepack pnpm run build`.
- [ ] Check `/candidate-leads`, `/lead-tasks`, and `/release`.
- [ ] Package without `node_modules`, `.next`, `.git`, `.env`, or `.env.local`.
