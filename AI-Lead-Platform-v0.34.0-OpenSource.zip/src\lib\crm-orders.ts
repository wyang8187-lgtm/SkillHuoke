import type { OpportunityCurrency } from './crm-opportunities';
import type { QuotationLineItem, SavedCrmQuotation, TradeTerm } from './crm-quotations';
import type { SavedCrmCustomer } from './lead-wizard';

export type CrmOrderStatus =
  | 'deposit_pending'
  | 'deposit_received'
  | 'production'
  | 'shipping_pending'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

export const CRM_ORDERS_STORAGE_KEY = 'skillhuoke_crm_orders_v030';

export const orderStatusOptions = [
  { value: 'deposit_pending' as const, label: '待收定金' },
  { value: 'deposit_received' as const, label: '已收定金' },
  { value: 'production' as const, label: '生产中' },
  { value: 'shipping_pending' as const, label: '待出货' },
  { value: 'shipped' as const, label: '已出货' },
  { value: 'delivered' as const, label: '已交付' },
  { value: 'cancelled' as const, label: '已取消' },
];

export interface SavedCrmOrder {
  id: string;
  number: string;
  customerId: string;
  customerName: string;
  contactName: string;
  opportunityId: string;
  quotationId: string;
  quotationNumber: string;
  currency: OpportunityCurrency;
  items: QuotationLineItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  tradeTerm: TradeTerm;
  paymentTerms: string;
  deliveryTime: string;
  quotationNote: string;
  depositPercent: number;
  depositReceived: number;
  depositReceivedAt: string;
  balanceReceived: number;
  balanceReceivedAt: string;
  expectedDeliveryDate: string;
  deliveredAt: string;
  status: CrmOrderStatus;
  internalNote: string;
  createdAt: string;
  updatedAt: string;
}

const money = (value: number) => Math.round(value * 100) / 100;

export function calculateOrderPayments(total: number, depositPercent: number, depositReceived: number, balanceReceived: number) {
  const safeTotal = Math.max(0, total);
  const percent = Math.min(100, Math.max(0, depositPercent));
  const depositDue = money(safeTotal * percent / 100);
  const balanceDue = money(safeTotal - depositDue);
  const received = money(Math.max(0, depositReceived) + Math.max(0, balanceReceived));
  return { depositDue, balanceDue, received, outstanding: money(Math.max(0, safeTotal - received)) };
}

export function generateOrderNumber() {
  const date = new Date();
  const pad = (value: number) => String(value).padStart(2, '0');
  return `SO-${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${date.getTime().toString(36).slice(-4).toUpperCase()}`;
}

export function validateOrder(order: SavedCrmOrder) {
  const errors: string[] = [];
  if (order.depositPercent < 0 || order.depositPercent > 100) errors.push('定金比例必须在 0 到 100 之间。');
  if (order.depositReceived < 0 || order.balanceReceived < 0) errors.push('收款金额不能为负数。');
  if (order.depositReceived + order.balanceReceived > order.total) errors.push('已收金额不能超过订单总额。');
  if (!order.number.trim()) errors.push('订单编号不能为空。');
  return errors;
}

export function createOrderFromQuotation(
  quotation: SavedCrmQuotation,
  customer: Pick<SavedCrmCustomer, 'company' | 'contactName'>,
): SavedCrmOrder {
  if (quotation.status !== 'accepted') throw new Error('只有已接受报价可以转为订单。');
  const subtotal = quotation.items.reduce((sum, item) => sum + Math.max(0, item.quantity) * Math.max(0, item.unitPrice), 0);
  const total = Math.max(0, subtotal - Math.max(0, quotation.discount) + Math.max(0, quotation.shipping) + Math.max(0, quotation.tax));
  const now = new Date().toISOString();
  return {
    id: `order-${Date.now()}`,
    number: generateOrderNumber(),
    customerId: quotation.customerId,
    customerName: customer.company,
    contactName: customer.contactName || quotation.contactName,
    opportunityId: quotation.opportunityId,
    quotationId: quotation.id,
    quotationNumber: quotation.number,
    currency: quotation.currency,
    items: quotation.items.map((item) => ({ ...item })),
    subtotal: money(subtotal),
    discount: quotation.discount,
    shipping: quotation.shipping,
    tax: quotation.tax,
    total: money(total),
    tradeTerm: quotation.tradeTerm,
    paymentTerms: quotation.paymentTerms,
    deliveryTime: quotation.deliveryTime,
    quotationNote: quotation.note,
    depositPercent: 30,
    depositReceived: 0,
    depositReceivedAt: '',
    balanceReceived: 0,
    balanceReceivedAt: '',
    expectedDeliveryDate: '',
    deliveredAt: '',
    status: 'deposit_pending',
    internalNote: '',
    createdAt: now,
    updatedAt: now,
  };
}

export function loadSavedCrmOrders(): SavedCrmOrder[] {
  if (typeof window === 'undefined') return [];
  try {
    const value = JSON.parse(window.localStorage.getItem(CRM_ORDERS_STORAGE_KEY) || '[]');
    return Array.isArray(value) ? value : [];
  } catch {
    return [];
  }
}

export function saveCrmOrders(orders: SavedCrmOrder[]) {
  if (typeof window !== 'undefined') window.localStorage.setItem(CRM_ORDERS_STORAGE_KEY, JSON.stringify(orders));
}

export function saveCrmOrder(order: SavedCrmOrder) {
  const errors = validateOrder(order);
  if (errors.length) throw new Error(errors[0]);
  const all = loadSavedCrmOrders();
  const existing = all.find((item) => item.id === order.id);
  const saved = { ...order, createdAt: existing?.createdAt || order.createdAt, updatedAt: new Date().toISOString() };
  saveCrmOrders(existing ? all.map((item) => item.id === order.id ? saved : item) : [saved, ...all]);
  return saved;
}

export function findOrderByQuotationId(quotationId: string) {
  return loadSavedCrmOrders().find((order) => order.quotationId === quotationId);
}

export function convertAcceptedQuotationToOrder(
  quotation: SavedCrmQuotation,
  customer?: Pick<SavedCrmCustomer, 'company' | 'contactName'>,
) {
  if (quotation.status !== 'accepted') throw new Error('只有已接受报价可以转为订单。');
  const existing = findOrderByQuotationId(quotation.id);
  if (existing) return existing;
  return saveCrmOrder(createOrderFromQuotation(quotation, {
    company: customer?.company || '',
    contactName: customer?.contactName || quotation.contactName,
  }));
}

export function deleteCrmOrder(id: string) {
  const next = loadSavedCrmOrders().filter((order) => order.id !== id);
  saveCrmOrders(next);
  return next;
}
