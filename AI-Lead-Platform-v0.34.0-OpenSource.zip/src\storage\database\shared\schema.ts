import { sql } from "drizzle-orm";
import { pgTable, serial, varchar, timestamp, boolean, integer, numeric, text, jsonb, index, uuid } from "drizzle-orm/pg-core";

// 系统表 - 必须保留
export const healthCheck = pgTable("health_check", {
  id: serial().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

// 用户角色表 - 用于区分管理员和普通成员
export const userRoles = pgTable(
  "user_roles",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    user_id: uuid("user_id").notNull(),
    role: varchar("role", { length: 20 }).notNull().default('member'), // 'admin' | 'member'
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("user_roles_user_id_idx").on(table.user_id),
    index("user_roles_role_idx").on(table.role),
  ]
);

// 客户表 - 场景D：用户私有数据
export const customers = pgTable(
  "customers",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    company_name: varchar("company_name", { length: 200 }).notNull(),
    customer_type: varchar("customer_type", { length: 50 }).notNull(), // 'full_designer' | 'building_materials'
    contact_name: varchar("contact_name", { length: 100 }).notNull(),
    phone: varchar("phone", { length: 20 }).notNull(),
    region: varchar("region", { length: 100 }).notNull(),
    address: varchar("address", { length: 500 }),
    source: varchar("source", { length: 100 }), // 来源渠道
    grade: varchar("grade", { length: 10 }).notNull().default('C'), // 'A' | 'B' | 'C' | 'D'
    status: varchar("status", { length: 50 }).notNull().default('new'), // 'new' | 'following' | 'negotiating' | 'won' | 'lost'
    tags: jsonb("tags").default([]), // 标签数组
    notes: text("notes"), // 备注
    last_follow_up_time: timestamp("last_follow_up_time", { withTimezone: true }),
    next_follow_up_time: timestamp("next_follow_up_time", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("customers_user_id_idx").on(table.user_id),
    index("customers_phone_idx").on(table.phone),
    index("customers_company_name_idx").on(table.company_name),
    index("customers_status_idx").on(table.status),
    index("customers_grade_idx").on(table.grade),
    index("customers_created_at_idx").on(table.created_at),
  ]
);

// 线索表 - 场景D：用户私有数据
export const leads = pgTable(
  "leads",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    company_name: varchar("company_name", { length: 200 }).notNull(),
    contact_name: varchar("contact_name", { length: 100 }),
    phone: varchar("phone", { length: 20 }),
    region: varchar("region", { length: 100 }),
    source: varchar("source", { length: 100 }), // 来源
    match_score: integer("match_score").default(0), // 匹配度评分
    status: varchar("status", { length: 50 }).notNull().default('new'), // 'new' | 'contacted' | 'converted' | 'invalid'
    assignee_id: uuid("assignee_id"), // 分配给团队成员
    assignee_name: varchar("assignee_name", { length: 100 }),
    notes: text("notes"),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("leads_user_id_idx").on(table.user_id),
    index("leads_phone_idx").on(table.phone),
    index("leads_status_idx").on(table.status),
    index("leads_assignee_id_idx").on(table.assignee_id),
    index("leads_created_at_idx").on(table.created_at),
  ]
);

// 商机表 - 场景D：用户私有数据
export const opportunities = pgTable(
  "opportunities",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    customer_id: varchar("customer_id", { length: 36 }).notNull().references(() => customers.id),
    customer_name: varchar("customer_name", { length: 200 }),
    name: varchar("name", { length: 200 }).notNull(), // 商机名称
    stage: varchar("stage", { length: 50 }).notNull().default('initial'), // 'initial' | 'requirement' | 'proposal' | 'negotiation' | 'won' | 'lost'
    amount: numeric("amount", { precision: 12, scale: 2 }).default(sql`0`), // 金额
    probability: integer("probability").default(0), // 成功概率
    expected_close_date: timestamp("expected_close_date", { withTimezone: true }),
    lost_reason: varchar("lost_reason", { length: 200 }), // 输单原因
    notes: text("notes"),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("opportunities_user_id_idx").on(table.user_id),
    index("opportunities_customer_id_idx").on(table.customer_id),
    index("opportunities_stage_idx").on(table.stage),
    index("opportunities_created_at_idx").on(table.created_at),
  ]
);

// 任务表 - 场景D：用户私有数据
export const tasks = pgTable(
  "tasks",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    customer_id: varchar("customer_id", { length: 36 }).references(() => customers.id),
    title: varchar("title", { length: 200 }).notNull(),
    description: text("description"),
    type: varchar("type", { length: 50 }).notNull().default('follow_up'), // 'follow_up' | 'call' | 'email' | 'visit' | 'other'
    status: varchar("status", { length: 50 }).notNull().default('pending'), // 'pending' | 'completed' | 'cancelled'
    priority: varchar("priority", { length: 20 }).notNull().default('medium'), // 'high' | 'medium' | 'low'
    due_time: timestamp("due_time", { withTimezone: true }),
    completed_time: timestamp("completed_time", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("tasks_user_id_idx").on(table.user_id),
    index("tasks_customer_id_idx").on(table.customer_id),
    index("tasks_status_idx").on(table.status),
    index("tasks_due_time_idx").on(table.due_time),
  ]
);

// 团队成员表 - 场景C：仅登录用户可读写
export const teamMembers = pgTable(
  "team_members",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`), // 关联auth.users
    name: varchar("name", { length: 100 }).notNull(),
    email: varchar("email", { length: 200 }).notNull(),
    role: varchar("role", { length: 50 }).notNull().default('member'), // 'admin' | 'member'
    status: varchar("status", { length: 50 }).notNull().default('active'), // 'active' | 'inactive'
    avatar_url: varchar("avatar_url", { length: 500 }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("team_members_user_id_idx").on(table.user_id),
    index("team_members_email_idx").on(table.email),
  ]
);

// 邮件模板表 - 场景D：用户私有数据
export const emailTemplates = pgTable(
  "email_templates",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    name: varchar("name", { length: 200 }).notNull(),
    category: varchar("category", { length: 50 }).notNull(), // '初次接触' | '产品介绍' | '合作邀请' | '价格咨询' | '跟进提醒' | '其他'
    subject: varchar("subject", { length: 500 }).notNull(),
    content: text("content").notNull(),
    style: varchar("style", { length: 50 }).default('正式'), // '正式' | '友好' | '简洁'
    is_default: boolean("is_default").default(false),
    usage_count: integer("usage_count").default(0),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("email_templates_user_id_idx").on(table.user_id),
    index("email_templates_category_idx").on(table.category),
  ]
);

// 邮件记录表 - 场景D：用户私有数据
export const emailRecords = pgTable(
  "email_records",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    customer_id: varchar("customer_id", { length: 36 }).references(() => customers.id),
    to_email: varchar("to_email", { length: 200 }).notNull(),
    subject: varchar("subject", { length: 500 }).notNull(),
    content: text("content").notNull(),
    template_id: varchar("template_id", { length: 36 }),
    status: varchar("status", { length: 50 }).notNull().default('sent'), // 'sent' | 'delivered' | 'opened' | 'clicked' | 'failed'
    sent_time: timestamp("sent_time", { withTimezone: true }).defaultNow().notNull(),
    opened_time: timestamp("opened_time", { withTimezone: true }),
    clicked_time: timestamp("clicked_time", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("email_records_user_id_idx").on(table.user_id),
    index("email_records_customer_id_idx").on(table.customer_id),
    index("email_records_status_idx").on(table.status),
    index("email_records_sent_time_idx").on(table.sent_time),
  ]
);

// 营销活动表 - 场景D：用户私有数据
export const campaigns = pgTable(
  "campaigns",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    name: varchar("name", { length: 200 }).notNull(),
    type: varchar("type", { length: 50 }).notNull(), // 'email' | 'social' | 'whatsapp'
    status: varchar("status", { length: 50 }).notNull().default('draft'), // 'draft' | 'running' | 'completed' | 'paused'
    target_count: integer("target_count").default(0), // 目标数量
    sent_count: integer("sent_count").default(0), // 已发送
    opened_count: integer("opened_count").default(0), // 已打开
    clicked_count: integer("clicked_count").default(0), // 已点击
    start_time: timestamp("start_time", { withTimezone: true }),
    end_time: timestamp("end_time", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("campaigns_user_id_idx").on(table.user_id),
    index("campaigns_status_idx").on(table.status),
    index("campaigns_type_idx").on(table.type),
  ]
);

// 自动化流程表 - 场景D：用户私有数据
export const automationFlows = pgTable(
  "automation_flows",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    name: varchar("name", { length: 200 }).notNull(),
    trigger_type: varchar("trigger_type", { length: 50 }).notNull(), // 'new_lead' | 'email_opened' | 'email_clicked' | 'time_based'
    trigger_config: jsonb("trigger_config").default({}), // 触发条件配置
    action_type: varchar("action_type", { length: 50 }).notNull(), // 'send_email' | 'create_task' | 'update_status' | 'notify'
    action_config: jsonb("action_config").default({}), // 动作配置
    status: varchar("status", { length: 50 }).notNull().default('active'), // 'active' | 'paused' | 'deleted'
    execution_count: integer("execution_count").default(0), // 执行次数
    last_execution_time: timestamp("last_execution_time", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updated_at: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("automation_flows_user_id_idx").on(table.user_id),
    index("automation_flows_status_idx").on(table.status),
    index("automation_flows_trigger_type_idx").on(table.trigger_type),
  ]
);

// 跟进记录表 - 场景D：用户私有数据
export const followUpRecords = pgTable(
  "follow_up_records",
  {
    id: varchar("id", { length: 36 }).primaryKey().default(sql`gen_random_uuid()`),
    user_id: uuid("user_id").notNull().default(sql`auth.uid()`),
    customer_id: varchar("customer_id", { length: 36 }).notNull().references(() => customers.id),
    type: varchar("type", { length: 50 }).notNull(), // 'call' | 'email' | 'visit' | 'wechat' | 'other'
    content: text("content").notNull(),
    next_action: varchar("next_action", { length: 200 }), // 下次跟进计划
    next_time: timestamp("next_time", { withTimezone: true }),
    created_at: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  },
  (table) => [
    index("follow_up_records_user_id_idx").on(table.user_id),
    index("follow_up_records_customer_id_idx").on(table.customer_id),
    index("follow_up_records_created_at_idx").on(table.created_at),
  ]
);

// 类型导出
export type Customer = typeof customers.$inferSelect;
export type Lead = typeof leads.$inferSelect;
export type Opportunity = typeof opportunities.$inferSelect;
export type Task = typeof tasks.$inferSelect;
export type TeamMember = typeof teamMembers.$inferSelect;
export type EmailTemplate = typeof emailTemplates.$inferSelect;
export type EmailRecord = typeof emailRecords.$inferSelect;
export type Campaign = typeof campaigns.$inferSelect;
export type AutomationFlow = typeof automationFlows.$inferSelect;
export type FollowUpRecord = typeof followUpRecords.$inferSelect;