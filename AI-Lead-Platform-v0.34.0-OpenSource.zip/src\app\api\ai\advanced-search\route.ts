import { NextRequest, NextResponse } from 'next/server';

// 行业标签预设
const INDUSTRY_TAGS = [
  '建材外贸', '家具出口', '全屋定制', '橱柜衣柜', '陶瓷卫浴',
  '五金配件', '照明灯饰', '地板门窗', '涂料化工', '机械装备',
  '纺织服装', '家电出口', '跨境电商', '进出口贸易', '国际物流'
];

// 区域预设
const REGIONS = {
  domestic: {
    '广东': {
      '广州': ['天河区', '番禺区', '白云区', '南沙区', '花都区'],
      '深圳': ['福田区', '南山区', '龙岗区', '宝安区', '龙华区', '光明区', '罗湖区'],
      '佛山': ['顺德区', '南海区', '禅城区', '三水区', '高明区'],
      '东莞': ['虎门镇', '厚街镇', '大朗镇', '常平镇', '长安镇', '寮步镇'],
      '中山': ['中山市区', '小榄镇', '古镇镇', '东凤镇'],
      '珠海': ['香洲区', '斗门区', '金湾区']
    },
    '浙江': {
      '杭州': ['余杭区', '西湖区', '滨江区', '萧山区'],
      '宁波': ['鄞州区', '北仑区', '慈溪市'],
      '温州': ['鹿城区', '瓯海区', '瑞安市']
    },
    '江苏': {
      '苏州': ['吴中区', '工业园区', '昆山市'],
      '南京': ['江宁区', '鼓楼区'],
      '无锡': ['锡山区', '惠山区']
    }
  },
  international: {
    '亚洲': ['日本', '韩国', '新加坡', '马来西亚', '泰国', '越南', '印度', '菲律宾'],
    '欧洲': ['德国', '法国', '英国', '意大利', '西班牙', '荷兰', '波兰'],
    '北美': ['美国', '加拿大'],
    '南美': ['巴西', '墨西哥', '阿根廷'],
    '大洋洲': ['澳大利亚', '新西兰'],
    '非洲': ['南非', '埃及', '尼日利亚']
  }
};

// 公司规模预设
const COMPANY_SIZES = ['大型(500人以上)', '中型(100-500人)', '小型(50-100人)', '微型(50人以下)'];

// 手机号验证
function isValidMobilePhone(phone: string): boolean {
  const mobileRegex = /^1[3-9]\d{9}$/;
  return mobileRegex.test(phone);
}

// 根据搜索条件生成模拟结果
function generateSearchResults(params: {
  industry?: string;
  region?: string;
  city?: string;
  district?: string;
  companySize?: string;
  customerType?: string;
  keywords?: string[];
}): Array<{
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  address: string;
  industry: string;
  companySize: string;
  customerType: string;
  matchScore: number;
  source: string;
  verified: boolean;
  tags: string[];
}> {
  const results = [];
  const count = Math.floor(Math.random() * 10) + 8;

  // 公司名称库 - 根据行业
  const companyPrefixes: Record<string, string[]> = {
    '建材外贸': ['宏达建材', '盈科建材', '鑫源建材', '恒信建材', '博远建材'],
    '家具出口': ['东方家具', '华艺家具', '美家家具', '雅居家具', '尚品家具'],
    '全屋定制': ['全屋之家', '定制空间', '理想家居', '尚层定制', '欧派定制'],
    '橱柜衣柜': ['金牌橱柜', '好太太衣柜', '索菲亚衣柜', '志邦橱柜'],
    '陶瓷卫浴': ['东鹏陶瓷', '箭牌卫浴', '恒洁卫浴', '马可波罗瓷砖'],
    '五金配件': ['坚朗五金', '汇泰龙五金', '雅洁五金', '顶固五金'],
    '照明灯饰': ['欧普照明', '雷士照明', '华艺灯饰', '三雄极光'],
    '地板门窗': ['圣象地板', '大自然地板', '盼盼门窗', '凤铝门窗'],
    '涂料化工': ['立邦涂料', '多乐士漆', '华润漆', '嘉宝莉漆'],
    '机械装备': ['大族激光', '博世机械', '西门子装备', 'ABB自动化'],
    '纺织服装': ['红豆纺织', '雅戈尔服装', '波司登服饰', '安踏服装'],
    '家电出口': ['格力电器', '美的集团', '海尔家电', 'TCL电子'],
    '跨境电商': ['跨境通电商', '有棵树电商', '安克创新', '傲基电商'],
    '进出口贸易': ['中粮贸易', '华润进出口', '广新外贸', '粤海进出口'],
    '国际物流': ['顺丰物流', 'DHL物流', 'FedEx快递', '马士基航运']
  };

  const surnames = ['王', '李', '张', '刘', '陈', '杨', '黄', '赵', '周', '吴', '郑', '孙', '林', '何', '郭'];
  const givenNames = ['伟', '芳', '娜', '敏', '静', '丽', '强', '磊', '洋', '艳', '勇', '军', '明', '华', '杰'];

  const industry = params.industry || INDUSTRY_TAGS[Math.floor(Math.random() * INDUSTRY_TAGS.length)];
  const region = params.region || '广东';
  const city = params.city || '深圳';
  
  const prefixes = companyPrefixes[industry] || companyPrefixes['建材外贸'];
    const domesticRegions = REGIONS.domestic as Record<string, Record<string, string[]>>;
  const districts = domesticRegions[region]?.[city] || ['某区'];

  for (let i = 0; i < count; i++) {
    // 生成真实手机号
    const phonePrefixes = ['138', '139', '150', '151', '152', '158', '159', '186', '187', '188', '189', '199'];
    const prefix = phonePrefixes[Math.floor(Math.random() * phonePrefixes.length)];
    const phoneSuffix = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    const phone = prefix + phoneSuffix;

    if (!isValidMobilePhone(phone)) continue;

    const prefixName = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffixes = ['有限公司', '股份有限公司', '集团', '贸易公司', '制造公司', '科技有限公司'];
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
    
    const district = districts[Math.floor(Math.random() * districts.length)];
    const streetNum = Math.floor(Math.random() * 200) + 1;

    const size = params.companySize || COMPANY_SIZES[Math.floor(Math.random() * COMPANY_SIZES.length)];
    const customerType = params.customerType || (Math.random() > 0.5 ? '全案设计师' : '建材外贸公司');

    // 根据匹配条件计算匹配度
    let matchScore = 70 + Math.floor(Math.random() * 30);
    if (params.industry && industry === params.industry) matchScore += 10;
    if (params.region && region === params.region) matchScore += 5;
    if (params.companySize && size === params.companySize) matchScore += 5;
    matchScore = Math.min(matchScore, 99);

    // 生成标签
    const tags = [industry, customerType];
    if (size.includes('大型')) tags.push('大客户');
    if (matchScore > 90) tags.push('高匹配');

    results.push({
      id: `adv_search_${Date.now()}_${i}`,
      companyName: `${region}${city}${prefixName}${suffix}`,
      contactName: surnames[Math.floor(Math.random() * surnames.length)] + givenNames[Math.floor(Math.random() * givenNames.length)],
      phone: phone,
      address: `${region}${city}${district}某路${streetNum}号`,
      industry: industry,
      companySize: size,
      customerType: customerType,
      matchScore: matchScore,
      source: '智能搜索',
      verified: true,
      tags: tags
    });
  }

  // 按匹配度排序
  return results.sort((a, b) => b.matchScore - a.matchScore);
}

// POST - AI高级组合搜索
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    const {
      industry,
      region,
      city,
      district,
      companySize,
      customerType,
      keywords
    } = body;

    // 验证至少有一个搜索条件
    if (!industry && !region && !companySize && !keywords?.length) {
      return NextResponse.json({
        success: false,
        error: '请至少提供一个搜索条件'
      }, { status: 400 });
    }

    // 生成搜索结果
    const results = generateSearchResults({
      industry,
      region,
      city,
      district,
      companySize,
      customerType,
      keywords
    });

    // 统计信息
    const stats = {
      total: results.length,
      byIndustry: results.reduce((acc, r) => {
        acc[r.industry] = (acc[r.industry] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      byRegion: results.reduce((acc, r) => {
        const addr = r.address.split('市')[0];
        acc[addr] = (acc[addr] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      avgMatchScore: Math.round(results.reduce((sum, r) => sum + r.matchScore, 0) / results.length)
    };

    return NextResponse.json({
      success: true,
      results,
      stats,
      searchParams: {
        industry,
        region,
        city,
        district,
        companySize,
        customerType,
        keywords
      },
      availableFilters: {
        industries: INDUSTRY_TAGS,
        regions: Object.keys(REGIONS.domestic),
        companySizes: COMPANY_SIZES
      },
      note: '当前为模拟数据，接入真实API后可获取实时企业数据'
    });

  } catch (error) {
    console.error('AI高级搜索错误:', error);
    return NextResponse.json({
      success: false,
      error: '搜索服务暂时不可用'
    }, { status: 500 });
  }
}

// GET - 获取筛选选项
export async function GET() {
  return NextResponse.json({
    success: true,
    data: {
      industries: INDUSTRY_TAGS,
      regions: REGIONS,
      companySizes: COMPANY_SIZES,
      customerTypes: ['全案设计师', '建材外贸公司', '家具出口商', '橱柜经销商', '卫浴代理商']
    }
  });
}