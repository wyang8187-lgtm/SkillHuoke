# v0.19.0 Candidate Leads Pool Design

## Goal

Turn task execution candidate previews into a manageable candidate lead pool.

## User Value

- 用户可以从执行台进入候选客户池，不再只看临时预览。
- 外贸团队可以筛选 A/B/C 级客户，标记开发状态，并模拟加入正式客户池。
- 这一步把流程推进为：获客向导 -> 任务记录 -> 执行台 -> 候选客户池 -> 客户池/CRM。

## Scope

- Add candidate lead local storage helpers.
- Add `/candidate-leads` page.
- Allow candidate status changes: 优先开发、需要核验、暂缓开发、已加入客户池.
- Allow priority filtering.
- Link task execution console to candidate pool.
- Update release center, README, and version.

## Out Of Scope

- Real CRM database writes.
- Real duplicate detection against existing customer tables.
- Multi-user candidate assignment.

## Acceptance Criteria

- `/candidate-leads` renders candidate leads from local storage.
- Users can seed candidate leads from task execution preview.
- Users can filter by priority and update candidate status.
- Users can mark a candidate as joined to customer pool preview.
- Type check, lint, build, and HTTP checks pass.
