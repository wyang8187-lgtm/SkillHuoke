'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, Plus, Edit, Trash2, Package, 
  Database, DollarSign, Archive, Tag
} from 'lucide-react';
import { useTheme } from '@/lib/theme-context';

interface Product {
  id: string;
  name: string;
  category: string;
  spec: string;
  unit: string;
  price: number;
  stock: number;
  status: string;
}

export default function ProductsPage() {
  const { theme } = useTheme();
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('全部');
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    category: '柜体',
    spec: '',
    unit: '平方米',
    price: '',
    stock: ''
  });

  useEffect(() => {
    fetchProducts();
  }, [selectedCategory, searchKeyword]);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedCategory !== '全部') params.append('category', selectedCategory);
      if (searchKeyword) params.append('keyword', searchKeyword);
      
      const response = await fetch(`/api/products?${params}`);
      const data = await response.json();
      if (data.success) {
        setProducts(data.data.products);
        setCategories(data.data.categories);
      }
    } catch (error) {
      console.error('获取产品列表失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = async () => {
    try {
      const response = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await response.json();
      if (data.success) {
        setShowAddModal(false);
        setFormData({ name: '', category: '柜体', spec: '', unit: '平方米', price: '', stock: '' });
        fetchProducts();
      }
    } catch (error) {
      console.error('添加产品失败:', error);
    }
  };

  const handleEditProduct = async () => {
    if (!editingProduct) return;
    try {
      const response = await fetch('/api/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: editingProduct.id, ...formData })
      });
      const data = await response.json();
      if (data.success) {
        setEditingProduct(null);
        setFormData({ name: '', category: '柜体', spec: '', unit: '平方米', price: '', stock: '' });
        fetchProducts();
      }
    } catch (error) {
      console.error('更新产品失败:', error);
    }
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('确定要删除此产品吗？')) return;
    try {
      const response = await fetch(`/api/products?id=${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        fetchProducts();
      }
    } catch (error) {
      console.error('删除产品失败:', error);
    }
  };

  const openEditModal = (product: Product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      category: product.category,
      spec: product.spec,
      unit: product.unit,
      price: product.price.toString(),
      stock: product.stock.toString()
    });
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      '柜体': 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      '门板': 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
      '台面': 'bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-300',
      '五金': 'bg-orange-100 text-orange-700 dark:bg-orange-900 dark:text-orange-300',
      '电器': 'bg-cyan-100 text-cyan-700 dark:bg-cyan-900 dark:text-cyan-300',
    };
    return colors[category] || 'bg-gray-100 text-gray-700';
  };

  const cardBg = theme === 'dark' ? 'bg-[#16213e]' : 'bg-white';
  const borderColor = theme === 'dark' ? 'border-[#1a1a2e]' : 'border-gray-200';

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">产品目录</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-1">管理全屋定制产品信息</p>
        </div>
        <Button
          onClick={() => setShowAddModal(true)}
          className="bg-gradient-to-r from-blue-500 to-blue-600 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          新增产品
        </Button>
      </div>

      {/* 搜索和筛选 */}
      <Card className={`${cardBg} ${borderColor}`}>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--text-secondary)]" />
                <Input
                  placeholder="搜索产品名称或规格..."
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  className="pl-10 bg-[var(--input-bg)] border-[var(--border-color)]"
                />
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              <Button
                variant={selectedCategory === '全部' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory('全部')}
                className={selectedCategory === '全部' ? 'bg-blue-500' : ''}
              >
                全部
              </Button>
              {categories.map(cat => (
                <Button
                  key={cat}
                  variant={selectedCategory === cat ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedCategory(cat)}
                  className={selectedCategory === cat ? 'bg-blue-500' : ''}
                >
                  {cat}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 产品列表 */}
      {loading ? (
        <div className="text-center py-12 text-[var(--text-secondary)]">加载中...</div>
      ) : products.length === 0 ? (
        <Card className={`${cardBg} ${borderColor}`}>
          <CardContent className="p-12 text-center">
            <Package className="h-12 w-12 mx-auto text-[var(--text-secondary)] mb-4" />
            <p className="text-[var(--text-secondary)]">暂无产品数据</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map(product => (
            <Card key={product.id} className={`${cardBg} ${borderColor} hover:shadow-lg transition-shadow`}>
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg text-[var(--text-primary)]">{product.name}</CardTitle>
                    <Badge className={`mt-2 ${getCategoryColor(product.category)}`}>
                      {product.category}
                    </Badge>
                  </div>
                  <Badge variant={product.status === '在售' ? 'default' : 'secondary'}>
                    {product.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                  <Database className="h-4 w-4" />
                  <span>{product.spec}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-green-500" />
                    <span className="text-lg font-bold text-green-500">
                      ¥{product.price}
                    </span>
                    <span className="text-sm text-[var(--text-secondary)]">/{product.unit}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[var(--text-secondary)]">
                    <Archive className="h-4 w-4" />
                    <span>库存: {product.stock}</span>
                  </div>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => openEditModal(product)}
                    className="flex-1"
                  >
                    <Edit className="h-3 w-3 mr-1" />
                    编辑
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteProduct(product.id)}
                    className="flex-1 text-red-500 hover:text-red-600"
                  >
                    <Trash2 className="h-3 w-3 mr-1" />
                    删除
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* 新增产品弹窗 */}
      {(showAddModal || editingProduct) && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className={`${cardBg} w-full max-w-md mx-4`}>
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">
                {editingProduct ? '编辑产品' : '新增产品'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">产品名称 *</label>
                <Input
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="如：定制衣柜"
                  className="bg-[var(--input-bg)] border-[var(--border-color)]"
                />
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">产品类别 *</label>
                <select
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  className="w-full h-10 px-3 rounded-md bg-[var(--input-bg)] border-[var(--border-color)] text-[var(--text-primary)]"
                >
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">规格说明</label>
                <Input
                  value={formData.spec}
                  onChange={(e) => setFormData({ ...formData, spec: e.target.value })}
                  placeholder="如：高度2.4m，宽度定制"
                  className="bg-[var(--input-bg)] border-[var(--border-color)]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-[var(--text-secondary)] mb-1 block">单价 *</label>
                  <Input
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    placeholder="800"
                    className="bg-[var(--input-bg)] border-[var(--border-color)]"
                  />
                </div>
                <div>
                  <label className="text-sm text-[var(--text-secondary)] mb-1 block">单位</label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full h-10 px-3 rounded-md bg-[var(--input-bg)] border-[var(--border-color)] text-[var(--text-primary)]"
                  >
                    <option value="平方米">平方米</option>
                    <option value="个">个</option>
                    <option value="台">台</option>
                    <option value="件">件</option>
                    <option value="套">套</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">库存数量</label>
                <Input
                  type="number"
                  value={formData.stock}
                  onChange={(e) => setFormData({ ...formData, stock: e.target.value })}
                  placeholder="100"
                  className="bg-[var(--input-bg)] border-[var(--border-color)]"
                />
              </div>
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingProduct(null);
                    setFormData({ name: '', category: '柜体', spec: '', unit: '平方米', price: '', stock: '' });
                  }}
                  className="flex-1"
                >
                  取消
                </Button>
                <Button
                  onClick={editingProduct ? handleEditProduct : handleAddProduct}
                  className="flex-1 bg-blue-500"
                >
                  {editingProduct ? '保存' : '添加'}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}