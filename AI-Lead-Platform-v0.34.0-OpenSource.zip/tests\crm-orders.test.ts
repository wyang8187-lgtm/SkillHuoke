import assert from 'node:assert/strict';
import {
  calculateOrderPayments,
  createOrderFromQuotation,
  validateOrder,
} from '../src/lib/crm-orders';

const quotation = {
  id: 'quote-1',
  number: 'SH-20260627-TEST',
  language: 'en' as const,
  customerId: 'customer-1',
  opportunityId: 'opportunity-1',
  contactName: 'Alex',
  currency: 'USD' as const,
  quotationDate: '2026-06-27',
  validUntil: '2026-07-27',
  tradeTerm: 'FOB' as const,
  paymentTerms: '30% deposit, 70% before shipment',
  deliveryTime: '30-45 days',
  note: 'Quote note',
  status: 'accepted' as const,
  items: [{ id: 'line-1', product: 'Kitchen Cabinet', specification: 'Oak', quantity: 2, unit: 'set', unitPrice: 5000 }],
  discount: 0,
  shipping: 500,
  tax: 0,
  createdAt: '2026-06-27T00:00:00.000Z',
  updatedAt: '2026-06-27T00:00:00.000Z',
};

assert.deepEqual(calculateOrderPayments(10500, 30, 3150, 0), {
  depositDue: 3150,
  balanceDue: 7350,
  received: 3150,
  outstanding: 7350,
});

const order = createOrderFromQuotation(quotation, { company: 'Example Builder', contactName: 'Alex' });
assert.equal(order.quotationId, 'quote-1');
assert.equal(order.total, 10500);
assert.equal(order.items[0].product, 'Kitchen Cabinet');
assert.notEqual(order.items, quotation.items);
assert.deepEqual(validateOrder({ ...order, depositReceived: 20000 }), ['已收金额不能超过订单总额。']);
assert.throws(
  () => createOrderFromQuotation({ ...quotation, status: 'draft' }, { company: 'Example Builder', contactName: 'Alex' }),
  /只有已接受报价可以转为订单/,
);

console.log('crm-orders tests passed');
