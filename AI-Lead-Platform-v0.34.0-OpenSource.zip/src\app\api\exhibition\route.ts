import { NextRequest, NextResponse } from 'next/server';

// 展会信息模拟API
// 真实实现需要接入展会信息聚合平台

interface Exhibition {
  id: string;
  name: string;
  industry: string;
  start_date: string;
  end_date: string;
  location: string;
  venue: string;
  exhibitors_count: number;
  visitors_estimate: number;
  description: string;
  website: string;
  status: 'upcoming' | 'ongoing' | 'completed';
}

// 模拟展会数据
const mockExhibitions: Exhibition[] = [
  {
    id: 'ex-001',
    name: '2024中国（广州）国际建材博览会',
    industry: '建材',
    start_date: '2024-03-15',
    end_date: '2024-03-18',
    location: '广州',
    venue: '广州保利世贸博览馆',
    exhibitors_count: 850,
    visitors_estimate: 50000,
    description: '华南地区规模最大的建材行业展会，涵盖瓷砖、卫浴、橱柜、门窗等领域',
    website: 'https://www.gzbuildingexpo.com',
    status: 'upcoming',
  },
  {
    id: 'ex-002',
    name: '第28届中国国际家具展览会',
    industry: '家具',
    start_date: '2024-04-08',
    end_date: '2024-04-12',
    location: '上海',
    venue: '上海新国际博览中心',
    exhibitors_count: 1200,
    visitors_estimate: 80000,
    description: '亚洲顶级家具展，覆盖民用家具、办公家具、定制家居等全产业链',
    website: 'https://www.furniturechina.com',
    status: 'upcoming',
  },
  {
    id: 'ex-003',
    name: '2024佛山陶瓷工业展',
    industry: '陶瓷',
    start_date: '2024-05-20',
    end_date: '2024-05-23',
    location: '佛山',
    venue: '佛山潭洲国际会展中心',
    exhibitors_count: 450,
    visitors_estimate: 30000,
    description: '陶瓷行业技术设备展会，展示最新陶瓷生产线、智能化制造技术',
    website: 'https://www.fsceramicexpo.com',
    status: 'upcoming',
  },
  {
    id: 'ex-004',
    name: '深圳国际家装设计与定制家居展',
    industry: '全屋定制',
    start_date: '2024-06-10',
    end_date: '2024-06-14',
    location: '深圳',
    venue: '深圳会展中心',
    exhibitors_count: 380,
    visitors_estimate: 25000,
    description: '聚焦家装设计与全屋定制，汇聚设计师、定制品牌、软装企业',
    website: 'https://www.szhomedesign.com',
    status: 'upcoming',
  },
  {
    id: 'ex-005',
    name: '2024东莞国际家具机械展',
    industry: '家具机械',
    start_date: '2024-07-15',
    end_date: '2024-07-18',
    location: '东莞',
    venue: '广东现代国际展览中心',
    exhibitors_count: 280,
    visitors_estimate: 15000,
    description: '家具生产设备与智能制造技术专业展会',
    website: 'https://www.dgfurnmachinery.com',
    status: 'upcoming',
  },
  {
    id: 'ex-006',
    name: 'Design Shanghai 上海国际设计周',
    industry: '设计',
    start_date: '2024-08-05',
    end_date: '2024-08-09',
    location: '上海',
    venue: '上海世博展览馆',
    exhibitors_count: 600,
    visitors_estimate: 45000,
    description: '顶级设计盛会，汇集国内外设计师、建筑师、家居品牌',
    website: 'https://www.designshanghai.com',
    status: 'upcoming',
  },
  {
    id: 'ex-007',
    name: '第12届广州定制家居展',
    industry: '全屋定制',
    start_date: '2023-12-10',
    end_date: '2023-12-13',
    location: '广州',
    venue: '广州国际采购中心',
    exhibitors_count: 520,
    visitors_estimate: 35000,
    description: '定制家居行业年度盛会，展示橱柜、衣柜、门窗等定制产品',
    website: 'https://www.gzcustomhome.com',
    status: 'completed',
  },
];

// GET - 查询展会信息
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const keyword = searchParams.get('keyword') || '';
    const industry = searchParams.get('industry') || '';
    const status = searchParams.get('status') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');

    let filtered = mockExhibitions;

    if (keyword) {
      const lowerKeyword = keyword.toLowerCase();
      filtered = filtered.filter(ex =>
        ex.name.toLowerCase().includes(lowerKeyword) ||
        ex.location.toLowerCase().includes(lowerKeyword)
      );
    }

    if (industry) {
      filtered = filtered.filter(ex => ex.industry === industry);
    }

    if (status) {
      filtered = filtered.filter(ex => ex.status === status);
    }

    const total = filtered.length;
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const data = filtered.slice(startIndex, endIndex);

    // 统计信息
    const upcomingCount = mockExhibitions.filter(ex => ex.status === 'upcoming').length;
    const ongoingCount = mockExhibitions.filter(ex => ex.status === 'ongoing').length;
    const completedCount = mockExhibitions.filter(ex => ex.status === 'completed').length;

    return NextResponse.json({
      success: true,
      data: data,
      pagination: {
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize),
      },
      stats: {
        upcoming: upcomingCount,
        ongoing: ongoingCount,
        completed: completedCount,
        total: mockExhibitions.length,
      },
      industries: ['建材', '家具', '陶瓷', '全屋定制', '家具机械', '设计'],
      note: '当前为模拟数据，接入展会信息API后可获取实时展会信息'
    });
  } catch (error) {
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}