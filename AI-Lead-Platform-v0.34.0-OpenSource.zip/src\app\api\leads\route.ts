// 线索池 API - GET获取列表, POST创建新线索
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取线索列表（支持筛选、分页）
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  // 获取查询参数
  const { searchParams } = new URL(req.url);
  const status = searchParams.get('status') || undefined;
  const source = searchParams.get('source') || undefined;
  const region = searchParams.get('region') || undefined;
  const keyword = searchParams.get('keyword') || undefined;
  const page = parseInt(searchParams.get('page') || '1');
  const pageSize = parseInt(searchParams.get('pageSize') || '20');

  try {
    const result = await dbService.getLeads(user.id, {
      status,
      source,
      region,
      keyword,
    }, page, pageSize);

    // 转换为前端需要的格式（移除不存在的字段）
    const leads = result.data.map(lead => ({
      id: lead.id,
      company_name: lead.company_name,
      contact_name: lead.contact_name || '',
      phone: lead.phone || '',
      region: lead.region || '',
      source: lead.source || '手动录入',
      status: lead.status,
      match_score: lead.match_score || 50,
      assignee_id: lead.assignee_id,
      assignee_name: lead.assignee_name,
      notes: lead.notes,
      user_id: lead.user_id,
      create_time: lead.created_at,
      update_time: lead.updated_at,
    }));

    return NextResponse.json({
      leads,
      total: result.total,
      page,
      pageSize,
    });
  } catch (error) {
    console.error('获取线索列表失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取线索列表失败' 
    }, { status: 500 });
  }
}

// 创建新线索
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();

    // 检查手机号是否重复
    if (body.phone) {
      const duplicate = await dbService.checkDuplicateLead(user.id, body.phone);
      if (duplicate) {
        return NextResponse.json({ 
          success: false,
          error: '该手机号已存在线索中' 
        }, { status: 400 });
      }
    }

    const lead = await dbService.createLead(user.id, {
      company_name: body.company_name,
      contact_name: body.contact_name || '',
      phone: body.phone || '',
      region: body.region || '',
      source: body.source || '手动录入',
      match_score: body.match_score || 50,
      status: 'new',
      assignee_id: body.assignee_id,
      assignee_name: body.assignee_name,
      notes: body.notes,
    });

    return NextResponse.json({ 
      success: true, 
      data: {
        id: lead.id,
        company_name: lead.company_name,
        contact_name: lead.contact_name,
        phone: lead.phone,
        region: lead.region,
        source: lead.source,
        match_score: lead.match_score,
        status: lead.status,
        create_time: lead.created_at,
      },
      message: '线索创建成功'
    });
  } catch (error) {
    console.error('创建线索失败:', error);
    return NextResponse.json({ 
      success: false,
      error: error instanceof Error ? error.message : '创建线索失败' 
    }, { status: 400 });
  }
}