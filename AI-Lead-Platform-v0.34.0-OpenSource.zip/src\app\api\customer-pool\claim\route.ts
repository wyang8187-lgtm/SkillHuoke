// 公海池认领 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 认领客户/线索
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { id, type } = body;

    if (!id || !type) {
      return NextResponse.json({ error: '缺少必要参数' }, { status: 400 });
    }

    const table = type === 'customer' ? 'customers' : 'leads';

    // 更新负责人
    const { error: updateError } = await client
      .from(table)
      .update({
        assignee_id: user.id,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id);

    if (updateError) {
      console.error('认领失败:', updateError);
      return NextResponse.json({ error: '认领失败' }, { status: 500 });
    }

    // 创建跟进记录
    await client.from('follow_up_records').insert({
      customer_id: type === 'customer' ? id : null,
      lead_id: type === 'lead' ? id : null,
      user_id: user.id,
      content: `从公海池认领${type === 'customer' ? '客户' : '线索'}`,
      type: '认领',
      created_at: new Date().toISOString(),
    });

    return NextResponse.json({ 
      success: true, 
      message: `已成功认领${type === 'customer' ? '客户' : '线索'}` 
    });
  } catch (error) {
    console.error('认领失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '认领失败' 
    }, { status: 500 });
  }
}