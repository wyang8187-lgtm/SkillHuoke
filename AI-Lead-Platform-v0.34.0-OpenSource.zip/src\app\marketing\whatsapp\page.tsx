'use client';

import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  MessageSquare,
  Send,
  FileText,
  History,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  Clock,
  Eye,
  Loader2,
  Phone,
  User,
  ChevronDown,
  Search,
  X,
} from 'lucide-react';

// 消息模板类型
interface MessageTemplate {
  id: string;
  name: string;
  category: string;
  content: string;
  variables: string[];
  created_at: string;
  usage_count: number;
}

// 发送记录类型
interface SendRecord {
  id: string;
  template_id: string;
  template_name: string;
  customer_name: string;
  customer_phone: string;
  content: string;
  status: 'sent' | 'delivered' | 'read' | 'replied' | 'failed';
  sent_time: string;
  read_time?: string;
  replied_time?: string;
}

// 统计数据
interface Statistics {
  total_sent: number;
  delivered: number;
  read: number;
  replied: number;
  delivery_rate: number;
  read_rate: number;
  reply_rate: number;
}

export default function WhatsAppPage() {
  const [templates, setTemplates] = useState<MessageTemplate[]>([]);
  const [records, setRecords] = useState<SendRecord[]>([]);
  const [stats, setStats] = useState<Statistics>({
    total_sent: 0,
    delivered: 0,
    read: 0,
    replied: 0,
    delivery_rate: 0,
    read_rate: 0,
    reply_rate: 0,
  });
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'send' | 'templates' | 'records'>('send');
  
  // 发送表单
  const [sendForm, setSendForm] = useState({
    customer_id: '',
    customer_name: '',
    customer_phone: '',
    template_id: '',
    content: '',
  });
  const [customers, setCustomers] = useState<any[]>([]);
  const [showCustomerSelect, setShowCustomerSelect] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<MessageTemplate | null>(null);

  // 编辑模板
  const [editTemplate, setEditTemplate] = useState<MessageTemplate | null>(null);
  const [showTemplateEdit, setShowTemplateEdit] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/whatsapp');
      if (res.ok) {
        const data = await res.json();
        setTemplates(data.templates || []);
        setRecords(data.records || []);
        setStats(data.stats || stats);
        setCustomers(data.customers || []);
      }
    } catch (error) {
      console.error('加载WhatsApp数据失败', error);
    } finally {
      setLoading(false);
    }
  };

  // 选择客户
  const handleSelectCustomer = (customer: any) => {
    setSendForm({
      ...sendForm,
      customer_id: customer.id,
      customer_name: customer.name,
      customer_phone: customer.phone,
    });
    setShowCustomerSelect(false);
  };

  // 选择模板
  const handleSelectTemplate = (template: MessageTemplate) => {
    setSelectedTemplate(template);
    setSendForm({
      ...sendForm,
      template_id: template.id,
      content: template.content,
    });
  };

  // 发送消息
  const handleSendMessage = async () => {
    if (!sendForm.customer_phone || !sendForm.content) {
      alert('请选择客户并填写消息内容');
      return;
    }

    try {
      const res = await fetch('/api/whatsapp/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(sendForm),
      });

      if (res.ok) {
        const data = await res.json();
        setRecords([data.record, ...records]);
        setStats({
          ...stats,
          total_sent: stats.total_sent + 1,
          delivered: stats.delivered + 1,
        });
        setSendForm({
          customer_id: '',
          customer_name: '',
          customer_phone: '',
          template_id: '',
          content: '',
        });
        setSelectedTemplate(null);
        alert('消息发送成功！（模拟）');
      } else {
        const data = await res.json();
        alert(data.error || '发送失败');
      }
    } catch (error) {
      alert('发送失败，请重试');
    }
  };

  // 创建/更新模板
  const handleSaveTemplate = async () => {
    if (!editTemplate?.name || !editTemplate?.content) {
      alert('请填写模板名称和内容');
      return;
    }

    try {
      const res = await fetch('/api/whatsapp/templates', {
        method: editTemplate.id ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editTemplate),
      });

      if (res.ok) {
        const data = await res.json();
        if (editTemplate.id) {
          setTemplates(templates.map(t => t.id === editTemplate.id ? data.template : t));
        } else {
          setTemplates([...templates, data.template]);
        }
        setShowTemplateEdit(false);
        setEditTemplate(null);
        alert('模板保存成功！');
      }
    } catch (error) {
      alert('保存失败，请重试');
    }
  };

  // 删除模板
  const handleDeleteTemplate = async (templateId: string) => {
    if (!confirm('确定要删除此模板吗？')) return;
    
    try {
      const res = await fetch(`/api/whatsapp/templates?id=${templateId}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        setTemplates(templates.filter(t => t.id !== templateId));
      }
    } catch (error) {
      console.error('删除模板失败', error);
    }
  };

  // 获取状态图标
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent': return <Clock className="h-4 w-4 text-muted-foreground" />;
      case 'delivered': return <CheckCircle className="h-4 w-4 text-blue-500" />;
      case 'read': return <Eye className="h-4 w-4 text-green-500" />;
      case 'replied': return <MessageSquare className="h-4 w-4 text-purple-500" />;
      case 'failed': return <X className="h-4 w-4 text-red-500" />;
      default: return null;
    }
  };

  // 获取状态文本
  const getStatusText = (status: string) => {
    switch (status) {
      case 'sent': return '已发送';
      case 'delivered': return '已送达';
      case 'read': return '已阅读';
      case 'replied': return '已回复';
      case 'failed': return '发送失败';
      default: return status;
    }
  };

  if (loading) {
    return (
      <MainLayout title="WhatsApp营销" breadcrumbs={[{ label: '营销中心' }, { label: 'WhatsApp' }]}>
        <div className="flex items-center justify-center h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="WhatsApp营销" breadcrumbs={[{ label: '营销中心' }, { label: 'WhatsApp' }]}>
      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center">
                <Send className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">已发送</p>
                <p className="text-2xl font-bold text-foreground">{stats.total_sent}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">送达率</p>
                <p className="text-2xl font-bold text-foreground">{stats.delivery_rate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                <Eye className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">阅读率</p>
                <p className="text-2xl font-bold text-foreground">{stats.read_rate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                <MessageSquare className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">回复率</p>
                <p className="text-2xl font-bold text-foreground">{stats.reply_rate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tab切换 */}
      <div className="flex gap-2 mb-4">
        <Button
          variant={activeTab === 'send' ? 'default' : 'outline'}
          onClick={() => setActiveTab('send')}
          className={activeTab === 'send' ? 'bg-primary' : ''}
        >
          <Send className="h-4 w-4 mr-2" />
          发送消息
        </Button>
        <Button
          variant={activeTab === 'templates' ? 'default' : 'outline'}
          onClick={() => setActiveTab('templates')}
          className={activeTab === 'templates' ? 'bg-primary' : ''}
        >
          <FileText className="h-4 w-4 mr-2" />
          消息模板 ({templates.length})
        </Button>
        <Button
          variant={activeTab === 'records' ? 'default' : 'outline'}
          onClick={() => setActiveTab('records')}
          className={activeTab === 'records' ? 'bg-primary' : ''}
        >
          <History className="h-4 w-4 mr-2" />
          发送记录 ({records.length})
        </Button>
      </div>

      {/* 发送消息 */}
      {activeTab === 'send' && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <Send className="h-5 w-5" />
              发送WhatsApp消息（模拟）
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* 选择客户 */}
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">选择客户 *</label>
                <div 
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground cursor-pointer flex items-center justify-between"
                  onClick={() => setShowCustomerSelect(!showCustomerSelect)}
                >
                  {sendForm.customer_name ? (
                    <span className="flex items-center gap-2">
                      <User className="h-4 w-4" />
                      {sendForm.customer_name} ({sendForm.customer_phone})
                    </span>
                  ) : (
                    <span className="text-muted-foreground">点击选择客户...</span>
                  )}
                  <ChevronDown className="h-4 w-4" />
                </div>
                
                {showCustomerSelect && (
                  <div className="mt-2 border border-border rounded-lg bg-card max-h-[200px] overflow-y-auto">
                    {customers.length > 0 ? (
                      customers.map((customer) => (
                        <div
                          key={customer.id}
                          className="p-2 hover:bg-muted cursor-pointer flex items-center gap-2"
                          onClick={() => handleSelectCustomer(customer)}
                        >
                          <User className="h-4 w-4 text-muted-foreground" />
                          <span className="text-foreground">{customer.name}</span>
                          <span className="text-muted-foreground text-sm">{customer.phone}</span>
                        </div>
                      ))
                    ) : (
                      <div className="p-4 text-center text-muted-foreground">
                        暂无客户数据
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* 选择模板 */}
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">选择模板（可选）</label>
                <div className="flex gap-2 flex-wrap">
                  {templates.map((template) => (
                    <Button
                      key={template.id}
                      variant={selectedTemplate?.id === template.id ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handleSelectTemplate(template)}
                      className={selectedTemplate?.id === template.id ? 'bg-primary' : ''}
                    >
                      {template.name}
                    </Button>
                  ))}
                </div>
              </div>

              {/* 消息内容 */}
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">消息内容 *</label>
                <textarea
                  value={sendForm.content}
                  onChange={(e) => setSendForm({ ...sendForm, content: e.target.value })}
                  placeholder="输入消息内容，可使用 {{姓名}}、{{公司}} 等变量..."
                  rows={5}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground focus:border-primary resize-none"
                />
                {selectedTemplate && (
                  <p className="text-sm text-muted-foreground mt-1">
                    模板变量：{selectedTemplate.variables.join(', ')}
                  </p>
                )}
              </div>

              {/* 发送按钮 */}
              <div className="flex gap-3">
                <Button
                  onClick={handleSendMessage}
                  className="bg-green-500 hover:bg-green-600"
                  disabled={!sendForm.customer_phone || !sendForm.content}
                >
                  <Send className="h-4 w-4 mr-2" />
                  发送消息
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setSendForm({
                      customer_id: '',
                      customer_name: '',
                      customer_phone: '',
                      template_id: '',
                      content: '',
                    });
                    setSelectedTemplate(null);
                  }}
                >
                  清空
                </Button>
              </div>

              <div className="mt-4 p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <p className="text-sm text-yellow-600">
                  注意：当前为模拟发送功能。接入真实WhatsApp API后，消息将实际发送到客户手机。
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* 消息模板 */}
      {activeTab === 'templates' && (
        <div className="space-y-4">
          <Button
            onClick={() => {
              setEditTemplate({
                id: '',
                name: '',
                category: '初次接触',
                content: '',
                variables: [],
                created_at: new Date().toISOString(),
                usage_count: 0,
              });
              setShowTemplateEdit(true);
            }}
            className="bg-primary"
          >
            <Plus className="h-4 w-4 mr-2" />
            新建模板
          </Button>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {templates.map((template) => (
              <Card key={template.id} className="bg-card border-border">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-medium text-foreground">{template.name}</h3>
                      <Badge variant="outline" className="mt-1">{template.category}</Badge>
                    </div>
                    <div className="flex gap-1">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setEditTemplate(template);
                          setShowTemplateEdit(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteTemplate(template.id)}
                        className="text-red-500"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2 line-clamp-3">
                    {template.content}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    使用次数：{template.usage_count}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          {templates.length === 0 && (
            <Card className="bg-card border-border">
              <CardContent className="p-8 text-center text-muted-foreground">
                <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>暂无消息模板</p>
                <p className="text-sm mt-1">点击"新建模板"创建常用消息模板</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* 发送记录 */}
      {activeTab === 'records' && (
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            {records.length > 0 ? (
              <div className="divide-y divide-border">
                {records.map((record) => (
                  <div key={record.id} className="p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="h-8 w-8 rounded-full bg-muted flex items-center justify-center">
                          <Phone className="h-4 w-4 text-muted-foreground" />
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{record.customer_name}</p>
                          <p className="text-sm text-muted-foreground">{record.customer_phone}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {getStatusIcon(record.status)}
                        <span className="text-sm">{getStatusText(record.status)}</span>
                      </div>
                    </div>
                    <div className="mt-2 p-2 bg-muted rounded text-sm text-muted-foreground">
                      {record.content.substring(0, 100)}...
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      发送时间：{new Date(record.sent_time).toLocaleString('zh-CN')}
                      {record.read_time && ` · 阅读时间：${new Date(record.read_time).toLocaleString('zh-CN')}`}
                    </p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>暂无发送记录</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* 编辑模板弹窗 */}
      {showTemplateEdit && editTemplate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="bg-card border-border w-full max-w-md">
            <CardHeader>
              <CardTitle className="text-foreground">
                {editTemplate.id ? '编辑模板' : '新建模板'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">模板名称</label>
                  <input
                    type="text"
                    value={editTemplate.name}
                    onChange={(e) => setEditTemplate({ ...editTemplate, name: e.target.value })}
                    placeholder="如：初次接触模板"
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground"
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">分类</label>
                  <select
                    value={editTemplate.category}
                    onChange={(e) => setEditTemplate({ ...editTemplate, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground"
                  >
                    <option value="初次接触">初次接触</option>
                    <option value="产品推荐">产品推荐</option>
                    <option value="跟进提醒">跟进提醒</option>
                    <option value="节日问候">节日问候</option>
                    <option value="其他">其他</option>
                  </select>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">消息内容</label>
                  <textarea
                    value={editTemplate.content}
                    onChange={(e) => setEditTemplate({ ...editTemplate, content: e.target.value })}
                    placeholder="您好 {{姓名}}，我是XX公司的..."
                    rows={5}
                    className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground resize-none"
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    可用变量：{`{{姓名}}`}、{`{{公司}}`}、{`{{产品}}`}
                  </p>
                </div>
                <div className="flex gap-3">
                  <Button onClick={handleSaveTemplate} className="bg-primary">
                    保存
                  </Button>
                  <Button variant="outline" onClick={() => setShowTemplateEdit(false)}>
                    取消
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </MainLayout>
  );
}