'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { AIPortraitAnalysis } from '@/components/ai-portrait';
import {
  Search,
  Plus,
  Eye,
  Edit,
  Trash2,
  Tag,
  UserPlus,
  Building2,
  Phone,
  MapPin,
  Clock,
  Calendar,
  ChevronLeft,
  ChevronRight,
  CheckCircle,
  AlertCircle,
  Loader2,
  Download,
  MessageSquare,
  Target,
  CheckSquare,
} from 'lucide-react';

// 类型定义
interface Customer {
  id: string;
  company_name?: string;
  customer_type?: string;
  contact_name?: string;
  phone?: string;
  region?: string;
  address?: string;
  grade?: string;
  status?: string;
  source?: string;
  tags?: string[];
  last_follow_up_time?: string | null;
  next_follow_up_time?: string | null;
  notes?: string | null;
  assignee_id?: string | null;
  assignee_name?: string | null;
  user_id: string;
  created_at?: string;
  updated_at?: string;
  [key: string]: unknown;
}

interface FollowUpRecord {
  id: string;
  customer_id: string;
  content: string;
  create_time: string;
  user_id: string;
  next_plan: string | null;
}

interface CustomerListResponse {
  customers: Customer[];
  total: number;
  page: number;
  pageSize: number;
}

interface StatsResponse {
  totalCustomers: number;
  totalLeads: number;
  totalOpportunities: number;
  totalTasks: number;
  customersByType: { type: string; count: number }[];
  customersByRegion: { region: string; count: number }[];
}

// 客户详情模态框
function CustomerDetailDialog({ 
  customerId, 
  open, 
  onClose,
  onUpdate 
}: {
  customerId: string | null;
  open: boolean;
  onClose: () => void;
  onUpdate: () => void;
}) {
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [followUpRecords, setFollowUpRecords] = useState<FollowUpRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [newFollowUp, setNewFollowUp] = useState('');
  const [nextPlan, setNextPlan] = useState('');
  const [addingFollowUp, setAddingFollowUp] = useState(false);

  useEffect(() => {
    if (customerId && open) {
      loadCustomerDetail();
    }
  }, [customerId, open]);

  const loadCustomerDetail = async () => {
    if (!customerId) return;
    setLoading(true);
    try {
      const res = await fetch(`/api/customers/${customerId}`);
      if (!res.ok) throw new Error('加载失败');
      const data = await res.json();
      setCustomer(data.customer);
      setFollowUpRecords(data.followUpRecords || []);
    } catch (error) {
      toast.error('加载客户详情失败');
    } finally {
      setLoading(false);
    }
  };

  const handleAddFollowUp = async () => {
    if (!customerId || !newFollowUp.trim()) return;
    setAddingFollowUp(true);
    try {
      const res = await fetch('/api/follow-up-records', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer_id: customerId,
          content: newFollowUp,
          next_plan: nextPlan || null,
        }),
      });
      if (!res.ok) throw new Error('添加失败');
      toast.success('跟进记录已添加');
      setNewFollowUp('');
      setNextPlan('');
      loadCustomerDetail();
      onUpdate();
    } catch (error) {
      toast.error('添加跟进记录失败');
    } finally {
      setAddingFollowUp(false);
    }
  };

  if (!customer && !loading) return null;

  const gradeColors: Record<string, string> = {
    A: '#22c55e',
    B: '#f97316',
    C: '#6b7280',
    D: '#ef4444',
  };

  const gradeColor = gradeColors[customer?.grade || 'C'];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-[#3b82f6]" />
            {loading ? '加载中...' : customer?.company_name}
            {customer && (
              <Badge 
                className="ml-2"
                style={{
                  backgroundColor: `${gradeColor}20`,
                  color: gradeColor,
                  border: `1px solid ${gradeColor}30`
                }}
              >
                {customer.grade || 'C'}类客户
              </Badge>
            )}
          </DialogTitle>
        </DialogHeader>
        
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
          </div>
        ) : customer && (
          <div className="grid grid-cols-2 gap-6 py-4">
            {/* 基本信息 */}
            <div className="space-y-4">
              <h3 className="text-sm text-[#94a3b8] uppercase">基本信息</h3>
              <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548] space-y-3">
                <div className="flex items-center gap-2">
                  <UserPlus className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">联系人：</span>
                  <span className="text-[#f8fafc]">{customer.contact_name}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">手机号：</span>
                  <span className="text-[#3b82f6]">{customer.phone}</span>
                  <CheckCircle className="h-3 w-3 text-[#22c55e]" />
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">地区：</span>
                  <span className="text-[#f8fafc]">{customer.region}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Building2 className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">地址：</span>
                  <span className="text-[#f8fafc]">{customer.address}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Tag className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">来源：</span>
                  <span className="text-[#f8fafc]">{customer.source}</span>
                </div>
              </div>
              
              {/* 标签 */}
              <h3 className="text-sm text-[#94a3b8] uppercase">客户标签</h3>
              <div className="flex flex-wrap gap-2">
                {customer.tags?.map((tag, idx) => (
                  <Badge key={idx} className="bg-[#3b82f6]/20 text-[#3b82f6]">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
            
            {/* 跟进信息 */}
            <div className="space-y-4">
              <h3 className="text-sm text-[#94a3b8] uppercase">跟进状态</h3>
              <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548] space-y-3">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-[#f97316]" />
                  <span className="text-[#94a3b8]">状态：</span>
                  <Badge className="bg-[#f97316]/20 text-[#f97316] border border-[#f97316]/30">
                    {customer.status}
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">最近跟进：</span>
                  <span className="text-[#f8fafc]">{customer.last_follow_up_time || '暂无'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-[#64748b]" />
                  <span className="text-[#94a3b8]">下次计划：</span>
                  <span className="text-[#f8fafc]">{customer.next_follow_up_time || '未设置'}</span>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {/* 添加跟进 */}
        <div className="border-t border-[#2d3548] pt-4">
          <h3 className="text-sm text-[#94a3b8] uppercase mb-4">添加跟进记录</h3>
          <div className="space-y-3">
            <Textarea
              placeholder="输入跟进内容..."
              value={newFollowUp}
              onChange={(e) => setNewFollowUp(e.target.value)}
              className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc] min-h-[80px]"
            />
            <Input
              placeholder="下一步计划（可选）"
              value={nextPlan}
              onChange={(e) => setNextPlan(e.target.value)}
              className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
            />
            <Button 
              onClick={handleAddFollowUp}
              disabled={addingFollowUp || !newFollowUp.trim()}
              className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
            >
              {addingFollowUp ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Plus className="h-4 w-4 mr-2" />
              )}
              添加跟进
            </Button>
          </div>
        </div>
        
        {/* AI客户画像分析 */}
        {customer && (
          <div className="border-t border-[#2d3548] pt-4">
            <AIPortraitAnalysis customer={customer} />
          </div>
        )}
        
        {/* 快捷操作按钮 */}
        <div className="border-t border-[#2d3548] pt-4">
          <h3 className="text-sm text-[#94a3b8] uppercase mb-3">快捷操作</h3>
          <div className="flex gap-2 flex-wrap">
            <Button
              size="sm"
              variant="outline"
              className="border-[#2d3548] text-[#f8fafc] hover:bg-[#1a1f2c]"
              onClick={() => {
                // TODO: 打开新增跟进记录对话框
                toast.info('新增跟进功能开发中');
              }}
            >
              <MessageSquare className="h-4 w-4 mr-1" />
              新增跟进
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="border-[#2d3548] text-[#f8fafc] hover:bg-[#1a1f2c]"
              onClick={() => {
                // TODO: 打开新增商机对话框
                toast.info('新增商机功能开发中');
              }}
            >
              <Target className="h-4 w-4 mr-1" />
              新增商机
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="border-[#2d3548] text-[#f8fafc] hover:bg-[#1a1f2c]"
              onClick={() => {
                // TODO: 打开新增任务对话框
                toast.info('新增任务功能开发中');
              }}
            >
              <CheckSquare className="h-4 w-4 mr-1" />
              新增任务
            </Button>
          </div>
        </div>
        
        {/* 跟进记录时间轴 */}
        <div className="border-t border-[#2d3548] pt-4">
          <h3 className="text-sm text-[#94a3b8] uppercase mb-4">跟进时间轴</h3>
          <div className="space-y-4 max-h-[200px] overflow-y-auto">
            {followUpRecords.length > 0 ? (
              followUpRecords.map(record => (
                <div key={record.id} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-[#3b82f6]/20 flex items-center justify-center">
                      <div className="w-3 h-3 rounded-full bg-[#3b82f6]" />
                    </div>
                    <div className="w-0.5 h-12 bg-[#2d3548] mt-1" />
                  </div>
                  <div className="flex-1 pb-4">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-xs text-[#64748b]">{record.create_time}</span>
                    </div>
                    <p className="text-sm text-[#94a3b8]">{record.content}</p>
                    {record.next_plan && (
                      <p className="text-xs text-[#3b82f6] mt-1">下一步：{record.next_plan}</p>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-[#64748b]">
                暂无跟进记录
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

// 新增客户模态框
function AddCustomerDialog({ 
  open, 
  onClose,
  onSuccess 
}: {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    type: '全案设计师',
    contact_name: '',
    phone: '',
    region: '深圳',
    address: '',
    grade: 'C',
    status: '初步接触',
    source: '手动录入',
    tags: '',
  });

  const handleSubmit = async () => {
    if (!formData.name || !formData.contact_name || !formData.phone) {
      toast.error('请填写必填信息');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          tags: formData.tags.split(',').map(t => t.trim()).filter(Boolean),
        }),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.error || '创建失败');
      }
      toast.success('客户已创建');
      setFormData({
        name: '',
        type: '全案设计师',
        contact_name: '',
        phone: '',
        region: '深圳',
        address: '',
        grade: 'C',
        status: '初步接触',
        source: '手动录入',
        tags: '',
      });
      onSuccess();
      onClose();
    } catch (error: unknown) {
      toast.error(error instanceof Error ? error.message : '创建客户失败');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
        <DialogHeader>
          <DialogTitle>新增客户</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-2 gap-4 py-4">
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">公司名称 *</label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">客户类型 *</label>
            <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="全案设计师">全案设计师</SelectItem>
                <SelectItem value="建材外贸公司">建材外贸公司</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">联系人 *</label>
            <Input
              value={formData.contact_name}
              onChange={(e) => setFormData({ ...formData, contact_name: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">手机号 *</label>
            <Input
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">地区</label>
            <Select value={formData.region} onValueChange={(v) => setFormData({ ...formData, region: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="深圳">深圳</SelectItem>
                <SelectItem value="广州">广州</SelectItem>
                <SelectItem value="佛山">佛山</SelectItem>
                <SelectItem value="东莞">东莞</SelectItem>
                <SelectItem value="珠海">珠海</SelectItem>
                <SelectItem value="中山">中山</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">详细地址</label>
            <Input
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">客户分级</label>
            <Select value={formData.grade} onValueChange={(v) => setFormData({ ...formData, grade: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="A">A类（高意向）</SelectItem>
                <SelectItem value="B">B类（培育中）</SelectItem>
                <SelectItem value="C">C类（潜在）</SelectItem>
                <SelectItem value="D">D类（无效）</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-sm text-[#94a3b8] mb-2 block">跟进状态</label>
            <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="初步接触">初步接触</SelectItem>
                <SelectItem value="需求确认">需求确认</SelectItem>
                <SelectItem value="方案报价">方案报价</SelectItem>
                <SelectItem value="谈判中">谈判中</SelectItem>
                <SelectItem value="已成交">已成交</SelectItem>
                <SelectItem value="已输单">已输单</SelectItem>
                <SelectItem value="待跟进">待跟进</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <label className="text-sm text-[#94a3b8] mb-2 block">来源渠道</label>
            <Select value={formData.source} onValueChange={(v) => setFormData({ ...formData, source: v })}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="手动录入">手动录入</SelectItem>
                <SelectItem value="智能搜索">智能搜索</SelectItem>
                <SelectItem value="企查查">企查查</SelectItem>
                <SelectItem value="天眼查">天眼查</SelectItem>
                <SelectItem value="展会名录">展会名录</SelectItem>
                <SelectItem value="设计师平台">设计师平台</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="col-span-2">
            <label className="text-sm text-[#94a3b8] mb-2 block">标签（逗号分隔）</label>
            <Input
              value={formData.tags}
              onChange={(e) => setFormData({ ...formData, tags: e.target.value })}
              placeholder="住宅全案,工装全案,陶瓷外贸..."
              className="bg-[#0f1419] border-[#2d3548]"
            />
          </div>
        </div>
        
        <div className="flex justify-end gap-2">
          <Button variant="outline" onClick={onClose} className="border-[#2d3548]">
            取消
          </Button>
          <Button onClick={handleSubmit} disabled={loading} className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
            {loading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
            创建客户
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function CustomersListPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedGrade, setSelectedGrade] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [showAdd, setShowAdd] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;
  
  // 批量操作状态
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showBatchAssign, setShowBatchAssign] = useState(false);
  const [showBatchTag, setShowBatchTag] = useState(false);
  const [showBatchGrade, setShowBatchGrade] = useState(false);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [assignTo, setAssignTo] = useState('');
  const [newTags, setNewTags] = useState('');
  const [newGrade, setNewGrade] = useState('');

  const loadCustomers = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: currentPage.toString(),
        pageSize: pageSize.toString(),
      });
      if (searchKeyword) params.append('keyword', searchKeyword);
      if (selectedGrade !== 'all') params.append('grade', selectedGrade);
      if (selectedType !== 'all') params.append('type', selectedType);
      if (selectedStatus !== 'all') params.append('status', selectedStatus);
      if (selectedRegion !== 'all') params.append('region', selectedRegion);

      const res = await fetch(`/api/customers?${params.toString()}`);
      if (!res.ok) throw new Error('加载失败');
      const data: CustomerListResponse = await res.json();
      setCustomers(data.customers);
      setTotal(data.total);
    } catch (error) {
      toast.error('加载客户列表失败');
    } finally {
      setLoading(false);
    }
  }, [currentPage, searchKeyword, selectedGrade, selectedType, selectedStatus, selectedRegion]);

  useEffect(() => {
    loadCustomers();
  }, [loadCustomers]);

  const handleDelete = async () => {
    if (!deleteId) return;
    try {
      const res = await fetch(`/api/customers/${deleteId}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('删除失败');
      toast.success('客户已删除');
      setDeleteId(null);
      loadCustomers();
    } catch (error) {
      toast.error('删除客户失败');
    }
  };

  // 全选/取消全选当前页
  const handleSelectAll = () => {
    if (selectedIds.length === customers.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(customers.map(c => c.id));
    }
  };

  // 单个选择
  const handleSelectOne = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  // 批量分配
  const handleBatchAssign = async () => {
    if (selectedIds.length === 0 || !assignTo) {
      toast.error('请选择客户并填写分配对象');
      return;
    }
    setBatchProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const res = await fetch('/api/customers/batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': session || ''
        },
        body: JSON.stringify({
          action: 'assign',
          customerIds: selectedIds,
          data: { ownerId: assignTo, ownerName: assignTo }
        })
      });
      if (!res.ok) throw new Error('分配失败');
      toast.success(`成功分配 ${selectedIds.length} 个客户`);
      setShowBatchAssign(false);
      setSelectedIds([]);
      loadCustomers();
    } catch (error) {
      toast.error('批量分配失败');
    } finally {
      setBatchProcessing(false);
    }
  };

  // 批量打标签
  const handleBatchTag = async () => {
    if (selectedIds.length === 0 || !newTags) {
      toast.error('请选择客户并填写标签');
      return;
    }
    setBatchProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const tags = newTags.split(',').map(t => t.trim()).filter(t => t);
      const res = await fetch('/api/customers/batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': session || ''
        },
        body: JSON.stringify({
          action: 'tag',
          customerIds: selectedIds,
          data: { tags }
        })
      });
      if (!res.ok) throw new Error('打标签失败');
      toast.success(`成功为 ${selectedIds.length} 个客户添加标签`);
      setShowBatchTag(false);
      setSelectedIds([]);
      setNewTags('');
      loadCustomers();
    } catch (error) {
      toast.error('批量打标签失败');
    } finally {
      setBatchProcessing(false);
    }
  };

  // 批量设置等级
  const handleBatchGrade = async () => {
    if (selectedIds.length === 0 || !newGrade) {
      toast.error('请选择客户并选择等级');
      return;
    }
    setBatchProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const res = await fetch('/api/customers/batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': session || ''
        },
        body: JSON.stringify({
          action: 'grade',
          customerIds: selectedIds,
          data: { grade: newGrade }
        })
      });
      if (!res.ok) throw new Error('设置等级失败');
      toast.success(`成功设置 ${selectedIds.length} 个客户的等级`);
      setShowBatchGrade(false);
      setSelectedIds([]);
      loadCustomers();
    } catch (error) {
      toast.error('批量设置等级失败');
    } finally {
      setBatchProcessing(false);
    }
  };

  // 批量删除
  const handleBatchDelete = async () => {
    if (selectedIds.length === 0) return;
    setBatchProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const res = await fetch('/api/customers/batch', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': session || ''
        },
        body: JSON.stringify({
          action: 'delete',
          customerIds: selectedIds
        })
      });
      if (!res.ok) throw new Error('删除失败');
      toast.success(`成功删除 ${selectedIds.length} 个客户`);
      setSelectedIds([]);
      loadCustomers();
    } catch (error) {
      toast.error('批量删除失败');
    } finally {
      setBatchProcessing(false);
    }
  };

  // 导出数据
  const handleExport = async () => {
    try {
      const session = localStorage.getItem('supabase_session');
      const idsParam = selectedIds.length > 0 ? `?ids=${selectedIds.join(',')}` : '';
      const res = await fetch(`/api/customers/export${idsParam}`, {
        headers: { 'x-session': session || '' }
      });
      if (!res.ok) throw new Error('导出失败');
      
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `customers_${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
      toast.success('导出成功');
    } catch (error) {
      toast.error('导出失败');
    }
  };

  const totalPages = Math.ceil(total / pageSize);

  const gradeColors: Record<string, string> = {
    A: '#22c55e',
    B: '#f97316',
    C: '#6b7280',
    D: '#ef4444',
  };

  const typeColors: Record<string, string> = {
    '全案设计师': '#3b82f6',
    '建材外贸公司': '#f97316',
  };

  const statusColors: Record<string, string> = {
    '初步接触': '#6b7280',
    '需求确认': '#3b82f6',
    '方案报价': '#8b5cf6',
    '谈判中': '#f97316',
    '已成交': '#22c55e',
    '已输单': '#ef4444',
    '待跟进': '#f59e0b',
  };

  return (
    <MainLayout title="客户列表">
      {/* 操作栏 */}
      <div className="flex flex-col md:flex-row gap-4 mb-6">
        {/* 搜索 */}
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#64748b]" />
          <Input
            placeholder="搜索客户名称、联系人..."
            value={searchKeyword}
            onChange={(e) => setSearchKeyword(e.target.value)}
            className="pl-12 h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]"
          />
        </div>
        
        {/* 篮选 */}
        <Select value={selectedGrade} onValueChange={setSelectedGrade}>
          <SelectTrigger className="w-[120px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="客户分级" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部等级</SelectItem>
            <SelectItem value="A" className="text-[#f8fafc]">A类</SelectItem>
            <SelectItem value="B" className="text-[#f8fafc]">B类</SelectItem>
            <SelectItem value="C" className="text-[#f8fafc]">C类</SelectItem>
            <SelectItem value="D" className="text-[#f8fafc]">D类</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={selectedType} onValueChange={setSelectedType}>
          <SelectTrigger className="w-[140px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="客户类型" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部类型</SelectItem>
            <SelectItem value="全案设计师" className="text-[#f8fafc]">全案设计师</SelectItem>
            <SelectItem value="建材外贸公司" className="text-[#f8fafc]">建材外贸公司</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={selectedStatus} onValueChange={setSelectedStatus}>
          <SelectTrigger className="w-[140px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="跟进状态" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部状态</SelectItem>
            <SelectItem value="初步接触" className="text-[#f8fafc]">初步接触</SelectItem>
            <SelectItem value="需求确认" className="text-[#f8fafc]">需求确认</SelectItem>
            <SelectItem value="方案报价" className="text-[#f8fafc]">方案报价</SelectItem>
            <SelectItem value="谈判中" className="text-[#f8fafc]">谈判中</SelectItem>
            <SelectItem value="已成交" className="text-[#f8fafc]">已成交</SelectItem>
            <SelectItem value="待跟进" className="text-[#f8fafc]">待跟进</SelectItem>
          </SelectContent>
        </Select>
        
        <Select value={selectedRegion} onValueChange={setSelectedRegion}>
          <SelectTrigger className="w-[100px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
            <SelectValue placeholder="地区" />
          </SelectTrigger>
          <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
            <SelectItem value="all" className="text-[#f8fafc]">全部地区</SelectItem>
            <SelectItem value="深圳" className="text-[#f8fafc]">深圳</SelectItem>
            <SelectItem value="广州" className="text-[#f8fafc]">广州</SelectItem>
            <SelectItem value="佛山" className="text-[#f8fafc]">佛山</SelectItem>
            <SelectItem value="东莞" className="text-[#f8fafc]">东莞</SelectItem>
          </SelectContent>
        </Select>
        
        <Button 
          onClick={() => setShowAdd(true)}
          className="h-12 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] px-6"
        >
          <Plus className="h-5 w-5 mr-2" />
          新增客户
        </Button>
        
        {/* 批量操作按钮 */}
        {selectedIds.length > 0 && (
          <div className="flex gap-2">
            <Badge variant="secondary" className="h-12 px-4 bg-[#f97316]/20 text-[#f97316]">
              已选择 {selectedIds.length} 个
            </Badge>
            <Button 
              variant="outline"
              onClick={() => setShowBatchAssign(true)}
              className="h-12 border-[#2d3548] text-[#f8fafc]"
            >
              <UserPlus className="h-4 w-4 mr-2" />
              批量分配
            </Button>
            <Button 
              variant="outline"
              onClick={() => setShowBatchTag(true)}
              className="h-12 border-[#2d3548] text-[#f8fafc]"
            >
              <Tag className="h-4 w-4 mr-2" />
              批量打标签
            </Button>
            <Button 
              variant="outline"
              onClick={() => setShowBatchGrade(true)}
              className="h-12 border-[#2d3548] text-[#f8fafc]"
            >
              批量设等级
            </Button>
            <Button 
              variant="outline"
              onClick={handleBatchDelete}
              className="h-12 border-[#ef4444] text-[#ef4444]"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              批量删除
            </Button>
          </div>
        )}
        
        {/* 导出按钮 */}
        <Button 
          variant="outline"
          onClick={handleExport}
          className="h-12 border-[#2d3548] text-[#f8fafc]"
        >
          <Download className="h-4 w-4 mr-2" />
          {selectedIds.length > 0 ? '导出选中' : '导出全部'}
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#f8fafc]">{total}</div>
            <div className="text-sm text-[#94a3b8]">客户总数</div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#22c55e]">
              {customers.filter(c => c.status === '已成交').length}
            </div>
            <div className="text-sm text-[#94a3b8]">已成交</div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#f97316]">
              {customers.filter(c => c.status === '谈判中').length}
            </div>
            <div className="text-sm text-[#94a3b8]">谈判中</div>
          </CardContent>
        </Card>
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-[#f59e0b]">
              {customers.filter(c => c.status === '待跟进').length}
            </div>
            <div className="text-sm text-[#94a3b8]">待跟进</div>
          </CardContent>
        </Card>
      </div>

      {/* 客户表格 */}
      <Card className="bg-[#1a1f2c] border-[#2d3548]">
        <CardHeader>
          <CardTitle className="text-[#f8fafc]">客户列表</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow className="border-[#2d3548]">
                  <TableHead className="w-12">
                    <input
                      type="checkbox"
                      checked={selectedIds.length === customers.length && customers.length > 0}
                      onChange={handleSelectAll}
                      className="w-4 h-4 rounded border-[#2d3548] bg-[#1a1f2c]"
                    />
                  </TableHead>
                  <TableHead className="text-[#94a3b8]">公司名称</TableHead>
                  <TableHead className="text-[#94a3b8]">类型</TableHead>
                  <TableHead className="text-[#94a3b8]">联系人</TableHead>
                  <TableHead className="text-[#94a3b8]">手机号</TableHead>
                  <TableHead className="text-[#94a3b8]">地区</TableHead>
                  <TableHead className="text-[#94a3b8]">等级</TableHead>
                  <TableHead className="text-[#94a3b8]">状态</TableHead>
                  <TableHead className="text-[#94a3b8]">最近跟进</TableHead>
                  <TableHead className="text-[#94a3b8]">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {customers.length > 0 ? (
                  customers.map((customer) => (
                    <TableRow key={customer.id} className="border-[#2d3548]">
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={selectedIds.includes(customer.id)}
                          onChange={() => handleSelectOne(customer.id)}
                          className="w-4 h-4 rounded border-[#2d3548] bg-[#1a1f2c]"
                        />
                      </TableCell>
                      <TableCell className="text-[#f8fafc] font-medium">
                        {customer.company_name}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className="text-xs"
                          style={{
                            backgroundColor: `${typeColors[customer.customer_type || '全案设计师'] || '#3b82f6'}20`,
                            color: typeColors[customer.customer_type || '全案设计师'] || '#3b82f6',
                          }}
                        >
                          {customer.customer_type || '未知'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#f8fafc]">
                        {customer.contact_name}
                      </TableCell>
                      <TableCell className="text-[#3b82f6]">
                        {customer.phone}
                      </TableCell>
                      <TableCell className="text-[#f8fafc]">
                        {customer.region}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className="text-xs"
                          style={{
                            backgroundColor: `${gradeColors[customer.grade || 'C']}20`,
                            color: gradeColors[customer.grade || 'C'],
                          }}
                        >
                          {customer.grade || 'C'}类
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          className="text-xs"
                          style={{
                            backgroundColor: `${statusColors[customer.status || '待跟进']}20`,
                            color: statusColors[customer.status || '待跟进'],
                          }}
                        >
                          {customer.status || '待跟进'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#94a3b8] text-sm">
                        {customer.last_follow_up_time || '暂无'}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => {
                              setSelectedCustomerId(customer.id);
                              setShowDetail(true);
                            }}
                            className="text-[#3b82f6] hover:text-[#3b82f6] hover:bg-[#3b82f6]/10"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => setDeleteId(customer.id)}
                            className="text-[#ef4444] hover:text-[#ef4444] hover:bg-[#ef4444]/10"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={9} className="text-center py-8 text-[#64748b]">
                      暂无客户数据
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          )}
          
          {/* 分页 */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <div className="text-sm text-[#94a3b8]">
                共 {total} 条，第 {currentPage}/{totalPages} 页
              </div>
              <div className="flex gap-2">
                <Button 
                  size="sm" 
                  variant="outline"
                  disabled={currentPage <= 1}
                  onClick={() => setCurrentPage(p => p - 1)}
                  className="border-[#2d3548]"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button 
                  size="sm" 
                  variant="outline"
                  disabled={currentPage >= totalPages}
                  onClick={() => setCurrentPage(p => p + 1)}
                  className="border-[#2d3548]"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 客户详情模态框 */}
      <CustomerDetailDialog
        customerId={selectedCustomerId}
        open={showDetail}
        onClose={() => setShowDetail(false)}
        onUpdate={loadCustomers}
      />

      {/* 新增客户模态框 */}
      <AddCustomerDialog
        open={showAdd}
        onClose={() => setShowAdd(false)}
        onSuccess={loadCustomers}
      />

      {/* 删除确认 */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
          <AlertDialogHeader>
            <AlertDialogTitle>确认删除</AlertDialogTitle>
            <AlertDialogDescription className="text-[#94a3b8]">
              此操作将永久删除该客户及其所有跟进记录，无法恢复。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2d3548]">取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-[#ef4444]">
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* 批量分配Dialog */}
      <Dialog open={showBatchAssign} onOpenChange={setShowBatchAssign}>
        <DialogContent className="bg-[#1a1f2c] border-[#2d3548]">
          <DialogHeader>
            <DialogTitle className="text-[#f8fafc]">批量分配客户</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-[#94a3b8]">已选择 {selectedIds.length} 个客户</p>
            <Input
              placeholder="输入分配对象名称"
              value={assignTo}
              onChange={(e) => setAssignTo(e.target.value)}
              className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
            />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowBatchAssign(false)} className="border-[#2d3548]">
                取消
              </Button>
              <Button 
                onClick={handleBatchAssign} 
                disabled={batchProcessing || !assignTo}
                className="bg-[#3b82f6]"
              >
                {batchProcessing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                确认分配
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 批量打标签Dialog */}
      <Dialog open={showBatchTag} onOpenChange={setShowBatchTag}>
        <DialogContent className="bg-[#1a1f2c] border-[#2d3548]">
          <DialogHeader>
            <DialogTitle className="text-[#f8fafc]">批量打标签</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-[#94a3b8]">已选择 {selectedIds.length} 个客户</p>
            <Input
              placeholder="输入标签，多个用逗号分隔"
              value={newTags}
              onChange={(e) => setNewTags(e.target.value)}
              className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
            />
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setNewTags('住宅全案')}
                className="border-[#2d3548] text-[#f8fafc]"
              >
                住宅全案
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setNewTags('工装全案')}
                className="border-[#2d3548] text-[#f8fafc]"
              >
                工装全案
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setNewTags('陶瓷外贸')}
                className="border-[#2d3548] text-[#f8fafc]"
              >
                陶瓷外贸
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setNewTags('家具外贸')}
                className="border-[#2d3548] text-[#f8fafc]"
              >
                家具外贸
              </Button>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowBatchTag(false)} className="border-[#2d3548]">
                取消
              </Button>
              <Button 
                onClick={handleBatchTag} 
                disabled={batchProcessing || !newTags}
                className="bg-[#3b82f6]"
              >
                {batchProcessing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                确认添加
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 批量设置等级Dialog */}
      <Dialog open={showBatchGrade} onOpenChange={setShowBatchGrade}>
        <DialogContent className="bg-[#1a1f2c] border-[#2d3548]">
          <DialogHeader>
            <DialogTitle className="text-[#f8fafc]">批量设置等级</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-[#94a3b8]">已选择 {selectedIds.length} 个客户</p>
            <Select value={newGrade} onValueChange={setNewGrade}>
              <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                <SelectValue placeholder="选择等级" />
              </SelectTrigger>
              <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                <SelectItem value="A" className="text-[#f8fafc]">A类（高意向）</SelectItem>
                <SelectItem value="B" className="text-[#f8fafc]">B类（培育中）</SelectItem>
                <SelectItem value="C" className="text-[#f8fafc]">C类（潜在）</SelectItem>
                <SelectItem value="D" className="text-[#f8fafc]">D类（无效）</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowBatchGrade(false)} className="border-[#2d3548]">
                取消
              </Button>
              <Button 
                onClick={handleBatchGrade} 
                disabled={batchProcessing || !newGrade}
                className="bg-[#3b82f6]"
              >
                {batchProcessing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                确认设置
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
}