# v0.17.0 Lead Task Storage Design

## Goal

Let users save generated lead wizard plans as local lead tasks, review task history, update execution status, and export task content.

## User Value

- 用户不再只是临时生成获客方案，可以沉淀成任务记录。
- 外贸团队可以按任务状态推进：草稿、待执行、执行中、已完成。
- 后续可以把本地任务记录升级为后端自动化任务队列。

## Scope

- Add local lead task storage helpers.
- Upgrade `/lead-wizard` with save and export actions.
- Add `/lead-tasks` task record page.
- Add status editing in local browser storage.
- Add navigation and release notes.

## Out Of Scope

- Server-side database persistence.
- Real scheduled queue execution.
- Multi-user task assignment.

## Acceptance Criteria

- Users can save a task from `/lead-wizard`.
- `/lead-tasks` lists saved tasks from local storage.
- Users can change task status locally.
- Users can export task content as a text file.
- Type check, lint, build, and HTTP checks pass.
