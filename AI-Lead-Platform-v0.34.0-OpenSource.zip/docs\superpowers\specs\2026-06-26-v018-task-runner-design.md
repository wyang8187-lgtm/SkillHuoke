# v0.18.0 Task Runner Design

## Goal

Turn saved lead tasks into an execution console with workflow steps, running logs, and candidate lead result previews.

## User Value

- 用户不只是保存任务，还能看到任务“执行中”的过程。
- 外贸老板可以理解自动获客系统未来如何跑：关键词、搜索、解析、联系方式提取、真实性评分、候选客户沉淀。
- 任务执行台为后续真实后端任务队列打前端基础。

## Scope

- Add task execution step and candidate result models.
- Add deterministic simulated execution data from saved task input.
- Add `/lead-tasks/[id]` execution console.
- Link task records to execution console.
- Update release center, README, and version.

## Out Of Scope

- Real internet search.
- Real contact extraction.
- Server-side task queue.
- Persisted candidate lead database.

## Acceptance Criteria

- `/lead-tasks/[id]` loads a saved local task by id.
- Execution console shows workflow steps, run logs, and candidate result preview.
- Users can mark a task as running or completed from the execution console.
- Task record page links each task to its execution console.
- Type check, lint, build, and HTTP checks pass.
