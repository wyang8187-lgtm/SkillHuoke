import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 获取当前用户的角色
export async function GET(request: NextRequest) {
  try {
    const sessionToken = request.headers.get('x-session');
    
    if (!sessionToken) {
      return NextResponse.json({ error: '未登录' }, { status: 401 });
    }
    
    const supabase = getSupabaseClient(sessionToken);
    
    // 获取当前用户信息
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError || !user) {
      return NextResponse.json({ error: '用户信息无效' }, { status: 401 });
    }
    
    // 获取用户角色
    const { data: roleData, error: roleError } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();
    
    // 如果没有角色记录，说明是新用户，默认是member
    const role = roleData?.role || 'member';
    
    return NextResponse.json({
      userId: user.id,
      email: user.email,
      role: role,
      isAdmin: role === 'admin'
    });
  } catch (error) {
    console.error('获取用户角色失败:', error);
    return NextResponse.json({ error: '获取用户角色失败' }, { status: 500 });
  }
}