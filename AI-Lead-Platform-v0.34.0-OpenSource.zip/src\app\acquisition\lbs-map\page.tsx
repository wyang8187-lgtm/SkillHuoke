'use client';

import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  MapPin,
  Map,
  Users,
  Building2,
  Navigation,
  Loader2,
  ZoomIn,
  ZoomOut,
  Filter,
  RefreshCw,
  ChevronRight,
  ChevronLeft,
  Eye,
} from 'lucide-react';

// 地区类型
interface Region {
  name: string;
  customers: Customer[];
  count: number;
}

// 客户类型
interface Customer {
  id: string;
  name: string;
  company: string;
  phone: string;
  address: string;
  type: '设计师' | '建材外贸';
  grade: 'A' | 'B' | 'C' | 'D';
  region: string;
  position: { x: number; y: number };
}

// 地区数据
const regions: Region[] = [
  { name: '深圳', customers: [], count: 45 },
  { name: '广州', customers: [], count: 38 },
  { name: '佛山', customers: [], count: 32 },
  { name: '东莞', customers: [], count: 28 },
];

// 模拟客户数据（带位置坐标）
const mockCustomers: Customer[] = [
  {
    id: 'cust_001',
    name: '张设计师',
    company: '深圳某某设计公司',
    phone: '13912345678',
    address: '深圳市福田区CBD中心',
    type: '设计师',
    grade: 'A',
    region: '深圳',
    position: { x: 150, y: 80 },
  },
  {
    id: 'cust_002',
    name: '李经理',
    company: '深圳某某建材贸易公司',
    phone: '13898765432',
    address: '深圳市南山区科技园',
    type: '建材外贸',
    grade: 'B',
    region: '深圳',
    position: { x: 180, y: 120 },
  },
  {
    id: 'cust_003',
    name: '王总监',
    company: '广州某某家居有限公司',
    phone: '13612349876',
    address: '广州市天河区珠江新城',
    type: '设计师',
    grade: 'A',
    region: '广州',
    position: { x: 280, y: 100 },
  },
  {
    id: 'cust_004',
    name: '陈设计师',
    company: '广州某某室内设计工作室',
    phone: '13587654321',
    address: '广州市白云区设计城',
    type: '设计师',
    grade: 'B',
    region: '广州',
    position: { x: 300, y: 150 },
  },
  {
    id: 'cust_005',
    name: '赵经理',
    company: '佛山某某建材外贸公司',
    phone: '13456789012',
    address: '佛山市南海区建材市场',
    type: '建材外贸',
    grade: 'A',
    region: '佛山',
    position: { x: 400, y: 120 },
  },
  {
    id: 'cust_006',
    name: '孙总监',
    company: '佛山某某全屋定制工厂',
    phone: '13345678901',
    address: '佛山市顺德区家具产业园',
    type: '建材外贸',
    grade: 'C',
    region: '佛山',
    position: { x: 380, y: 180 },
  },
  {
    id: 'cust_007',
    name: '周设计师',
    company: '东莞某某设计工作室',
    phone: '13234567890',
    address: '东莞市厚街镇家具大道',
    type: '设计师',
    grade: 'B',
    region: '东莞',
    position: { x: 500, y: 100 },
  },
  {
    id: 'cust_008',
    name: '吴经理',
    company: '东莞某某建材公司',
    phone: '13123456789',
    address: '东莞市大岭山镇工业区',
    type: '建材外贸',
    grade: 'D',
    region: '东莞',
    position: { x: 520, y: 160 },
  },
];

export default function LBSMapPage() {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedRegion, setSelectedRegion] = useState<string>('全部');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer | null>(null);
  const [loading, setLoading] = useState(true);
  const [mapZoom, setMapZoom] = useState(1);
  const [showDetails, setShowDetails] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/lbs-map');
      if (res.ok) {
        const data = await res.json();
        setCustomers(data.customers || mockCustomers);
      } else {
        setCustomers(mockCustomers);
      }
    } catch (error) {
      console.error('加载地图数据失败', error);
      setCustomers(mockCustomers);
    } finally {
      setLoading(false);
    }
  };

  // 筛选客户
  const filteredCustomers = selectedRegion === '全部' 
    ? customers 
    : customers.filter(c => c.region === selectedRegion);

  // 获取客户类型颜色
  const getTypeColor = (type: string) => {
    return type === '设计师' ? '#3b82f6' : '#f97316';
  };

  // 获取客户等级颜色
  const getGradeColor = (grade: string) => {
    switch (grade) {
      case 'A': return '#22c55e';
      case 'B': return '#f97316';
      case 'C': return '#6b7280';
      case 'D': return '#ef4444';
      default: return '#6b7280';
    }
  };

  // 获取地区统计
  const getRegionStats = () => {
    const stats: { [key: string]: { total: number; designers: number; traders: number } } = {};
    regions.forEach(r => {
      stats[r.name] = {
        total: customers.filter(c => c.region === r.name).length,
        designers: customers.filter(c => c.region === r.name && c.type === '设计师').length,
        traders: customers.filter(c => c.region === r.name && c.type === '建材外贸').length,
      };
    });
    return stats;
  };

  // 点击地图上的客户点
  const handlePointClick = (customer: Customer) => {
    setSelectedCustomer(customer);
    setShowDetails(true);
  };

  // 获取地图背景路径（简化的大湾区轮廓）
  const getMapPath = () => {
    return `
      M 100,60 
      L 200,40 
      L 350,50 
      L 450,70 
      L 550,90 
      L 580,150 
      L 550,200 
      L 450,220 
      L 300,210 
      L 200,200 
      L 100,180 
      L 80,120 
      Z
    `;
  };

  if (loading) {
    return (
      <MainLayout title="LBS地图获客" breadcrumbs={[{ label: 'AI获客中心' }, { label: '地图获客' }]}>
        <div className="flex items-center justify-center h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  const regionStats = getRegionStats();

  return (
    <MainLayout title="LBS地图获客" breadcrumbs={[{ label: 'AI获客中心' }, { label: '地图获客' }]}>
      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center">
                <MapPin className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">覆盖城市</p>
                <p className="text-2xl font-bold text-foreground">{regions.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-blue-500/20 flex items-center justify-center">
                <Users className="h-5 w-5 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">客户总数</p>
                <p className="text-2xl font-bold text-foreground">{customers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                <Building2 className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">设计师</p>
                <p className="text-2xl font-bold text-foreground">
                  {customers.filter(c => c.type === '设计师').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center">
                <Navigation className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">建材外贸</p>
                <p className="text-2xl font-bold text-foreground">
                  {customers.filter(c => c.type === '建材外贸').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 地区和筛选 */}
      <div className="flex gap-2 mb-4">
        <Button
          variant={selectedRegion === '全部' ? 'default' : 'outline'}
          onClick={() => setSelectedRegion('全部')}
          className={selectedRegion === '全部' ? 'bg-primary' : ''}
        >
          全部 ({customers.length})
        </Button>
        {regions.map((region) => (
          <Button
            key={region.name}
            variant={selectedRegion === region.name ? 'default' : 'outline'}
            onClick={() => setSelectedRegion(region.name)}
            className={selectedRegion === region.name ? 'bg-primary' : ''}
          >
            {region.name} ({customers.filter(c => c.region === region.name).length})
          </Button>
        ))}
        <Button
          variant="outline"
          onClick={loadData}
          className="ml-2"
        >
          <RefreshCw className="h-4 w-4 mr-1" />
          刷新
        </Button>
      </div>

      {/* 地图区域 */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* 地图 */}
        <div className="lg:col-span-2">
          <Card className="bg-card border-border overflow-hidden">
            <CardContent className="p-0">
              <div 
                className="relative bg-muted h-[400px] overflow-hidden"
                style={{ transform: `scale(${mapZoom})`, transformOrigin: 'center' }}
              >
                {/* SVG地图背景 */}
                <svg 
                  viewBox="0 0 650 250" 
                  className="w-full h-full"
                  preserveAspectRatio="xMidYMid meet"
                >
                  {/* 地区轮廓 */}
                  <path
                    d={getMapPath()}
                    fill="hsl(var(--muted))"
                    stroke="hsl(var(--border))"
                    strokeWidth="2"
                    opacity="0.5"
                  />
                  
                  {/* 地区标签 */}
                  <text x="150" y="100" fill="hsl(var(--foreground))" fontSize="14" opacity="0.5">深圳</text>
                  <text x="280" y="130" fill="hsl(var(--foreground))" fontSize="14" opacity="0.5">广州</text>
                  <text x="400" y="150" fill="hsl(var(--foreground))" fontSize="14" opacity="0.5">佛山</text>
                  <text x="510" y="130" fill="hsl(var(--foreground))" fontSize="14" opacity="0.5">东莞</text>
                  
                  {/* 客户标注点 */}
                  {filteredCustomers.map((customer) => (
                    <g 
                      key={customer.id}
                      onClick={() => handlePointClick(customer)}
                      className="cursor-pointer"
                    >
                      {/* 圆点 */}
                      <circle
                        cx={customer.position.x}
                        cy={customer.position.y}
                        r="8"
                        fill={getTypeColor(customer.type)}
                        stroke={selectedCustomer?.id === customer.id ? '#fff' : getGradeColor(customer.grade)}
                        strokeWidth={selectedCustomer?.id === customer.id ? "3" : "2"}
                        className="transition-all hover:r-10"
                      />
                      {/* 标签 */}
                      <text
                        x={customer.position.x}
                        y={customer.position.y + 20}
                        fill="hsl(var(--foreground))"
                        fontSize="10"
                        textAnchor="middle"
                        className="pointer-events-none"
                      >
                        {customer.name}
                      </text>
                    </g>
                  ))}
                </svg>

                {/* 缩放控制 */}
                <div className="absolute bottom-4 right-4 flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setMapZoom(Math.min(mapZoom + 0.2, 2))}
                  >
                    <ZoomIn className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setMapZoom(Math.max(mapZoom - 0.2, 0.6))}
                  >
                    <ZoomOut className="h-4 w-4" />
                  </Button>
                </div>

                {/* 类型说明 */}
                <div className="absolute top-4 right-4 bg-card/80 rounded-lg p-2 text-sm">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="w-3 h-3 rounded-full bg-blue-500"></span>
                    <span className="text-muted-foreground">设计师</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-orange-500"></span>
                    <span className="text-muted-foreground">建材外贸</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 右侧详情 */}
        <div>
          {/* 选中客户详情 */}
          {selectedCustomer && showDetails ? (
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-foreground flex items-center justify-between">
                  <span>客户详情</span>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowDetails(false)}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <span 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: getTypeColor(selectedCustomer.type) }}
                    ></span>
                    <span className="font-medium text-foreground">{selectedCustomer.name}</span>
                    <Badge 
                      style={{ backgroundColor: getGradeColor(selectedCustomer.grade) + '20', color: getGradeColor(selectedCustomer.grade) }}
                    >
                      {selectedCustomer.grade}类
                    </Badge>
                  </div>
                  
                  <div className="text-sm text-muted-foreground space-y-1">
                    <p><strong>公司：</strong>{selectedCustomer.company}</p>
                    <p><strong>电话：</strong>{selectedCustomer.phone}</p>
                    <p><strong>地址：</strong>{selectedCustomer.address}</p>
                    <p><strong>类型：</strong>{selectedCustomer.type}</p>
                    <p><strong>地区：</strong>{selectedCustomer.region}</p>
                  </div>

                  <div className="flex gap-2 pt-2">
                    <Button variant="default" size="sm">
                      <Eye className="h-4 w-4 mr-1" />
                      查看详情
                    </Button>
                    <Button variant="outline" size="sm">
                      添加跟进
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ) : (
            /* 地区统计 */
            <Card className="bg-card border-border">
              <CardHeader className="pb-2">
                <CardTitle className="text-foreground">地区分布统计</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {regions.map((region) => (
                    <div key={region.name} className="flex items-center justify-between">
                      <span className="font-medium text-foreground">{region.name}</span>
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-blue-500">
                          {regionStats[region.name]?.designers || 0} 设计师
                        </span>
                        <span className="text-orange-500">
                          {regionStats[region.name]?.traders || 0} 外贸
                        </span>
                        <Badge variant="outline">
                          {regionStats[region.name]?.total || 0}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowDetails(true)}
                  className="w-full mt-4"
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  点击地图查看客户详情
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* 客户列表 */}
      <Card className="bg-card border-border mt-4">
        <CardHeader className="pb-2">
          <CardTitle className="text-foreground">当前筛选客户列表</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="max-h-[200px] overflow-y-auto">
            {filteredCustomers.length > 0 ? (
              <div className="divide-y divide-border">
                {filteredCustomers.map((customer) => (
                  <div 
                    key={customer.id}
                    className="p-3 hover:bg-muted/50 cursor-pointer flex items-center gap-3"
                    onClick={() => handlePointClick(customer)}
                  >
                    <span 
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: getTypeColor(customer.type) }}
                    ></span>
                    <span className="font-medium text-foreground">{customer.name}</span>
                    <span className="text-sm text-muted-foreground">{customer.company}</span>
                    <Badge variant="outline" className="ml-auto">{customer.region}</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-muted-foreground">
                该地区暂无客户数据
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 使用说明 */}
      <Card className="bg-card border-border mt-4">
        <CardContent className="p-4">
          <p className="text-sm text-muted-foreground">
            <strong>使用说明：</strong>点击地图上的标注点可查看客户详情。蓝色标注表示设计师，橙色标注表示建材外贸公司。标注边框颜色表示客户等级（绿色=A类、橙色=B类、灰色=C类、红色=D类）。
          </p>
          <p className="text-sm text-muted-foreground mt-2">
            当前为模拟数据，接入百度/高德地图API后可获取真实地理位置数据。
          </p>
        </CardContent>
      </Card>
    </MainLayout>
  );
}