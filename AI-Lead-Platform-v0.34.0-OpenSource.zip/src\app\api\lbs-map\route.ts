// LBS地图获客 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 模拟客户数据（带位置坐标）
const mockCustomers = [
  {
    id: 'cust_001',
    name: '张设计师',
    company: '深圳某某设计公司',
    phone: '13912345678',
    address: '深圳市福田区CBD中心',
    type: '设计师',
    grade: 'A',
    region: '深圳',
    position: { x: 150, y: 80 },
  },
  {
    id: 'cust_002',
    name: '李经理',
    company: '深圳某某建材贸易公司',
    phone: '13898765432',
    address: '深圳市南山区科技园',
    type: '建材外贸',
    grade: 'B',
    region: '深圳',
    position: { x: 180, y: 120 },
  },
  {
    id: 'cust_003',
    name: '王总监',
    company: '广州某某家居有限公司',
    phone: '13612349876',
    address: '广州市天河区珠江新城',
    type: '设计师',
    grade: 'A',
    region: '广州',
    position: { x: 280, y: 100 },
  },
  {
    id: 'cust_004',
    name: '陈设计师',
    company: '广州某某室内设计工作室',
    phone: '13587654321',
    address: '广州市白云区设计城',
    type: '设计师',
    grade: 'B',
    region: '广州',
    position: { x: 300, y: 150 },
  },
  {
    id: 'cust_005',
    name: '赵经理',
    company: '佛山某某建材外贸公司',
    phone: '13456789012',
    address: '佛山市南海区建材市场',
    type: '建材外贸',
    grade: 'A',
    region: '佛山',
    position: { x: 400, y: 120 },
  },
  {
    id: 'cust_006',
    name: '孙总监',
    company: '佛山某某全屋定制工厂',
    phone: '13345678901',
    address: '佛山市顺德区家具产业园',
    type: '建材外贸',
    grade: 'C',
    region: '佛山',
    position: { x: 380, y: 180 },
  },
  {
    id: 'cust_007',
    name: '周设计师',
    company: '东莞某某设计工作室',
    phone: '13234567890',
    address: '东莞市厚街镇家具大道',
    type: '设计师',
    grade: 'B',
    region: '东莞',
    position: { x: 500, y: 100 },
  },
  {
    id: 'cust_008',
    name: '吴经理',
    company: '东莞某某建材公司',
    phone: '13123456789',
    address: '东莞市大岭山镇工业区',
    type: '建材外贸',
    grade: 'D',
    region: '东莞',
    position: { x: 520, y: 160 },
  },
];

// 地区列表
const regions = ['深圳', '广州', '佛山', '东莞'];

// 获取地图数据
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    // 尝试从数据库获取客户数据
    const { data: dbCustomers, error } = await client
      .from('customers')
      .select('id, name, company, phone, address, customer_type, grade, region')
      .eq('user_id', user.id)
      .limit(50);

    let customers = mockCustomers;
    if (dbCustomers && dbCustomers.length > 0) {
      // 将数据库客户转换为地图格式，并分配随机位置
      customers = dbCustomers.map((c, index) => ({
        id: c.id,
        name: c.name,
        company: c.company || '',
        phone: c.phone,
        address: c.address || '',
        type: c.customer_type === '全案设计师' ? '设计师' : '建材外贸',
        grade: c.grade || 'C',
        region: c.region || regions[Math.floor(index / 2) % regions.length],
        position: {
          x: 100 + (index % 4) * 120 + Math.random() * 30,
          y: 80 + Math.floor(index / 4) * 60 + Math.random() * 20,
        },
      }));
    }

    return NextResponse.json({ customers, regions });
  } catch (error) {
    console.error('获取地图数据失败:', error);
    // 返回模拟数据作为兜底
    return NextResponse.json({ customers: mockCustomers, regions });
  }
}