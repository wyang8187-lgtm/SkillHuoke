'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  completeScheduledCrmFollowUp,
  crmCustomerStatusOptions,
  getCrmCustomerStatusMeta,
  getCrmReminderBucket,
  getCrmReminderSummary,
  loadSavedCrmCustomers,
  rescheduleSavedCrmCustomer,
  updateSavedCrmCustomer,
  type CrmCustomerStatus,
  type CrmReminderBucket,
  type SavedCrmCustomer,
} from '@/lib/lead-wizard';
import { ArrowRight, CalendarClock, CheckCircle2, Clock3, RotateCcw, TriangleAlert, UsersRound } from 'lucide-react';

type ReminderFilter = 'due' | CrmReminderBucket | 'all';
type PriorityFilter = 'all' | 'A' | 'B' | 'C';

const filterOptions: Array<{ value: ReminderFilter; label: string }> = [
  { value: 'due', label: '今天 + 逾期' },
  { value: 'overdue', label: '仅逾期' },
  { value: 'today', label: '仅今天' },
  { value: 'upcoming', label: '未来计划' },
  { value: 'unscheduled', label: '未安排' },
  { value: 'all', label: '全部客户' },
];

function formatSchedule(value?: string) {
  if (!value) return '尚未安排';
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? '日期无效' : date.toLocaleString('zh-CN');
}

export default function CrmFollowUpsPage() {
  const [customers, setCustomers] = useState<SavedCrmCustomer[]>([]);
  const [bucketFilter, setBucketFilter] = useState<ReminderFilter>('due');
  const [statusFilter, setStatusFilter] = useState<CrmCustomerStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<PriorityFilter>('all');
  const [error, setError] = useState('');

  useEffect(() => {
    setCustomers(loadSavedCrmCustomers());
  }, []);

  const summary = useMemo(() => getCrmReminderSummary(customers), [customers]);
  const filteredCustomers = useMemo(() => customers
    .filter((customer) => {
      const bucket = getCrmReminderBucket(customer);
      if (bucketFilter === 'due' && bucket !== 'overdue' && bucket !== 'today') return false;
      if (bucketFilter !== 'due' && bucketFilter !== 'all' && bucket !== bucketFilter) return false;
      if (statusFilter !== 'all' && customer.status !== statusFilter) return false;
      if (priorityFilter !== 'all' && customer.priority !== priorityFilter) return false;
      return true;
    })
    .sort((a, b) => {
      if (!a.nextFollowUpAt) return 1;
      if (!b.nextFollowUpAt) return -1;
      return new Date(a.nextFollowUpAt).getTime() - new Date(b.nextFollowUpAt).getTime();
    }), [customers, bucketFilter, statusFilter, priorityFilter]);

  const refreshWith = (nextCustomers: SavedCrmCustomer[]) => {
    setCustomers(nextCustomers);
    setError('');
  };

  const complete = (customer: SavedCrmCustomer) => {
    if (!window.confirm(`确认完成 ${customer.company} 的本次计划跟进吗？`)) return;
    refreshWith(completeScheduledCrmFollowUp(customer.id));
  };

  const updateCustomDate = (customerId: string, value: string) => {
    if (!value) {
      setError('请选择有效的日期和时间。');
      return;
    }
    refreshWith(updateSavedCrmCustomer(customerId, { nextFollowUpAt: value }));
  };

  return (
    <MainLayout title="今日跟进">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.23.0</Badge>
                <Badge className="border-amber-500/25 bg-amber-500/15 text-amber-300">{summary.due} 个待处理</Badge>
              </div>
              <h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">今天应该联系谁</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                优先处理逾期和今天到期的客户，完成后重新安排下一次动作，让跟进节奏持续运转。
              </p>
            </div>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/crm-customers">打开 CRM 客户池<ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </section>

        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            { label: '已经逾期', value: summary.overdue, icon: TriangleAlert, tone: 'text-red-300' },
            { label: '今天跟进', value: summary.today, icon: Clock3, tone: 'text-amber-300' },
            { label: '未来计划', value: summary.upcoming, icon: CalendarClock, tone: 'text-blue-300' },
            { label: '未安排', value: summary.unscheduled, icon: UsersRound, tone: 'text-slate-300' },
          ].map((item) => (
            <Card key={item.label} className="border-[#2d3548] bg-[#121823]">
              <CardContent className="flex items-center justify-between p-5">
                <div><p className="text-sm text-[#94a3b8]">{item.label}</p><p className={`mt-2 text-2xl font-semibold ${item.tone}`}>{item.value}</p></div>
                <item.icon className={`h-6 w-6 ${item.tone}`} />
              </CardContent>
            </Card>
          ))}
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">跟进工作队列</CardTitle>
            <div className="grid gap-3 pt-3 md:grid-cols-3">
              <Select value={bucketFilter} onValueChange={(value) => setBucketFilter(value as ReminderFilter)}>
                <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger>
                <SelectContent>{filterOptions.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as CrmCustomerStatus | 'all')}>
                <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="all">全部 CRM 阶段</SelectItem>{crmCustomerStatusOptions.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={priorityFilter} onValueChange={(value) => setPriorityFilter(value as PriorityFilter)}>
                <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger>
                <SelectContent><SelectItem value="all">全部优先级</SelectItem><SelectItem value="A">A 级</SelectItem><SelectItem value="B">B 级</SelectItem><SelectItem value="C">C 级</SelectItem></SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {error ? <p className="mb-4 rounded-md border border-red-500/25 bg-red-500/10 p-3 text-sm text-red-200">{error}</p> : null}
            {filteredCustomers.length === 0 ? (
              <div className="rounded-lg border border-dashed border-[#2d3548] bg-[#0f1419] p-9 text-center">
                <CheckCircle2 className="mx-auto h-10 w-10 text-emerald-300" />
                <h3 className="mt-4 font-medium text-[#f8fafc]">当前没有需要处理的客户</h3>
                <p className="mt-2 text-sm text-[#94a3b8]">可以切换筛选条件，或进入 CRM 客户详情安排下次跟进时间。</p>
              </div>
            ) : (
              <div className="grid gap-4 xl:grid-cols-2">
                {filteredCustomers.map((customer) => {
                  const bucket = getCrmReminderBucket(customer);
                  const status = getCrmCustomerStatusMeta(customer.status);
                  return (
                    <article key={customer.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <div className="flex flex-wrap gap-2">
                            <Badge className={`border ${status.className}`}>{status.label}</Badge>
                            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{customer.priority} 级 · {customer.score} 分</Badge>
                            <Badge className={bucket === 'overdue' ? 'border-red-500/25 bg-red-500/15 text-red-300' : bucket === 'today' ? 'border-amber-500/25 bg-amber-500/15 text-amber-300' : 'border-slate-500/25 bg-slate-500/15 text-slate-300'}>
                              {bucket === 'overdue' ? '已逾期' : bucket === 'today' ? '今天' : bucket === 'upcoming' ? '未来' : '未安排'}
                            </Badge>
                          </div>
                          <h3 className="mt-3 text-lg font-semibold text-[#f8fafc]">{customer.company}</h3>
                          <p className="mt-1 text-sm text-[#94a3b8]">{customer.country} / {customer.city} · {customer.customerType}</p>
                        </div>
                        <Button asChild variant="outline" className="border-[#2d3548] bg-[#121823] text-[#cbd5e1]">
                          <Link href={`/crm-customers/${encodeURIComponent(customer.id)}`}>查看详情<ArrowRight className="ml-2 h-4 w-4" /></Link>
                        </Button>
                      </div>
                      <div className="mt-4 grid gap-3 sm:grid-cols-2">
                        <div className="rounded-md border border-[#2d3548] bg-[#121823] p-3">
                          <p className="text-xs text-[#64748b]">计划时间</p><p className="mt-2 text-sm text-[#cbd5e1]">{formatSchedule(customer.nextFollowUpAt)}</p>
                        </div>
                        <div className="rounded-md border border-[#2d3548] bg-[#121823] p-3">
                          <p className="text-xs text-[#64748b]">下一步动作</p><p className="mt-2 line-clamp-2 text-sm text-[#cbd5e1]">{customer.nextAction || '待安排下一步动作'}</p>
                        </div>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button type="button" size="sm" variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1]" onClick={() => refreshWith(rescheduleSavedCrmCustomer(customer.id, 1))}><RotateCcw className="mr-2 h-4 w-4" />明天</Button>
                        <Button type="button" size="sm" variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1]" onClick={() => refreshWith(rescheduleSavedCrmCustomer(customer.id, 3))}>三天后</Button>
                        <Button type="button" size="sm" variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1]" onClick={() => refreshWith(rescheduleSavedCrmCustomer(customer.id, 7))}>下周</Button>
                        <Input type="datetime-local" className="h-9 w-full border-[#2d3548] bg-[#121823] text-[#f8fafc] sm:w-auto" value={customer.nextFollowUpAt || ''} onChange={(event) => updateCustomDate(customer.id, event.target.value)} />
                        {bucket === 'overdue' || bucket === 'today' ? (
                          <Button type="button" size="sm" className="ml-auto bg-emerald-600 text-white hover:bg-emerald-500" onClick={() => complete(customer)}><CheckCircle2 className="mr-2 h-4 w-4" />完成本次跟进</Button>
                        ) : null}
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
