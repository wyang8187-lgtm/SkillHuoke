'use client';
import { useParams } from 'next/navigation';
import { MainLayout } from '@/components/layout';
import { OpportunityForm } from '@/components/crm/opportunity-form';
import { loadSavedCrmOpportunities } from '@/lib/crm-opportunities';
export default function EditOpportunityPage(){const params=useParams<{id:string}>();const item=loadSavedCrmOpportunities().find((entry)=>entry.id===decodeURIComponent(params.id));return <MainLayout title="编辑销售机会">{item?<OpportunityForm opportunity={item}/>:<p className="text-[#cbd5e1]">没有找到这个销售机会。</p>}</MainLayout>;}
