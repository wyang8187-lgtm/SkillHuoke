# v0.15.0 Onboarding Center Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build an onboarding center that guides a first-time user through the core foreign-trade lead generation workflow.

**Architecture:** Store workflow steps and wizard examples in a small library file, render them in a new `/onboarding` page, and link that page from the sidebar and release center.

**Tech Stack:** Next.js App Router, React, TypeScript, Tailwind CSS, local UI components, lucide-react icons.

---

### Task 1: Onboarding Data

**Files:**
- Create: `src/lib/onboarding-workflow.ts`

- [ ] Add six workflow steps.
- [ ] Add sample lead task input and generated outputs.
- [ ] Add follow-up checklist items.

### Task 2: Onboarding Page

**Files:**
- Create: `src/app/onboarding/page.tsx`

- [ ] Render workflow overview.
- [ ] Render six operating steps.
- [ ] Render lightweight lead task wizard preview.
- [ ] Render checklist and next pages.

### Task 3: Navigation And Release Links

**Files:**
- Modify: `src/components/layout/sidebar.tsx`
- Modify: `src/lib/release-experience.ts`

- [ ] Add sidebar entry for `/onboarding`.
- [ ] Add onboarding to release review pages.

### Task 4: Version And Docs

**Files:**
- Modify: `package.json`
- Modify: `README.md`

- [ ] Bump version to `0.15.0`.
- [ ] Add v0.15 update notes.

### Task 5: Verification And Package

**Files:**
- Create output zip: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.15.0-OpenSource.zip`

- [ ] Run `corepack pnpm run ts-check`.
- [ ] Run `corepack pnpm run lint:build`.
- [ ] Run `corepack pnpm run build`.
- [ ] Check `/onboarding` and `/release` with local HTTP requests.
- [ ] Package without `node_modules`, `.next`, `.git`, `.env`, or `.env.local`.
