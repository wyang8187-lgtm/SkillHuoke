import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

/**
 * 初始化管理员接口
 * 
 * 注意：这个接口只能在没有任何管理员的情况下使用
 * 用于设置第一个管理员账号
 * 
 * 使用方式：
 * 1. 先注册一个普通账号
 * 2. 用这个接口将该账号设置为管理员
 */
export async function POST(request: NextRequest) {
  try {
    const sessionToken = request.headers.get('x-session');
    
    if (!sessionToken) {
      return NextResponse.json({ error: '未登录' }, { status: 401 });
    }
    
    const supabase = getSupabaseClient(sessionToken);
    
    // 获取当前用户信息
    const { data: { user }, error: userError } = await supabase.auth.getUser();
    
    if (userError || !user) {
      return NextResponse.json({ error: '用户信息无效' }, { status: 401 });
    }
    
    // 检查是否已经有管理员存在
    const { data: existingAdmin, error: checkError } = await supabase
      .from('user_roles')
      .select('id')
      .eq('role', 'admin')
      .limit(1);
    
    if (existingAdmin && existingAdmin.length > 0) {
      return NextResponse.json({ 
        error: '系统中已存在管理员，无法通过此接口添加新管理员',
        hint: '请联系现有管理员添加新管理员账号'
      }, { status: 403 });
    }
    
    // 使用服务端客户端直接插入管理员角色（绕过RLS）
    // 因为还没有管理员，RLS策略不允许插入
    const { getSupabaseCredentials } = await import('@/storage/database/supabase-client');
    const { url, anonKey } = getSupabaseCredentials();
    
    // 创建一个带有服务角色的客户端（使用 anon key + 特殊处理）
    // 这里我们使用普通客户端，但设置 user_id 为当前用户的 ID
    const { error: insertError } = await supabase
      .from('user_roles')
      .insert({
        user_id: user.id,
        role: 'admin',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      });
    
    if (insertError) {
      // 如果RLS阻止了插入，我们需要直接使用SQL
      console.log('RLS阻止插入，尝试直接SQL:', insertError);
      
      // 直接使用 exec_sql 工具在这里不可用，所以我们需要返回一个提示
      return NextResponse.json({ 
        error: '无法添加管理员角色',
        details: insertError.message,
        hint: '请联系系统管理员在数据库中手动执行：INSERT INTO user_roles (user_id, role) VALUES (\'' + user.id + '\', \'admin\');'
      }, { status: 500 });
    }
    
    return NextResponse.json({
      success: true,
      message: '管理员角色已设置',
      userId: user.id,
      email: user.email,
      role: 'admin'
    });
  } catch (error) {
    console.error('初始化管理员失败:', error);
    return NextResponse.json({ error: '初始化管理员失败', details: String(error) }, { status: 500 });
  }
}