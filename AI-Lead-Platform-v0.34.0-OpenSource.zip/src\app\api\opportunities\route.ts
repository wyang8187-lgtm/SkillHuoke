// 商机管理 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取商机列表（带统计）
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const stage = searchParams.get('stage') || undefined;
    const customerId = searchParams.get('customerId') || undefined;
    const statsOnly = searchParams.get('stats') === 'true';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '50');

    // 获取商机列表
    const result = await dbService.getOpportunities(user.id, {
      stage,
      customer_id: customerId,
    }, page, pageSize);

    const opportunities = result.data;
    const total = result.total;

    // 计算漏斗统计
    const stageStats: Record<string, number> = {
      '初步接触': 0,
      '需求确认': 0,
      '方案报价': 0,
      '谈判': 0,
      '成交': 0,
      '输单': 0,
    };
    
    const stageAmounts: Record<string, number> = {
      '初步接触': 0,
      '需求确认': 0,
      '方案报价': 0,
      '谈判': 0,
      '成交': 0,
      '输单': 0,
    };

    opportunities.forEach((opp: dbService.OpportunityDB) => {
      if (stageStats[opp.stage] !== undefined) {
        stageStats[opp.stage]++;
        stageAmounts[opp.stage] += Number(opp.amount || 0);
      }
    });

    // 计算转化率
    const wonCount = stageStats['成交'];
    const lostCount = stageStats['输单'];
    const finishedCount = wonCount + lostCount;
    const winRate = finishedCount > 0 ? Math.round((wonCount / finishedCount) * 100) : 0;

    // 计算总金额
    const totalAmount = opportunities.reduce((sum: number, opp: dbService.OpportunityDB) => sum + Number(opp.amount || 0), 0);
    const wonAmount = stageAmounts['成交'];

    // 如果只请求统计数据
    if (statsOnly) {
      return NextResponse.json({
        stats: {
          totalAmount,
          stageDistribution: Object.entries(stageStats).map(([stage, count]) => ({
            stage,
            count,
            amount: stageAmounts[stage],
          })),
          winRate,
        },
      });
    }

    // 转换为前端格式
    const formattedOpportunities = opportunities.map(opp => ({
      id: opp.id,
      name: opp.name,
      customer_id: opp.customer_id,
      customer_name: opp.customer_name || '',
      amount: opp.amount || 0,
      stage: opp.stage,
      expected_close_date: opp.expected_close_date || null,
      description: opp.notes || '',
      user_id: opp.user_id,
      create_time: opp.created_at,
      update_time: opp.updated_at,
    }));

    return NextResponse.json({
      opportunities: formattedOpportunities,
      total,
      page,
      pageSize,
      stats: {
        stageCounts: stageStats,
        stageAmounts,
        totalAmount,
        wonAmount,
        winRate,
      },
    });
  } catch (error) {
    console.error('获取商机列表失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取商机列表失败' 
    }, { status: 500 });
  }
}

// 创建新商机
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();

    // 获取客户名称
    let customerName = '';
    if (body.customer_id) {
      const customer = await dbService.getCustomerById(user.id, body.customer_id);
      customerName = customer.company_name;
    }

    const opportunity = await dbService.createOpportunity(user.id, {
      name: body.name,
      customer_id: body.customer_id,
      customer_name: customerName,
      stage: body.stage || '初步接触',
      amount: body.amount || 0,
      probability: 20,
      expected_close_date: body.expected_close_date || undefined,
      notes: body.description || '',
    });

    return NextResponse.json({
      success: true,
      data: opportunity,
      message: '商机创建成功',
    });
  } catch (error) {
    console.error('创建商机失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建商机失败' 
    }, { status: 500 });
  }
}