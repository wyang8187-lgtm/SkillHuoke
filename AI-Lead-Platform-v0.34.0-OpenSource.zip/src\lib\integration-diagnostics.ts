export type IntegrationId =
  | 'openai'
  | 'deepseek'
  | 'google-search'
  | 'serpapi'
  | 'bing-search'
  | 'resend'
  | 'supabase';

export type IntegrationCategory = 'AI 模型' | '搜索服务' | '邮件服务' | '数据库';

export interface IntegrationEnvField {
  name: string;
  label: string;
  required: boolean;
  secret: boolean;
  aliases?: string[];
  defaultValue?: string;
}

export interface IntegrationDefinition {
  id: IntegrationId;
  name: string;
  category: IntegrationCategory;
  description: string;
  docsUrl: string;
  fields: IntegrationEnvField[];
  setupGuide: string;
  testable: boolean;
}

export interface IntegrationStatusField {
  name: string;
  label: string;
  required: boolean;
  configured: boolean;
  secret: boolean;
  value: string;
}

export interface IntegrationStatus {
  id: IntegrationId;
  name: string;
  category: IntegrationCategory;
  description: string;
  docsUrl: string;
  configured: boolean;
  missingEnv: string[];
  fields: IntegrationStatusField[];
  setupGuide: string;
  testable: boolean;
  mode: string;
}

export interface ProxySummaryItem {
  name: string;
  configured: boolean;
  value: string;
}

export interface ProxySummary {
  hasProxy: boolean;
  preferredSource: string;
  items: ProxySummaryItem[];
  note: string;
}

export const INTEGRATIONS: IntegrationDefinition[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    category: 'AI 模型',
    description: '用于 AI 开发信、客户判断和内容生成。',
    docsUrl: 'https://platform.openai.com/api-keys',
    setupGuide: '在 .env 填写 OPENAI_API_KEY；OPENAI_BASE_URL 和 OPENAI_MODEL 可按需要调整。',
    testable: true,
    fields: [
      { name: 'OPENAI_API_KEY', label: 'API Key', required: true, secret: true },
      { name: 'OPENAI_BASE_URL', label: 'Base URL', required: false, secret: false, defaultValue: 'https://api.openai.com/v1' },
      { name: 'OPENAI_MODEL', label: '模型', required: false, secret: false },
    ],
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    category: 'AI 模型',
    description: '可作为 AI 文案和判断模型的备用服务。',
    docsUrl: 'https://platform.deepseek.com/api_keys',
    setupGuide: '在 .env 填写 DEEPSEEK_API_KEY；默认模型可使用 deepseek-chat。',
    testable: true,
    fields: [
      { name: 'DEEPSEEK_API_KEY', label: 'API Key', required: true, secret: true },
      { name: 'DEEPSEEK_BASE_URL', label: 'Base URL', required: false, secret: false, defaultValue: 'https://api.deepseek.com/v1' },
      { name: 'DEEPSEEK_MODEL', label: '模型', required: false, secret: false, defaultValue: 'deepseek-chat' },
    ],
  },
  {
    id: 'google-search',
    name: 'Google Custom Search',
    category: '搜索服务',
    description: '用于通过 Google 自定义搜索发现公开客户线索。',
    docsUrl: 'https://programmablesearchengine.google.com/',
    setupGuide: '需要同时配置 GOOGLE_SEARCH_API_KEY 和 GOOGLE_SEARCH_CX。',
    testable: true,
    fields: [
      { name: 'GOOGLE_SEARCH_API_KEY', label: 'API Key', required: true, secret: true },
      { name: 'GOOGLE_SEARCH_CX', label: '搜索引擎 CX', required: true, secret: true },
    ],
  },
  {
    id: 'serpapi',
    name: 'SerpAPI',
    category: '搜索服务',
    description: '默认推荐的搜索聚合源，适合海外搜索结果采集。',
    docsUrl: 'https://serpapi.com/manage-api-key',
    setupGuide: '在 .env 填写 SERPAPI_KEY；系统也兼容旧变量 SERPAPI_API_KEY。',
    testable: true,
    fields: [
      { name: 'SERPAPI_KEY', label: 'API Key', required: true, secret: true, aliases: ['SERPAPI_API_KEY'] },
    ],
  },
  {
    id: 'bing-search',
    name: 'Bing Search',
    category: '搜索服务',
    description: '作为搜索降级来源，适合补充 Google 或 SerpAPI。',
    docsUrl: 'https://www.microsoft.com/bing/apis/bing-web-search-api',
    setupGuide: '在 .env 填写 BING_SEARCH_API_KEY；端点默认使用 Bing Web Search v7。',
    testable: true,
    fields: [
      { name: 'BING_SEARCH_API_KEY', label: 'API Key', required: true, secret: true },
      { name: 'BING_SEARCH_ENDPOINT', label: 'Endpoint', required: false, secret: false, defaultValue: 'https://api.bing.microsoft.com/v7.0/search' },
    ],
  },
  {
    id: 'resend',
    name: 'Resend',
    category: '邮件服务',
    description: '用于报价、订单、单据和物流邮件真实发送。',
    docsUrl: 'https://resend.com/api-keys',
    setupGuide: '在 .env 填写 RESEND_API_KEY 和 RESEND_FROM_EMAIL，并先验证发件域名。',
    testable: true,
    fields: [
      { name: 'RESEND_API_KEY', label: 'API Key', required: true, secret: true },
      { name: 'RESEND_FROM_EMAIL', label: '发件邮箱', required: true, secret: false },
      { name: 'RESEND_FROM_NAME', label: '发件名称', required: false, secret: false },
      { name: 'RESEND_REPLY_TO', label: '回复邮箱', required: false, secret: false },
    ],
  },
  {
    id: 'supabase',
    name: 'Supabase',
    category: '数据库',
    description: '用于后续 SaaS 数据库、账号和业务数据持久化。',
    docsUrl: 'https://supabase.com/dashboard',
    setupGuide: '在 .env 填写 COZE_SUPABASE_URL 和 COZE_SUPABASE_ANON_KEY；服务角色密钥为可选后端能力。',
    testable: true,
    fields: [
      { name: 'COZE_SUPABASE_URL', label: '项目 URL', required: true, secret: false },
      { name: 'COZE_SUPABASE_ANON_KEY', label: 'Anon Key', required: true, secret: true },
      { name: 'COZE_SUPABASE_SERVICE_ROLE_KEY', label: 'Service Role Key', required: false, secret: true },
    ],
  },
];

export function maskSecret(value: string | undefined) {
  const trimmed = value?.trim() || '';
  if (!trimmed) return '';
  return `••••${trimmed.slice(-4)}`;
}

function getEnvValue(env: NodeJS.ProcessEnv | Record<string, string | undefined>, field: IntegrationEnvField) {
  const names = [field.name, ...(field.aliases || [])];
  for (const name of names) {
    const value = env[name]?.trim();
    if (value) return { value, sourceName: field.name };
  }
  return { value: field.defaultValue || '', sourceName: field.name };
}

export function buildIntegrationStatuses(env: NodeJS.ProcessEnv | Record<string, string | undefined> = process.env): IntegrationStatus[] {
  return INTEGRATIONS.map((definition) => {
    const fields = definition.fields.map((field) => {
      const { value } = getEnvValue(env, field);
      const configured = Boolean(value);
      return {
        name: field.name,
        label: field.label,
        required: field.required,
        configured,
        secret: field.secret,
        value: field.secret ? maskSecret(value) : value,
      };
    });
    const missingEnv = fields
      .filter((field) => field.required && !field.configured)
      .map((field) => field.name);

    return {
      id: definition.id,
      name: definition.name,
      category: definition.category,
      description: definition.description,
      docsUrl: definition.docsUrl,
      configured: missingEnv.length === 0,
      missingEnv,
      fields,
      setupGuide: definition.setupGuide,
      testable: definition.testable,
      mode: missingEnv.length === 0 ? '可真实测试' : '未配置完整，将使用演示或降级能力',
    };
  });
}

export function getIntegrationById(id: string) {
  return INTEGRATIONS.find((integration) => integration.id === id);
}

export function getRawEnvValue(id: IntegrationId, name: string, env: NodeJS.ProcessEnv = process.env) {
  const definition = getIntegrationById(id);
  const field = definition?.fields.find((item) => item.name === name);
  if (!field) return '';
  return getEnvValue(env, field).value;
}

function safeProxyValue(value: string | undefined) {
  const trimmed = value?.trim();
  if (!trimmed) return '';
  try {
    const url = new URL(trimmed);
    const host = url.port ? `${url.hostname}:${url.port}` : url.hostname;
    return `${url.protocol}//${host}`;
  } catch {
    return trimmed.replace(/\/\/.*@/, '//***@');
  }
}

export function summarizeProxyConfig(env: NodeJS.ProcessEnv | Record<string, string | undefined> = process.env): ProxySummary {
  const names = ['SKILLHUOKE_PROXY', 'HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY'];
  const items = names.map((name) => {
    const value = env[name];
    return {
      name,
      configured: Boolean(value?.trim()),
      value: safeProxyValue(value),
    };
  });
  const first = items.find((item) => item.configured);
  return {
    hasProxy: Boolean(first),
    preferredSource: first?.name || '未检测到代理变量',
    items,
    note: first
      ? '后端检测到代理环境变量。页面只显示主机摘要，不显示账号或密码。'
      : '未检测到代理环境变量。如本机无法访问海外 API，可配置系统代理或 SKILLHUOKE_PROXY 后重启后端。',
  };
}
