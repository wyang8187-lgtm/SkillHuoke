# v0.28.0 Quotation and PDF Print Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Create saved bilingual quotations with line-item calculations, CRM/opportunity synchronization, and A4 browser PDF printing.

**Architecture:** Keep quotation records and calculations in a dedicated domain module. Share an editor between create/edit routes, use a separate print route, and include quotations in backup v3.

**Tech Stack:** Next.js 16, React 19, TypeScript, localStorage, CSS print media.

---

### Task 1: Quotation data domain
- Create quotation types, CRUD, numbering, totals, copy, and CRM/opportunity synchronization.

### Task 2: Quotation editor and list
- Build shared line-item form, create/edit routes, filtering, copy, delete, and print links.

### Task 3: Bilingual A4 print
- Build independent Chinese/English print route with print-only CSS and browser print action.

### Task 4: Backup v3, navigation, release
- Include quotations in backup with v1/v2 compatibility, update navigation/release/README, verify and package.
