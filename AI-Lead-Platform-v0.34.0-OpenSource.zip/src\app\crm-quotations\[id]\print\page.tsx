'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { loadCompanyProfile } from '@/lib/company-profile';
import { loadSavedCrmCustomers } from '@/lib/lead-wizard';
import { calculateQuotationTotals, loadSavedCrmQuotations } from '@/lib/crm-quotations';
import { Printer } from 'lucide-react';

export default function QuotationPrintPage() {
  const params = useParams<{ id: string }>();
  const quotation = loadSavedCrmQuotations().find((item) => item.id === decodeURIComponent(params.id));
  if (!quotation) return <p className="p-10">Quotation not found.</p>;

  const company = loadCompanyProfile();
  const customer = loadSavedCrmCustomers().find((item) => item.id === quotation.customerId);
  const totals = calculateQuotationTotals(quotation);
  const en = quotation.language === 'en';
  const companyName = en ? company.companyNameEn : company.companyNameZh || company.companyNameEn;
  const companyAddress = en ? company.addressEn || company.addressZh : company.addressZh || company.addressEn;

  return (
    <main className="min-h-screen bg-slate-200 p-6 print:bg-white print:p-0">
      <div className="no-print mx-auto mb-4 flex max-w-[210mm] gap-2">
        <Button onClick={() => window.print()}><Printer className="mr-2 h-4 w-4" />打印 / 保存为 PDF</Button>
        <Button asChild variant="outline"><Link href="/crm-quotations">返回报价列表</Link></Button>
      </div>
      <article className="mx-auto min-h-[297mm] max-w-[210mm] bg-white p-[16mm] text-slate-900 shadow print:min-h-0 print:max-w-none print:shadow-none">
        <header className="flex items-start justify-between gap-6 border-b-2 border-slate-900 pb-5">
          <div className="flex items-center gap-4">
            {company.logoDataUrl ? <img src={company.logoDataUrl} alt="Company logo" className="h-16 w-20 object-contain" /> : null}
            <div>
              <p className="text-lg font-semibold">{companyName}</p>
              {companyAddress ? <p className="mt-1 max-w-md text-xs text-slate-600">{companyAddress}</p> : null}
              <p className="mt-1 text-xs text-slate-600">{[company.phone, company.email, company.website].filter(Boolean).join(' · ')}</p>
            </div>
          </div>
          <div className="text-right"><h1 className="text-3xl font-bold">{en ? 'QUOTATION' : '报价单'}</h1><p className="mt-2 text-sm">{en ? 'Quotation No.' : '报价编号'}: {quotation.number}</p></div>
        </header>

        <section className="mt-6 grid grid-cols-2 gap-3 text-sm">
          <p>{en ? 'Customer' : '客户'}: {customer?.company || '-'}</p><p>{en ? 'Contact' : '联系人'}: {quotation.contactName || customer?.contactName || '-'}</p>
          <p>{en ? 'Date' : '报价日期'}: {quotation.quotationDate}</p><p>{en ? 'Valid Until' : '有效期'}: {quotation.validUntil}</p>
          <p>{en ? 'Trade Term' : '贸易条款'}: {quotation.tradeTerm}</p><p>{en ? 'Delivery' : '交期'}: {quotation.deliveryTime}</p>
        </section>

        <table className="mt-8 w-full border-collapse text-sm">
          <thead><tr className="bg-slate-100">{[en ? 'Product' : '产品', en ? 'Specification' : '规格', en ? 'Qty' : '数量', en ? 'Unit' : '单位', en ? 'Unit Price' : '单价', en ? 'Amount' : '金额'].map((label) => <th key={label} className="border border-slate-300 p-2 text-left">{label}</th>)}</tr></thead>
          <tbody>{quotation.items.map((item) => <tr key={item.id} className="break-inside-avoid"><td className="border p-2">{item.product}</td><td className="border p-2">{item.specification}</td><td className="border p-2">{item.quantity}</td><td className="border p-2">{item.unit}</td><td className="border p-2">{item.unitPrice.toFixed(2)}</td><td className="border p-2">{(item.quantity * item.unitPrice).toFixed(2)}</td></tr>)}</tbody>
        </table>

        <section className="ml-auto mt-6 w-72 space-y-2 text-sm">
          <p className="flex justify-between"><span>{en ? 'Subtotal' : '商品小计'}</span><b>{quotation.currency} {totals.subtotal.toFixed(2)}</b></p>
          <p className="flex justify-between"><span>{en ? 'Discount' : '折扣'}</span><span>- {quotation.discount.toFixed(2)}</span></p>
          <p className="flex justify-between"><span>{en ? 'Shipping' : '运费'}</span><span>{quotation.shipping.toFixed(2)}</span></p>
          <p className="flex justify-between"><span>{en ? 'Tax' : '税费'}</span><span>{quotation.tax.toFixed(2)}</span></p>
          <p className="flex justify-between border-t pt-2 text-lg"><span>{en ? 'Total' : '总金额'}</span><b>{quotation.currency} {totals.total.toFixed(2)}</b></p>
        </section>

        <section className="mt-10 text-sm"><p><b>{en ? 'Payment Terms' : '付款条款'}:</b> {quotation.paymentTerms}</p><p className="mt-3"><b>{en ? 'Notes' : '备注'}:</b> {quotation.note || '-'}</p></section>
        {company.showBankDetails ? (
          <section className="mt-8 break-inside-avoid border-t border-slate-300 pt-5 text-xs">
            <h2 className="mb-3 text-sm font-semibold">{en ? 'Bank Information' : '收款银行信息'}</h2>
            <div className="grid grid-cols-2 gap-2">
              <p>{en ? 'Bank' : '银行'}: {company.bankName || '-'}</p><p>{en ? 'Account Name' : '账户名称'}: {company.bankAccountName || '-'}</p>
              <p>{en ? 'Account No.' : '银行账号'}: {company.bankAccountNumber || '-'}</p><p>SWIFT / BIC: {company.bankSwift || '-'}</p>
              {company.bankAddress ? <p className="col-span-2">{en ? 'Bank Address' : '银行地址'}: {company.bankAddress}</p> : null}
            </div>
          </section>
        ) : null}
      </article>
      <style jsx global>{`@media print{.no-print{display:none!important}@page{size:A4;margin:0}body{background:white!important}}`}</style>
    </main>
  );
}
