/**
 * 表单校验工具
 */

// 校验结果类型
export interface ValidationResult {
  valid: boolean;
  message?: string;
}

// 手机号校验（11位中国大陆手机号）
export function validatePhone(phone: string): ValidationResult {
  if (!phone) {
    return { valid: false, message: '请输入手机号' };
  }
  
  // 去除空格和特殊字符
  const cleanPhone = phone.replace(/\s/g, '').replace(/[-]/g, '');
  
  // 中国大陆手机号正则：1开头，第二位3-9，共11位
  const phoneRegex = /^1[3-9]\d{9}$/;
  
  if (!phoneRegex.test(cleanPhone)) {
    return { valid: false, message: '请输入正确的11位手机号' };
  }
  
  return { valid: true };
}

// 邮箱校验
export function validateEmail(email: string): ValidationResult {
  if (!email) {
    return { valid: true }; // 邮箱可选
  }
  
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(email)) {
    return { valid: false, message: '请输入正确的邮箱格式' };
  }
  
  return { valid: true };
}

// 必填校验
export function validateRequired(value: string | undefined | null, fieldName: string): ValidationResult {
  if (!value || value.trim() === '') {
    return { valid: false, message: `${fieldName}为必填项` };
  }
  return { valid: true };
}

// 数字范围校验
export function validateNumberRange(value: string, min?: number, max?: number): ValidationResult {
  if (!value) {
    return { valid: true };
  }
  
  const num = parseFloat(value);
  
  if (isNaN(num)) {
    return { valid: false, message: '请输入有效的数字' };
  }
  
  if (min !== undefined && num < min) {
    return { valid: false, message: `数值不能小于${min}` };
  }
  
  if (max !== undefined && num > max) {
    return { valid: false, message: `数值不能大于${max}` };
  }
  
  return { valid: true };
}

// 金额校验（正数）
export function validateAmount(value: string): ValidationResult {
  if (!value) {
    return { valid: true };
  }
  
  const num = parseFloat(value);
  
  if (isNaN(num) || num < 0) {
    return { valid: false, message: '请输入有效的金额（正数）' };
  }
  
  return { valid: true };
}

// 批量校验
export function validateForm(fields: { name: string; value: string; validators: ((value: string) => ValidationResult)[] }[]): {
  valid: boolean;
  errors: Record<string, string>;
} {
  const errors: Record<string, string> = {};
  
  for (const field of fields) {
    for (const validator of field.validators) {
      const result = validator(field.value);
      if (!result.valid) {
        errors[field.name] = result.message || '校验失败';
        break;
      }
    }
  }
  
  return {
    valid: Object.keys(errors).length === 0,
    errors,
  };
}

// 获取校验错误提示样式类名
export function getFieldErrorClass(hasError: boolean): string {
  return hasError 
    ? 'border-red-500 focus:border-red-500 focus:ring-red-500/20' 
    : 'border-border focus:border-primary focus:ring-primary/20';
}

// 格式化手机号显示（隐藏中间4位）
export function formatPhoneDisplay(phone: string): string {
  if (!phone || phone.length < 11) return phone;
  return phone.replace(/(\d{3})\d{4}(\d{4})/, '$1****$2');
}

// 校验手机号是否唯一（用于查重）
export async function checkPhoneUnique(phone: string, excludeId?: string): Promise<boolean> {
  try {
    const res = await fetch(`/api/customers/check-phone?phone=${encodeURIComponent(phone)}&exclude=${excludeId || ''}`);
    if (res.ok) {
      const data = await res.json();
      return data.unique;
    }
    return true; // API失败时默认允许
  } catch {
    return true;
  }
}