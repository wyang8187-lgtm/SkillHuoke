import { NextRequest, NextResponse } from 'next/server';

// 行业专属搜索模板 - 4个重点行业详细模板
const INDUSTRY_SEARCH_TEMPLATES = {
  '灯饰照明': {
    id: 'lighting',
    industry: '灯饰照明',
    keywords: {
      zh: ['灯饰', '照明', '灯具', '吊灯', '壁灯', '筒灯', '户外灯', 'LED灯', '水晶灯', '吸顶灯'],
      en: ['lighting', 'lamp', 'chandelier', 'LED lighting', 'pendant light', 'wall lamp', 'ceiling light', 'outdoor lighting', 'floor lamp', 'table lamp', 'spotlight', 'track lighting', 'crystal chandelier'],
    },
    targetRegions: {
      primary: ['中东', '东南亚', '非洲', '南美'],
      secondary: ['欧美', '澳洲'],
      domesticFocus: ['深圳', '中山古镇', '佛山', '东莞'],
    },
    customerProfile: {
      type: ['灯具批发商', '照明工程公司', '建材超市', '酒店采购', '装修公司', '电商卖家'],
      scale: ['中型企业', '大型批发商', '工程承包商'],
      keyDecisionMakers: ['采购经理', '工程经理', '老板/总经理'],
    },
    searchTips: [
      '中东地区偏好奢华风格水晶灯、大型吊灯',
      '东南亚市场注重性价比，LED灯具需求量大',
      '非洲市场需要户外照明、太阳能灯具',
      '古镇灯饰厂商竞争激烈，差异化定位很重要',
    ],
    developmentLetterTemplate: {
      formal: `尊敬的{客户名}，

我是来自{公司名}的{联系人}，我们是一家专注于灯饰照明产品的专业制造商。

主要产品：
• LED商业照明：筒灯、射灯、轨道灯系列
• 家居照明：吊灯、吸顶灯、壁灯等
• 户外照明：路灯、景观灯、太阳能灯具
• 定制服务：酒店、商场、别墅整体照明解决方案

我们的优势：
- 10年灯具制造经验，ISO9001认证
- 产品符合CE、UL、SASO认证标准
- 灵活的定制能力，支持OEM/ODM
- 月产能50万件，交货周期15-30天

期待与您建立合作关系，欢迎索取产品目录和报价。

{签名}`,
      simple: `您好！我们是专业灯饰制造商，主营LED商业照明、家居灯具、户外照明。产品通过CE/UL认证，支持OEM定制。欢迎索取报价和样品！`,
      whatsapp: `Hi! We are a professional lighting manufacturer specializing in LED commercial lighting, home fixtures, and outdoor lighting. CE/UL certified, OEM available. Would you like to see our catalog and pricing? 🌟`,
    },
  },

  '油漆涂料': {
    id: 'paint',
    industry: '油漆涂料',
    keywords: {
      zh: ['油漆', '涂料', '木器漆', '墙面漆', '防水涂料', '艺术涂料', '乳胶漆', 'PU漆', '环保涂料'],
      en: ['paint', 'coating', 'varnish', 'waterproof coating', 'wood paint', 'wall paint', 'lacquer', 'PU coating', 'artistic coating', 'eco-friendly paint', 'industrial coating', 'marine paint'],
    },
    targetRegions: {
      primary: ['东南亚', '非洲', '南美'],
      secondary: ['中东', '中亚'],
      domesticFocus: ['顺德', '东莞', '广州', '佛山'],
    },
    customerProfile: {
      type: ['涂料经销商', '建材批发商', '家具厂', '装修公司', '工程承包商', '船舶维修'],
      scale: ['大型经销商', '家具制造企业', '工程项目'],
      keyDecisionMakers: ['采购总监', '技术经理', '老板'],
    },
    searchTips: [
      '东南亚市场对环保水性漆需求增长',
      '非洲市场偏好工业涂料、船舶涂料',
      '南美市场需要防水涂料、外墙涂料',
      '家具厂需要木器漆配套服务',
    ],
    developmentLetterTemplate: {
      formal: `尊敬的{客户名}，

我是{公司名}的{联系人}，我们是一家专业的涂料制造商。

产品系列：
• 木器漆：PU漆、PE漆、水性木器漆
• 建筑涂料：乳胶漆、防水涂料、外墙漆
• 工业涂料：防腐漆、地坪漆、船舶漆
• 艺术涂料：质感漆、仿石漆、金属漆

核心优势：
- 环保配方，符合国际环保标准
- 完善的技术支持和施工指导
- 灵活的产品定制能力
- 快速物流，支持门到门服务

期待为您提供优质涂料解决方案。

{签名}`,
      simple: `您好！我们专业生产环保油漆涂料，产品涵盖木器漆、建筑涂料、工业涂料。符合国际环保标准，技术支持完善。欢迎索取样品和报价！`,
      whatsapp: `Hi! We manufacture eco-friendly paints & coatings: wood paint, wall paint, waterproof coating, industrial coating. International standards certified. Samples and pricing available! 🎨`,
    },
  },

  '岩板大板': {
    id: 'slab',
    industry: '岩板大板',
    keywords: {
      zh: ['岩板', '大板', '岩板台面', '大板瓷砖', '薄板', '陶瓷大板', '石英岩板', '烧结石材'],
      en: ['sintered stone', 'slab', 'porcelain slab', 'large format tile', 'thin slab', 'stone slab', 'ceramic panel', 'quartz slab', 'countertop slab', 'wall cladding'],
    },
    targetRegions: {
      primary: ['中东', '欧美', '澳洲'],
      secondary: ['东南亚', '非洲'],
      domesticFocus: ['佛山', '清远', '肇庆', '云浮'],
    },
    customerProfile: {
      type: ['石材经销商', '橱柜厂', '家具厂', '建材超市', '设计公司', '工程承包商'],
      scale: ['大型经销商', '橱柜制造企业', '工程项目'],
      keyDecisionMakers: ['采购经理', '设计总监', '老板'],
    },
    searchTips: [
      '中东高端市场偏好奢华纹理岩板',
      '欧美市场注重环保认证和可持续性',
      '橱柜厂是岩板台面的重要客户',
      '大板运输成本高，需考虑物流方案',
    ],
    developmentLetterTemplate: {
      formal: `尊敬的{客户名}，

我是{公司名}的{联系人}，专注于岩板大板产品的研发与生产。

产品系列：
• 岩板台面：厚度3mm-20mm，规格定制
• 大板瓷砖：1200x2400mm、1600x3200mm等
• 应用场景：厨房台面、浴室台面、墙面装饰
• 表面处理：哑光、高光、仿石纹、仿木纹

产品优势：
- 采用意大利先进生产技术
- 高耐磨、耐高温、耐腐蚀
- 食品级安全，可直接接触食物
- 支持定制规格和图案

期待为您的项目提供优质岩板解决方案。

{签名}`,
      simple: `您好！我们专业生产高端岩板大板，产品用于台面、墙面装饰。意大利工艺，耐高温耐磨，支持定制规格。欢迎索取样品和报价！`,
      whatsapp: `Hi! We specialize in sintered stone & large format slabs for countertops and wall cladding. Italian technology, heat-resistant, durable. Custom sizes available! 🪨`,
    },
  },

  '橱柜定制': {
    id: 'cabinet',
    industry: '橱柜定制',
    keywords: {
      zh: ['整体橱柜', '橱柜定制', '橱柜门板', '橱柜台面', '厨房橱柜', '定制厨柜', '衣柜定制'],
      en: ['cabinet', 'kitchen cabinet', 'custom cabinet', 'cabinet door', 'countertop', 'wardrobe', 'closet', 'bathroom vanity', 'custom kitchen', 'RTA cabinet', 'flat pack cabinet'],
    },
    targetRegions: {
      primary: ['中东', '澳洲', '北美'],
      secondary: ['东南亚', '欧洲'],
      domesticFocus: ['广州', '佛山', '东莞', '深圳'],
    },
    customerProfile: {
      type: ['橱柜经销商', '建材超市', '装修公司', '房地产开发商', '酒店采购', '海外电商'],
      scale: ['大型经销商', '工程项目', '连锁卖场'],
      keyDecisionMakers: ['采购经理', '项目经理', '老板'],
    },
    searchTips: [
      '中东市场偏好豪华欧式橱柜',
      '澳洲市场注重环保认证和耐用性',
      '北美RTA橱柜市场增长迅速',
      '一站式橱柜+台面+配件服务更有竞争力',
    ],
    developmentLetterTemplate: {
      formal: `尊敬的{客户名}，

我是{公司名}的{联系人}，专注于整体橱柜定制生产。

产品系列：
• 整体橱柜：现代简约、欧式古典、中式风格
• 门板类型：实木门板、亚克力门板、PET门板、UV门板
• 台面配套：石英石台面、岩板台面、不锈钢台面
• 定制服务：尺寸定制、风格定制、功能定制

核心优势：
- 15年橱柜制造经验
- 完整供应链，橱柜+台面+配件一站式
- 灵活定制，支持OEM/ODM
- RTA柜出口经验丰富

期待为您提供专业的橱柜解决方案。

{签名}`,
      simple: `您好！我们专业定制整体橱柜，产品涵盖橱柜门板、台面、衣柜等。15年经验，一站式服务，支持OEM定制。欢迎索取产品目录和报价！`,
      whatsapp: `Hi! We specialize in custom kitchen cabinets, wardrobe, and closet. Complete solutions with doors & countertops. OEM available. Catalog and pricing available! 🏠`,
    },
  },
};

// 获取所有行业模板列表
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const industry = searchParams.get('industry');

  if (industry && INDUSTRY_SEARCH_TEMPLATES[industry as keyof typeof INDUSTRY_SEARCH_TEMPLATES]) {
    return NextResponse.json({
      success: true,
      data: INDUSTRY_SEARCH_TEMPLATES[industry as keyof typeof INDUSTRY_SEARCH_TEMPLATES],
    });
  }

  // 返回所有行业模板概览
  const templateList = Object.entries(INDUSTRY_SEARCH_TEMPLATES).map(([name, template]) => ({
    name,
    id: template.id,
    keywords: template.keywords,
    targetRegions: template.targetRegions,
    customerTypes: template.customerProfile.type,
  }));

  return NextResponse.json({
    success: true,
    data: templateList,
    total: templateList.length,
    note: '当前为模拟数据，4个重点行业详细模板已配置',
  });
}