// 自动获客任务切换 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { task_id, action } = body;

    if (!task_id || !action) {
      return NextResponse.json({ error: '请提供任务ID和操作' }, { status: 400 });
    }

    const newStatus = action === 'start' ? 'running' : 'paused';
    const nextRunTime = action === 'start' 
      ? new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString()
      : null;

    // 尝试更新数据库
    const { error: updateError } = await client
      .from('auto_acquisition_tasks')
      .update({
        status: newStatus,
        next_run_time: nextRunTime,
        updated_at: new Date().toISOString(),
      })
      .eq('id', task_id)
      .eq('user_id', user.id);

    if (updateError) {
      console.error('更新任务状态失败:', updateError);
    }

    return NextResponse.json({ 
      success: true, 
      status: newStatus,
      message: `任务已${action === 'start' ? '启动' : '暂停'}` 
    });
  } catch (error) {
    console.error('切换任务状态失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '操作失败' 
    }, { status: 500 });
  }
}