'use client';

import { useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { demoWorkspace } from '@/lib/workspace';
import {
  demoTeamMembers,
  getRole,
  getStatusClass,
  getStatusLabel,
  getTeamSummary,
  teamRoles,
  type TeamRoleId,
} from '@/lib/team-access';
import { Activity, BriefcaseBusiness, Clock3, Mail, Search, ShieldCheck, UserPlus, Users } from 'lucide-react';

export default function TeamPage() {
  const summary = getTeamSummary();
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState<TeamRoleId | 'all'>('all');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<TeamRoleId>('sales');

  const filteredMembers = useMemo(() => {
    const keyword = searchTerm.trim().toLowerCase();
    return demoTeamMembers.filter((member) => {
      const matchKeyword =
        !keyword ||
        member.name.toLowerCase().includes(keyword) ||
        member.email.toLowerCase().includes(keyword) ||
        member.team.toLowerCase().includes(keyword);
      const matchRole = roleFilter === 'all' || member.role === roleFilter;
      return matchKeyword && matchRole;
    });
  }, [roleFilter, searchTerm]);

  const stats = [
    { label: '已启用成员', value: `${summary.activeMembers} 人`, icon: Users, tone: 'text-blue-300' },
    { label: '待激活邀请', value: `${summary.pendingMembers} 人`, icon: Mail, tone: 'text-amber-300' },
    { label: '团队客户数', value: `${summary.totalCustomers} 个`, icon: BriefcaseBusiness, tone: 'text-emerald-300' },
    { label: '待处理任务', value: `${summary.openTasks} 条`, icon: Activity, tone: 'text-violet-300' },
  ];

  return (
    <MainLayout title="团队管理">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.13 团队权限</Badge>
                <Badge className="border-slate-500/25 bg-slate-500/15 text-slate-300">{demoWorkspace.name}</Badge>
              </div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">成员、角色和客户数据范围</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                这里用于管理外贸获客团队：老板看全局，管理员管运营，销售跟进客户，运营负责搜索和核验。后续接入正式数据库后，每个成员都会绑定到同一个工作空间。
              </p>
            </div>
            <Button className="h-10 bg-blue-600 text-white hover:bg-blue-500">
              <UserPlus className="mr-2 h-4 w-4" />
              邀请成员
            </Button>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {stats.map((item) => {
            const Icon = item.icon;
            return (
              <Card key={item.label} className="border-[#2d3548] bg-[#121823]">
                <CardContent className="flex items-center gap-4 p-5">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg border border-[#2d3548] bg-[#0f1419]">
                    <Icon className={`h-5 w-5 ${item.tone}`} />
                  </div>
                  <div>
                    <p className="text-sm text-[#94a3b8]">{item.label}</p>
                    <p className="mt-1 text-xl font-semibold text-[#f8fafc]">{item.value}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </section>

        <section className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader className="space-y-4">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                <CardTitle className="text-[#f8fafc]">团队成员</CardTitle>
                <div className="flex flex-col gap-3 sm:flex-row">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-[#64748b]" />
                    <Input
                      value={searchTerm}
                      onChange={(event) => setSearchTerm(event.target.value)}
                      placeholder="搜索姓名、邮箱、团队"
                      className="h-10 w-full border-[#2d3548] bg-[#0f1419] pl-9 text-[#f8fafc] sm:w-64"
                    />
                  </div>
                  <Select value={roleFilter} onValueChange={(value) => setRoleFilter(value as TeamRoleId | 'all')}>
                    <SelectTrigger className="h-10 border-[#2d3548] bg-[#0f1419] text-[#f8fafc] sm:w-36">
                      <SelectValue placeholder="角色筛选" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">全部角色</SelectItem>
                      {teamRoles.map((role) => (
                        <SelectItem key={role.id} value={role.id}>
                          {role.shortName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="border-[#2d3548] hover:bg-transparent">
                    <TableHead className="text-[#94a3b8]">成员</TableHead>
                    <TableHead className="text-[#94a3b8]">角色</TableHead>
                    <TableHead className="text-[#94a3b8]">团队</TableHead>
                    <TableHead className="text-[#94a3b8]">客户 / 任务</TableHead>
                    <TableHead className="text-[#94a3b8]">状态</TableHead>
                    <TableHead className="text-[#94a3b8]">最后登录</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMembers.map((member) => {
                    const role = getRole(member.role);
                    return (
                      <TableRow key={member.id} className="border-[#2d3548] hover:bg-[#0f1419]">
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="flex h-10 w-10 items-center justify-center rounded-full border border-[#2d3548] bg-[#0f1419] text-sm font-semibold text-[#f8fafc]">
                              {member.name.slice(0, 1)}
                            </div>
                            <div>
                              <p className="font-medium text-[#f8fafc]">{member.name}</p>
                              <p className="text-xs text-[#94a3b8]">{member.email}</p>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={`border ${role.colorClass}`}>{role.shortName}</Badge>
                        </TableCell>
                        <TableCell className="text-[#cbd5e1]">{member.team}</TableCell>
                        <TableCell className="text-[#cbd5e1]">
                          {member.customerCount} 个 / {member.taskCount} 条
                        </TableCell>
                        <TableCell>
                          <Badge className={`border ${getStatusClass(member.status)}`}>{getStatusLabel(member.status)}</Badge>
                        </TableCell>
                        <TableCell className="text-[#94a3b8]">{member.lastLogin}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                  <UserPlus className="h-5 w-5 text-blue-300" />
                  邀请预览
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Input
                  value={inviteEmail}
                  onChange={(event) => setInviteEmail(event.target.value)}
                  placeholder="member@company.com"
                  className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                />
                <Select value={inviteRole} onValueChange={(value) => setInviteRole(value as TeamRoleId)}>
                  <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {teamRoles.map((role) => (
                      <SelectItem key={role.id} value={role.id}>
                        {role.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3 text-sm text-[#94a3b8]">
                  当前是演示邀请，不会真实发送邮件。正式 SaaS 版本会接入邮箱服务和账号激活链接。
                </div>
                <Button className="w-full bg-blue-600 text-white hover:bg-blue-500" disabled={!inviteEmail.trim()}>
                  生成邀请记录
                </Button>
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                  <ShieldCheck className="h-5 w-5 text-emerald-300" />
                  角色说明
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {teamRoles.map((role) => (
                  <div key={role.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                    <div className="flex items-center justify-between gap-2">
                      <Badge className={`border ${role.colorClass}`}>{role.shortName}</Badge>
                      <span className="text-xs text-[#64748b]">{role.scope}</span>
                    </div>
                    <p className="mt-2 text-sm leading-5 text-[#94a3b8]">{role.description}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardContent className="flex items-start gap-3 p-4">
                <Clock3 className="mt-0.5 h-5 w-5 text-amber-300" />
                <p className="text-sm leading-6 text-[#94a3b8]">
                  v0.13 先完成前端角色模型。下一阶段可以把邀请、权限校验和客户分配接到 Supabase 数据库。
                </p>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}
