'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Search, Filter, Eye, Download, User, FileEdit, Trash2,
  PlusCircle, ArrowRightLeft, Mail, Upload, History
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface AuditLog {
  id: string;
  operator: string;
  operator_id: string;
  operation_type: string;
  target_type: string;
  target_id: string;
  target_name: string;
  before_data: Record<string, unknown> | null;
  after_data: Record<string, unknown> | null;
  created_at: string;
  ip_address: string;
}

interface LogStats {
  typeStats: Record<string, number>;
  operatorStats: Record<string, number>;
}

const operationTypeOptions = [
  '创建客户',
  '修改商机状态',
  '公海池认领',
  '删除客户',
  '导入客户',
  '创建跟进',
  '客户退回公海池',
  '发送邮件',
];

const getOperationIcon = (type: string) => {
  switch (type) {
    case '创建客户': return <PlusCircle className="w-4 h-4 text-green-400" />;
    case '修改商机状态': return <ArrowRightLeft className="w-4 h-4 text-blue-400" />;
    case '公海池认领': return <User className="w-4 h-4 text-orange-400" />;
    case '删除客户': return <Trash2 className="w-4 h-4 text-red-400" />;
    case '导入客户': return <Upload className="w-4 h-4 text-purple-400" />;
    case '创建跟进': return <FileEdit className="w-4 h-4 text-cyan-400" />;
    case '客户退回公海池': return <ArrowRightLeft className="w-4 h-4 text-yellow-400" />;
    case '发送邮件': return <Mail className="w-4 h-4 text-indigo-400" />;
    default: return <History className="w-4 h-4 text-gray-400" />;
  }
};

const getOperationColor = (type: string) => {
  switch (type) {
    case '创建客户': return 'bg-green-500/20 text-green-400';
    case '修改商机状态': return 'bg-blue-500/20 text-blue-400';
    case '公海池认领': return 'bg-orange-500/20 text-orange-400';
    case '删除客户': return 'bg-red-500/20 text-red-400';
    case '导入客户': return 'bg-purple-500/20 text-purple-400';
    case '创建跟进': return 'bg-cyan-500/20 text-cyan-400';
    case '客户退回公海池': return 'bg-yellow-500/20 text-yellow-400';
    case '发送邮件': return 'bg-indigo-500/20 text-indigo-400';
    default: return 'bg-gray-500/20 text-gray-400';
  }
};

export default function AuditLogsPage() {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [stats, setStats] = useState<LogStats>({ typeStats: {}, operatorStats: {} });
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pageSize] = useState(20);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    operator: '',
    operationType: '',
    startDate: '',
    endDate: '',
  });
  const [selectedLog, setSelectedLog] = useState<AuditLog | null>(null);

  // 加载审计日志
  const loadLogs = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (filters.operator) params.append('operator', filters.operator);
      if (filters.operationType) params.append('operationType', filters.operationType);
      if (filters.startDate) params.append('startDate', filters.startDate);
      if (filters.endDate) params.append('endDate', filters.endDate);
      params.append('page', page.toString());
      params.append('pageSize', pageSize.toString());

      const res = await fetch(`/api/audit-logs?${params}`);
      const data = await res.json();
      if (data.success) {
        setLogs(data.data.logs);
        setTotal(data.data.total);
        setStats({ typeStats: data.data.typeStats, operatorStats: data.data.operatorStats });
      }
    } catch (error) {
      console.error('加载审计日志失败:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, [page]);

  // 导出日志
  const exportLogs = async () => {
    try {
      const csvContent = [
        ['时间', '操作人', '操作类型', '目标类型', '目标名称', 'IP地址'].join(','),
        ...logs.map(log => [
          new Date(log.created_at).toLocaleString('zh-CN'),
          log.operator,
          log.operation_type,
          log.target_type,
          log.target_name,
          log.ip_address,
        ].join(','))
      ].join('\n');

      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `audit_logs_${Date.now()}.csv`;
      link.click();
      URL.revokeObjectURL(link.href);
    } catch (error) {
      console.error('导出失败:', error);
    }
  };

  const totalPages = Math.ceil(total / pageSize);

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">操作审计日志</h1>
          <p className="text-[var(--text-muted)] mt-1">查看所有关键操作记录，保障数据安全</p>
        </div>
        <Button variant="outline" onClick={exportLogs}>
          <Download className="w-4 h-4 mr-2" />
          导出日志
        </Button>
      </div>

      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4">
        <Card className="bg-[var(--bg-card)]">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <History className="w-8 h-8 text-blue-400" />
              <div>
                <p className="text-2xl font-bold text-[var(--text-primary)]">{total}</p>
                <p className="text-sm text-[var(--text-muted)]">总记录数</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[var(--bg-card)]">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <PlusCircle className="w-8 h-8 text-green-400" />
              <div>
                <p className="text-2xl font-bold text-[var(--text-primary)]">
                  {stats.typeStats['创建客户'] || 0}
                </p>
                <p className="text-sm text-[var(--text-muted)]">创建操作</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[var(--bg-card)]">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <FileEdit className="w-8 h-8 text-blue-400" />
              <div>
                <p className="text-2xl font-bold text-[var(--text-primary)]">
                  {Object.entries(stats.typeStats)
                    .filter(([k]) => k.includes('修改') || k.includes('跟进'))
                    .reduce((sum, [, v]) => sum + v, 0)}
                </p>
                <p className="text-sm text-[var(--text-muted)]">修改操作</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[var(--bg-card)]">
          <CardContent className="pt-6">
            <div className="flex items-center gap-3">
              <Trash2 className="w-8 h-8 text-red-400" />
              <div>
                <p className="text-2xl font-bold text-[var(--text-primary)]">
                  {stats.typeStats['删除客户'] || 0}
                </p>
                <p className="text-sm text-[var(--text-muted)]">删除操作</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 筛选区域 */}
      <Card className="bg-[var(--bg-card)]">
        <CardHeader>
          <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
            <Filter className="w-5 h-5" />
            筛选条件
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4">
            <div>
              <label className="text-sm text-[var(--text-muted)] mb-2 block">操作人</label>
              <Input
                placeholder="输入操作人"
                value={filters.operator}
                onChange={(e) => setFilters(prev => ({ ...prev, operator: e.target.value }))}
                className="bg-[var(--bg-secondary)]"
              />
            </div>
            <div>
              <label className="text-sm text-[var(--text-muted)] mb-2 block">操作类型</label>
              <select
                value={filters.operationType}
                onChange={(e) => setFilters(prev => ({ ...prev, operationType: e.target.value }))}
                className="w-full h-10 rounded-md bg-[var(--bg-secondary)] border-[var(--border-color)] px-3 text-[var(--text-primary)]"
              >
                <option value="">全部类型</option>
                {operationTypeOptions.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm text-[var(--text-muted)] mb-2 block">开始日期</label>
              <Input
                type="date"
                value={filters.startDate}
                onChange={(e) => setFilters(prev => ({ ...prev, startDate: e.target.value }))}
                className="bg-[var(--bg-secondary)]"
              />
            </div>
            <div>
              <label className="text-sm text-[var(--text-muted)] mb-2 block">结束日期</label>
              <Input
                type="date"
                value={filters.endDate}
                onChange={(e) => setFilters(prev => ({ ...prev, endDate: e.target.value }))}
                className="bg-[var(--bg-secondary)]"
              />
            </div>
          </div>
          <Button className="mt-4" onClick={loadLogs}>
            <Search className="w-4 h-4 mr-2" />
            查询
          </Button>
        </CardContent>
      </Card>

      {/* 日志列表 */}
      <Card className="bg-[var(--bg-card)]">
        <CardHeader>
          <CardTitle className="text-[var(--text-primary)]">审计日志列表</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="border-[var(--border-color)]">
                <TableHead className="text-[var(--text-secondary)]">时间</TableHead>
                <TableHead className="text-[var(--text-secondary)]">操作人</TableHead>
                <TableHead className="text-[var(--text-secondary)]">操作类型</TableHead>
                <TableHead className="text-[var(--text-secondary)]">目标</TableHead>
                <TableHead className="text-[var(--text-secondary)]">目标名称</TableHead>
                <TableHead className="text-[var(--text-secondary)]">IP地址</TableHead>
                <TableHead className="text-[var(--text-secondary)]">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {logs.map(log => (
                <TableRow key={log.id} className="border-[var(--border-color)] hover:bg-[var(--bg-secondary)]">
                  <TableCell className="text-[var(--text-secondary)]">
                    {new Date(log.created_at).toLocaleString('zh-CN')}
                  </TableCell>
                  <TableCell className="text-[var(--text-secondary)]">{log.operator}</TableCell>
                  <TableCell>
                    <Badge className={cn('gap-1', getOperationColor(log.operation_type))}>
                      {getOperationIcon(log.operation_type)}
                      {log.operation_type}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-[var(--text-secondary)]">{log.target_type}</TableCell>
                  <TableCell className="text-[var(--text-secondary)]">{log.target_name}</TableCell>
                  <TableCell className="text-[var(--text-muted)]">{log.ip_address}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" onClick={() => setSelectedLog(log)}>
                      <Eye className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {/* 分页 */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-[var(--text-muted)]">
                共 {total} 条记录，第 {page}/{totalPages} 页
              </p>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === 1}
                  onClick={() => setPage(page - 1)}
                >
                  上一页
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={page === totalPages}
                  onClick={() => setPage(page + 1)}
                >
                  下一页
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 详情弹窗 */}
      {selectedLog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className="bg-[var(--bg-card)] w-full max-w-lg mx-4">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)] flex items-center gap-2">
                {getOperationIcon(selectedLog.operation_type)}
                操作详情
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-[var(--text-muted)]">操作时间</p>
                  <p className="text-[var(--text-primary)]">
                    {new Date(selectedLog.created_at).toLocaleString('zh-CN')}
                  </p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-muted)]">操作人</p>
                  <p className="text-[var(--text-primary)]">{selectedLog.operator}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-muted)]">IP地址</p>
                  <p className="text-[var(--text-primary)]">{selectedLog.ip_address}</p>
                </div>
                <div>
                  <p className="text-sm text-[var(--text-muted)]">目标类型</p>
                  <p className="text-[var(--text-primary)]">{selectedLog.target_type}</p>
                </div>
              </div>

              {selectedLog.before_data && (
                <div>
                  <p className="text-sm text-[var(--text-muted)] mb-2">变更前数据</p>
                  <div className="bg-[var(--bg-secondary)] rounded-lg p-3 text-sm">
                    <pre className="text-[var(--text-secondary)] overflow-auto">
                      {JSON.stringify(selectedLog.before_data, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              {selectedLog.after_data && (
                <div>
                  <p className="text-sm text-[var(--text-muted)] mb-2">变更后数据</p>
                  <div className="bg-[var(--bg-secondary)] rounded-lg p-3 text-sm">
                    <pre className="text-[var(--text-secondary)] overflow-auto">
                      {JSON.stringify(selectedLog.after_data, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              <Button className="w-full" onClick={() => setSelectedLog(null)}>
                关闭
              </Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}