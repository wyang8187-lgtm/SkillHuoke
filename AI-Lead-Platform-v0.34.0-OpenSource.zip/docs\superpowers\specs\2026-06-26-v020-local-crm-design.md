# v0.20.0 Local CRM Customers Design

## Goal

Convert candidate leads into a local CRM customer pool with follow-up status, notes, and next actions.

## User Value

- 用户可以把候选客户真正沉淀为 CRM 客户，而不是停留在候选池。
- 外贸销售可以标记开发状态、写备注、记录下一步动作。
- 平台流程形成闭环：获客向导 -> 任务执行 -> 候选客户 -> CRM 跟进。

## Scope

- Add local CRM customer types and storage helpers.
- Add `/crm-customers` page.
- Convert candidate leads to CRM customers from candidate pool.
- Track CRM status, notes, next action, score, priority, and source task.
- Update navigation, release center, README, and version.

## Out Of Scope

- Real database-backed CRM.
- Full customer detail page.
- Email or WhatsApp sending.
- Multi-user owner assignment.

## Acceptance Criteria

- Users can convert a candidate lead into a local CRM customer.
- `/crm-customers` lists local CRM customers from browser storage.
- Users can update CRM status, note, and next action locally.
- Candidate pool marks converted candidates as joined.
- Type check, lint, build, and HTTP checks pass.
