# v0.25.0 CRM Sales Funnel Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn local CRM records into a real cumulative sales funnel, customer distribution, and operating-risk dashboard.

**Architecture:** Keep all metrics in a pure `crm-analytics` module. The client page loads local customers once and renders metrics without mock APIs; CRM list reads optional status query parameters for drill-down.

**Tech Stack:** Next.js 16, React 19, TypeScript, localStorage, CSS progress bars.

---

### Task 1: Build analytics calculations

**Files:**
- Create: `src/lib/crm-analytics.ts`

- [ ] Calculate cumulative funnel stages and adjacent conversion rates.
- [ ] Calculate priority, country, and customer-type distributions.
- [ ] Classify overdue, unscheduled, high-score new, and paused risks.
- [ ] Return safe zero values for empty data.

### Task 2: Build CRM analytics page

**Files:**
- Create: `src/app/crm-analytics/page.tsx`

- [ ] Render real headline metrics and empty state.
- [ ] Render four-stage cumulative funnel with drill-down links.
- [ ] Render priority, country, and customer-type distributions.
- [ ] Render operating-risk customer lists with detail links.

### Task 3: Add drill-down and navigation

**Files:**
- Modify: `src/app/crm-customers/page.tsx`
- Modify: `src/components/layout/sidebar.tsx`

- [ ] Initialize CRM status filter from `?status=`.
- [ ] Add CRM analytics navigation entry.

### Task 4: Update release and package

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `package.json`
- Modify: `README.md`
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.25.0-OpenSource.zip`

- [ ] Set v0.25.0 release metadata and GitHub remark.
- [ ] Run TypeScript, ESLint, production build, page checks, and package safety inspection.
