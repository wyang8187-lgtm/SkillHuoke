'use client';

import { useEffect, useState } from 'react';
import { useTheme } from '@/lib/theme-context';
import {
  FunnelChart, Funnel, BarChart, Bar, XAxis, YAxis,
  CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@/components/ui/empty-state';
import { TrendingUp, Mail, Target, DollarSign } from 'lucide-react';

const FUNNEL_COLORS = ['#3b82f6', '#22c55e', '#f97316', '#8b5cf6', '#06b6d4', '#22c55e', '#ef4444'];

export default function SalesAnalyticsPage() {
  const { theme } = useTheme();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const res = await fetch('/api/analytics/sales');
      const json = await res.json();
      if (json.success) {
        setData(json.data);
      }
    } catch (error) {
      console.error('获取数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-32" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  const hasData = data && (data.totalOpportunities > 0 || data.totalLeads > 0);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold flex items-center gap-2">
        <TrendingUp className="w-6 h-6" />
        销售数据分析
      </h1>

      {/* 总数卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">总线索数</div>
            <div className="text-2xl font-bold">{data?.totalLeads || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">总商机数</div>
            <div className="text-2xl font-bold">{data?.totalOpportunities || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">成交率</div>
            <div className="text-2xl font-bold text-green-500">
              {data?.conversionRate?.winRate || 0}%
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">邮件回复率</div>
            <div className="text-2xl font-bold">{data?.emailStats?.replyRate || 0}%</div>
          </CardContent>
        </Card>
      </div>

      {!hasData ? (
        <EmptyState
          icon={<Target className="w-12 h-12" />}
          title="暂无销售数据"
          description="请先创建商机或添加线索数据"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 商机漏斗 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5" />
                商机漏斗分析
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={data?.funnel || []} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#2d3548' : '#e5e7eb'} />
                  <XAxis type="number" stroke="#64748b" />
                  <YAxis type="category" dataKey="stage" stroke="#64748b" tick={{ fontSize: 12 }} width={80} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: theme === 'dark' ? '#1a1f2c' : '#fff',
                      border: '1px solid #2d3548'
                    }}
                    formatter={(value: any, name: string) => {
                      if (name === 'rate') return `${value}%`;
                      return value;
                    }}
                  />
                  <Bar dataKey="count" name="数量" radius={[0, 4, 4, 0]}>
                    {(data?.funnel || []).map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={FUNNEL_COLORS[index % FUNNEL_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2">
                {data?.funnel?.map((item: any, index: number) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <span className="flex items-center gap-2">
                      <span className="w-3 h-3 rounded-full" style={{ backgroundColor: FUNNEL_COLORS[index] }}></span>
                      {item.stage}
                    </span>
                    <span className="text-muted-foreground">
                      {item.count}个 · 转化率 {item.rate}%
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 月度销售趋势 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="w-5 h-5" />
                月度成交趋势
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={data?.salesTrend || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#2d3548' : '#e5e7eb'} />
                  <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="left" stroke="#64748b" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#64748b" tick={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: theme === 'dark' ? '#1a1f2c' : '#fff',
                      border: '1px solid #2d3548'
                    }}
                  />
                  <Legend />
                  <Bar yAxisId="left" dataKey="count" name="成交数量" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  <Bar yAxisId="right" dataKey="amount" name="成交金额(万元)" fill="#22c55e" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* 开发信统计 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                开发信效果统计
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-2xl font-bold">{data?.emailStats?.total || 0}</div>
                  <div className="text-sm text-muted-foreground">发送总数</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-500">{data?.emailStats?.opened || 0}</div>
                  <div className="text-sm text-muted-foreground">已打开</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-500">{data?.emailStats?.replied || 0}</div>
                  <div className="text-sm text-muted-foreground">已回复</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-500">{data?.emailStats?.clicked || 0}</div>
                  <div className="text-sm text-muted-foreground">已点击</div>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-muted/20 rounded-lg p-4 text-center">
                  <div className="text-lg font-semibold">{data?.emailStats?.openRate || 0}%</div>
                  <div className="text-xs text-muted-foreground">打开率</div>
                </div>
                <div className="bg-muted/20 rounded-lg p-4 text-center">
                  <div className="text-lg font-semibold">{data?.emailStats?.replyRate || 0}%</div>
                  <div className="text-xs text-muted-foreground">回复率</div>
                </div>
                <div className="bg-muted/20 rounded-lg p-4 text-center">
                  <div className="text-lg font-semibold">{data?.emailStats?.clickRate || 0}%</div>
                  <div className="text-xs text-muted-foreground">点击率</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 成交率统计 */}
          <Card>
            <CardHeader>
              <CardTitle>客户开发成功率</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-gray-500"></span>
                    总线索数
                  </span>
                  <span className="font-semibold">{data?.conversionRate?.totalLeads || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-green-500"></span>
                    成交客户
                  </span>
                  <span className="font-semibold text-green-500">{data?.conversionRate?.wonOpps || 0}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    流失客户
                  </span>
                  <span className="font-semibold text-red-500">{data?.conversionRate?.lostOpps || 0}</span>
                </div>
                <div className="border-t pt-4 mt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-green-500/10 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-green-500">{data?.conversionRate?.winRate || 0}%</div>
                      <div className="text-sm text-muted-foreground">成交转化率</div>
                    </div>
                    <div className="bg-red-500/10 rounded-lg p-4 text-center">
                      <div className="text-2xl font-bold text-red-500">{data?.conversionRate?.lossRate || 0}%</div>
                      <div className="text-sm text-muted-foreground">流失率</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}