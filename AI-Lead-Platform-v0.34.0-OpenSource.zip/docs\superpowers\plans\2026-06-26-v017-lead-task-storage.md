# v0.17.0 Lead Task Storage Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Save generated lead wizard output into local task records and provide a task history page.

**Architecture:** Extend lead wizard types with saved task records, add browser localStorage helpers, update `/lead-wizard` to save/export generated plans, and add `/lead-tasks` to manage saved tasks.

**Tech Stack:** Next.js App Router, React client components, TypeScript, browser localStorage, Tailwind CSS, local UI components.

---

### Task 1: Task Storage Helpers

**Files:**
- Modify: `src/lib/lead-wizard.ts`

- [ ] Add task status and saved task types.
- [ ] Add storage key.
- [ ] Add create, read, update, delete, and export helpers.

### Task 2: Wizard Save Actions

**Files:**
- Modify: `src/app/lead-wizard/page.tsx`

- [ ] Add save task button.
- [ ] Add export text button.
- [ ] Add link to task history.

### Task 3: Task History Page

**Files:**
- Create: `src/app/lead-tasks/page.tsx`

- [ ] Load saved tasks from localStorage.
- [ ] Render task cards.
- [ ] Allow status updates.
- [ ] Allow export and delete.

### Task 4: Navigation And Docs

**Files:**
- Modify: `src/components/layout/sidebar.tsx`
- Modify: `src/lib/release-experience.ts`
- Modify: `package.json`
- Modify: `README.md`

- [ ] Add navigation item.
- [ ] Update release version and review pages.
- [ ] Add v0.17 update notes.

### Task 5: Verification And Package

**Files:**
- Create output zip: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.17.0-OpenSource.zip`

- [ ] Run `corepack pnpm run ts-check`.
- [ ] Run `corepack pnpm run lint:build`.
- [ ] Run `corepack pnpm run build`.
- [ ] Check `/lead-wizard`, `/lead-tasks`, and `/release`.
- [ ] Package without `node_modules`, `.next`, `.git`, `.env`, or `.env.local`.
