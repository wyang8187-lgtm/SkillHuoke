// 公海池 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取公海池数据
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    // 获取所有客户和线索
    const customersResult = await dbService.getCustomers(user.id, undefined, 1, 1000);
    const leadsResult = await dbService.getLeads(user.id, undefined, 1, 1000);
    const teamMembers = await dbService.getTeamMembers(user.id);

    const customers = customersResult.data;
    const leads = leadsResult.data;

    // 计算公海池客户（未分配或超期未跟进）
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    const poolCustomers = customers
      .filter(c => {
        // 未分配
        if (!c.assignee_id) return true;
        // 超期未跟进
        if (c.last_follow_up_time) {
          const lastFollowUp = new Date(c.last_follow_up_time);
          return lastFollowUp < thirtyDaysAgo;
        }
        // 从未跟进过且创建超过30天
        if (c.created_at) {
          const created = new Date(c.created_at);
          return created < thirtyDaysAgo;
        }
        return false;
      })
      .map(c => {
        // 计算未跟进天数
        let daysSinceFollowUp = 0;
        if (c.last_follow_up_time) {
          const lastFollowUp = new Date(c.last_follow_up_time);
          daysSinceFollowUp = Math.floor((Date.now() - lastFollowUp.getTime()) / (24 * 60 * 60 * 1000));
        } else if (c.created_at) {
          const created = new Date(c.created_at);
          daysSinceFollowUp = Math.floor((Date.now() - created.getTime()) / (24 * 60 * 60 * 1000));
        }

        // 确定进入原因
        let enterReason = '';
        if (!c.assignee_id) {
          enterReason = '未分配客户';
        } else if (daysSinceFollowUp >= 30) {
          enterReason = `超期${daysSinceFollowUp}天未跟进`;
        } else {
          enterReason = '系统规则自动进入';
        }

        // 获取原负责人名称
        const originalOwner = c.assignee_id 
          ? teamMembers.find(m => m.id === c.assignee_id)?.name || '未知'
          : null;

        return {
          id: c.id,
          company_name: c.company_name,
          contact_name: c.contact_name,
          phone: c.phone,
          region: c.region,
          customer_type: c.customer_type,
          grade: c.grade,
          status: c.status,
          last_follow_up_time: c.last_follow_up_time,
          days_since_follow_up: daysSinceFollowUp,
          original_owner: originalOwner,
          entered_pool_time: c.updated_at || c.created_at,
          enter_reason: enterReason,
          source: c.source || '手动录入',
        };
      });

    // 公海池线索（未分配）
    const poolLeads = leads
      .filter(l => !l.assignee_id)
      .map(l => ({
        id: l.id,
        company_name: l.company_name,
        contact_name: l.contact_name,
        phone: l.phone,
        region: l.region,
        customer_type: l.customer_type,
        grade: l.grade || 'C',
        status: l.status,
        last_follow_up_time: null,
        days_since_follow_up: 0,
        original_owner: null,
        entered_pool_time: l.created_at,
        enter_reason: '未分配线索',
        source: l.source || 'AI获客',
      }));

    // 公海池规则（模拟）
    const rules = [
      {
        id: 'rule_1',
        name: '30天未跟进自动入池',
        description: '客户超过30天未跟进时，自动进入公海池供其他成员认领',
        days_threshold: 30,
        action: '移入公海池',
        is_active: true,
      },
      {
        id: 'rule_2',
        name: '新线索24小时未分配',
        description: '新线索创建后24小时内未分配负责人，自动进入公海池',
        days_threshold: 1,
        action: '移入公海池',
        is_active: false,
      },
      {
        id: 'rule_3',
        name: '输单客户自动入池',
        description: '输单的客户自动进入公海池，便于后续重新开发',
        days_threshold: 0,
        action: '移入公海池',
        is_active: true,
      },
    ];

    return NextResponse.json({
      customers: poolCustomers,
      leads: poolLeads,
      rules,
    });
  } catch (error) {
    console.error('获取公海池数据失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取数据失败' 
    }, { status: 500 });
  }
}