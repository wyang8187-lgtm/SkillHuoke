# v0.22.0 AI Outreach Upgrade Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add real OpenAI-backed customer outreach generation with four content types, three tones, and deterministic local fallback.

**Architecture:** Keep API credentials and provider selection in the server-only OpenAI provider. The customer detail page sends bounded customer context to the existing integration route, renders the returned source and fallback reason, and preserves the v0.21.0 local copy as its initial state.

**Tech Stack:** Next.js 16 Route Handlers, React 19, TypeScript, OpenAI Responses HTTP API, local deterministic templates, pnpm.

---

### Task 1: Build the outreach generation provider

**Files:**
- Modify: `src/lib/integrations/openai-provider.ts`
- Modify: `.env.example`

- [ ] Add `generate_customer_outreach` to `OpenAITask`.
- [ ] Define outreach type, tone, context, and structured result types.
- [ ] Generate four local fallback variants for professional, concise, and friendly tones.
- [ ] Add Chinese-character detection and response normalization.
- [ ] Call the OpenAI Responses API with server-side `OPENAI_API_KEY`, `OPENAI_MODEL`, timeout, and an English-only prompt.
- [ ] Return fallback content with a reason when the key is missing, the request fails, output is empty, or Chinese characters are detected.
- [ ] Run `corepack pnpm run ts-check`.

### Task 2: Extend the integration route

**Files:**
- Modify: `src/app/api/integrations/openai/route.ts`

- [ ] Allow `generate_customer_outreach`.
- [ ] Validate content type, tone, and bounded customer context.
- [ ] Return a stable top-level response containing `source`, `subject`, `content`, and optional `reason`.
- [ ] Keep existing OpenAI tasks backward compatible.
- [ ] Verify missing prompt and invalid task responses remain HTTP 400.

### Task 3: Upgrade the CRM customer detail UI

**Files:**
- Modify: `src/app/crm-customers/[id]/page.tsx`

- [ ] Add segmented content-type controls for first email, follow-up email, WhatsApp, and LinkedIn.
- [ ] Add tone selection for professional, concise, and friendly.
- [ ] Call `/api/integrations/openai` only when the user clicks generate.
- [ ] Show loading, generated source, fallback reason, and generation time.
- [ ] Support regenerate, copy subject, and copy content.
- [ ] Keep existing deterministic copy visible before the first request.
- [ ] Run `corepack pnpm run lint:build`.

### Task 4: Update release metadata

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `src/app/release/page.tsx`
- Modify: `package.json`
- Modify: `README.md`

- [ ] Set version to v0.22.0 and package name to `AI-Lead-Platform-v0.22.0-OpenSource.zip`.
- [ ] Add AI outreach generation to release highlights and review pages.
- [ ] Set GitHub remark to `v0.22.0：升级 AI 开发信，支持 OpenAI 生成与本地模板自动降级`.
- [ ] Document `OPENAI_API_KEY` and optional `OPENAI_MODEL`.

### Task 5: Verify and package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.22.0-OpenSource.zip`

- [ ] Run TypeScript, ESLint, and production build checks.
- [ ] Start the local server and test the OpenAI route without a key to confirm `fallback`.
- [ ] Verify `/login`, `/crm-customers`, `/crm-customers/demo-customer`, and `/release`.
- [ ] Inspect the updated page in the in-app browser.
- [ ] Package source without dependencies, build output, Git metadata, logs, or environment secrets.
- [ ] Inspect the ZIP manifest and confirm the new provider and customer detail page are included.
