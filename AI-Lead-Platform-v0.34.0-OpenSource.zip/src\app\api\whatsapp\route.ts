// WhatsApp营销 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 模拟消息模板
const mockTemplates = [
  {
    id: 'template_001',
    name: '初次接触',
    category: '初次接触',
    content: '您好 {{姓名}}，我是深圳某某全屋定制工厂的业务经理。我们专注为设计师和建材外贸公司提供高品质定制服务，期待与您合作！如有需求请随时联系。',
    variables: ['姓名'],
    created_at: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
    usage_count: 156,
  },
  {
    id: 'template_002',
    name: '产品推荐',
    category: '产品推荐',
    content: '{{姓名}}您好！根据您{{公司}}的需求，我为您推荐我们的{{产品}}系列。该系列采用环保材质，定制周期短，性价比高。详细资料可点击链接查看，期待您的反馈。',
    variables: ['姓名', '公司', '产品'],
    created_at: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(),
    usage_count: 89,
  },
  {
    id: 'template_003',
    name: '跟进提醒',
    category: '跟进提醒',
    content: '{{姓名}}您好，距离上次沟通已有一周，不知您对我们{{产品}}方案是否有新的想法？如有任何疑问或需要调整的地方，请随时告知，我会尽快为您处理。',
    variables: ['姓名', '产品'],
    created_at: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(),
    usage_count: 67,
  },
];

// 模拟发送记录
const mockRecords = [
  {
    id: 'record_001',
    template_id: 'template_001',
    template_name: '初次接触',
    customer_name: '张设计师',
    customer_phone: '13912345678',
    content: '您好 张设计师，我是深圳某某全屋定制工厂的业务经理。我们专注为设计师和建材外贸公司提供高品质定制服务，期待与您合作！如有需求请随时联系。',
    status: 'read',
    sent_time: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    read_time: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'record_002',
    template_id: 'template_002',
    template_name: '产品推荐',
    customer_name: '李经理',
    customer_phone: '13898765432',
    content: '李经理您好！根据您建材外贸公司的需求，我为您推荐我们的全屋定制系列。该系列采用环保材质，定制周期短，性价比高。详细资料可点击链接查看，期待您的反馈。',
    status: 'replied',
    sent_time: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
    read_time: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    replied_time: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: 'record_003',
    template_id: 'template_003',
    template_name: '跟进提醒',
    customer_name: '王总监',
    customer_phone: '13612349876',
    content: '王总监您好，距离上次沟通已有一周，不知您对我们定制方案是否有新的想法？如有任何疑问或需要调整的地方，请随时告知，我会尽快为您处理。',
    status: 'delivered',
    sent_time: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

// 模拟客户列表
const mockCustomers = [
  { id: 'cust_001', name: '张设计师', phone: '13912345678', company: '深圳某某设计公司' },
  { id: 'cust_002', name: '李经理', phone: '13898765432', company: '佛山建材外贸公司' },
  { id: 'cust_003', name: '王总监', phone: '13612349876', company: '广州某某家居有限公司' },
  { id: 'cust_004', name: '陈设计师', phone: '13587654321', company: '东莞室内设计工作室' },
];

// 统计数据
const mockStats = {
  total_sent: 312,
  delivered: 305,
  read: 189,
  replied: 78,
  delivery_rate: 98,
  read_rate: 62,
  reply_rate: 25,
};

// 获取所有WhatsApp数据
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    // 尝试获取数据库数据，如果没有则使用模拟数据
    const { data: dbTemplates, error: templateError } = await client
      .from('whatsapp_templates')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    let templates = mockTemplates;
    if (dbTemplates && dbTemplates.length > 0) {
      templates = dbTemplates.map(t => ({
        id: t.id,
        name: t.name,
        category: t.category || '其他',
        content: t.content,
        variables: t.variables || [],
        created_at: t.created_at,
        usage_count: t.usage_count || 0,
      }));
    }

    const { data: dbRecords } = await client
      .from('whatsapp_records')
      .select('*')
      .eq('user_id', user.id)
      .order('sent_time', { ascending: false })
      .limit(50);

    let records = mockRecords;
    if (dbRecords && dbRecords.length > 0) {
      records = dbRecords.map(r => ({
        id: r.id,
        template_id: r.template_id,
        template_name: r.template_name || '',
        customer_name: r.customer_name,
        customer_phone: r.customer_phone,
        content: r.content,
        status: r.status || 'sent',
        sent_time: r.sent_time,
        read_time: r.read_time,
        replied_time: r.replied_time,
      }));
    }

    // 获取客户列表
    const { data: dbCustomers } = await client
      .from('customers')
      .select('id, name, phone, company')
      .eq('user_id', user.id)
      .limit(20);

    let customers = mockCustomers;
    if (dbCustomers && dbCustomers.length > 0) {
      customers = dbCustomers.map(c => ({
        id: c.id,
        name: c.name,
        phone: c.phone,
        company: c.company || '',
      }));
    }

    return NextResponse.json({ templates, records, stats: mockStats, customers });
  } catch (error) {
    console.error('获取WhatsApp数据失败:', error);
    // 返回模拟数据作为兜底
    return NextResponse.json({ 
      templates: mockTemplates, 
      records: mockRecords, 
      stats: mockStats, 
      customers: mockCustomers 
    });
  }
}