# v0.34.0 接口配置与连接诊断中心设计

## 目标

把当前可输入密钥但缺少可靠安全存储的页面，改造成服务器 `.env` 只读诊断中心。用户可以看懂每个接口是否已配置、缺少什么、能否真实连接，以及失败的中文原因，但前端永远无法读取完整密钥。

## 页面与接口

- 页面：`/settings/api-keys`
- 服务清单接口：`GET /api/integrations/status`
- 单项测试接口：`POST /api/integrations/test`
- 页面不提供密钥输入框、保存按钮或完整密钥查看功能

## 支持服务

### OpenAI

环境变量：

- `OPENAI_API_KEY`
- `OPENAI_BASE_URL`，可选
- `OPENAI_MODEL`，可选

测试：

- 默认请求模型列表或一个最小响应
- 超时 15 秒
- 不保存返回内容

### DeepSeek

环境变量：

- `DEEPSEEK_API_KEY`
- `DEEPSEEK_BASE_URL`，可选
- `DEEPSEEK_MODEL`，可选

测试：

- 使用最小聊天请求
- `max_tokens` 限制在最低可用范围
- 超时 15 秒

### Google Custom Search

环境变量：

- `GOOGLE_SEARCH_API_KEY`
- `GOOGLE_SEARCH_CX`

测试：

- 固定查询 `SkillHuoke connection test`
- `num=1`
- 不保存搜索结果

### SerpAPI

环境变量：

- `SERPAPI_KEY`

测试：

- 固定查询词
- 最多请求一条结果

### Bing Search

环境变量：

- `BING_SEARCH_API_KEY`
- `BING_SEARCH_ENDPOINT`，可选

测试：

- 固定查询词
- `count=1`

### Resend

环境变量：

- `RESEND_API_KEY`
- `RESEND_FROM_EMAIL`
- `RESEND_FROM_NAME`，可选
- `RESEND_REPLY_TO`，可选

测试：

- 请求 Resend 域名或 API Key 状态
- 不发送测试邮件
- 同时检查发件邮箱是否填写

### Supabase

环境变量：

- `COZE_SUPABASE_URL`
- `COZE_SUPABASE_ANON_KEY`
- `COZE_SUPABASE_SERVICE_ROLE_KEY`，可选

测试：

- 请求 Supabase REST 健康端点或只读 schema
- 不新增、修改或删除数据库记录

## 状态数据

每个服务返回：

- `id`
- 中文名称
- 分类
- `configured`
- 缺失环境变量列表
- 已配置字段的掩码摘要
- 是否支持真实测试
- 当前模式
- 中文配置说明
- 官方申请链接

掩码规则：

- 密钥长度大于 4 时只显示 `••••` 加末尾 4 位
- URL、模型名、发件邮箱不作为密钥，可显示安全摘要
- API 响应、浏览器状态和日志中都不得出现完整密钥

## 测试结果

测试结果包含：

- 服务 ID
- 状态：成功、失败、未配置
- 中文消息
- 错误分类
- HTTP 状态码，可选
- 响应延迟毫秒
- 测试时间
- 建议动作

错误分类：

- `missing_config`
- `invalid_key`
- `permission_denied`
- `quota_exceeded`
- `rate_limited`
- `network_error`
- `proxy_error`
- `timeout`
- `service_error`
- `unknown`

## 错误映射

- HTTP 400：配置或请求参数错误
- HTTP 401：密钥无效
- HTTP 403：权限不足或服务未启用
- HTTP 402 或明确 billing 错误：额度不足
- HTTP 429：限流或额度问题，根据响应内容区分
- DNS、连接拒绝：网络失败
- 代理握手失败：代理错误
- AbortSignal 超时：请求超时
- HTTP 500-599：外部服务异常

页面展示中文解释和下一步动作，不直接展示外部服务的完整原始响应。

## 一键检测全部

- 用户点击后逐项执行
- 默认并发数 2
- 单项超时 15 秒
- 某项失败不阻塞其他项目
- 显示整体进度
- 可中途取消尚未开始的测试
- 结果按原服务顺序显示

## 代理诊断

页面显示：

- Windows 系统代理是否存在
- `HTTPS_PROXY` / `HTTP_PROXY` 是否存在
- `SKILLHUOKE_PROXY` 是否存在
- 当前测试优先使用的代理来源

只显示代理类型和主机摘要，不显示含用户名或密码的完整代理 URL。

测试服务使用现有后端网络能力。代理支持不能通过把密钥或代理凭据发送到前端实现。

## 本地状态

- 最近测试结果保存在浏览器 localStorage
- 存储键：`skillhuoke_integration_diagnostics_v034`
- 只保存状态、延迟、错误分类、消息和时间
- 不保存密钥、原始响应或代理凭据
- 诊断结果不进入 CRM 业务备份

## 页面设计

顶部：

- 已配置接口数
- 测试成功数
- 测试失败数
- 未配置数
- 一键检测按钮

服务卡片：

- 图标、名称和分类
- 已配置/未配置标记
- 环境变量及掩码摘要
- 最近测试结果和延迟
- 中文配置说明
- 官方申请入口
- 单独测试按钮

页面底部：

- 代理诊断
- `.env` 文件位置说明
- 修改 `.env` 后需要重启服务的中文提示
- 不在网页中粘贴密钥的安全说明

## 后端安全

- 状态接口只返回白名单字段
- 测试接口只接受预定义服务 ID
- 不接受前端传入 API Key、URL 或模型配置
- 使用服务端环境变量构造请求
- 所有测试为只读或最小消耗
- 日志不得输出请求 Authorization、完整 URL 查询密钥或原始敏感响应
- 请求超时后主动终止
- 防止任意 URL 请求和 SSRF

## `.env.example`

补齐：

```env
OPENAI_API_KEY=
OPENAI_BASE_URL=https://api.openai.com/v1
OPENAI_MODEL=

DEEPSEEK_API_KEY=
DEEPSEEK_BASE_URL=https://api.deepseek.com/v1
DEEPSEEK_MODEL=deepseek-chat

GOOGLE_SEARCH_API_KEY=
GOOGLE_SEARCH_CX=
SERPAPI_KEY=
BING_SEARCH_API_KEY=
BING_SEARCH_ENDPOINT=https://api.bing.microsoft.com/v7.0/search

RESEND_API_KEY=
RESEND_FROM_EMAIL=
RESEND_FROM_NAME=SkillHuoke Export
RESEND_REPLY_TO=

COZE_SUPABASE_URL=
COZE_SUPABASE_ANON_KEY=
COZE_SUPABASE_SERVICE_ROLE_KEY=

SKILLHUOKE_PROXY=
```

## 测试

- 完整密钥不会出现在状态接口响应
- 每个服务缺失字段判断正确
- 密钥末尾 4 位掩码正确
- 未知服务 ID 被拒绝
- HTTP 状态和网络错误映射正确
- 超时会终止请求
- Resend 测试不会发送邮件
- Supabase 测试不会写数据库
- 一键检测失败隔离和顺序显示正确
- localStorage 诊断结果不含密钥
- 页面桌面与移动端无溢出

## 验收标准

1. 页面不再允许输入或保存完整密钥。
2. 支持七类服务的配置状态检查。
3. 每个已配置服务可执行真实轻量连接测试。
4. 完整密钥不会出现在前端、响应或日志。
5. 错误能映射为中文分类和建议动作。
6. 支持单项和一键检测。
7. 显示安全的代理诊断。
8. `.env.example` 包含全部变量。
9. 测试、TypeScript、ESLint、正式构建和页面检查通过。
10. 生成 v0.34.0 开源 ZIP、查看入口和 GitHub 备注。

## 本版不包含

- 网页保存密钥
- 数据库密钥保险库
- 团队成员密钥权限
- 自动轮换密钥
- 计费额度统计
- 外部服务使用量账单
- 真实测试邮件发送
