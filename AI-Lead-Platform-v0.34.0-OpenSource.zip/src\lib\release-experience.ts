import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.34.0',
  title: '接口配置与连接诊断中心',
  date: '2026-06-30',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.34.0-OpenSource.zip',
  githubRemark: 'v0.34.0：新增接口配置与连接诊断中心，支持 OpenAI/DeepSeek/搜索/邮件/Supabase 只读配置检测与真实连通测试',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '把原来的 API 密钥输入页升级为只读诊断中心，前端不再保存完整密钥。',
  '新增 OpenAI、DeepSeek、Google Custom Search、SerpAPI、Bing Search、Resend 和 Supabase 配置检测。',
  '支持单项连接测试和一键检测全部，并给出中文错误分类、延迟和下一步处理建议。',
  '新增代理诊断和 .env 配置说明，帮助非程序员判断后端是否真正能联网访问接口。',
];

export const releaseReviewPages = [
  {
    title: '接口诊断中心',
    href: '/settings/api-keys',
    description: '查看每个接口是否已配置、缺少哪些变量、最近测试结果和代理状态。',
  },
  {
    title: '版本体验中心',
    href: '/release',
    description: '查看本次版本更新、上传包名称、GitHub 备注和重点检查页面。',
  },
  {
    title: '邮件中心',
    href: '/email-center',
    description: '验证 Resend 未配置时可继续保存本地草稿，配置后可走后端真实发送。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和数量，生成获客任务并进入任务执行台。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '管理任务沉淀的候选客户，并把适合开发的客户加入 CRM。',
  },
  {
    title: 'CRM 客户池',
    href: '/crm-customers',
    description: '查看客户阶段、评分、优先级、联系方式和下一步动作。',
  },
  {
    title: '数据备份',
    href: '/data-backup',
    description: '导出或恢复本地 CRM、报价、订单、单据、出货和邮件记录。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '点击“演示模式进入工作台”即可查看当前版本。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看 CRM 客户、跟进时间线和英文开发动作。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看批量获客任务、候选客户核验和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '进入接口诊断中心，确认页面不再出现完整密钥输入框或保存按钮。',
  '点击“刷新配置”，查看每个服务缺少哪些 .env 变量。',
  '对已配置的服务点击“测试连接”，确认能看到中文结果、延迟和建议动作。',
  '确认版本体验中心显示 v0.34.0、上传包名称和 GitHub 备注。',
];
