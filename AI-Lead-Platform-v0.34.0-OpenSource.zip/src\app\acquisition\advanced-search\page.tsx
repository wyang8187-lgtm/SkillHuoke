'use client';

import React, { useState, useEffect } from 'react';
import {
  Search, MapPin, Building2, User, Phone, Star, Plus, Loader2, Sparkles,
  CheckCircle2, Filter, ChevronDown, Tag, X, Users, Briefcase
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { getSupabaseBrowserClientAsync } from '@/lib/supabase-browser';

interface SearchResult {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  address: string;
  industry: string;
  companySize: string;
  customerType: string;
  matchScore: number;
  source: string;
  verified: boolean;
  tags: string[];
}

interface SearchParams {
  industry: string;
  region: string;
  city: string;
  district: string;
  companySize: string;
  customerType: string;
  keywords: string;
}

interface FilterOptions {
  industries: string[];
  regions: Record<string, any>;
  companySizes: string[];
  customerTypes: string[];
}

interface ToastState {
  show: boolean;
  message: string;
  type: 'success' | 'error' | 'info';
}

export default function AdvancedSearchPage() {
  const [searchParams, setSearchParams] = useState<SearchParams>({
    industry: '',
    region: '',
    city: '',
    district: '',
    companySize: '',
    customerType: '',
    keywords: ''
  });
  
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    industries: [],
    regions: {},
    companySizes: [],
    customerTypes: []
  });
  
  const [availableCities, setAvailableCities] = useState<string[]>([]);
  const [availableDistricts, setAvailableDistricts] = useState<string[]>([]);
  
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedResults, setSelectedResults] = useState<string[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [toast, setToast] = useState<ToastState>({ show: false, message: '', type: 'info' });
  const [showFilters, setShowFilters] = useState(false);

  // 加载筛选选项
  useEffect(() => {
    fetchFilterOptions();
  }, []);

  // 当省份变化时更新城市列表
  useEffect(() => {
    if (searchParams.region && filterOptions.regions.domestic?.[searchParams.region]) {
      setAvailableCities(Object.keys(filterOptions.regions.domestic[searchParams.region]));
    } else {
      setAvailableCities([]);
    }
    setSearchParams(prev => ({ ...prev, city: '', district: '' }));
    setAvailableDistricts([]);
  }, [searchParams.region]);

  // 当城市变化时更新区/镇列表
  useEffect(() => {
    if (searchParams.city && filterOptions.regions.domestic?.[searchParams.region]?.[searchParams.city]) {
      setAvailableDistricts(filterOptions.regions.domestic[searchParams.region][searchParams.city]);
    } else {
      setAvailableDistricts([]);
    }
    setSearchParams(prev => ({ ...prev, district: '' }));
  }, [searchParams.city]);

  const fetchFilterOptions = async () => {
    try {
      const response = await fetch('/api/ai/advanced-search');
      const data = await response.json();
      if (data.success) {
        setFilterOptions(data.data);
      }
    } catch (error) {
      console.error('加载筛选选项失败:', error);
    }
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'info' }), 3000);
  };

  const handleSearch = async () => {
    // 验证至少有一个搜索条件
    const hasCondition = searchParams.industry || searchParams.region || 
                         searchParams.companySize || searchParams.customerType ||
                         searchParams.keywords;
    
    if (!hasCondition) {
      showToast('请至少提供一个搜索条件', 'error');
      return;
    }

    setIsSearching(true);
    setResults([]);
    setSelectedResults([]);
    setStats(null);

    try {
      const response = await fetch('/api/ai/advanced-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          industry: searchParams.industry,
          region: searchParams.region,
          city: searchParams.city,
          district: searchParams.district,
          companySize: searchParams.companySize,
          customerType: searchParams.customerType,
          keywords: searchParams.keywords ? [searchParams.keywords] : []
        })
      });

      const data = await response.json();

      if (data.success && data.results) {
        setResults(data.results);
        setStats(data.stats);
        showToast(`找到 ${data.results.length} 个匹配结果`, 'success');
      } else {
        showToast(data.error || '搜索失败', 'error');
      }
    } catch (error) {
      console.error('搜索错误:', error);
      showToast('搜索服务暂时不可用', 'error');
    } finally {
      setIsSearching(false);
    }
  };

  const getAuthInfo = async () => {
    const supabase = await getSupabaseBrowserClientAsync();
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      showToast('请先登录', 'error');
      return null;
    }

    const { data: { session } } = await supabase.auth.getSession();
    return { user, token: session?.access_token || '' };
  };

  const handleAddToLeads = async (result: SearchResult) => {
    const auth = await getAuthInfo();
    if (!auth) return;

    setActionInProgress(`lead_${result.id}`);

    try {
      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': auth.token
        },
        body: JSON.stringify({
          company_name: result.companyName,
          contact_name: result.contactName,
          phone: result.phone,
          address: result.address,
          customer_type: result.customerType,
          industry: result.industry,
          source: result.source,
          grade: 'C'
        })
      });

      const data = await response.json();

      if (data.success) {
        showToast('已添加到线索池', 'success');
      } else {
        showToast(data.error || '添加失败', 'error');
      }
    } catch (error) {
      console.error('添加线索失败:', error);
      showToast('添加失败', 'error');
    } finally {
      setActionInProgress(null);
    }
  };

  const handleAddToCustomers = async (result: SearchResult) => {
    const auth = await getAuthInfo();
    if (!auth) return;

    setActionInProgress(`customer_${result.id}`);

    try {
      const response = await fetch('/api/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': auth.token
        },
        body: JSON.stringify({
          company_name: result.companyName,
          contact_name: result.contactName,
          phone: result.phone,
          address: result.address,
          customer_type: result.customerType,
          industry: result.industry,
          grade: 'C'
        })
      });

      const data = await response.json();

      if (data.success) {
        showToast('已添加到客户列表', 'success');
      } else {
        showToast(data.error || '添加失败', 'error');
      }
    } catch (error) {
      console.error('添加客户失败:', error);
      showToast('添加失败', 'error');
    } finally {
      setActionInProgress(null);
    }
  };

  const handleBatchAddToLeads = async () => {
    if (selectedResults.length === 0) {
      showToast('请先选择要添加的结果', 'error');
      return;
    }

    const auth = await getAuthInfo();
    if (!auth) return;

    setActionInProgress('batch');

    const selectedData = results.filter(r => selectedResults.includes(r.id));
    let successCount = 0;

    for (const result of selectedData) {
      try {
        const response = await fetch('/api/leads', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-session': auth.token
          },
          body: JSON.stringify({
            company_name: result.companyName,
            contact_name: result.contactName,
            phone: result.phone,
            address: result.address,
            customer_type: result.customerType,
            industry: result.industry,
            source: result.source,
            grade: 'C'
          })
        });

        if (response.ok) successCount++;
      } catch (error) {
        console.error('批量添加失败:', error);
      }
    }

    showToast(`成功添加 ${successCount}/${selectedResults.length} 条线索`, successCount === selectedResults.length ? 'success' : 'info');
    setSelectedResults([]);
    setActionInProgress(null);
  };

  const [actionInProgress, setActionInProgress] = useState<string | null>(null);

  const toggleSelect = (id: string) => {
    setSelectedResults(prev => 
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedResults.length === results.length) {
      setSelectedResults([]);
    } else {
      setSelectedResults(results.map(r => r.id));
    }
  };

  const clearFilters = () => {
    setSearchParams({
      industry: '',
      region: '',
      city: '',
      district: '',
      companySize: '',
      customerType: '',
      keywords: ''
    });
  };

  const getTagColor = (tag: string) => {
    const colors: Record<string, string> = {
      '大客户': 'bg-red-500/20 text-red-400',
      '高匹配': 'bg-green-500/20 text-green-400',
      '全案设计师': 'bg-blue-500/20 text-blue-400',
      '建材外贸公司': 'bg-orange-500/20 text-orange-400'
    };
    return colors[tag] || 'bg-gray-500/20 text-gray-400';
  };

  return (
    <div className="p-6 space-y-6">
      {/* 标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)] flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-blue-500" />
            AI智能搜客增强
          </h1>
          <p className="text-[var(--text-secondary)] mt-1">
            支持按行业、地区、规模等条件组合搜索，精准定位潜在客户
          </p>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 px-4 py-2 bg-[var(--card-bg)] border border-[var(--border-color)] rounded-lg hover:bg-[var(--bg-hover)] transition-colors"
        >
          <Filter className="w-4 h-4" />
          高级筛选
          <ChevronDown className={cn("w-4 h-4 transition-transform", showFilters && "rotate-180")} />
        </button>
      </div>

      {/* 搜索区域 */}
      <div className="bg-[var(--card-bg)] rounded-lg border border-[var(--border-color)] p-4 space-y-4">
        {/* 关键词搜索 */}
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--text-muted)]" />
            <input
              type="text"
              placeholder="输入关键词（如：橱柜定制、外贸公司...）"
              value={searchParams.keywords}
              onChange={(e) => setSearchParams(prev => ({ ...prev, keywords: e.target.value }))}
              className="w-full pl-10 pr-4 py-3 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] placeholder-[var(--text-muted)] focus:outline-none focus:border-blue-500"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={isSearching}
            className="px-6 py-3 bg-blue-500 hover:bg-blue-600 disabled:bg-blue-500/50 text-white rounded-lg font-medium flex items-center gap-2 transition-colors"
          >
            {isSearching ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
            {isSearching ? '搜索中...' : '搜索'}
          </button>
        </div>

        {/* 高级筛选面板 */}
        {showFilters && (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-[var(--border-color)]">
            {/* 行业选择 */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1.5 block">行业</label>
              <select
                value={searchParams.industry}
                onChange={(e) => setSearchParams(prev => ({ ...prev, industry: e.target.value }))}
                className="w-full px-3 py-2 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-blue-500"
              >
                <option value="">全部行业</option>
                {filterOptions.industries.map(ind => (
                  <option key={ind} value={ind}>{ind}</option>
                ))}
              </select>
            </div>

            {/* 省份选择 */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1.5 block">省份</label>
              <select
                value={searchParams.region}
                onChange={(e) => setSearchParams(prev => ({ ...prev, region: e.target.value }))}
                className="w-full px-3 py-2 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-blue-500"
              >
                <option value="">全部省份</option>
                {Object.keys(filterOptions.regions.domestic || {}).map(prov => (
                  <option key={prov} value={prov}>{prov}</option>
                ))}
              </select>
            </div>

            {/* 城市选择 */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1.5 block">城市</label>
              <select
                value={searchParams.city}
                onChange={(e) => setSearchParams(prev => ({ ...prev, city: e.target.value }))}
                disabled={!availableCities.length}
                className="w-full px-3 py-2 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-blue-500 disabled:opacity-50"
              >
                <option value="">全部城市</option>
                {availableCities.map(city => (
                  <option key={city} value={city}>{city}</option>
                ))}
              </select>
            </div>

            {/* 区/镇选择 */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1.5 block">区/镇</label>
              <select
                value={searchParams.district}
                onChange={(e) => setSearchParams(prev => ({ ...prev, district: e.target.value }))}
                disabled={!availableDistricts.length}
                className="w-full px-3 py-2 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-blue-500 disabled:opacity-50"
              >
                <option value="">全部区/镇</option>
                {availableDistricts.map(dist => (
                  <option key={dist} value={dist}>{dist}</option>
                ))}
              </select>
            </div>

            {/* 公司规模 */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1.5 block">公司规模</label>
              <select
                value={searchParams.companySize}
                onChange={(e) => setSearchParams(prev => ({ ...prev, companySize: e.target.value }))}
                className="w-full px-3 py-2 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-blue-500"
              >
                <option value="">全部规模</option>
                {filterOptions.companySizes.map(size => (
                  <option key={size} value={size}>{size}</option>
                ))}
              </select>
            </div>

            {/* 客户类型 */}
            <div>
              <label className="text-sm text-[var(--text-secondary)] mb-1.5 block">客户类型</label>
              <select
                value={searchParams.customerType}
                onChange={(e) => setSearchParams(prev => ({ ...prev, customerType: e.target.value }))}
                className="w-full px-3 py-2 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-[var(--text-primary)] focus:outline-none focus:border-blue-500"
              >
                <option value="">全部类型</option>
                {filterOptions.customerTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* 清空筛选 */}
            <div className="flex items-end">
              <button
                onClick={clearFilters}
                className="px-4 py-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)] flex items-center gap-1"
              >
                <X className="w-4 h-4" />
                清空筛选
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 统计信息 */}
      {stats && (
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-[var(--card-bg)] rounded-lg border border-[var(--border-color)] p-4">
            <div className="text-sm text-[var(--text-secondary)]">搜索结果</div>
            <div className="text-2xl font-bold text-[var(--text-primary)]">{stats.total}</div>
          </div>
          <div className="bg-[var(--card-bg)] rounded-lg border border-[var(--border-color)] p-4">
            <div className="text-sm text-[var(--text-secondary)]">平均匹配度</div>
            <div className="text-2xl font-bold text-green-500">{stats.avgMatchScore}%</div>
          </div>
          <div className="bg-[var(--card-bg)] rounded-lg border border-[var(--border-color)] p-4">
            <div className="text-sm text-[var(--text-secondary)]">行业分布</div>
            <div className="text-lg font-bold text-[var(--text-primary)]">
              {Object.keys(stats.byIndustry).slice(0, 2).join('、')}
            </div>
          </div>
        </div>
      )}

      {/* 结果列表 */}
      {results.length > 0 && (
        <div className="space-y-4">
          {/* 批量操作栏 */}
          <div className="flex items-center justify-between bg-[var(--card-bg)] rounded-lg border border-[var(--border-color)] p-3">
            <div className="flex items-center gap-4">
              <button
                onClick={toggleSelectAll}
                className="flex items-center gap-2 text-[var(--text-secondary)] hover:text-[var(--text-primary)]"
              >
                <div className={cn(
                  "w-5 h-5 rounded border border-[var(--border-color)] flex items-center justify-center",
                  selectedResults.length === results.length && "bg-blue-500 border-blue-500"
                )}>
                  {selectedResults.length === results.length && <CheckCircle2 className="w-4 h-4 text-white" />}
                </div>
                {selectedResults.length === results.length ? '取消全选' : '全选'}
              </button>
              <span className="text-[var(--text-secondary)]">
                已选择 {selectedResults.length} 条
              </span>
            </div>
            
            {selectedResults.length > 0 && (
              <button
                onClick={handleBatchAddToLeads}
                disabled={actionInProgress === 'batch'}
                className="px-4 py-2 bg-blue-500 hover:bg-blue-600 disabled:bg-blue-500/50 text-white rounded-lg font-medium flex items-center gap-2"
              >
                {actionInProgress === 'batch' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                批量添加到线索池
              </button>
            )}
          </div>

          {/* 结果卡片 */}
          <div className="grid gap-3">
            {results.map((result) => (
              <div
                key={result.id}
                className="bg-[var(--card-bg)] rounded-lg border border-[var(--border-color)] p-4 hover:border-blue-500/50 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    {/* 选择框 */}
                    <button
                      onClick={() => toggleSelect(result.id)}
                      className="mt-1 w-5 h-5 rounded border border-[var(--border-color)] flex items-center justify-center hover:border-blue-500"
                    >
                      {selectedResults.includes(result.id) && <CheckCircle2 className="w-4 h-4 text-blue-500" />}
                    </button>
                    
                    {/* 内容 */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-[var(--text-muted)]" />
                        <span className="font-medium text-[var(--text-primary)]">{result.companyName}</span>
                        <div className="flex gap-1">
                          {result.tags.map(tag => (
                            <span key={tag} className={cn("px-2 py-0.5 rounded text-xs", getTagColor(tag))}>
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-[var(--text-secondary)]">
                        <span className="flex items-center gap-1">
                          <User className="w-3.5 h-3.5" />
                          {result.contactName}
                        </span>
                        <span className="flex items-center gap-1">
                          <Phone className="w-3.5 h-3.5" />
                          {result.phone}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5" />
                          {result.address}
                        </span>
                        <span className="flex items-center gap-1">
                          <Briefcase className="w-3.5 h-3.5" />
                          {result.companySize}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-xs">
                        <span className="flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 text-yellow-500" />
                          匹配度 {result.matchScore}%
                        </span>
                        <span className="text-[var(--text-muted)]">|</span>
                        <span className="text-[var(--text-muted)]">来源: {result.source}</span>
                        {result.verified && (
                          <span className="flex items-center gap-1 text-green-500">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            已验证
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {/* 操作按钮 */}
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleAddToLeads(result)}
                      disabled={actionInProgress === `lead_${result.id}`}
                      className="px-3 py-1.5 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-sm text-[var(--text-secondary)] hover:text-blue-500 hover:border-blue-500 flex items-center gap-1 disabled:opacity-50"
                    >
                      {actionInProgress === `lead_${result.id}` ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Plus className="w-3.5 h-3.5" />
                      )}
                      线索池
                    </button>
                    <button
                      onClick={() => handleAddToCustomers(result)}
                      disabled={actionInProgress === `customer_${result.id}`}
                      className="px-3 py-1.5 bg-[var(--bg-primary)] border border-[var(--border-color)] rounded-lg text-sm text-[var(--text-secondary)] hover:text-green-500 hover:border-green-500 flex items-center gap-1 disabled:opacity-50"
                    >
                      {actionInProgress === `customer_${result.id}` ? (
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      ) : (
                        <Plus className="w-3.5 h-3.5" />
                      )}
                      客户池
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 空状态 */}
      {!isSearching && results.length === 0 && (
        <div className="bg-[var(--card-bg)] rounded-lg border border-[var(--border-color)] p-8 text-center">
          <Search className="w-12 h-12 text-[var(--text-muted)] mx-auto mb-4" />
          <p className="text-[var(--text-secondary)]">输入搜索条件，开始智能搜客</p>
          <p className="text-sm text-[var(--text-muted)] mt-2">
            支持按行业关键词、地区、公司规模等条件组合搜索
          </p>
        </div>
      )}

      {/* Toast提示 */}
      {toast.show && (
        <div className={cn(
          "fixed bottom-4 right-4 px-4 py-2 rounded-lg shadow-lg z-50",
          toast.type === 'success' && "bg-green-500 text-white",
          toast.type === 'error' && "bg-red-500 text-white",
          toast.type === 'info' && "bg-blue-500 text-white"
        )}>
          {toast.message}
        </div>
      )}
    </div>
  );
}