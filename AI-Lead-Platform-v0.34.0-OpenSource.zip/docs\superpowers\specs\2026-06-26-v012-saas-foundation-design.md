# v0.12 SaaS Foundation Design

## Goal

V0.12 moves the product from a demo dashboard toward a SaaS platform by introducing visible workspace concepts, SaaS mode indicators, usage quotas, and workspace-aware API metadata.

## Scope

- Add a demo workspace model that represents one company tenant.
- Show the current workspace and mode in the global shell.
- Add SaaS setup cards on the settings page.
- Add workspace metadata to the dashboard API response.
- Keep demo mode and Supabase placeholders working.
- Avoid payment, real subscription billing, and database migrations in this version.

## Architecture

The release uses a lightweight `src/lib/workspace.ts` module as the single source for demo workspace metadata. UI surfaces read from it to display company, plan, quota, and mode information. API routes return a `workspaceId` and workspace summary so future database-backed routes can adopt the same contract.

## Success Criteria

- Dashboard shows the current company workspace and SaaS mode.
- Sidebar and topbar show workspace identity.
- Settings page contains company profile, plan, quota, API status, and data isolation cards.
- `package.json` and README report `v0.12.0`.
- TypeScript, lint, build, and browser smoke tests pass.
