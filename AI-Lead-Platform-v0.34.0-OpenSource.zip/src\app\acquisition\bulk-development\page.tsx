'use client';

import { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter
} from '@/components/ui/dialog';
import {
  Search,
  Mail,
  MessageSquare,
  Send,
  Users,
  FileText,
  CheckCircle2,
  XCircle,
  Loader2,
  Filter,
  Download,
  Eye,
  Copy,
  ChevronDown,
  ChevronUp,
  Sparkles
} from 'lucide-react';

interface LeadItem {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  industry: string;
  region: string;
  companySize: string;
  status: string;
  selected: boolean;
}

interface GeneratedLetter {
  customerId: string;
  companyName: string;
  contactName: string;
  emailContent: { subject: string; body: string };
  whatsappContent: string;
}

// 模拟线索数据
const MOCK_LEADS: LeadItem[] = [
  { id: '1', companyName: '深圳市某某家居有限公司', contactName: '张总', phone: '13912345678', industry: '全屋定制', region: '深圳', companySize: '中型', status: '未联系', selected: false },
  { id: '2', companyName: '广州某某建材贸易有限公司', contactName: '李经理', phone: '13823456789', industry: '建材外贸', region: '广州', companySize: '大型', status: '未联系', selected: false },
  { id: '3', companyName: '佛山某某家具出口公司', contactName: '王总监', phone: '13734567890', industry: '家具出口', region: '佛山', companySize: '中型', status: '未联系', selected: false },
  { id: '4', companyName: '东莞某某五金配件厂', contactName: '陈厂长', phone: '13645678901', industry: '五金配件', region: '东莞', companySize: '小型', status: '未联系', selected: false },
  { id: '5', companyName: '顺德某某橱柜定制厂', contactName: '刘经理', phone: '13556789012', industry: '橱柜衣柜', region: '佛山顺德', companySize: '中型', status: '未联系', selected: false },
  { id: '6', companyName: '中山某某照明科技公司', contactName: '赵总', phone: '13467890123', industry: '照明灯饰', region: '中山', companySize: '中型', status: '未联系', selected: false },
  { id: '7', companyName: '珠海某某陶瓷出口公司', contactName: '钱经理', phone: '13378901234', industry: '陶瓷卫浴', region: '珠海', companySize: '大型', status: '未联系', selected: false },
  { id: '8', companyName: '杭州某某跨境电商公司', contactName: '孙总监', phone: '13289012345', industry: '跨境电商', region: '杭州', companySize: '小型', status: '未联系', selected: false },
];

const INDUSTRY_OPTIONS = [
  '建材外贸', '家具出口', '全屋定制', '橱柜衣柜', '陶瓷卫浴', '五金配件',
  '照明灯饰', '地板门窗', '涂料化工', '机械装备', '纺织服装', '家电出口',
  '跨境电商', '进出口贸易', '国际物流'
];

const STYLE_OPTIONS = ['正式', '友好', '简洁', '详细'];

const COMPANY_SIZE_OPTIONS = ['小型', '中型', '大型'];

export default function BulkDevelopmentPage() {
  const [leads, setLeads] = useState<LeadItem[]>(MOCK_LEADS);
  const [selectedLeads, setSelectedLeads] = useState<LeadItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterIndustry, setFilterIndustry] = useState('');
  const [filterRegion, setFilterRegion] = useState('');
  const [filterSize, setFilterSize] = useState('');
  
  // 开发信设置
  const [letterStyle, setLetterStyle] = useState('正式');
  const [senderName, setSenderName] = useState('张经理');
  const [senderCompany, setSenderCompany] = useState('广东某某家居有限公司');
  const [senderPhone, setSenderPhone] = useState('13912345678');
  const [senderEmail, setSenderEmail] = useState('sales@example.com');
  
  // 生成的开发信
  const [generatedLetters, setGeneratedLetters] = useState<GeneratedLetter[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [sendingResults, setSendingResults] = useState<{ success: number; failed: number } | null>(null);
  
  // 对话框状态
  const [previewDialogOpen, setPreviewDialogOpen] = useState(false);
  const [previewLetter, setPreviewLetter] = useState<GeneratedLetter | null>(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [sendChannel, setSendChannel] = useState<'email' | 'whatsapp'>('email');
  
  // 过滤线索
  const filteredLeads = leads.filter(lead => {
    if (searchTerm && !lead.companyName.includes(searchTerm) && !lead.contactName.includes(searchTerm)) return false;
    if (filterIndustry && lead.industry !== filterIndustry) return false;
    if (filterRegion && !lead.region.includes(filterRegion)) return false;
    if (filterSize && lead.companySize !== filterSize) return false;
    return true;
  });
  
  // 选择处理
  const handleSelectAll = () => {
    if (selectedLeads.length === filteredLeads.length) {
      setSelectedLeads([]);
      setLeads(leads.map(l => ({ ...l, selected: false })));
    } else {
      setSelectedLeads(filteredLeads);
      setLeads(leads.map(l => ({ 
        ...l, 
        selected: filteredLeads.some(f => f.id === l.id)
      })));
    }
  };
  
  const handleSelectOne = (lead: LeadItem) => {
    if (selectedLeads.some(s => s.id === lead.id)) {
      setSelectedLeads(selectedLeads.filter(s => s.id !== lead.id));
      setLeads(leads.map(l => l.id === lead.id ? { ...l, selected: false } : l));
    } else {
      setSelectedLeads([...selectedLeads, lead]);
      setLeads(leads.map(l => l.id === lead.id ? { ...l, selected: true } : l));
    }
  };
  
  // 生成开发信
  const handleGenerateLetters = async () => {
    if (selectedLeads.length === 0) return;
    
    setIsGenerating(true);
    setGeneratedLetters([]);
    
    try {
      // 调用批量生成API
      const response = await fetch('/api/ai/bulk-development-letter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          leads: selectedLeads.map(lead => ({
            customerId: lead.id,
            companyName: lead.companyName,
            contactName: lead.contactName,
            industry: lead.industry,
            region: lead.region,
            companySize: lead.companySize
          })),
          style: letterStyle,
          senderName,
          senderCompany,
          senderPhone,
          senderEmail
        })
      });
      
      const result = await response.json();
      
      if (result.success) {
        setGeneratedLetters(result.data.letters);
      } else {
        // 使用本地生成
        const letters: GeneratedLetter[] = selectedLeads.map(lead => ({
          customerId: lead.id,
          companyName: lead.companyName,
          contactName: lead.contactName,
          emailContent: {
            subject: `业务合作邀约 - ${lead.industry}`,
            body: `尊敬的${lead.contactName}您好，

我是${senderCompany}的${senderName}，专注家居建材领域。

注意到贵司在${lead.industry}领域有良好声誉，我们的产品品质稳定、价格合理，期待与贵司建立合作关系。

欢迎随时联系沟通，期待您的回复。

祝商祺！
${senderName}
联系电话：${senderPhone}
电子邮箱：${senderEmail}`
          },
          whatsappContent: `您好！我是${senderCompany}的${senderName}。

我们专注${lead.industry}领域，产品品质稳定、价格合理。

期待与贵司建立合作关系，欢迎随时联系：${senderPhone}`
        }));
        setGeneratedLetters(letters);
      }
    } catch {
      // 本地生成fallback
      const letters: GeneratedLetter[] = selectedLeads.map(lead => ({
        customerId: lead.id,
        companyName: lead.companyName,
        contactName: lead.contactName,
        emailContent: {
          subject: `业务合作邀约 - ${lead.industry}`,
          body: `尊敬的${lead.contactName}您好，

我是${senderCompany}的${senderName}，专注家居建材领域。

注意到贵司在${lead.industry}领域有良好声誉，我们的产品品质稳定、价格合理，期待与贵司建立合作关系。

欢迎随时联系沟通，期待您的回复。

祝商祺！
${senderName}
联系电话：${senderPhone}`
        },
        whatsappContent: `您好！我是${senderCompany}的${senderName}。期待与贵司合作，联系电话：${senderPhone}`
      }));
      setGeneratedLetters(letters);
    }
    
    setIsGenerating(false);
  };
  
  // 预览开发信
  const handlePreviewLetter = (letter: GeneratedLetter) => {
    setPreviewLetter(letter);
    setPreviewDialogOpen(true);
  };
  
  // 复制内容
  const handleCopyContent = (content: string) => {
    navigator.clipboard.writeText(content);
  };
  
  // 确认发送
  const handleConfirmSend = (channel: 'email' | 'whatsapp') => {
    setSendChannel(channel);
    setConfirmDialogOpen(true);
  };
  
  // 执行发送
  const handleExecuteSend = async () => {
    setIsSending(true);
    setConfirmDialogOpen(false);
    
    try {
      // 模拟发送
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // 更新线索状态
      setLeads(leads.map(l => {
        if (selectedLeads.some(s => s.id === l.id)) {
          return { ...l, status: '已联系' };
        }
        return l;
      }));
      
      setSendingResults({ success: selectedLeads.length, failed: 0 });
      
      // 3秒后清除结果
      setTimeout(() => {
        setSendingResults(null);
        setSelectedLeads([]);
        setGeneratedLetters([]);
        setLeads(leads.map(l => ({ ...l, selected: false })));
      }, 3000);
    } catch {
      setSendingResults({ success: 0, failed: selectedLeads.length });
    }
    
    setIsSending(false);
  };
  
  return (
    <MainLayout breadcrumbs={[
      { label: 'AI获客', href: '/acquisition' },
      { label: '批量开发' }
    ]}>
      <div className="space-y-6">
        {/* 页面标题 */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-[var(--foreground)]">批量客户开发</h1>
            <p className="text-[var(--muted-foreground)] mt-1">批量生成个性化开发信，一键发送邮件或WhatsApp消息</p>
          </div>
          <Badge variant="outline" className="text-[var(--muted-foreground)]">
            共 {leads.length} 条线索
          </Badge>
        </div>
        
        {/* 发送结果提示 */}
        {sendingResults && (
          <Card className={`${sendingResults.success > 0 ? 'border-[var(--success)]' : 'border-[var(--error)]'}`}>
            <CardContent className="flex items-center gap-4 py-4">
              {sendingResults.success > 0 ? (
                <CheckCircle2 className="w-5 h-5 text-[var(--success)]" />
              ) : (
                <XCircle className="w-5 h-5 text-[var(--error)]" />
              )}
              <span>
                发送完成：成功 {sendingResults.success} 条，失败 {sendingResults.failed} 条
              </span>
            </CardContent>
          </Card>
        )}
        
        <Tabs defaultValue="select" className="space-y-4">
          <TabsList>
            <TabsTrigger value="select">选择线索</TabsTrigger>
            <TabsTrigger value="settings">发送设置</TabsTrigger>
            <TabsTrigger value="preview">预览开发信 ({generatedLetters.length})</TabsTrigger>
          </TabsList>
          
          {/* 选择线索 */}
          <TabsContent value="select" className="space-y-4">
            {/* 搜索和筛选 */}
            <Card>
              <CardContent className="py-4">
                <div className="flex flex-wrap gap-4">
                  <div className="flex-1 min-w-[200px]">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--muted-foreground)]" />
                      <Input
                        placeholder="搜索公司名或联系人..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                  <Select value={filterIndustry} onValueChange={setFilterIndustry}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="行业筛选" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">全部行业</SelectItem>
                      {INDUSTRY_OPTIONS.map(opt => (
                        <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    placeholder="地区筛选"
                    value={filterRegion}
                    onChange={(e) => setFilterRegion(e.target.value)}
                    className="w-[120px]"
                  />
                  <Select value={filterSize} onValueChange={setFilterSize}>
                    <SelectTrigger className="w-[100px]">
                      <SelectValue placeholder="规模" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">全部</SelectItem>
                      {COMPANY_SIZE_OPTIONS.map(opt => (
                        <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>
            
            {/* 线索列表 */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between py-4">
                <div className="flex items-center gap-4">
                  <Checkbox
                    checked={selectedLeads.length === filteredLeads.length && filteredLeads.length > 0}
                    onCheckedChange={handleSelectAll}
                  />
                  <span className="text-sm font-medium">
                    已选择 {selectedLeads.length} / {filteredLeads.length} 条
                  </span>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleGenerateLetters}
                  disabled={selectedLeads.length === 0 || isGenerating}
                >
                  {isGenerating ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4 mr-2" />
                  )}
                  生成开发信
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {filteredLeads.map(lead => (
                    <div
                      key={lead.id}
                      className={`flex items-center gap-4 p-3 rounded-lg border ${
                        lead.selected ? 'bg-[var(--primary)]/10 border-[var(--primary)]' : 'bg-[var(--card)] border-[var(--border)]'
                      } hover:bg-[var(--accent)] transition-colors`}
                    >
                      <Checkbox
                        checked={lead.selected}
                        onCheckedChange={() => handleSelectOne(lead)}
                      />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium truncate">{lead.companyName}</span>
                          <Badge variant="outline" className="text-xs">{lead.industry}</Badge>
                          <Badge variant="outline" className="text-xs">{lead.region}</Badge>
                        </div>
                        <div className="flex items-center gap-4 mt-1 text-sm text-[var(--muted-foreground)]">
                          <span>{lead.contactName}</span>
                          <span>{lead.phone}</span>
                          <span>{lead.companySize}</span>
                        </div>
                      </div>
                      <Badge className={
                        lead.status === '未联系' ? 'bg-[var(--muted)]' :
                        lead.status === '已联系' ? 'bg-[var(--warning)]' :
                        lead.status === '有意向' ? 'bg-[var(--info)]' :
                        lead.status === '已成交' ? 'bg-[var(--success)]' :
                        'bg-[var(--error)]'
                      }>
                        {lead.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* 发送设置 */}
          <TabsContent value="settings" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">发件人信息</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">您的姓名</label>
                    <Input value={senderName} onChange={(e) => setSenderName(e.target.value)} />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">所属公司</label>
                    <Input value={senderCompany} onChange={(e) => setSenderCompany(e.target.value)} />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">联系电话</label>
                    <Input value={senderPhone} onChange={(e) => setSenderPhone(e.target.value)} />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">电子邮箱</label>
                    <Input value={senderEmail} onChange={(e) => setSenderEmail(e.target.value)} />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">开发信风格</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-4 gap-4">
                  {STYLE_OPTIONS.map(style => (
                    <Button
                      key={style}
                      variant={letterStyle === style ? 'default' : 'outline'}
                      onClick={() => setLetterStyle(style)}
                      className="h-auto py-3"
                    >
                      {style}
                    </Button>
                  ))}
                </div>
                <div className="mt-4 p-4 rounded-lg bg-[var(--muted)]">
                  <p className="text-sm text-[var(--muted-foreground)]">
                    {letterStyle === '正式' && '适合初次商务接触，语言规范、格式完整'}
                    {letterStyle === '友好' && '适合已有一定接触的客户，语言亲切自然'}
                    {letterStyle === '简洁' && '适合WhatsApp等即时通讯场景，简短直接'}
                    {letterStyle === '详细' && '适合重要客户，内容丰富、优势展示全面'}
                  </p>
                </div>
              </CardContent>
            </Card>
            
            {generatedLetters.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">发送确认</CardTitle>
                </CardHeader>
                <CardContent className="flex gap-4">
                  <Button
                    className="flex-1"
                    onClick={() => handleConfirmSend('email')}
                    disabled={isSending}
                  >
                    {isSending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <Mail className="w-4 h-4 mr-2" />
                    )}
                    批量发送邮件 ({generatedLetters.length})
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => handleConfirmSend('whatsapp')}
                    disabled={isSending}
                  >
                    {isSending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <MessageSquare className="w-4 h-4 mr-2" />
                    )}
                    批量发送WhatsApp ({generatedLetters.length})
                  </Button>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          {/* 预览开发信 */}
          <TabsContent value="preview" className="space-y-4">
            {generatedLetters.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <FileText className="w-12 h-12 mx-auto text-[var(--muted-foreground)] mb-4" />
                  <p className="text-[var(--muted-foreground)]">请在"选择线索"页面选择客户后生成开发信</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {generatedLetters.map(letter => (
                  <Card key={letter.customerId}>
                    <CardHeader className="py-3 flex flex-row items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{letter.companyName}</span>
                        <Badge variant="outline">{letter.contactName}</Badge>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleCopyContent(letter.emailContent.body)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handlePreviewLetter(letter)}
                        >
                          <Eye className="w-4 h-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="py-2">
                      <div className="text-sm text-[var(--muted-foreground)]">
                        <p className="font-medium text-[var(--foreground)]">主题：{letter.emailContent.subject}</p>
                        <p className="mt-1 line-clamp-2">{letter.emailContent.body.slice(0, 100)}...</p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {/* 预览对话框 */}
        <Dialog open={previewDialogOpen} onOpenChange={setPreviewDialogOpen}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>开发信预览</DialogTitle>
              <DialogDescription>
                {previewLetter?.companyName} - {previewLetter?.contactName}
              </DialogDescription>
            </DialogHeader>
            {previewLetter && (
              <div className="space-y-4">
                <Tabs defaultValue="email">
                  <TabsList>
                    <TabsTrigger value="email">邮件版本</TabsTrigger>
                    <TabsTrigger value="whatsapp">WhatsApp版本</TabsTrigger>
                  </TabsList>
                  <TabsContent value="email">
                    <div className="p-4 rounded-lg bg-[var(--muted)] space-y-2">
                      <p className="font-medium">主题：{previewLetter.emailContent.subject}</p>
                      <hr className="border-[var(--border)]" />
                      <pre className="whitespace-pre-wrap text-sm">{previewLetter.emailContent.body}</pre>
                    </div>
                    <Button
                      variant="outline"
                      className="mt-2"
                      onClick={() => handleCopyContent(previewLetter.emailContent.body)}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      复制邮件内容
                    </Button>
                  </TabsContent>
                  <TabsContent value="whatsapp">
                    <div className="p-4 rounded-lg bg-[var(--muted)]">
                      <pre className="whitespace-pre-wrap text-sm">{previewLetter.whatsappContent}</pre>
                    </div>
                    <Button
                      variant="outline"
                      className="mt-2"
                      onClick={() => handleCopyContent(previewLetter.whatsappContent)}
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      复制WhatsApp内容
                    </Button>
                  </TabsContent>
                </Tabs>
              </div>
            )}
          </DialogContent>
        </Dialog>
        
        {/* 确认发送对话框 */}
        <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>确认批量发送</DialogTitle>
              <DialogDescription>
                将向 {selectedLeads.length} 位客户发送{sendChannel === 'email' ? '邮件' : 'WhatsApp消息'}
              </DialogDescription>
            </DialogHeader>
            <div className="py-4">
              <p className="text-sm text-[var(--muted-foreground)]">
                发送后，这些线索的状态将自动更新为"已联系"。请确认信息无误后再发送。
              </p>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setConfirmDialogOpen(false)}>
                取消
              </Button>
              <Button onClick={handleExecuteSend}>
                <Send className="w-4 h-4 mr-2" />
                确认发送
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </MainLayout>
  );
}