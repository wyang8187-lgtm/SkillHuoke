import Link from 'next/link';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  currentRelease,
  demoRoleAccounts,
  releaseChecklist,
  releaseHighlights,
  releaseReviewPages,
} from '@/lib/release-experience';
import { ArrowRight, CheckCircle2, ExternalLink, KeyRound, PackageCheck, Rocket, UserRoundCheck } from 'lucide-react';

export default function ReleasePage() {
  return (
    <MainLayout title="版本体验">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{currentRelease.version}</Badge>
            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">{currentRelease.date}</Badge>
            <Badge className="border-slate-500/25 bg-slate-500/15 text-slate-300">{currentRelease.workspaceName}</Badge>
          </div>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">{currentRelease.title}</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                这里集中展示本次版本新增能力、登录方式、重点页面、上传包名称和 GitHub 备注。
              </p>
            </div>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/login">打开登录页<ArrowRight className="ml-2 h-4 w-4" /></Link>
            </Button>
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-[1fr_360px]">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <Rocket className="h-5 w-5 text-blue-300" />本版新增能力
              </CardTitle>
            </CardHeader>
            <CardContent className="grid gap-3 md:grid-cols-2">
              {releaseHighlights.map((item) => (
                <div key={item} className="flex gap-3 rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                  <CheckCircle2 className="mt-0.5 h-5 w-5 shrink-0 text-emerald-300" />
                  <p className="text-sm leading-6 text-[#cbd5e1]">{item}</p>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <KeyRound className="h-5 w-5 text-amber-300" />登录方式
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                <p className="text-[#94a3b8]">本地地址</p>
                <p className="mt-1 font-medium text-[#f8fafc]">{currentRelease.localUrl}</p>
              </div>
              <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                <p className="text-[#94a3b8]">登录入口</p>
                <p className="mt-1 font-medium text-[#f8fafc]">{currentRelease.loginUrl}</p>
              </div>
              <div className="rounded-lg border border-amber-500/25 bg-amber-500/10 p-3 text-amber-200">
                点击“演示模式进入工作台”即可查看。演示账号只用于说明角色，不做真实密码校验。
              </div>
            </CardContent>
          </Card>
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
              <ExternalLink className="h-5 w-5 text-blue-300" />本次重点查看页面
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {releaseReviewPages.map((page) => (
              <Link key={page.href} href={page.href} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4 transition hover:border-blue-500/50">
                <div className="flex items-center justify-between">
                  <h3 className="font-medium text-[#f8fafc]">{page.title}</h3>
                  <ArrowRight className="h-4 w-4 text-[#64748b]" />
                </div>
                <p className="mt-2 text-sm leading-6 text-[#94a3b8]">{page.description}</p>
                <p className="mt-3 break-all text-xs text-blue-300">{currentRelease.localUrl}{page.href}</p>
              </Link>
            ))}
          </CardContent>
        </Card>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
              <UserRoundCheck className="h-5 w-5 text-emerald-300" />演示身份说明
            </CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            {demoRoleAccounts.map((account) => (
              <div key={account.email} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{account.role}</Badge>
                <p className="mt-3 text-sm font-medium text-[#f8fafc]">{account.email}</p>
                <p className="mt-1 text-xs text-[#94a3b8]">密码：{account.password}</p>
                <p className="mt-3 text-sm leading-6 text-[#94a3b8]">{account.focus}</p>
              </div>
            ))}
          </CardContent>
        </Card>

        <section className="grid gap-4 lg:grid-cols-2">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <PackageCheck className="h-5 w-5 text-violet-300" />上传包与 GitHub 备注
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                <p className="text-[#94a3b8]">上传包名称</p>
                <p className="mt-1 font-medium text-[#f8fafc]">{currentRelease.packageName}</p>
              </div>
              <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                <p className="text-[#94a3b8]">GitHub 备注</p>
                <p className="mt-1 font-medium text-[#f8fafc]">{currentRelease.githubRemark}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader><CardTitle className="text-[#f8fafc]">检查顺序</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              {releaseChecklist.map((item, index) => (
                <div key={item} className="flex gap-3 rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                  <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-blue-500/15 text-xs font-semibold text-blue-300">{index + 1}</div>
                  <p className="text-sm leading-6 text-[#cbd5e1]">{item}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </section>
      </div>
    </MainLayout>
  );
}
