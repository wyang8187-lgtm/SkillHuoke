import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';
import { getCustomerById } from '@/lib/db-service';

// 获取客户的所有跟进记录（时间轴）
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // 获取当前用户（从session中）
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    // 解析session token获取用户信息
    const supabase = getSupabaseServiceRoleClient();
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    
    if (authError || !user) {
      return NextResponse.json({ error: '认证失败' }, { status: 401 });
    }

    // 验证客户存在且属于当前用户
    const customer = await getCustomerById(user.id, id);
    if (!customer) {
      return NextResponse.json({ error: '客户不存在' }, { status: 404 });
    }

    // 查询该客户的所有跟进记录
    const { data: followUps, error } = await supabase
      .from('follow_up_records')
      .select('*')
      .eq('customer_id', id)
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('查询跟进记录失败:', error);
      return NextResponse.json({ error: '查询跟进记录失败' }, { status: 500 });
    }

    return NextResponse.json({ 
      followUps: followUps || [],
      total: followUps?.length || 0
    });
  } catch (error) {
    console.error('获取客户跟进记录失败:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}