'use client';

import React, { useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Search,
  Target,
  Filter,
  Globe,
  MapPin,
  Building2,
  Phone,
  User,
  Plus,
  Sparkles,
  Zap,
  RefreshCw,
  Download,
  ChevronRight,
  CheckCircle,
  Clock,
  Instagram,
  Facebook,
  FileText,
} from 'lucide-react';
import { regions } from '@/lib/mock-data';
import type { Lead } from '@/types';

// 搜索结果卡片
function SearchResultCard({ result, onAdd }: { result: Lead; onAdd: () => void }) {
  return (
    <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548] hover:border-[#3b82f6] transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <Building2 className="h-4 w-4 text-[#3b82f6]" />
            <h3 className="text-[#f8fafc] font-medium">{result.companyName}</h3>
            <Badge className="status-badge-A">
              匹配度 {result.matchScore}%
            </Badge>
          </div>
          <div className="space-y-1 text-sm">
            <div className="flex items-center gap-2 text-[#94a3b8]">
              <User className="h-4 w-4" />
              <span>{result.contactName}</span>
              <Phone className="h-4 w-4 ml-4" />
              <span className="text-[#3b82f6]">{result.phone}</span>
              <CheckCircle className="h-3 w-3 text-[#22c55e]" />
            </div>
            <div className="flex items-center gap-2 text-[#94a3b8]">
              <MapPin className="h-4 w-4" />
              <span>{result.region}</span>
              {result.address && <span className="text-[#64748b]">| {result.address}</span>}
            </div>
            <div className="flex items-center gap-2 text-[#94a3b8]">
              <Target className="h-4 w-4" />
              <span>来源：{result.source}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" className="border-[#2d3548] text-[#94a3b8]">
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button 
            size="sm" 
            onClick={onAdd}
            className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white"
          >
            <Plus className="h-4 w-4" />
            添加
          </Button>
        </div>
      </div>
    </div>
  );
}

// 获客渠道卡片
function ChannelCard({ name, icon, count, color, description }: {
  name: string;
  icon: React.ReactNode;
  count: number;
  color: string;
  description: string;
}) {
  return (
    <Card className="stat-card hover:border-[#3b82f6] transition-colors cursor-pointer">
      <CardContent className="p-6">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-lg ${color}`}>
            {icon}
          </div>
          <div className="flex-1">
            <h3 className="text-[#f8fafc] font-medium">{name}</h3>
            <p className="text-sm text-[#94a3b8]">{description}</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-[#f8fafc]">{count}</p>
            <p className="text-xs text-[#64748b]">今日获取</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

// AI自动获客配置卡片
function AIConfigCard({ enabled, keywords, regions }: {
  enabled: boolean;
  keywords: string[];
  regions: string[];
}) {
  return (
    <Card className="stat-card">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-[#f8fafc] flex items-center gap-2">
            <Zap className="h-5 w-5 text-[#f97316]" />
            AI自动获客配置
          </CardTitle>
          <Badge className={enabled ? 'status-badge-A' : 'status-badge-C'}>
            {enabled ? '运行中' : '已暂停'}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm text-[#94a3b8] mb-2 block">搜索关键词</label>
          <div className="flex flex-wrap gap-2">
            {keywords.map(kw => (
              <Badge key={kw} className="bg-[#1a1f2c] text-[#f8fafc] border border-[#2d3548]">
                {kw}
              </Badge>
            ))}
          </div>
        </div>
        <div>
          <label className="text-sm text-[#94a3b8] mb-2 block">目标区域</label>
          <div className="flex flex-wrap gap-2">
            {regions.map(r => (
              <Badge key={r} className="bg-[#3b82f6]/20 text-[#3b82f6] border border-[#3b82f6]/30">
                {r}
              </Badge>
            ))}
          </div>
        </div>
        <div className="flex gap-2 pt-4">
          <Button className="flex-1 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
            {enabled ? '暂停运行' : '启动运行'}
          </Button>
          <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]">
            <RefreshCw className="h-4 w-4 mr-2" />
            更新配置
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// AI获客状态卡片
function AIStatusCard({ title, value, status }: {
  title: string;
  value: number;
  status: 'success' | 'running' | 'pending';
}) {
  const statusColors = {
    success: '#22c55e',
    running: '#f97316',
    pending: '#6b7280',
  };
  
  return (
    <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548]">
      <div className="flex items-center justify-between">
        <span className="text-[#94a3b8]">{title}</span>
        <span className="text-[#f8fafc] font-semibold">{value}</span>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <div 
          className="w-2 h-2 rounded-full"
          style={{ backgroundColor: statusColors[status] }}
        />
        <span 
          className="text-xs"
          style={{ color: statusColors[status] }}
        >
          {status === 'success' ? '已完成' : status === 'running' ? '进行中' : '等待中'}
        </span>
      </div>
    </div>
  );
}

export default function AcquisitionPage() {
  const [activeTab, setActiveTab] = useState<'search' | 'channels' | 'auto'>('search');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedRegion, setSelectedRegion] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [searchResults, setSearchResults] = useState<Lead[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // 模拟搜索
  const handleSearch = () => {
    setIsSearching(true);
    // 模拟搜索延迟
    setTimeout(() => {
      const mockResults: Lead[] = [
        {
          id: 's1',
          companyName: '深圳华彩设计工作室',
          contactName: '张华',
          phone: '138****1234',
          region: '深圳',
          source: '智能搜索',
          status: '新线索',
          matchScore: 95,
          createTime: new Date().toISOString(),
          address: '深圳市南山区科技园',
        },
        {
          id: 's2',
          companyName: '广州艺境装饰设计',
          contactName: '李艺',
          phone: '139****5678',
          region: '广州',
          source: '智能搜索',
          status: '新线索',
          matchScore: 88,
          createTime: new Date().toISOString(),
          address: '广州市天河区珠江新城',
        },
        {
          id: 's3',
          companyName: '佛山陶瓷出口贸易公司',
          contactName: '王贸',
          phone: '137****9012',
          region: '佛山',
          source: '智能搜索',
          status: '新线索',
          matchScore: 82,
          createTime: new Date().toISOString(),
          address: '佛山市禅城区建材市场',
        },
        {
          id: 's4',
          companyName: '东莞美家家居外贸',
          contactName: '陈美',
          phone: '136****3456',
          region: '东莞',
          source: '智能搜索',
          status: '新线索',
          matchScore: 75,
          createTime: new Date().toISOString(),
          address: '东莞市厚街镇',
        },
      ];
      setSearchResults(mockResults);
      setIsSearching(false);
    }, 1500);
  };

  // 添加到客户池
  const handleAddToPool = (result: Lead) => {
    // 模拟添加操作
    setSearchResults(prev => prev.filter(r => r.id !== result.id));
  };

  // 获客渠道数据
  const channels = [
    { name: 'Google搜索', icon: <Globe className="h-5 w-5 text-white" />, count: 23, color: 'bg-[#4285f4]', description: '海外客户精准获客' },
    { name: '百度搜索', icon: <Search className="h-5 w-5 text-white" />, count: 45, color: 'bg-[#f73028]', description: '国内客户搜索获客' },
    { name: '抖音', icon: <Target className="h-5 w-5 text-white" />, count: 18, color: 'bg-[#000000]', description: '短视频内容获客' },
    { name: '小红书', icon: <FileText className="h-5 w-5 text-white" />, count: 32, color: 'bg-[#ff2442]', description: '生活方式内容获客' },
    { name: 'Instagram', icon: <Instagram className="h-5 w-5 text-white" />, count: 15, color: 'bg-[#e1306c]', description: '海外视觉内容获客' },
    { name: 'Facebook', icon: <Facebook className="h-5 w-5 text-white" />, count: 12, color: 'bg-[#1877f2]', description: '海外社媒广告获客' },
    { name: '企查查', icon: <Building2 className="h-5 w-5 text-white" />, count: 28, color: 'bg-[#22c55e]', description: '企业数据精准获客' },
    { name: '天眼查', icon: <Target className="h-5 w-5 text-white" />, count: 35, color: 'bg-[#f97316]', description: '商业数据获客' },
    { name: '展会名录', icon: <FileText className="h-5 w-5 text-white" />, count: 56, color: 'bg-[#8b5cf6]', description: '行业展会数据获客' },
    { name: '设计师平台', icon: <User className="h-5 w-5 text-white" />, count: 42, color: 'bg-[#3b82f6]', description: '设计师社群获客' },
  ];

  return (
    <MainLayout title="AI获客中心">
      {/* 子标签页 */}
      <div className="flex gap-2 mb-6">
        <Button
          onClick={() => setActiveTab('search')}
          className={activeTab === 'search' 
            ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
            : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
          }
        >
          <Search className="h-4 w-4 mr-2" />
          智能搜索
        </Button>
        <Button
          onClick={() => setActiveTab('channels')}
          className={activeTab === 'channels' 
            ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
            : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
          }
        >
          <Target className="h-4 w-4 mr-2" />
          多渠道获客
        </Button>
        <Button
          onClick={() => setActiveTab('auto')}
          className={activeTab === 'auto' 
            ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
            : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
          }
        >
          <Zap className="h-4 w-4 mr-2" />
          AI自动获客
        </Button>
      </div>

      {/* 智能搜索 */}
      {activeTab === 'search' && (
        <div className="space-y-6">
          {/* 搜索区域 */}
          <Card className="stat-card">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                {/* 搜索框 */}
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#64748b]" />
                  <Input
                    placeholder="输入关键词搜索，如「深圳全案设计师」「佛山建材外贸」"
                    value={searchKeyword}
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    className="pl-12 h-12 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
                  />
                </div>
                
                {/* 篮选条件 */}
                <Select value={selectedRegion} onValueChange={setSelectedRegion}>
                  <SelectTrigger className="w-[180px] h-12 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                    <SelectValue placeholder="选择地区" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                    {regions.map(r => (
                      <SelectItem key={r} value={r} className="text-[#f8fafc]">{r}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                <Select value={selectedType} onValueChange={setSelectedType}>
                  <SelectTrigger className="w-[180px] h-12 bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                    <SelectValue placeholder="客户类型" />
                  </SelectTrigger>
                  <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                    <SelectItem value="全案设计师" className="text-[#f8fafc]">全案设计师</SelectItem>
                    <SelectItem value="建材外贸公司" className="text-[#f8fafc]">建材外贸公司</SelectItem>
                  </SelectContent>
                </Select>
                
                {/* 搜索按钮 */}
                <Button 
                  onClick={handleSearch}
                  disabled={isSearching || !searchKeyword}
                  className="h-12 px-8 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white"
                >
                  {isSearching ? (
                    <RefreshCw className="h-5 w-5 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="h-5 w-5 mr-2" />
                  )}
                  {isSearching ? '搜索中...' : 'AI智能搜索'}
                </Button>
              </div>
              
              {/* 搜索提示 */}
              <div className="mt-4 flex flex-wrap gap-2">
                <span className="text-sm text-[#64748b]">热门搜索：</span>
                {['深圳全案设计师', '佛山建材外贸', '广州装饰设计', '东莞家具出口'].map(kw => (
                  <Button 
                    key={kw}
                    size="sm"
                    variant="outline"
                    onClick={() => setSearchKeyword(kw)}
                    className="h-7 bg-[#0f1419] border-[#2d3548] text-[#94a3b8]"
                  >
                    {kw}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* 搜索结果 */}
          {searchResults.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-[#f8fafc] font-medium">
                  搜索结果（共 {searchResults.length} 条）
                </h3>
                <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]">
                  <Download className="h-4 w-4 mr-2" />
                  批量导出
                </Button>
              </div>
              {searchResults.map(result => (
                <SearchResultCard 
                  key={result.id} 
                  result={result}
                  onAdd={() => handleAddToPool(result)}
                />
              ))}
            </div>
          )}

          {/* 无结果提示 */}
          {!isSearching && searchResults.length === 0 && searchKeyword && (
            <div className="text-center py-12">
              <Search className="h-12 w-12 text-[#2d3548] mx-auto mb-4" />
              <p className="text-[#94a3b8]">点击搜索按钮开始搜索</p>
            </div>
          )}
        </div>
      )}

      {/* 多渠道获客 */}
      {activeTab === 'channels' && (
        <div className="space-y-6">
          {/* 渠道概览 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {channels.map(channel => (
              <ChannelCard key={channel.name} {...channel} />
            ))}
          </div>
          
          {/* 今日获取统计 */}
          <Card className="stat-card">
            <CardHeader className="pb-4">
              <CardTitle className="text-[#f8fafc] flex items-center gap-2">
                <Clock className="h-5 w-5 text-[#3b82f6]" />
                今日获客统计
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-4 gap-4">
                <div className="text-center p-4 bg-[#0f1419] rounded-lg">
                  <p className="text-2xl font-bold text-[#f8fafc]">307</p>
                  <p className="text-sm text-[#94a3b8]">总获取线索</p>
                </div>
                <div className="text-center p-4 bg-[#0f1419] rounded-lg">
                  <p className="text-2xl font-bold text-[#22c55e]">128</p>
                  <p className="text-sm text-[#94a3b8]">已验证联系方式</p>
                </div>
                <div className="text-center p-4 bg-[#0f1419] rounded-lg">
                  <p className="text-2xl font-bold text-[#3b82f6]">56</p>
                  <p className="text-sm text-[#94a3b8]">已入库线索</p>
                </div>
                <div className="text-center p-4 bg-[#0f1419] rounded-lg">
                  <p className="text-2xl font-bold text-[#f97316]">82%</p>
                  <p className="text-sm text-[#94a3b8]">平均匹配度</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* AI自动获客 */}
      {activeTab === 'auto' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* 配置卡片 */}
          <AIConfigCard 
            enabled={true}
            keywords={['全案设计师', '建材外贸', '全屋定制', '室内设计']}
            regions={['深圳', '广州', '佛山', '东莞']}
          />
          
          {/* 运行状态 */}
          <Card className="stat-card">
            <CardHeader className="pb-4">
              <CardTitle className="text-[#f8fafc] flex items-center gap-2">
                <Zap className="h-5 w-5 text-[#f97316]" />
                AI获客运行状态
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <AIStatusCard title="今日搜索次数" value={256} status="running" />
              <AIStatusCard title="已获取线索" value={48} status="success" />
              <AIStatusCard title="自动入库线索" value={32} status="success" />
              <AIStatusCard title="待处理线索" value={16} status="pending" />
              
              {/* 运行日志 */}
              <div className="mt-4 pt-4 border-t border-[#2d3548]">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="h-4 w-4 text-[#64748b]" />
                  <span className="text-sm text-[#94a3b8]">最近运行记录</span>
                </div>
                <div className="space-y-2 text-sm">
                  <div className="flex items-center gap-2 text-[#f8fafc]">
                    <div className="w-2 h-2 rounded-full bg-[#22c55e]" />
                    <span className="text-[#64748b]">10:32</span>
                    <span>发现新线索：深圳华彩设计工作室</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#f8fafc]">
                    <div className="w-2 h-2 rounded-full bg-[#22c55e]" />
                    <span className="text-[#64748b]">10:15</span>
                    <span>自动入库：佛山陶瓷出口贸易</span>
                  </div>
                  <div className="flex items-center gap-2 text-[#f8fafc]">
                    <div className="w-2 h-2 rounded-full bg-[#3b82f6]" />
                    <span className="text-[#64748b]">10:00</span>
                    <span>搜索关键词「全案设计师」深圳</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </MainLayout>
  );
}