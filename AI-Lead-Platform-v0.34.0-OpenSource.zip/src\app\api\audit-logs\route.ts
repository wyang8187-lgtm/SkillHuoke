import { NextRequest, NextResponse } from 'next/server';

// 审计日志API
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const operator = searchParams.get('operator');
  const operationType = searchParams.get('operationType');
  const startDate = searchParams.get('startDate');
  const endDate = searchParams.get('endDate');
  const page = parseInt(searchParams.get('page') || '1');
  const pageSize = parseInt(searchParams.get('pageSize') || '20');

  // 模拟审计日志数据
  const allLogs = [
    {
      id: 'LOG001',
      operator: '张三',
      operator_id: 'user_001',
      operation_type: '创建客户',
      target_type: 'customer',
      target_id: 'C001',
      target_name: '深圳市优筑设计中心',
      before_data: null,
      after_data: { name: '深圳市优筑设计中心', phone: '13983796058', grade: 'A' },
      created_at: '2025-02-18T10:30:00Z',
      ip_address: '192.168.1.100',
    },
    {
      id: 'LOG002',
      operator: '李四',
      operator_id: 'user_002',
      operation_type: '修改商机状态',
      target_type: 'opportunity',
      target_id: 'O001',
      target_name: '写字楼定制项目',
      before_data: { stage: '需求确认' },
      after_data: { stage: '报价', amount: 150000 },
      created_at: '2025-02-18T09:20:00Z',
      ip_address: '192.168.1.101',
    },
    {
      id: 'LOG003',
      operator: '张三',
      operator_id: 'user_001',
      operation_type: '公海池认领',
      target_type: 'customer',
      target_id: 'C015',
      target_name: '广州建材采购商',
      before_data: { assignee_id: null, pool_status: '在公海池' },
      after_data: { assignee_id: 'user_001', pool_status: '已认领' },
      created_at: '2025-02-17T16:45:00Z',
      ip_address: '192.168.1.100',
    },
    {
      id: 'LOG004',
      operator: '管理员',
      operator_id: 'admin',
      operation_type: '删除客户',
      target_type: 'customer',
      target_id: 'C020',
      target_name: '测试客户（无效）',
      before_data: { name: '测试客户（无效）', phone: '13800000000' },
      after_data: null,
      created_at: '2025-02-16T14:10:00Z',
      ip_address: '192.168.1.1',
    },
    {
      id: 'LOG005',
      operator: '王五',
      operator_id: 'user_003',
      operation_type: '导入客户',
      target_type: 'batch',
      target_id: 'batch_001',
      target_name: '批量导入客户',
      before_data: null,
      after_data: { total: 50, success: 45, failed: 5 },
      created_at: '2025-02-15T11:00:00Z',
      ip_address: '192.168.1.102',
    },
    {
      id: 'LOG006',
      operator: '张三',
      operator_id: 'user_001',
      operation_type: '创建跟进',
      target_type: 'follow_up',
      target_id: 'FU001',
      target_name: '电话跟进-优筑设计',
      before_data: null,
      after_data: { customer_id: 'C001', type: '电话', content: '沟通报价方案' },
      created_at: '2025-02-14T15:30:00Z',
      ip_address: '192.168.1.100',
    },
    {
      id: 'LOG007',
      operator: '李四',
      operator_id: 'user_002',
      operation_type: '客户退回公海池',
      target_type: 'customer',
      target_id: 'C008',
      target_name: '佛山家居公司',
      before_data: { assignee_id: 'user_002', pool_status: '正常' },
      after_data: { assignee_id: null, pool_status: '在公海池', reason: '30天未跟进' },
      created_at: '2025-02-13T09:00:00Z',
      ip_address: '192.168.1.101',
    },
    {
      id: 'LOG008',
      operator: '张三',
      operator_id: 'user_001',
      operation_type: '发送邮件',
      target_type: 'email',
      target_id: 'EM001',
      target_name: '产品介绍邮件',
      before_data: null,
      after_data: { to: 'C001', subject: '产品介绍', status: '已发送' },
      created_at: '2025-02-12T10:00:00Z',
      ip_address: '192.168.1.100',
    },
  ];

  // 筛选
  let filteredLogs = allLogs;
  
  if (operator) {
    filteredLogs = filteredLogs.filter(log => log.operator === operator);
  }
  
  if (operationType) {
    filteredLogs = filteredLogs.filter(log => log.operation_type === operationType);
  }
  
  if (startDate) {
    filteredLogs = filteredLogs.filter(log => 
      new Date(log.created_at) >= new Date(startDate)
    );
  }
  
  if (endDate) {
    filteredLogs = filteredLogs.filter(log => 
      new Date(log.created_at) <= new Date(endDate)
    );
  }

  // 分页
  const total = filteredLogs.length;
  const totalPages = Math.ceil(total / pageSize);
  const logs = filteredLogs.slice((page - 1) * pageSize, page * pageSize);

  // 操作类型统计
  const typeStats: Record<string, number> = {};
  allLogs.forEach(log => {
    typeStats[log.operation_type] = (typeStats[log.operation_type] || 0) + 1;
  });

  // 操作人统计
  const operatorStats: Record<string, number> = {};
  allLogs.forEach(log => {
    operatorStats[log.operator] = (operatorStats[log.operator] || 0) + 1;
  });

  return NextResponse.json({
    success: true,
    data: {
      logs,
      total,
      page,
      pageSize,
      totalPages,
      typeStats,
      operatorStats,
    },
  });
}