'use client';

import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Search, Check, X } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Option {
  value: string;
  label: string;
  disabled?: boolean;
}

interface SearchSelectProps {
  options: Option[];
  value?: string;
  onChange: (value: string) => void;
  placeholder?: string;
  searchable?: boolean;
  disabled?: boolean;
  className?: string;
  emptyText?: string;
}

export function SearchSelect({
  options,
  value,
  onChange,
  placeholder = '请选择',
  searchable = true,
  disabled = false,
  className,
  emptyText = '暂无选项',
}: SearchSelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const ref = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSearchTerm('');
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 打开时聚焦搜索框
  useEffect(() => {
    if (isOpen && searchable && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen, searchable]);

  // 过滤选项
  const filteredOptions = searchable
    ? options.filter((opt) =>
        opt.label.toLowerCase().includes(searchTerm.toLowerCase()) ||
        opt.value.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : options;

  // 当前选中项
  const selectedOption = options.find((opt) => opt.value === value);

  // 选择选项
  const handleSelect = (option: Option) => {
    if (option.disabled) return;
    onChange(option.value);
    setIsOpen(false);
    setSearchTerm('');
  };

  // 清除选择
  const handleClear = () => {
    onChange('');
  };

  return (
    <div ref={ref} className={cn('relative', className)}>
      {/* 选择框 */}
      <button
        type="button"
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className={cn(
          'w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg border bg-background',
          'transition-colors hover:bg-muted/50',
          disabled && 'opacity-50 cursor-not-allowed',
          isOpen ? 'border-primary ring-2 ring-primary/20' : 'border-border'
        )}
      >
        <span className={value ? 'text-foreground' : 'text-muted-foreground'}>
          {selectedOption?.label || placeholder}
        </span>
        <div className="flex items-center gap-1">
          {value && !disabled && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleClear();
              }}
              className="p-0.5 rounded-md hover:bg-muted text-muted-foreground hover:text-foreground"
            >
              <X className="h-3 w-3" />
            </button>
          )}
          <ChevronDown className={cn(
            'h-4 w-4 text-muted-foreground transition-transform',
            isOpen && 'rotate-180'
          )} />
        </div>
      </button>

      {/* 下拉面板 */}
      {isOpen && (
        <div className="absolute z-50 mt-1 w-full rounded-lg border border-border bg-popover shadow-lg">
          {/* 搜索框 */}
          {searchable && (
            <div className="p-2 border-b border-border">
              <div className="flex items-center gap-2 px-3 py-2 rounded-md bg-muted">
                <Search className="h-4 w-4 text-muted-foreground" />
                <input
                  ref={inputRef}
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="搜索..."
                  className="w-full bg-transparent text-foreground placeholder:text-muted-foreground focus:outline-none"
                />
              </div>
            </div>
          )}

          {/* 选项列表 */}
          <div className="max-h-[200px] overflow-y-auto p-1">
            {filteredOptions.length > 0 ? (
              filteredOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  disabled={option.disabled}
                  onClick={() => handleSelect(option)}
                  className={cn(
                    'w-full flex items-center justify-between gap-2 px-3 py-2 rounded-md',
                    'text-sm transition-colors',
                    option.disabled && 'opacity-50 cursor-not-allowed',
                    !option.disabled && 'hover:bg-muted',
                    option.value === value && 'bg-primary/10 text-primary'
                  )}
                >
                  <span>{option.label}</span>
                  {option.value === value && (
                    <Check className="h-4 w-4 text-primary" />
                  )}
                </button>
              ))
            ) : (
              <div className="px-3 py-4 text-center text-sm text-muted-foreground">
                {searchable && searchTerm ? `未找到 "${searchTerm}" 相关选项` : emptyText}
              </div>
            )}
          </div>

          {/* 选项统计 */}
          {searchable && (
            <div className="px-3 py-2 border-t border-border text-xs text-muted-foreground">
              共 {options.length} 个选项，显示 {filteredOptions.length} 个
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// 常用选项预设
export const presetOptions = {
  // 客户等级
  customerGrade: [
    { value: 'A', label: 'A类 - 高价值' },
    { value: 'B', label: 'B类 - 重点培育' },
    { value: 'C', label: 'C类 - 持续跟进' },
    { value: 'D', label: 'D类 - 暂缓' },
  ],
  
  // 客户类型
  customerType: [
    { value: '全案设计师', label: '全案设计师' },
    { value: '建材外贸公司', label: '建材外贸公司' },
  ],
  
  // 客户状态
  customerStatus: [
    { value: '初步接触', label: '初步接触' },
    { value: '需求确认', label: '需求确认' },
    { value: '方案报价', label: '方案报价' },
    { value: '谈判中', label: '谈判中' },
    { value: '已成交', label: '已成交' },
    { value: '已输单', label: '已输单' },
  ],
  
  // 商机阶段
  opportunityStage: [
    { value: '初步接触', label: '初步接触' },
    { value: '需求确认', label: '需求确认' },
    { value: '方案报价', label: '方案报价' },
    { value: '谈判', label: '谈判' },
    { value: '成交', label: '成交' },
    { value: '输单', label: '输单' },
  ],
  
  // 任务优先级
  taskPriority: [
    { value: '高', label: '高优先级' },
    { value: '中', label: '中优先级' },
    { value: '低', label: '低优先级' },
  ],
  
  // 任务状态
  taskStatus: [
    { value: '待完成', label: '待完成' },
    { value: '已完成', label: '已完成' },
    { value: '已取消', label: '已取消' },
  ],
  
  // 地区
  region: [
    { value: '深圳', label: '深圳' },
    { value: '广州', label: '广州' },
    { value: '佛山', label: '佛山' },
    { value: '东莞', label: '东莞' },
    { value: '惠州', label: '惠州' },
    { value: '珠海', label: '珠海' },
    { value: '中山', label: '中山' },
    { value: '其他', label: '其他地区' },
  ],
  
  // 负责人（动态生成）
  getAssigneeOptions: (members: { id: string; name: string }[]) =>
    members.map((m) => ({ value: m.id, label: m.name })),
};