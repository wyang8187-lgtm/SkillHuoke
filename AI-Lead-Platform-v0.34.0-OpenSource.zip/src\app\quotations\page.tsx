'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, Plus, FileText, Eye, Edit, Trash2, 
  Send, CheckCircle, XCircle, Copy, DollarSign
} from 'lucide-react';
import { useTheme } from '@/lib/theme-context';

interface QuotationItem {
  productId: string;
  productName: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  amount: number;
}

interface Quotation {
  id: string;
  customerId: string;
  customerName: string;
  items: QuotationItem[];
  totalAmount: number;
  status: string;
  createdAt: string;
  updatedAt: string;
  validUntil: string;
  notes: string;
}

export default function QuotationsPage() {
  const { theme } = useTheme();
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('全部');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [viewingQuotation, setViewingQuotation] = useState<Quotation | null>(null);
  const [editingQuotation, setEditingQuotation] = useState<Quotation | null>(null);
  
  const statuses = ['全部', '草稿', '已发送', '已确认', '已拒绝'];
  
  // 新建报价单表单数据
  const [formData, setFormData] = useState({
    customerId: '',
    customerName: '',
    items: [{ productId: '', productName: '', quantity: 1, unit: '平方米', unitPrice: 0 }],
    validUntil: '',
    notes: ''
  });

  useEffect(() => {
    fetchQuotations();
  }, [selectedStatus]);

  const fetchQuotations = async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      if (selectedStatus !== '全部') params.append('status', selectedStatus);
      
      const response = await fetch(`/api/quotations?${params}`);
      const data = await response.json();
      if (data.success) {
        setQuotations(data.data.quotations);
      }
    } catch (error) {
      console.error('获取报价单列表失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredQuotations = quotations.filter(q => 
    q.customerName.toLowerCase().includes(searchKeyword.toLowerCase()) ||
    q.id.toLowerCase().includes(searchKeyword.toLowerCase())
  );

  const handleCreateQuotation = async () => {
    try {
      const response = await fetch('/api/quotations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      const data = await response.json();
      if (data.success) {
        setShowCreateModal(false);
        resetForm();
        fetchQuotations();
      }
    } catch (error) {
      console.error('创建报价单失败:', error);
    }
  };

  const handleUpdateStatus = async (id: string, newStatus: string) => {
    try {
      const response = await fetch('/api/quotations', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, status: newStatus })
      });
      const data = await response.json();
      if (data.success) {
        fetchQuotations();
      }
    } catch (error) {
      console.error('更新状态失败:', error);
    }
  };

  const handleDeleteQuotation = async (id: string) => {
    if (!confirm('确定要删除此报价单吗？')) return;
    try {
      const response = await fetch(`/api/quotations?id=${id}`, { method: 'DELETE' });
      const data = await response.json();
      if (data.success) {
        fetchQuotations();
      }
    } catch (error) {
      console.error('删除报价单失败:', error);
    }
  };

  const addItem = () => {
    setFormData({
      ...formData,
      items: [...formData.items, { productId: '', productName: '', quantity: 1, unit: '平方米', unitPrice: 0 }]
    });
  };

  const removeItem = (index: number) => {
    setFormData({
      ...formData,
      items: formData.items.filter((_, i) => i !== index)
    });
  };

  const updateItem = (index: number, field: string, value: string | number) => {
    const newItems = [...formData.items];
    newItems[index] = { ...newItems[index], [field]: value };
    setFormData({ ...formData, items: newItems });
  };

  const resetForm = () => {
    setFormData({
      customerId: '',
      customerName: '',
      items: [{ productId: '', productName: '', quantity: 1, unit: '平方米', unitPrice: 0 }],
      validUntil: '',
      notes: ''
    });
  };

  const calculateTotal = () => {
    return formData.items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      '草稿': 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300',
      '已发送': 'bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-300',
      '已确认': 'bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300',
      '已拒绝': 'bg-red-100 text-red-700 dark:bg-red-900 dark:text-red-300',
    };
    return colors[status] || 'bg-gray-100 text-gray-700';
  };

  const cardBg = theme === 'dark' ? 'bg-[#16213e]' : 'bg-white';
  const borderColor = theme === 'dark' ? 'border-[#1a1a2e]' : 'border-gray-200';

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">报价单管理</h1>
          <p className="text-sm text-[var(--text-secondary)] mt-1">管理客户报价单</p>
        </div>
        <Button
          onClick={() => setShowCreateModal(true)}
          className="bg-gradient-to-r from-blue-500 to-blue-600 text-white"
        >
          <Plus className="h-4 w-4 mr-2" />
          新建报价单
        </Button>
      </div>

      {/* 搜索和筛选 */}
      <Card className={`${cardBg} ${borderColor}`}>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--text-secondary)]" />
                <Input
                  placeholder="搜索客户名称或报价单号..."
                  value={searchKeyword}
                  onChange={(e) => setSearchKeyword(e.target.value)}
                  className="pl-10 bg-[var(--input-bg)] border-[var(--border-color)]"
                />
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              {statuses.map(status => (
                <Button
                  key={status}
                  variant={selectedStatus === status ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedStatus(status)}
                  className={selectedStatus === status ? 'bg-blue-500' : ''}
                >
                  {status}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 报价单列表 */}
      {loading ? (
        <div className="text-center py-12 text-[var(--text-secondary)]">加载中...</div>
      ) : filteredQuotations.length === 0 ? (
        <Card className={`${cardBg} ${borderColor}`}>
          <CardContent className="p-12 text-center">
            <FileText className="h-12 w-12 mx-auto text-[var(--text-secondary)] mb-4" />
            <p className="text-[var(--text-secondary)]">暂无报价单数据</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredQuotations.map(quotation => (
            <Card key={quotation.id} className={`${cardBg} ${borderColor} hover:shadow-lg transition-shadow`}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="font-medium text-[var(--text-primary)]">{quotation.id}</span>
                      <Badge className={getStatusColor(quotation.status)}>
                        {quotation.status}
                      </Badge>
                    </div>
                    <p className="text-[var(--text-primary)] font-medium">{quotation.customerName}</p>
                    <div className="flex items-center gap-4 mt-2 text-sm text-[var(--text-secondary)]">
                      <span>创建日期: {quotation.createdAt}</span>
                      <span>有效期至: {quotation.validUntil}</span>
                      <span>产品数: {quotation.items.length}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center gap-2 mb-3">
                      <DollarSign className="h-5 w-5 text-green-500" />
                      <span className="text-xl font-bold text-green-500">
                        ¥{quotation.totalAmount.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={() => setViewingQuotation(quotation)}>
                        <Eye className="h-3 w-3 mr-1" />
                        查看
                      </Button>
                      {quotation.status === '草稿' && (
                        <Button variant="outline" size="sm" onClick={() => handleUpdateStatus(quotation.id, '已发送')}>
                          <Send className="h-3 w-3 mr-1" />
                          发送
                        </Button>
                      )}
                      {quotation.status === '已发送' && (
                        <>
                          <Button variant="outline" size="sm" className="text-green-500" onClick={() => handleUpdateStatus(quotation.id, '已确认')}>
                            <CheckCircle className="h-3 w-3 mr-1" />
                            确认
                          </Button>
                          <Button variant="outline" size="sm" className="text-red-500" onClick={() => handleUpdateStatus(quotation.id, '已拒绝')}>
                            <XCircle className="h-3 w-3 mr-1" />
                            拒绝
                          </Button>
                        </>
                      )}
                      <Button variant="outline" size="sm" onClick={() => handleDeleteQuotation(quotation.id)} className="text-red-500">
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* 新建报价单弹窗 */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className={`${cardBg} w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto`}>
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">新建报价单</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-[var(--text-secondary)] mb-1 block">客户ID</label>
                  <Input
                    value={formData.customerId}
                    onChange={(e) => setFormData({ ...formData, customerId: e.target.value })}
                    placeholder="C001"
                    className="bg-[var(--input-bg)] border-[var(--border-color)]"
                  />
                </div>
                <div>
                  <label className="text-sm text-[var(--text-secondary)] mb-1 block">客户名称 *</label>
                  <Input
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    placeholder="深圳市某某家居有限公司"
                    className="bg-[var(--input-bg)] border-[var(--border-color)]"
                  />
                </div>
              </div>
              
              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">有效期至</label>
                <Input
                  type="date"
                  value={formData.validUntil}
                  onChange={(e) => setFormData({ ...formData, validUntil: e.target.value })}
                  className="bg-[var(--input-bg)] border-[var(--border-color)]"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm text-[var(--text-secondary)]">产品明细</label>
                  <Button variant="outline" size="sm" onClick={addItem}>
                    <Plus className="h-3 w-3 mr-1" />
                    添加产品
                  </Button>
                </div>
                <div className="space-y-2">
                  {formData.items.map((item, index) => (
                    <div key={index} className="grid grid-cols-5 gap-2 items-center">
                      <Input
                        placeholder="产品名称"
                        value={item.productName}
                        onChange={(e) => updateItem(index, 'productName', e.target.value)}
                        className="bg-[var(--input-bg)] border-[var(--border-color)]"
                      />
                      <Input
                        type="number"
                        placeholder="数量"
                        value={item.quantity}
                        onChange={(e) => updateItem(index, 'quantity', parseInt(e.target.value) || 0)}
                        className="bg-[var(--input-bg)] border-[var(--border-color)]"
                      />
                      <select
                        value={item.unit}
                        onChange={(e) => updateItem(index, 'unit', e.target.value)}
                        className="h-10 px-3 rounded-md bg-[var(--input-bg)] border-[var(--border-color)] text-[var(--text-primary)]"
                      >
                        <option value="平方米">平方米</option>
                        <option value="个">个</option>
                        <option value="台">台</option>
                      </select>
                      <Input
                        type="number"
                        placeholder="单价"
                        value={item.unitPrice}
                        onChange={(e) => updateItem(index, 'unitPrice', parseFloat(e.target.value) || 0)}
                        className="bg-[var(--input-bg)] border-[var(--border-color)]"
                      />
                      <Button variant="outline" size="sm" onClick={() => removeItem(index)} className="text-red-500">
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t border-[var(--border-color)]">
                <span className="text-[var(--text-secondary)]">总金额:</span>
                <span className="text-xl font-bold text-green-500">¥{calculateTotal().toLocaleString()}</span>
              </div>

              <div>
                <label className="text-sm text-[var(--text-secondary)] mb-1 block">备注</label>
                <textarea
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="报价备注..."
                  className="w-full h-20 px-3 py-2 rounded-md bg-[var(--input-bg)] border-[var(--border-color)] text-[var(--text-primary)] resize-none"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => { setShowCreateModal(false); resetForm(); }} className="flex-1">
                  取消
                </Button>
                <Button onClick={handleCreateQuotation} className="flex-1 bg-blue-500">
                  创建报价单
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* 查看报价单弹窗 */}
      {viewingQuotation && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <Card className={`${cardBg} w-full max-w-2xl mx-4`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-[var(--text-primary)]">
                  报价单详情 - {viewingQuotation.id}
                </CardTitle>
                <Badge className={getStatusColor(viewingQuotation.status)}>
                  {viewingQuotation.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-[var(--text-secondary)]">客户名称:</span>
                  <span className="text-[var(--text-primary)] ml-2">{viewingQuotation.customerName}</span>
                </div>
                <div>
                  <span className="text-[var(--text-secondary)]">创建日期:</span>
                  <span className="text-[var(--text-primary)] ml-2">{viewingQuotation.createdAt}</span>
                </div>
                <div>
                  <span className="text-[var(--text-secondary)]">有效期至:</span>
                  <span className="text-[var(--text-primary)] ml-2">{viewingQuotation.validUntil}</span>
                </div>
                <div>
                  <span className="text-[var(--text-secondary)]">最后更新:</span>
                  <span className="text-[var(--text-primary)] ml-2">{viewingQuotation.updatedAt}</span>
                </div>
              </div>

              <div>
                <h4 className="font-medium text-[var(--text-primary)] mb-2">产品明细</h4>
                <div className="border border-[var(--border-color)] rounded-md overflow-hidden">
                  <table className="w-full text-sm">
                    <thead className="bg-[var(--table-header-bg)]">
                      <tr>
                        <th className="px-3 py-2 text-left text-[var(--text-secondary)]">产品名称</th>
                        <th className="px-3 py-2 text-center text-[var(--text-secondary)]">数量</th>
                        <th className="px-3 py-2 text-center text-[var(--text-secondary)]">单位</th>
                        <th className="px-3 py-2 text-right text-[var(--text-secondary)]">单价</th>
                        <th className="px-3 py-2 text-right text-[var(--text-secondary)]">金额</th>
                      </tr>
                    </thead>
                    <tbody>
                      {viewingQuotation.items.map((item, index) => (
                        <tr key={index} className="border-t border-[var(--border-color)]">
                          <td className="px-3 py-2 text-[var(--text-primary)]">{item.productName}</td>
                          <td className="px-3 py-2 text-center text-[var(--text-primary)]">{item.quantity}</td>
                          <td className="px-3 py-2 text-center text-[var(--text-primary)]">{item.unit}</td>
                          <td className="px-3 py-2 text-right text-[var(--text-primary)]">¥{item.unitPrice}</td>
                          <td className="px-3 py-2 text-right text-[var(--text-primary)]">¥{item.amount.toLocaleString()}</td>
                        </tr>
                      ))}
                      <tr className="border-t border-[var(--border-color)] bg-[var(--table-header-bg)]">
                        <td colSpan={4} className="px-3 py-2 text-right font-medium text-[var(--text-primary)]">总计:</td>
                        <td className="px-3 py-2 text-right font-bold text-green-500">¥{viewingQuotation.totalAmount.toLocaleString()}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {viewingQuotation.notes && (
                <div>
                  <h4 className="font-medium text-[var(--text-primary)] mb-1">备注</h4>
                  <p className="text-sm text-[var(--text-secondary)] bg-[var(--input-bg)] p-2 rounded-md">
                    {viewingQuotation.notes}
                  </p>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => setViewingQuotation(null)} className="flex-1">
                  关闭
                </Button>
                {viewingQuotation.status === '已确认' && (
                  <Button className="flex-1 bg-green-500">
                    <Copy className="h-4 w-4 mr-2" />
                    转为商机
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}