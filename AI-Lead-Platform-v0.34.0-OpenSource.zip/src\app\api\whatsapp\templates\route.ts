// WhatsApp模板管理 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 创建或更新模板
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, category, content } = body;

    if (!name || !content) {
      return NextResponse.json({ error: '请提供模板名称和内容' }, { status: 400 });
    }

    // 解析变量（查找 {{xxx}} 格式）
    const variables = content.match(/\{\{[^}]+\}\}/g)?.map((v: string) => v.replace(/[{}]/g, '')) || [];

    const newTemplate = {
      id: `template_${Date.now()}`,
      name,
      category: category || '其他',
      content,
      variables,
      created_at: new Date().toISOString(),
      usage_count: 0,
    };

    // 保存到数据库
    const { error: insertError } = await client
      .from('whatsapp_templates')
      .insert({
        user_id: user.id,
        ...newTemplate,
      });

    if (insertError) {
      console.error('保存模板失败:', insertError);
    }

    return NextResponse.json({ template: newTemplate });
  } catch (error) {
    console.error('创建模板失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建失败' 
    }, { status: 500 });
  }
}

// 更新模板
export async function PUT(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { id, name, category, content } = body;

    if (!id) {
      return NextResponse.json({ error: '请提供模板ID' }, { status: 400 });
    }

    const variables = content.match(/\{\{[^}]+\}\}/g)?.map((v: string) => v.replace(/[{}]/g, '')) || [];

    const updatedTemplate = {
      name,
      category: category || '其他',
      content,
      variables,
    };

    await client
      .from('whatsapp_templates')
      .update(updatedTemplate)
      .eq('id', id)
      .eq('user_id', user.id);

    return NextResponse.json({ template: { id, ...updatedTemplate } });
  } catch (error) {
    console.error('更新模板失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '更新失败' 
    }, { status: 500 });
  }
}

// 删除模板
export async function DELETE(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get('id');

    if (!id) {
      return NextResponse.json({ error: '请提供模板ID' }, { status: 400 });
    }

    await client
      .from('whatsapp_templates')
      .delete()
      .eq('id', id)
      .eq('user_id', user.id);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('删除模板失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '删除失败' 
    }, { status: 500 });
  }
}