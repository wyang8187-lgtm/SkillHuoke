'use client';

import React from 'react';
import { cn } from '@/lib/utils';
import { ChevronRight, Home } from 'lucide-react';
import Link from 'next/link';

// 面包屑项类型定义 - 使用export type确保是纯类型导出
type BreadcrumbItemType = {
  label: string;
  href?: string;
};

export type BreadcrumbItem = BreadcrumbItemType;

interface BreadcrumbProps {
  items: BreadcrumbItem[];
  className?: string;
}

export const Breadcrumb: React.FC<BreadcrumbProps> = ({ items, className }) => {
  return (
    <nav className={cn('flex items-center text-sm text-[#94a3b8]', className)}>
      {/* Home Link */}
      <Link
        href="/dashboard"
        className="flex items-center hover:text-[#f8fafc] transition-colors"
      >
        <Home className="w-4 h-4" />
      </Link>

      {/* Items */}
      {items.map((item, index) => (
        <div key={index} className="flex items-center">
          <ChevronRight className="w-4 h-4 mx-2 text-[#64748b]" />
          {item.href ? (
            <Link
              href={item.href}
              className="hover:text-[#f8fafc] transition-colors"
            >
              {item.label}
            </Link>
          ) : (
            <span className="text-[#f8fafc]">{item.label}</span>
          )}
        </div>
      ))}
    </nav>
  );
}

// Helper function to generate breadcrumbs from path
export function generateBreadcrumbs(path: string): BreadcrumbItem[] {
  const pathMap: Record<string, string> = {
    dashboard: '仪表盘',
    acquisition: 'AI获客中心',
    search: '智能搜索',
    channels: '多渠道获客',
    auto: 'AI自动获客',
    customers: '客户管理',
    list: '客户列表',
    pool: '公海池',
    marketing: '营销中心',
    email: '邮件营销',
    social: '社媒营销',
    whatsapp: 'WhatsApp营销',
    automation: '自动化流程',
    leads: '线索池',
    opportunities: '商机管理',
    team: '团队管理',
    analytics: '数据分析',
    settings: '系统设置',
  };

  const segments = path.split('/').filter(Boolean);
  const items: BreadcrumbItem[] = [];

  let currentPath = '';
  for (const segment of segments) {
    currentPath += `/${segment}`;
    const label = pathMap[segment] || segment;
    
    // Last item doesn't have href (current page)
    if (segments.indexOf(segment) === segments.length - 1) {
      items.push({ label });
    } else {
      items.push({ label, href: currentPath });
    }
  }

  return items;
}