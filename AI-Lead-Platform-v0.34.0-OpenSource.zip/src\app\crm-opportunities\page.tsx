'use client';
import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { loadSavedCrmCustomers, type SavedCrmCustomer } from '@/lib/lead-wizard';
import { deleteCrmOpportunity, loadSavedCrmOpportunities, opportunityCurrencies, opportunityStageOptions, summarizeOpportunityCurrencies, type OpportunityCurrency, type OpportunityStage, type SavedCrmOpportunity } from '@/lib/crm-opportunities';
import { ArrowRight, CircleDollarSign, Plus, Trash2 } from 'lucide-react';

export default function CrmOpportunitiesPage(){
  const [items,setItems]=useState<SavedCrmOpportunity[]>([]); const [customers,setCustomers]=useState<SavedCrmCustomer[]>([]);
  const [stage,setStage]=useState<OpportunityStage|'all'>('all'); const [currency,setCurrency]=useState<OpportunityCurrency|'all'>('all');
  useEffect(()=>{setItems(loadSavedCrmOpportunities());setCustomers(loadSavedCrmCustomers());},[]);
  const filtered=useMemo(()=>items.filter((item)=>(stage==='all'||item.stage===stage)&&(currency==='all'||item.currency===currency)),[items,stage,currency]);
  const totals=useMemo(()=>summarizeOpportunityCurrencies(items),[items]);
  const customerMap=useMemo(()=>new Map(customers.map((item)=>[item.id,item])),[customers]);
  return <MainLayout title="销售机会">
    <div className="space-y-6">
      <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6"><div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between"><div><Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.27.0</Badge><h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">销售机会与报价管道</h2><p className="mt-2 text-sm text-[#94a3b8]">按币种查看预计金额、加权金额、报价中金额与赢单金额。</p></div><Button asChild className="bg-blue-600 text-white hover:bg-blue-500"><Link href="/crm-opportunities/new"><Plus className="mr-2 h-4 w-4"/>新建机会</Link></Button></div></section>
      <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{totals.length?totals.map((item)=><Card key={item.currency} className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">{item.currency} 管道</p><p className="mt-2 text-2xl font-semibold text-blue-300">{item.currency} {item.total.toLocaleString()}</p><div className="mt-3 grid grid-cols-3 gap-2 text-xs text-[#94a3b8]"><span>加权 {Math.round(item.weighted).toLocaleString()}</span><span>报价中 {item.quoting.toLocaleString()}</span><span>赢单 {item.won.toLocaleString()}</span></div></CardContent></Card>):<Card className="border-[#2d3548] bg-[#121823]"><CardContent className="p-6 text-[#94a3b8]">还没有机会金额。</CardContent></Card>}</section>
      <Card className="border-[#2d3548] bg-[#121823]"><CardHeader><CardTitle className="text-[#f8fafc]">机会列表</CardTitle><div className="grid gap-3 pt-3 sm:grid-cols-2"><Select value={stage} onValueChange={(v)=>setStage(v as OpportunityStage|'all')}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="all">全部阶段</SelectItem>{opportunityStageOptions.map((item)=><SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select><Select value={currency} onValueChange={(v)=>setCurrency(v as OpportunityCurrency|'all')}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue/></SelectTrigger><SelectContent><SelectItem value="all">全部币种</SelectItem>{opportunityCurrencies.map((item)=><SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div></CardHeader><CardContent>
        {filtered.length===0?<p className="rounded-lg border border-dashed border-[#2d3548] p-8 text-center text-[#94a3b8]">还没有销售机会。</p>:<div className="grid gap-4 xl:grid-cols-2">{filtered.map((item)=>{const customer=customerMap.get(item.customerId);const meta=opportunityStageOptions.find((entry)=>entry.value===item.stage);return <article key={item.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4"><div className="flex justify-between gap-3"><div><Badge className="border-violet-500/25 bg-violet-500/15 text-violet-300">{meta?.label}</Badge><h3 className="mt-3 font-semibold text-[#f8fafc]">{item.name}</h3><p className="mt-1 text-sm text-[#94a3b8]">{customer?.company||'客户已删除'} · {item.productRequirement}</p></div><p className="text-right font-semibold text-blue-300">{item.currency} {item.amount.toLocaleString()}<span className="block text-xs text-[#64748b]">{item.probability}%</span></p></div><div className="mt-4 flex flex-wrap gap-2"><Button asChild size="sm" variant="outline" className="border-[#2d3548] text-[#cbd5e1]"><Link href={`/crm-opportunities/${item.id}/edit`}>编辑<ArrowRight className="ml-2 h-4 w-4"/></Link></Button>{customer?<Button asChild size="sm" variant="ghost"><Link href={`/crm-customers/${customer.id}`}>客户详情</Link></Button>:null}<Button size="icon" variant="ghost" className="ml-auto text-red-300" onClick={()=>{if(confirm('确认删除这个销售机会吗？'))setItems(deleteCrmOpportunity(item.id));}}><Trash2 className="h-4 w-4"/></Button></div></article>})}</div>}
      </CardContent></Card>
    </div>
  </MainLayout>;
}
