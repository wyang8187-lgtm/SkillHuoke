# v0.23.0 CRM Follow-up Reminders Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a daily CRM work queue that classifies scheduled customers and supports fast completion and rescheduling.

**Architecture:** Add pure date-classification and reminder-action helpers to the local CRM data module. Render a dedicated client page from the existing customer store, and calculate the sidebar badge from the same helper so page totals and navigation remain consistent.

**Tech Stack:** Next.js 16, React 19, TypeScript, localStorage, shadcn UI, Lucide icons.

---

### Task 1: Add reminder data helpers

**Files:**
- Modify: `src/lib/lead-wizard.ts`

- [ ] Define reminder bucket types and date classification helpers.
- [ ] Add helpers for due-count calculation, quick rescheduling, and completing a scheduled follow-up.
- [ ] Ensure completion creates an internal note and clears the scheduled time.
- [ ] Treat invalid dates as unscheduled and paused customers as excluded from active due buckets.
- [ ] Run TypeScript validation.

### Task 2: Build the daily follow-up page

**Files:**
- Create: `src/app/crm-follow-ups/page.tsx`

- [ ] Render overdue, today, upcoming, and unscheduled summary metrics.
- [ ] Add combined due view plus individual bucket filters.
- [ ] Add CRM status and priority filters.
- [ ] Render customer cards with schedule, action, status, score, and detail link.
- [ ] Add tomorrow, three-day, next-week, custom-date, and complete actions.
- [ ] Confirm completion before mutating local data.

### Task 3: Add navigation reminder

**Files:**
- Modify: `src/components/layout/sidebar.tsx`

- [ ] Add a “今日跟进” entry beside CRM customer pool.
- [ ] Calculate overdue plus today count from local CRM data.
- [ ] Display the badge on the follow-up entry without affecting existing task notification logic.
- [ ] Refresh the count on route changes and local storage events.

### Task 4: Update release metadata

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `package.json`
- Modify: `README.md`

- [ ] Set v0.23.0 package and release metadata.
- [ ] Add the daily follow-up page to highlights and review links.
- [ ] Set GitHub remark to `v0.23.0：新增 CRM 今日跟进、逾期提醒和快速延期`.

### Task 5: Verify and package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.23.0-OpenSource.zip`

- [ ] Run TypeScript, ESLint, and production build.
- [ ] Verify login, follow-up page, CRM page, customer detail, and release page return HTTP 200.
- [ ] Inspect the follow-up page and release center in the in-app browser.
- [ ] Package without dependencies, build output, Git metadata, logs, or environment secrets.
- [ ] Verify the ZIP includes the new page and contains no excluded files.
