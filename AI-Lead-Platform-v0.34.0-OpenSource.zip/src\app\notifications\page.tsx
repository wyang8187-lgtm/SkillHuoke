'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Bell, Clock, Check, CheckCheck, Trash2, Settings,
  Mail, MessageSquare, Users, TrendingUp, ArrowLeft
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface Notification {
  id: string;
  type: string;
  title: string;
  content: string;
  created_at: string;
  is_read: boolean;
  priority: string;
  customer_id?: string;
  customer_name?: string;
  opportunity_id?: string;
  opportunity_name?: string;
  operator_name?: string;
}

interface NotificationSettings {
  [key: string]: {
    enabled: boolean;
    channels: string[];
    threshold_days?: number;
    stages?: string[];
  };
}

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [settings, setSettings] = useState<NotificationSettings>({});
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('list');

  useEffect(() => {
    loadNotifications();
    loadSettings();
  }, []);

  const loadNotifications = async () => {
    try {
      setLoading(true);
      const res = await fetch('/api/notifications?limit=50');
      const data = await res.json();
      if (data.success) {
        setNotifications(data.data);
      }
    } catch (error) {
      console.error('加载通知失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadSettings = async () => {
    try {
      const res = await fetch('/api/notifications/settings');
      const data = await res.json();
      if (data.success) {
        setSettings(data.data);
      }
    } catch (error) {
      console.error('加载设置失败:', error);
    }
  };

  const handleMarkRead = async (notificationId: string) => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'mark_read',
          notification_ids: [notificationId],
        }),
      });
      
      if (res.ok) {
        setNotifications(prev =>
          prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
        );
      }
    } catch (error) {
      console.error('标记已读失败:', error);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark_all_read' }),
      });
      
      if (res.ok) {
        setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
      }
    } catch (error) {
      console.error('全部已读失败:', error);
    }
  };

  const handleDelete = async (notificationId: string) => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'delete',
          notification_ids: [notificationId],
        }),
      });
      
      if (res.ok) {
        setNotifications(prev => prev.filter(n => n.id !== notificationId));
      }
    } catch (error) {
      console.error('删除失败:', error);
    }
  };

  const handleSaveSettings = async () => {
    try {
      const res = await fetch('/api/notifications/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
      
      if (res.ok) {
        alert('设置已保存');
      }
    } catch (error) {
      console.error('保存设置失败:', error);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'follow_up_reminder':
        return <Bell className="w-4 h-4" />;
      case 'opportunity_change':
        return <TrendingUp className="w-4 h-4" />;
      case 'pool_claim':
        return <Users className="w-4 h-4" />;
      case 'pool_return':
        return <ArrowLeft className="w-4 h-4" />;
      case 'system_announcement':
        return <Bell className="w-4 h-4" />;
      case 'email_opened':
        return <Mail className="w-4 h-4" />;
      case 'whatsapp_reply':
        return <MessageSquare className="w-4 h-4" />;
      default:
        return <Bell className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'follow_up_reminder':
        return 'bg-orange-500/20 text-orange-400';
      case 'opportunity_change':
        return 'bg-blue-500/20 text-blue-400';
      case 'pool_claim':
        return 'bg-green-500/20 text-green-400';
      case 'pool_return':
        return 'bg-gray-500/20 text-gray-400';
      case 'system_announcement':
        return 'bg-red-500/20 text-red-400';
      case 'email_opened':
        return 'bg-purple-500/20 text-purple-400';
      case 'whatsapp_reply':
        return 'bg-green-500/20 text-green-400';
      default:
        return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getTypeName = (type: string) => {
    switch (type) {
      case 'follow_up_reminder':
        return '跟进提醒';
      case 'opportunity_change':
        return '商机变更';
      case 'pool_claim':
        return '公海认领';
      case 'pool_return':
        return '公海退回';
      case 'system_announcement':
        return '系统公告';
      case 'email_opened':
        return '邮件打开';
      case 'whatsapp_reply':
        return 'WhatsApp回复';
      default:
        return '通知';
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString('zh-CN', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const unreadCount = notifications.filter(n => !n.is_read).length;

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">通知中心</h1>
          <p className="text-[var(--text-muted)] mt-1">查看和管理所有通知消息</p>
        </div>
        {unreadCount > 0 && (
          <Button onClick={handleMarkAllRead} className="gap-2">
            <CheckCheck className="w-4 h-4" />
            全部标记已读
          </Button>
        )}
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-[var(--bg-card)]">
          <TabsTrigger value="list">
            <Bell className="w-4 h-4 mr-2" />
            通知列表
            {unreadCount > 0 && (
              <Badge className="ml-2 bg-red-500">{unreadCount}</Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="settings">
            <Settings className="w-4 h-4 mr-2" />
            通知设置
          </TabsTrigger>
        </TabsList>

        {/* 通知列表 */}
        <TabsContent value="list" className="space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" />
            </div>
          ) : notifications.length === 0 ? (
            <Card className="bg-[var(--bg-card)]">
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Bell className="w-12 h-12 text-[var(--text-muted)] mb-4" />
                <p className="text-[var(--text-muted)]">暂无通知</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-3">
              {notifications.map(notification => (
                <Card 
                  key={notification.id}
                  className={cn(
                    'bg-[var(--bg-card)] hover:bg-[var(--bg-hover)] transition-colors',
                    !notification.is_read && 'border-blue-500/30 bg-blue-500/5'
                  )}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      {/* 类型图标 */}
                      <div className={cn(
                        'w-10 h-10 rounded-lg flex items-center justify-center',
                        getTypeColor(notification.type)
                      )}>
                        {getTypeIcon(notification.type)}
                      </div>
                      
                      {/* 内容 */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={cn('text-xs', getTypeColor(notification.type))}>
                            {getTypeName(notification.type)}
                          </Badge>
                          <span className={cn(
                            'font-medium',
                            notification.is_read ? 'text-[var(--text-secondary)]' : 'text-[var(--text-primary)]'
                          )}>
                            {notification.title}
                          </span>
                        </div>
                        <p className={cn(
                          'text-sm mb-2',
                          notification.is_read ? 'text-[var(--text-muted)]' : 'text-[var(--text-secondary)]'
                        )}>
                          {notification.content}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-[var(--text-muted)]">
                          <span className="flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {formatTime(notification.created_at)}
                          </span>
                          {notification.operator_name && (
                            <span>操作人：{notification.operator_name}</span>
                          )}
                        </div>
                      </div>
                      
                      {/* 操作按钮 */}
                      <div className="flex items-center gap-2">
                        {!notification.is_read && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2"
                            onClick={() => handleMarkRead(notification.id)}
                          >
                            <Check className="w-4 h-4" />
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 px-2 text-[var(--text-muted)] hover:text-red-400"
                          onClick={() => handleDelete(notification.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        {/* 通知设置 */}
        <TabsContent value="settings" className="space-y-4">
          <Card className="bg-[var(--bg-card)]">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">通知类型设置</CardTitle>
              <CardDescription className="text-[var(--text-muted)]">
                配置各类通知的接收方式和条件
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* 跟进提醒 */}
              <div className="p-4 bg-[var(--bg-secondary)] rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-orange-400" />
                    <Label className="text-[var(--text-primary)] font-medium">跟进提醒</Label>
                  </div>
                  <Switch
                    checked={settings.follow_up_reminder?.enabled}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({
                        ...prev,
                        follow_up_reminder: { ...prev.follow_up_reminder, enabled: checked }
                      }))
                    }
                  />
                </div>
                <div className="flex items-center gap-4 ml-8">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={settings.follow_up_reminder?.channels?.includes('app')}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({
                          ...prev,
                          follow_up_reminder: {
                            ...prev.follow_up_reminder,
                            channels: checked 
                              ? [...(prev.follow_up_reminder?.channels || []), 'app']
                              : (prev.follow_up_reminder?.channels || []).filter(c => c !== 'app')
                          }
                        }))
                      }
                    />
                    <span className="text-sm text-[var(--text-secondary)]">应用内通知</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={settings.follow_up_reminder?.channels?.includes('email')}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({
                          ...prev,
                          follow_up_reminder: {
                            ...prev.follow_up_reminder,
                            channels: checked 
                              ? [...(prev.follow_up_reminder?.channels || []), 'email']
                              : (prev.follow_up_reminder?.channels || []).filter(c => c !== 'email')
                          }
                        }))
                      }
                    />
                    <span className="text-sm text-[var(--text-secondary)]">邮件通知</span>
                  </div>
                </div>
              </div>

              {/* 商机变更 */}
              <div className="p-4 bg-[var(--bg-secondary)] rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <TrendingUp className="w-5 h-5 text-blue-400" />
                    <Label className="text-[var(--text-primary)] font-medium">商机状态变更</Label>
                  </div>
                  <Switch
                    checked={settings.opportunity_change?.enabled}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({
                        ...prev,
                        opportunity_change: { ...prev.opportunity_change, enabled: checked }
                      }))
                    }
                  />
                </div>
                <div className="flex items-center gap-4 ml-8">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={settings.opportunity_change?.channels?.includes('app')}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({
                          ...prev,
                          opportunity_change: {
                            ...prev.opportunity_change,
                            channels: checked 
                              ? [...(prev.opportunity_change?.channels || []), 'app']
                              : (prev.opportunity_change?.channels || []).filter(c => c !== 'app')
                          }
                        }))
                      }
                    />
                    <span className="text-sm text-[var(--text-secondary)]">应用内通知</span>
                  </div>
                </div>
              </div>

              {/* 公海池操作 */}
              <div className="p-4 bg-[var(--bg-secondary)] rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Users className="w-5 h-5 text-green-400" />
                    <Label className="text-[var(--text-primary)] font-medium">公海池操作</Label>
                  </div>
                  <Switch
                    checked={settings.pool_claim?.enabled}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({
                        ...prev,
                        pool_claim: { ...prev.pool_claim, enabled: checked },
                        pool_return: { ...prev.pool_return, enabled: checked }
                      }))
                    }
                  />
                </div>
              </div>

              {/* 系统公告 */}
              <div className="p-4 bg-[var(--bg-secondary)] rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <Bell className="w-5 h-5 text-red-400" />
                    <Label className="text-[var(--text-primary)] font-medium">系统公告</Label>
                  </div>
                  <Switch
                    checked={settings.system_announcement?.enabled}
                    onCheckedChange={(checked) => 
                      setSettings(prev => ({
                        ...prev,
                        system_announcement: { ...prev.system_announcement, enabled: checked }
                      }))
                    }
                  />
                </div>
                <div className="flex items-center gap-4 ml-8">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={settings.system_announcement?.channels?.includes('app')}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({
                          ...prev,
                          system_announcement: {
                            ...prev.system_announcement,
                            channels: checked 
                              ? [...(prev.system_announcement?.channels || []), 'app']
                              : (prev.system_announcement?.channels || []).filter(c => c !== 'app')
                          }
                        }))
                      }
                    />
                    <span className="text-sm text-[var(--text-secondary)]">应用内通知</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      checked={settings.system_announcement?.channels?.includes('email')}
                      onCheckedChange={(checked) => 
                        setSettings(prev => ({
                          ...prev,
                          system_announcement: {
                            ...prev.system_announcement,
                            channels: checked 
                              ? [...(prev.system_announcement?.channels || []), 'email']
                              : (prev.system_announcement?.channels || []).filter(c => c !== 'email')
                          }
                        }))
                      }
                    />
                    <span className="text-sm text-[var(--text-secondary)]">邮件通知</span>
                  </div>
                </div>
              </div>

              {/* 保存按钮 */}
              <Button onClick={handleSaveSettings} className="w-full">
                保存设置
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}