import type {
  Customer,
  Lead,
  Opportunity,
  TeamMember,
  Task,
  EmailTemplate,
  EmailRecord,
  MarketingCampaign,
  Activity,
  CustomerTag,
  SocialMediaAccount,
  SocialMediaPost,
} from '@/types';

// 模拟客户标签
export const mockTags: CustomerTag[] = [
  { id: '1', name: '住宅全案', color: '#3b82f6' },
  { id: '2', name: '工装全案', color: '#8b5cf6' },
  { id: '3', name: '陶瓷外贸', color: '#f97316' },
  { id: '4', name: '家具外贸', color: '#06b6d4' },
  { id: '5', name: '高意向', color: '#22c55e' },
  { id: '6', name: '需培育', color: '#f59e0b' },
  { id: '7', name: 'VIP客户', color: '#ec4899' },
  { id: '8', name: '大湾区', color: '#14b8a6' },
];

// 模拟客户数据
export const mockCustomers: Customer[] = [
  {
    id: '1',
    name: '深圳星空间设计事务所',
    type: '全案设计师',
    contactName: '李明',
    phone: '138****5678',
    region: '深圳',
    address: '深圳市南山区科技园南区',
    grade: 'A',
    status: '方案报价',
    source: '智能搜索',
    tags: [mockTags[0], mockTags[5], mockTags[7]],
    lastFollowUpTime: '2024-01-15 14:30',
    nextFollowUpTime: '2024-01-18 10:00',
    createTime: '2024-01-10',
    notes: [
      { id: 'n1', content: '初次联系，对方对全屋定制方案感兴趣', createTime: '2024-01-10', userId: 'u1', userName: '张三', nextPlan: '发送产品资料' },
      { id: 'n2', content: '发送了产品资料，客户反馈积极', createTime: '2024-01-12', userId: 'u1', userName: '张三', nextPlan: '预约实地考察' },
    ],
    ownerId: 'u1',
  },
  {
    id: '2',
    name: '佛山建材进出口有限公司',
    type: '建材外贸公司',
    contactName: '王芳',
    phone: '139****2345',
    region: '佛山',
    address: '佛山市禅城区建材市场B区',
    grade: 'B',
    status: '需求确认',
    source: '企查查',
    tags: [mockTags[2], mockTags[6]],
    lastFollowUpTime: '2024-01-14 16:00',
    createTime: '2024-01-08',
    notes: [
      { id: 'n1', content: '电话联系，对方主要做陶瓷出口业务', createTime: '2024-01-08', userId: 'u2', userName: '李四' },
    ],
    ownerId: 'u2',
  },
  {
    id: '3',
    name: '广州豪庭装饰设计',
    type: '全案设计师',
    contactName: '陈伟',
    phone: '137****8901',
    region: '广州',
    address: '广州市天河区珠江新城',
    grade: 'A',
    status: '谈判中',
    source: '设计师平台',
    tags: [mockTags[0], mockTags[4]],
    lastFollowUpTime: '2024-01-16 09:00',
    createTime: '2024-01-05',
    notes: [],
    ownerId: 'u1',
  },
  {
    id: '4',
    name: '东莞家具贸易公司',
    type: '建材外贸公司',
    contactName: '赵丽',
    phone: '136****4567',
    region: '东莞',
    address: '东莞市厚街镇家具大道',
    grade: 'C',
    status: '待跟进',
    source: '展会名录',
    tags: [mockTags[3]],
    lastFollowUpTime: '2024-01-05 11:00',
    createTime: '2024-01-03',
    notes: [],
    ownerId: 'u2',
  },
  {
    id: '5',
    name: '珠海设计工作室',
    type: '全案设计师',
    contactName: '刘洋',
    phone: '135****1234',
    region: '珠海',
    address: '珠海市香洲区设计产业园',
    grade: 'B',
    status: '初步接触',
    source: '小红书',
    tags: [mockTags[1], mockTags[5]],
    lastFollowUpTime: '2024-01-13 15:30',
    createTime: '2024-01-11',
    notes: [],
    ownerId: 'u1',
  },
  {
    id: '6',
    name: '中山建材出口公司',
    type: '建材外贸公司',
    contactName: '孙强',
    phone: '134****7890',
    region: '中山',
    address: '中山市小榄镇工业区',
    grade: 'D',
    status: '已输单',
    source: '天眼查',
    tags: [],
    lastFollowUpTime: '2024-01-02 10:00',
    createTime: '2024-01-01',
    notes: [],
    ownerId: 'u2',
  },
];

// 模拟线索数据
export const mockLeads: Lead[] = [
  {
    id: 'l1',
    companyName: '惠州设计联盟',
    contactName: '周杰',
    phone: '133****5678',
    region: '惠州',
    source: '智能搜索',
    status: '新线索',
    matchScore: 92,
    createTime: '2024-01-16 10:30',
    address: '惠州市惠城区',
  },
  {
    id: 'l2',
    companyName: '江门建材集团',
    contactName: '吴婷',
    phone: '132****3456',
    region: '江门',
    source: 'AI自动获客',
    status: '新线索',
    matchScore: 88,
    createTime: '2024-01-16 08:15',
    address: '江门市蓬江区',
  },
  {
    id: 'l3',
    companyName: '肇庆装饰设计院',
    contactName: '郑华',
    phone: '131****9012',
    region: '肇庆',
    source: '百度搜索',
    status: '已跟进',
    matchScore: 75,
    createTime: '2024-01-15 14:00',
    assigneeId: 'u1',
    assigneeName: '张三',
    address: '肇庆市端州区',
  },
  {
    id: 'l4',
    companyName: '清远建材出口',
    contactName: '黄梅',
    phone: '130****5678',
    region: '清远',
    source: 'Google搜索',
    status: '新线索',
    matchScore: 70,
    createTime: '2024-01-16 09:00',
    address: '清远市清城区',
  },
  {
    id: 'l5',
    companyName: '顺德设计事务所',
    contactName: '林涛',
    phone: '189****2345',
    region: '佛山',
    source: '设计师平台',
    status: '已转客户',
    matchScore: 95,
    createTime: '2024-01-14',
    assigneeId: 'u1',
    assigneeName: '张三',
    address: '佛山市顺德区',
  },
];

// 模拟商机数据
export const mockOpportunities: Opportunity[] = [
  {
    id: 'op1',
    customerId: '1',
    customerName: '深圳星空间设计事务所',
    stage: '方案报价',
    amount: 150000,
    expectedCloseDate: '2024-02-15',
    probability: 60,
    ownerId: 'u1',
    ownerName: '张三',
    createTime: '2024-01-10',
  },
  {
    id: 'op2',
    customerId: '3',
    customerName: '广州豪庭装饰设计',
    stage: '谈判',
    amount: 280000,
    expectedCloseDate: '2024-01-25',
    probability: 80,
    ownerId: 'u1',
    ownerName: '张三',
    createTime: '2024-01-05',
  },
  {
    id: 'op3',
    customerId: '2',
    customerName: '佛山建材进出口有限公司',
    stage: '需求确认',
    amount: 120000,
    expectedCloseDate: '2024-03-01',
    probability: 40,
    ownerId: 'u2',
    ownerName: '李四',
    createTime: '2024-01-08',
  },
  {
    id: 'op4',
    customerId: '6',
    customerName: '中山建材出口公司',
    stage: '输单',
    amount: 80000,
    expectedCloseDate: '2024-01-20',
    probability: 0,
    ownerId: 'u2',
    ownerName: '李四',
    createTime: '2024-01-01',
    lostReason: '价格竞争失败',
  },
];

// 模拟团队成员
export const mockTeamMembers: TeamMember[] = [
  {
    id: 'u1',
    name: '张三',
    email: 'zhangsan@example.com',
    role: '销售经理',
    status: '在职',
    createTime: '2023-06-01',
  },
  {
    id: 'u2',
    name: '李四',
    email: 'lisi@example.com',
    role: '销售员',
    status: '在职',
    createTime: '2023-08-15',
  },
  {
    id: 'u3',
    name: '王五',
    email: 'wangwu@example.com',
    role: '管理员',
    status: '在职',
    createTime: '2023-01-01',
  },
  {
    id: 'u4',
    name: '赵六',
    email: 'zhaoliu@example.com',
    role: '运营',
    status: '在职',
    createTime: '2023-10-01',
  },
];

// 模拟任务数据
export const mockTasks: Task[] = [
  {
    id: 't1',
    title: '跟进深圳星空间客户',
    customerId: '1',
    customerName: '深圳星空间设计事务所',
    type: '跟进客户',
    status: '待完成',
    dueTime: '2024-01-18 10:00',
    userId: 'u1',
    userName: '张三',
    createTime: '2024-01-15',
  },
  {
    id: 't2',
    title: '发送产品报价单',
    customerId: '3',
    customerName: '广州豪庭装饰设计',
    type: '发送邮件',
    status: '待完成',
    dueTime: '2024-01-17 14:00',
    userId: 'u1',
    userName: '张三',
    createTime: '2024-01-16',
  },
  {
    id: 't3',
    title: '电话联系佛山建材客户',
    customerId: '2',
    customerName: '佛山建材进出口有限公司',
    type: '电话联系',
    status: '已完成',
    dueTime: '2024-01-14 16:00',
    userId: 'u2',
    userName: '李四',
    createTime: '2024-01-14',
  },
  {
    id: 't4',
    title: '处理新线索',
    type: '其他',
    status: '已过期',
    dueTime: '2024-01-15 09:00',
    userId: 'u1',
    userName: '张三',
    createTime: '2024-01-15',
  },
];

// 模拟邮件模板
export const mockEmailTemplates: EmailTemplate[] = [
  {
    id: 'et1',
    name: '全案设计师开发信',
    subject: '专业全屋定制解决方案 - 为您的设计赋能',
    content: '尊敬的设计师朋友，您好！\n\n我们是一家专业的全屋定制工厂，专注于为全案设计师提供高品质的定制产品解决方案...\n\n期待与您的合作！',
    category: '开发信',
    createTime: '2024-01-01',
  },
  {
    id: 'et2',
    name: '建材外贸开发信',
    subject: '优质建材产品供应 - 国际出口品质',
    content: '尊敬的合作伙伴，您好！\n\n我们专注于建材出口业务，产品涵盖陶瓷、家具、卫浴等品类...\n\n期待建立长期合作关系！',
    category: '开发信',
    createTime: '2024-01-02',
  },
  {
    id: 'et3',
    name: '产品介绍邮件',
    subject: '最新产品目录 - 2024新品发布',
    content: '尊敬的客户，\n\n我们为您准备了最新的产品目录，包含2024年全屋定制新品系列...',
    category: '产品介绍',
    createTime: '2024-01-05',
  },
  {
    id: 'et4',
    name: '案例分享邮件',
    subject: '精选案例分享 - 优秀设计师合作案例',
    content: '尊敬的设计师朋友，\n\n我们整理了近期与优秀设计师合作的精彩案例...',
    category: '案例分享',
    createTime: '2024-01-10',
  },
];

// 模拟邮件记录
export const mockEmailRecords: EmailRecord[] = [
  {
    id: 'er1',
    customerId: '1',
    customerName: '深圳星空间设计事务所',
    templateId: 'et1',
    subject: '专业全屋定制解决方案 - 为您的设计赋能',
    content: '...',
    status: '已打开',
    sentTime: '2024-01-12 10:00',
    openTime: '2024-01-12 14:30',
  },
  {
    id: 'er2',
    customerId: '2',
    customerName: '佛山建材进出口有限公司',
    templateId: 'et2',
    subject: '优质建材产品供应 - 国际出口品质',
    content: '...',
    status: '已送达',
    sentTime: '2024-01-08 09:00',
  },
  {
    id: 'er3',
    customerId: '3',
    customerName: '广州豪庭装饰设计',
    templateId: 'et3',
    subject: '最新产品目录 - 2024新品发布',
    content: '...',
    status: '已点击',
    sentTime: '2024-01-10 11:00',
    openTime: '2024-01-10 15:00',
    clickTime: '2024-01-10 15:30',
  },
];

// 模拟营销活动
export const mockCampaigns: MarketingCampaign[] = [
  {
    id: 'c1',
    name: '大湾区设计师推广计划',
    type: '邮件营销',
    status: '进行中',
    targetCount: 50,
    sentCount: 35,
    openRate: 45,
    clickRate: 20,
    createTime: '2024-01-10',
    startTime: '2024-01-12',
  },
  {
    id: 'c2',
    name: '建材外贸新年问候',
    type: '邮件营销',
    status: '已完成',
    targetCount: 30,
    sentCount: 30,
    openRate: 60,
    clickRate: 15,
    createTime: '2024-01-01',
    startTime: '2024-01-02',
    endTime: '2024-01-05',
  },
  {
    id: 'c3',
    name: '抖音内容矩阵推广',
    type: '社媒营销',
    status: '进行中',
    targetCount: 1000,
    sentCount: 200,
    createTime: '2024-01-15',
  },
];

// 模拟活动记录
export const mockActivities: Activity[] = [
  {
    id: 'a1',
    type: '新增线索',
    content: '新增线索：惠州设计联盟（匹配度92%）',
    customerId: 'l1',
    customerName: '惠州设计联盟',
    userId: 'system',
    userName: 'AI系统',
    createTime: '2024-01-16 10:30',
  },
  {
    id: 'a2',
    type: '客户跟进',
    content: '跟进深圳星空间客户，发送报价方案',
    customerId: '1',
    customerName: '深圳星空间设计事务所',
    userId: 'u1',
    userName: '张三',
    createTime: '2024-01-15 14:30',
  },
  {
    id: 'a3',
    type: '商机进展',
    content: '广州豪庭装饰进入谈判阶段',
    customerId: '3',
    customerName: '广州豪庭装饰设计',
    userId: 'u1',
    userName: '张三',
    createTime: '2024-01-16 09:00',
  },
  {
    id: 'a4',
    type: '邮件发送',
    content: '向佛山建材发送产品介绍邮件',
    customerId: '2',
    customerName: '佛山建材进出口有限公司',
    userId: 'u2',
    userName: '李四',
    createTime: '2024-01-14 16:00',
  },
  {
    id: 'a5',
    type: '成交',
    content: '成功签约顺德设计事务所（金额15万）',
    customerId: 'l5',
    customerName: '顺德设计事务所',
    userId: 'u1',
    userName: '张三',
    createTime: '2024-01-14 11:00',
  },
];

// 模拟社媒账号
export const mockSocialAccounts: SocialMediaAccount[] = [
  {
    id: 'sa1',
    platform: '抖音',
    accountName: '全屋定制工厂官方号',
    followers: 5000,
    posts: 32,
    engagement: 4.5,
    status: '正常',
  },
  {
    id: 'sa2',
    platform: '小红书',
    accountName: '定制生活家',
    followers: 3500,
    posts: 48,
    engagement: 6.2,
    status: '正常',
  },
  {
    id: 'sa3',
    platform: 'Instagram',
    accountName: 'CustomHomeFactory',
    followers: 1200,
    posts: 25,
    engagement: 3.8,
    status: '正常',
  },
  {
    id: 'sa4',
    platform: 'Facebook',
    accountName: 'HomeCustomFactory',
    followers: 800,
    posts: 18,
    engagement: 2.5,
    status: '正常',
  },
];

// 模拟社媒内容
export const mockSocialPosts: SocialMediaPost[] = [
  {
    id: 'sp1',
    title: '现代简约风格全屋定制案例分享',
    content: '这是一个来自深圳客户的现代简约风格定制案例...',
    platform: '小红书',
    type: '图文',
    status: '已发布',
    publishTime: '2024-01-16 10:00',
    views: 1250,
    likes: 89,
    comments: 12,
  },
  {
    id: 'sp2',
    title: '工厂实拍：定制衣柜制作过程',
    content: '从设计到成品，带你了解定制衣柜的制作全流程...',
    platform: '抖音',
    type: '视频',
    status: '已发布',
    publishTime: '2024-01-15 14:30',
    views: 3200,
    likes: 156,
    comments: 45,
  },
  {
    id: 'sp3',
    title: '2024新品发布 - 意式轻奢系列',
    content: '全新意式轻奢系列，为高端设计师客户提供更多选择...',
    platform: 'Instagram',
    type: '图文',
    status: '已发布',
    publishTime: '2024-01-14 09:00',
    views: 580,
    likes: 32,
    comments: 8,
  },
  {
    id: 'sp4',
    title: '全屋定制设计方案征集',
    content: '征集大湾区设计师参与我们的定制方案设计...',
    platform: '小红书',
    type: '图文',
    status: '草稿',
    publishTime: '-',
    views: 0,
    likes: 0,
    comments: 0,
  },
  {
    id: 'sp5',
    title: '外贸客户定制案例展示',
    content: '为海外客户提供的高品质定制家具案例...',
    platform: 'Facebook',
    type: '图文',
    status: '已发布',
    publishTime: '2024-01-12 11:00',
    views: 420,
    likes: 28,
    comments: 5,
  },
];

// 大湾区城市列表
export const regions = [
  '深圳', '广州', '佛山', '东莞', '珠海', 
  '中山', '惠州', '江门', '肇庆', '清远',
  '香港', '澳门', '顺德', '南海'
];

// 数据存储管理
const STORAGE_KEYS = {
  customers: 'saas_customers',
  leads: 'saas_leads',
  opportunities: 'saas_opportunities',
  teamMembers: 'saas_teamMembers',
  tasks: 'saas_tasks',
  emailTemplates: 'saas_emailTemplates',
  emailRecords: 'saas_emailRecords',
  campaigns: 'saas_campaigns',
  activities: 'saas_activities',
  isLoggedIn: 'saas_isLoggedIn',
};

// 初始化数据到localStorage
export function initData(): void {
  if (typeof window === 'undefined') return;
  
  // 检查是否已初始化
  if (localStorage.getItem(STORAGE_KEYS.customers)) return;
  
  localStorage.setItem(STORAGE_KEYS.customers, JSON.stringify(mockCustomers));
  localStorage.setItem(STORAGE_KEYS.leads, JSON.stringify(mockLeads));
  localStorage.setItem(STORAGE_KEYS.opportunities, JSON.stringify(mockOpportunities));
  localStorage.setItem(STORAGE_KEYS.teamMembers, JSON.stringify(mockTeamMembers));
  localStorage.setItem(STORAGE_KEYS.tasks, JSON.stringify(mockTasks));
  localStorage.setItem(STORAGE_KEYS.emailTemplates, JSON.stringify(mockEmailTemplates));
  localStorage.setItem(STORAGE_KEYS.emailRecords, JSON.stringify(mockEmailRecords));
  localStorage.setItem(STORAGE_KEYS.campaigns, JSON.stringify(mockCampaigns));
  localStorage.setItem(STORAGE_KEYS.activities, JSON.stringify(mockActivities));
}

// 获取数据
export function getData<T>(key: string): T[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

// 保存数据
export function saveData<T>(key: string, data: T[]): void {
  if (typeof window === 'undefined') return;
  localStorage.setItem(key, JSON.stringify(data));
}

// 添加数据
export function addData<T extends { id: string }>(key: string, item: T): void {
  const data = getData<T>(key);
  data.push(item);
  saveData(key, data);
}

// 更新数据
export function updateData<T extends { id: string }>(key: string, id: string, updates: Partial<T>): void {
  const data = getData<T>(key);
  const index = data.findIndex(item => item.id === id);
  if (index !== -1) {
    data[index] = { ...data[index], ...updates };
    saveData(key, data);
  }
}

// 删除数据
export function deleteData<T extends { id: string }>(key: string, id: string): void {
  const data = getData<T>(key);
  const filtered = data.filter(item => item.id !== id);
  saveData(key, filtered);
}

// 导出存储键
export { STORAGE_KEYS };