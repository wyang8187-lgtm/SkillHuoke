# v0.13 Team Members And Permissions Plan

1. Create `src/lib/team-access.ts` with roles, permissions, demo members, data scopes, and helper functions.
2. Rewrite `/team` as the main team member console.
3. Rewrite `/team/permissions` as the permission matrix and data scope page.
4. Rewrite `/settings/team` as the SaaS team settings overview.
5. Update workspace demo text, version number, and README notes.
6. Run `ts-check`, `lint:build`, `build`, and browser smoke checks.
7. Package a clean open-source zip without `node_modules`, `.next`, `.git`, or local env files.
