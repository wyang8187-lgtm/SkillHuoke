import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

// AI客户画像接口 - 分析客户特征，生成结构化画像
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { customerData } = body;

    if (!customerData) {
      return NextResponse.json({ error: '请提供客户数据' }, { status: 400 });
    }

    // 提取请求头用于转发
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    // 使用LLMClient调用AI模型
    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    const systemPrompt = `你是一个专业的客户关系管理分析师，专门为全屋定制工厂分析客户特征并提供跟进策略建议。
你的客户群体是：全案设计师、建材外贸公司。

请根据提供的客户数据，生成以下分析结果（JSON格式）：
{
  "companyProfile": {
    "estimatedScale": "企业规模估算（小型/中型/大型）",
    "mainProducts": ["主营产品列表，最多5个"],
    "businessType": "业务类型描述",
    "serviceArea": "服务覆盖区域"
  },
  "cooperationPotential": {
    "score": 合作意向评分（1-100）,
    "level": "合作意向等级（高/中/低）",
    "reasons": ["评分原因说明"]
  },
  "keyNeeds": ["客户核心需求，最多5个"],
  "recommendedApproach": {
    "primaryChannel": "推荐首选渠道（邮件/电话/微信/展会/拜访）",
    "timing": "推荐接触时机",
    "tone": "沟通风格建议（正式/友好/简洁）"
  },
  "followUpStrategy": {
    "summary": "跟进策略摘要",
    "steps": ["具体跟进步骤，最多5个"],
    "frequency": "建议跟进频率"
  },
  "riskFactors": ["风险因素提示，最多3个"],
  "nextAction": "下一步具体行动建议"
}

只返回JSON，不要其他内容。`;

    const customerInfo = JSON.stringify(customerData, null, 2);
    
    const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `请分析以下客户数据：\n${customerInfo}` }
    ];

    // 调用AI模型
    let parsedResult;
    try {
      const response = await client.invoke(messages, {
        model: 'doubao-seed-1-8-251228',
        temperature: 0.5,
      });

      // 解析AI返回的JSON
      let content = response.content.trim();
      if (content.startsWith('```json')) {
        content = content.slice(7);
      }
      if (content.startsWith('```')) {
        content = content.slice(3);
      }
      if (content.endsWith('```')) {
        content = content.slice(0, -3);
      }
      content = content.trim();
      parsedResult = JSON.parse(content);
    } catch {
      // AI解析失败时，返回默认画像
      const customerType = customerData.customer_type || customerData.type || '设计师';
      const region = customerData.region || '大湾区';
      
      parsedResult = {
        companyProfile: {
          estimatedScale: '中型',
          mainProducts: customerType === '设计师' 
            ? ['住宅全案设计', '商业空间设计', '软装搭配']
            : ['建材出口', '陶瓷产品', '家具配件'],
          businessType: customerType === '设计师' ? '室内设计服务' : '建材外贸贸易',
          serviceArea: region
        },
        cooperationPotential: {
          score: 75,
          level: '中',
          reasons: ['需进一步了解客户实际需求', '行业匹配度高']
        },
        keyNeeds: ['产品质量', '价格合理', '交期稳定', '定制能力'],
        recommendedApproach: {
          primaryChannel: '邮件',
          timing: '工作日上午',
          tone: '正式'
        },
        followUpStrategy: {
          summary: '建议通过邮件建立初步联系，逐步深入了解需求',
          steps: ['发送产品介绍邮件', '分享成功案例', '邀约线上会议', '提供样品报价'],
          frequency: '每两周一次'
        },
        riskFactors: ['可能已有稳定供应商', '预算限制'],
        nextAction: '发送专业开发信建立初步联系'
      };
    }

    return NextResponse.json({
      success: true,
      data: parsedResult
    });

  } catch (error) {
    console.error('AI画像分析错误:', error);
    return NextResponse.json({ 
      error: 'AI画像分析失败，请稍后重试',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}