import { NextRequest, NextResponse } from 'next/server';

// 通知中心API
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const type = searchParams.get('type');
    const is_read = searchParams.get('is_read');
    const limit = parseInt(searchParams.get('limit') || '20');

    // 模拟通知数据
    const mockNotifications = [
      {
        id: 'notif_001',
        type: 'follow_up_reminder',
        title: '跟进提醒',
        content: '客户"深圳市某某家居有限公司"超过7天未跟进，请及时跟进',
        customer_id: 'cust_001',
        customer_name: '深圳市某某家居有限公司',
        created_at: '2024-12-15 09:00:00',
        is_read: false,
        priority: 'high',
      },
      {
        id: 'notif_002',
        type: 'opportunity_change',
        title: '商机状态变更',
        content: '商机"广州某项目定制"已进入报价阶段',
        opportunity_id: 'opp_001',
        opportunity_name: '广州某项目定制',
        created_at: '2024-12-15 10:30:00',
        is_read: false,
        priority: 'medium',
      },
      {
        id: 'notif_003',
        type: 'pool_claim',
        title: '公海池认领',
        content: '李主管从公海池认领了客户"佛山某某建材公司"',
        customer_id: 'cust_002',
        customer_name: '佛山某某建材公司',
        operator_name: '李主管',
        created_at: '2024-12-15 11:00:00',
        is_read: true,
        priority: 'low',
      },
      {
        id: 'notif_004',
        type: 'system_announcement',
        title: '系统公告',
        content: '系统将于今晚23:00-24:00进行维护升级，届时部分功能可能暂时不可用',
        created_at: '2024-12-14 18:00:00',
        is_read: false,
        priority: 'high',
      },
      {
        id: 'notif_005',
        type: 'follow_up_reminder',
        title: '跟进提醒',
        content: '线索"东莞某设计工作室"已超过30天未跟进，即将进入公海池',
        lead_id: 'lead_001',
        lead_name: '东莞某设计工作室',
        created_at: '2024-12-14 08:00:00',
        is_read: true,
        priority: 'high',
      },
      {
        id: 'notif_006',
        type: 'opportunity_change',
        title: '商机状态变更',
        content: '商机"深圳某写字楼全屋定制"已成交，金额￥150,000',
        opportunity_id: 'opp_002',
        opportunity_name: '深圳某写字楼全屋定制',
        amount: 150000,
        created_at: '2024-12-13 16:00:00',
        is_read: true,
        priority: 'medium',
      },
      {
        id: 'notif_007',
        type: 'pool_claim',
        title: '公海池退回',
        content: '王销售将客户"广州某某装饰公司"退回公海池',
        customer_id: 'cust_003',
        customer_name: '广州某某装饰公司',
        operator_name: '王销售',
        created_at: '2024-12-13 14:00:00',
        is_read: true,
        priority: 'low',
      },
      {
        id: 'notif_008',
        type: 'email_opened',
        title: '邮件已打开',
        content: '客户"惠州某某家居中心"打开了您发送的开发信邮件',
        customer_id: 'cust_004',
        customer_name: '惠州某某家居中心',
        email_id: 'email_001',
        created_at: '2024-12-12 15:00:00',
        is_read: true,
        priority: 'medium',
      },
      {
        id: 'notif_009',
        type: 'system_announcement',
        title: '系统公告',
        content: '新功能上线：AI自动获客功能已上线，可配置自动搜索任务',
        created_at: '2024-12-11 10:00:00',
        is_read: true,
        priority: 'high',
      },
      {
        id: 'notif_010',
        type: 'whatsapp_reply',
        title: 'WhatsApp回复',
        content: '客户"珠海某某设计公司"回复了您的WhatsApp消息',
        customer_id: 'cust_005',
        customer_name: '珠海某某设计公司',
        whatsapp_id: 'wa_001',
        created_at: '2024-12-10 12:00:00',
        is_read: true,
        priority: 'medium',
      },
    ];

    // 过滤
    let filtered = mockNotifications;
    if (type && type !== 'all') {
      filtered = filtered.filter(n => n.type === type);
    }
    if (is_read !== null && is_read !== 'all') {
      filtered = filtered.filter(n => n.is_read === (is_read === 'true'));
    }

    // 排序和限制数量
    const result = filtered
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, limit);

    return NextResponse.json({
      success: true,
      data: result,
      total: filtered.length,
      unread_count: mockNotifications.filter(n => !n.is_read).length,
    });
  } catch (error) {
    console.error('获取通知失败:', error);
    return NextResponse.json({ error: '获取失败' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { action, notification_ids } = body;

    switch (action) {
      case 'mark_read':
        return NextResponse.json({
          success: true,
          message: '已标记为已读',
          updated_ids: notification_ids,
        });
      case 'mark_all_read':
        return NextResponse.json({
          success: true,
          message: '全部已标记为已读',
        });
      default:
        return NextResponse.json({ error: '未知操作' }, { status: 400 });
    }
  } catch (error) {
    console.error('通知操作失败:', error);
    return NextResponse.json({ error: '操作失败' }, { status: 500 });
  }
}