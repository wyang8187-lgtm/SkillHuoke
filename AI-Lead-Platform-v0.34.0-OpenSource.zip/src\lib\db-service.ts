/**
 * 数据库服务层 - 使用Service Role Key绕过RLS
 * 用于服务端API操作数据库
 */

import { createClient } from '@supabase/supabase-js';

// 获取Supabase凭证
function getSupabaseCredentials() {
  const url = process.env.COZE_SUPABASE_URL;
  const serviceRoleKey = process.env.COZE_SUPABASE_SERVICE_ROLE_KEY;
  
  if (!url || !serviceRoleKey) {
    throw new Error('Supabase credentials not configured');
  }
  
  return { url, serviceRoleKey };
}

// 创建Service Role客户端（绕过RLS）
export function getSupabaseAdmin() {
  const { url, serviceRoleKey } = getSupabaseCredentials();
  return createClient(url, serviceRoleKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}

// 类型定义
export interface CustomerDB {
  id: string;
  user_id: string;
  company_name: string;
  customer_type: string;
  contact_name: string;
  phone: string;
  region: string;
  address?: string;
  source?: string;
  grade: string;
  status: string;
  tags?: string[];
  notes?: string;
  remarks?: string;
  assignee_id?: string;
  last_follow_up_time?: string;
  next_follow_up_time?: string;
  created_at: string;
  updated_at: string;
}

export interface LeadDB {
  id: string;
  user_id: string;
  company_name: string;
  contact_name?: string;
  phone?: string;
  region?: string;
  customer_type?: string;
  grade?: string;
  source?: string;
  match_score?: number;
  status: string;
  assignee_id?: string;
  assignee_name?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface OpportunityDB {
  id: string;
  user_id: string;
  customer_id: string;
  customer_name?: string;
  name: string;
  stage: string;
  amount?: number;
  probability?: number;
  expected_close_date?: string;
  lost_reason?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface TaskDB {
  id: string;
  user_id: string;
  customer_id?: string;
  title: string;
  description?: string;
  type: string;
  status: string;
  priority: string;
  due_time?: string;
  completed_time?: string;
  created_at: string;
  updated_at: string;
}

export interface FollowUpRecordDB {
  id: string;
  user_id: string;
  customer_id: string;
  type: string;
  content: string;
  next_action?: string;
  next_time?: string;
  created_at: string;
}

export interface EmailRecordDB {
  id: string;
  user_id: string;
  customer_id?: string;
  to_email: string;
  subject: string;
  content: string;
  template_id?: string;
  status: string;
  sent_time: string;
  opened_time?: string;
  clicked_time?: string;
  created_at: string;
}

export interface CampaignDB {
  id: string;
  user_id: string;
  name: string;
  type: string;
  status: string;
  target_count?: number;
  sent_count?: number;
  opened_count?: number;
  clicked_count?: number;
  start_time?: string;
  end_time?: string;
  created_at: string;
  updated_at: string;
}

// ========== 客户 CRUD ==========

export async function getCustomers(userId: string, filters?: {
  customer_type?: string;
  region?: string;
  grade?: string;
  status?: string;
  keyword?: string;
}, page = 1, pageSize = 20) {
  const supabase = getSupabaseAdmin();
  
  let query = supabase
    .from('customers')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (filters?.customer_type) {
    query = query.eq('customer_type', filters.customer_type);
  }
  if (filters?.region) {
    query = query.eq('region', filters.region);
  }
  if (filters?.grade) {
    query = query.eq('grade', filters.grade);
  }
  if (filters?.status) {
    query = query.eq('status', filters.status);
  }
  if (filters?.keyword) {
    query = query.or(`company_name.ilike.%${filters.keyword}%,contact_name.ilike.%${filters.keyword}%,phone.ilike.%${filters.keyword}%`);
  }
  
  const offset = (page - 1) * pageSize;
  query = query.range(offset, offset + pageSize - 1);
  
  const { data, error, count } = await query;
  
  if (error) throw error;
  
  return { data: data as CustomerDB[], total: count || 0, page, pageSize };
}

export async function getCustomerById(userId: string, customerId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('customers')
    .select('*')
    .eq('user_id', userId)
    .eq('id', customerId)
    .single();
  
  if (error) throw error;
  
  return data as CustomerDB;
}

export async function createCustomer(userId: string, customer: Omit<CustomerDB, 'id' | 'user_id' | 'created_at' | 'updated_at'>) {
  const supabase = getSupabaseAdmin();
  
  // 查重 - 手机号和公司名
  const { data: existing } = await supabase
    .from('customers')
    .select('id')
    .eq('user_id', userId)
    .or(`phone.eq.${customer.phone},company_name.eq.${customer.company_name}`)
    .limit(1);
  
  if (existing && existing.length > 0) {
    throw new Error('客户已存在（手机号或公司名重复）');
  }
  
  const { data, error } = await supabase
    .from('customers')
    .insert({ ...customer, user_id: userId })
    .select()
    .single();
  
  if (error) throw error;
  
  return data as CustomerDB;
}

export async function updateCustomer(userId: string, customerId: string, updates: Partial<CustomerDB>) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('customers')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('user_id', userId)
    .eq('id', customerId)
    .select()
    .single();
  
  if (error) throw error;
  
  return data as CustomerDB;
}

export async function deleteCustomer(userId: string, customerId: string) {
  const supabase = getSupabaseAdmin();
  
  const { error } = await supabase
    .from('customers')
    .delete()
    .eq('user_id', userId)
    .eq('id', customerId);
  
  if (error) throw error;
  
  return true;
}

export async function batchDeleteCustomers(userId: string, customerIds: string[]) {
  const supabase = getSupabaseAdmin();
  
  const { error } = await supabase
    .from('customers')
    .delete()
    .eq('user_id', userId)
    .in('id', customerIds);
  
  if (error) throw error;
  
  return true;
}

// ========== 线索 CRUD ==========

export async function getLeads(userId: string, filters?: {
  status?: string;
  region?: string;
  source?: string;
  keyword?: string;
}, page = 1, pageSize = 20) {
  const supabase = getSupabaseAdmin();
  
  let query = supabase
    .from('leads')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (filters?.status) {
    query = query.eq('status', filters.status);
  }
  if (filters?.region) {
    query = query.eq('region', filters.region);
  }
  if (filters?.source) {
    query = query.eq('source', filters.source);
  }
  if (filters?.keyword) {
    query = query.or(`company_name.ilike.%${filters.keyword}%,contact_name.ilike.%${filters.keyword}%,phone.ilike.%${filters.keyword}%`);
  }
  
  const offset = (page - 1) * pageSize;
  query = query.range(offset, offset + pageSize - 1);
  
  const { data, error, count } = await query;
  
  if (error) throw error;
  
  return { data: data as LeadDB[], total: count || 0, page, pageSize };
}

export async function createLead(userId: string, lead: Omit<LeadDB, 'id' | 'user_id' | 'created_at' | 'updated_at'>) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('leads')
    .insert({ ...lead, user_id: userId })
    .select()
    .single();
  
  if (error) throw error;
  
  return data as LeadDB;
}

export async function updateLead(userId: string, leadId: string, updates: Partial<LeadDB>) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('leads')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('user_id', userId)
    .eq('id', leadId)
    .select()
    .single();
  
  if (error) throw error;
  
  return data as LeadDB;
}

export async function deleteLead(userId: string, leadId: string) {
  const supabase = getSupabaseAdmin();
  
  const { error } = await supabase
    .from('leads')
    .delete()
    .eq('user_id', userId)
    .eq('id', leadId);
  
  if (error) throw error;
  
  return true;
}

// 线索转客户
export async function convertLeadToCustomer(userId: string, leadId: string) {
  const supabase = getSupabaseAdmin();
  
  // 获取线索信息
  const { data: lead, error: leadError } = await supabase
    .from('leads')
    .select('*')
    .eq('user_id', userId)
    .eq('id', leadId)
    .single();
  
  if (leadError) throw leadError;
  
  // 创建客户
  const customerData = {
    company_name: lead.company_name,
    customer_type: 'full_designer', // 默认类型
    contact_name: lead.contact_name || '',
    phone: lead.phone || '',
    region: lead.region || '',
    source: lead.source,
    grade: 'C',
    status: 'new',
  };
  
  const { data: customer, error: customerError } = await supabase
    .from('customers')
    .insert({ ...customerData, user_id: userId })
    .select()
    .single();
  
  if (customerError) throw customerError;
  
  // 更新线索状态为已转客户
  await supabase
    .from('leads')
    .update({ status: 'converted', updated_at: new Date().toISOString() })
    .eq('id', leadId);
  
  return customer as CustomerDB;
}

// ========== 商机 CRUD ==========

export async function getOpportunities(userId: string, filters?: {
  stage?: string;
  customer_id?: string;
}, page = 1, pageSize = 20) {
  const supabase = getSupabaseAdmin();
  
  let query = supabase
    .from('opportunities')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (filters?.stage) {
    query = query.eq('stage', filters.stage);
  }
  if (filters?.customer_id) {
    query = query.eq('customer_id', filters.customer_id);
  }
  
  const offset = (page - 1) * pageSize;
  query = query.range(offset, offset + pageSize - 1);
  
  const { data, error, count } = await query;
  
  if (error) throw error;
  
  return { data: data as OpportunityDB[], total: count || 0, page, pageSize };
}

export async function createOpportunity(userId: string, opportunity: Omit<OpportunityDB, 'id' | 'user_id' | 'created_at' | 'updated_at'>) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('opportunities')
    .insert({ ...opportunity, user_id: userId })
    .select()
    .single();
  
  if (error) throw error;
  
  return data as OpportunityDB;
}

export async function updateOpportunity(userId: string, opportunityId: string, updates: Partial<OpportunityDB>) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('opportunities')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('user_id', userId)
    .eq('id', opportunityId)
    .select()
    .single();
  
  if (error) throw error;
  
  return data as OpportunityDB;
}

export async function deleteOpportunity(userId: string, opportunityId: string) {
  const supabase = getSupabaseAdmin();
  
  const { error } = await supabase
    .from('opportunities')
    .delete()
    .eq('user_id', userId)
    .eq('id', opportunityId);
  
  if (error) throw error;
  
  return true;
}

// 商机阶段统计
export async function getOpportunityStats(userId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('opportunities')
    .select('stage, amount')
    .eq('user_id', userId);
  
  if (error) throw error;
  
  const stats = {
    initial: { count: 0, amount: 0 },
    requirement: { count: 0, amount: 0 },
    proposal: { count: 0, amount: 0 },
    negotiation: { count: 0, amount: 0 },
    won: { count: 0, amount: 0 },
    lost: { count: 0, amount: 0 },
  };
  
  (data as OpportunityDB[]).forEach((opp) => {
    const stage = opp.stage as keyof typeof stats;
    if (stats[stage]) {
      stats[stage].count++;
      stats[stage].amount += Number(opp.amount) || 0;
    }
  });
  
  return stats;
}

// ========== 任务 CRUD ==========

export async function getTasks(userId: string, filters?: {
  status?: string;
  type?: string;
  customer_id?: string;
}, page = 1, pageSize = 20) {
  const supabase = getSupabaseAdmin();
  
  let query = supabase
    .from('tasks')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .order('due_time', { ascending: true });
  
  if (filters?.status) {
    query = query.eq('status', filters.status);
  }
  if (filters?.type) {
    query = query.eq('type', filters.type);
  }
  if (filters?.customer_id) {
    query = query.eq('customer_id', filters.customer_id);
  }
  
  const offset = (page - 1) * pageSize;
  query = query.range(offset, offset + pageSize - 1);
  
  const { data, error, count } = await query;
  
  if (error) throw error;
  
  return { data: data as TaskDB[], total: count || 0, page, pageSize };
}

export async function createTask(userId: string, task: Omit<TaskDB, 'id' | 'user_id' | 'created_at' | 'updated_at'>) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('tasks')
    .insert({ ...task, user_id: userId })
    .select()
    .single();
  
  if (error) throw error;
  
  return data as TaskDB;
}

export async function updateTask(userId: string, taskId: string, updates: Partial<TaskDB>) {
  const supabase = getSupabaseAdmin();
  
  // 如果完成，记录完成时间
  if (updates.status === 'completed') {
    updates.completed_time = new Date().toISOString();
  }
  
  const { data, error } = await supabase
    .from('tasks')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('user_id', userId)
    .eq('id', taskId)
    .select()
    .single();
  
  if (error) throw error;
  
  return data as TaskDB;
}

export async function deleteTask(userId: string, taskId: string) {
  const supabase = getSupabaseAdmin();
  
  const { error } = await supabase
    .from('tasks')
    .delete()
    .eq('user_id', userId)
    .eq('id', taskId);
  
  if (error) throw error;
  
  return true;
}

// ========== 跟进记录 CRUD ==========

export async function getFollowUpRecords(userId: string, customerId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('follow_up_records')
    .select('*')
    .eq('user_id', userId)
    .eq('customer_id', customerId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  
  return data as FollowUpRecordDB[];
}

// ================== 自动化规则相关 ==================

// 自动化规则类型
export interface AutomationFlowDB {
  id: string;
  user_id: string;
  name: string;
  trigger_type: string; // 'new_lead' | 'email_opened' | 'email_clicked' | 'time_based' | 'status_change' | 'days_no_follow_up'
  trigger_config: Record<string, unknown>;
  action_type: string; // 'send_email' | 'create_task' | 'update_status' | 'notify'
  action_config: Record<string, unknown>;
  status: string; // 'active' | 'paused' | 'deleted'
  execution_count: number;
  last_execution_time?: string;
  created_at: string;
  updated_at: string;
}

// 获取自动化规则列表
export async function getAutomationFlows(
  userId: string,
  options?: { status?: string; page?: number; pageSize?: number }
): Promise<{ data: AutomationFlowDB[]; total: number; page: number; pageSize: number }> {
  const supabase = getSupabaseAdmin();
  const page = options?.page || 1;
  const pageSize = options?.pageSize || 20;
  const offset = (page - 1) * pageSize;

  let query = supabase
    .from('automation_flows')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .neq('status', 'deleted')
    .order('created_at', { ascending: false });

  if (options?.status) {
    query = query.eq('status', options.status);
  }

  const { data, error, count } = await query.range(offset, offset + pageSize - 1);

  if (error) throw error;

  return {
    data: data as AutomationFlowDB[],
    total: count || 0,
    page,
    pageSize
  };
}

// 获取单个自动化规则
export async function getAutomationFlowById(userId: string, flowId: string): Promise<AutomationFlowDB | null> {
  const supabase = getSupabaseAdmin();

  const { data, error } = await supabase
    .from('automation_flows')
    .select('*')
    .eq('user_id', userId)
    .eq('id', flowId)
    .single();

  if (error) return null;

  return data as AutomationFlowDB;
}

// 创建自动化规则
export async function createAutomationFlow(
  userId: string,
  flowData: {
    name: string;
    trigger_type: string;
    trigger_config?: Record<string, unknown>;
    action_type: string;
    action_config?: Record<string, unknown>;
  }
): Promise<AutomationFlowDB> {
  const supabase = getSupabaseAdmin();

  const { data, error } = await supabase
    .from('automation_flows')
    .insert({
      user_id: userId,
      name: flowData.name,
      trigger_type: flowData.trigger_type,
      trigger_config: flowData.trigger_config || {},
      action_type: flowData.action_type,
      action_config: flowData.action_config || {},
      status: 'active',
      execution_count: 0
    })
    .select()
    .single();

  if (error) throw error;

  return data as AutomationFlowDB;
}

// 更新自动化规则
export async function updateAutomationFlow(
  userId: string,
  flowId: string,
  updates: Partial<{
    name: string;
    trigger_type: string;
    trigger_config: Record<string, unknown>;
    action_type: string;
    action_config: Record<string, unknown>;
    status: string;
  }>
): Promise<AutomationFlowDB | null> {
  const supabase = getSupabaseAdmin();

  const { data, error } = await supabase
    .from('automation_flows')
    .update({
      ...updates,
      updated_at: new Date().toISOString()
    })
    .eq('user_id', userId)
    .eq('id', flowId)
    .select()
    .single();

  if (error) return null;

  return data as AutomationFlowDB;
}

// 启用/停用自动化规则
export async function toggleAutomationFlowStatus(
  userId: string,
  flowId: string,
  status: 'active' | 'paused'
): Promise<AutomationFlowDB | null> {
  const supabase = getSupabaseAdmin();

  const { data, error } = await supabase
    .from('automation_flows')
    .update({
      status,
      updated_at: new Date().toISOString()
    })
    .eq('user_id', userId)
    .eq('id', flowId)
    .select()
    .single();

  if (error) return null;

  return data as AutomationFlowDB;
}

// 删除自动化规则（软删除）
export async function deleteAutomationFlow(userId: string, flowId: string): Promise<boolean> {
  const supabase = getSupabaseAdmin();

  const { error } = await supabase
    .from('automation_flows')
    .update({
      status: 'deleted',
      updated_at: new Date().toISOString()
    })
    .eq('user_id', userId)
    .eq('id', flowId);

  return !error;
}

// 获取活跃的自动化规则数量
export async function getActiveAutomationFlowsCount(userId: string): Promise<number> {
  const supabase = getSupabaseAdmin();

  const { count, error } = await supabase
    .from('automation_flows')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('status', 'active');

  if (error) return 0;

  return count || 0;
}

export async function createFollowUpRecord(userId: string, record: Omit<FollowUpRecordDB, 'id' | 'user_id' | 'created_at'>) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('follow_up_records')
    .insert({ ...record, user_id: userId })
    .select()
    .single();
  
  if (error) throw error;
  
  // 更新客户的最近跟进时间
  await supabase
    .from('customers')
    .update({
      last_follow_up_time: new Date().toISOString(),
      next_follow_up_time: record.next_time,
      updated_at: new Date().toISOString(),
    })
    .eq('id', record.customer_id);
  
  return data as FollowUpRecordDB;
}

// ========== 邮件记录 ==========

export async function getEmailRecords(userId: string, page = 1, pageSize = 20) {
  const supabase = getSupabaseAdmin();
  
  const offset = (page - 1) * pageSize;
  
  const { data, error, count } = await supabase
    .from('email_records')
    .select('*', { count: 'exact' })
    .eq('user_id', userId)
    .order('sent_time', { ascending: false })
    .range(offset, offset + pageSize - 1);
  
  if (error) throw error;
  
  return { data: data as EmailRecordDB[], total: count || 0, page, pageSize };
}

// ========== 营销活动 ==========

export async function getCampaigns(userId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('campaigns')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  
  return data as CampaignDB[];
}

// ========== 仪表盘统计 ==========

export async function getDashboardStats(userId: string) {
  const supabase = getSupabaseAdmin();
  
  // 获取今日新增线索数
  const today = new Date().toISOString().split('T')[0];
  const { count: todayLeads } = await supabase
    .from('leads')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .gte('created_at', today);
  
  // 获取跟进中客户数
  const { count: followingCustomers } = await supabase
    .from('customers')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('status', 'following');
  
  // 获取已成交客户数
  const { count: wonCustomers } = await supabase
    .from('customers')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('status', 'won');
  
  // 获取客户总数
  const { count: totalCustomers } = await supabase
    .from('customers')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId);
  
  // 获取待完成任务数
  const { count: pendingTasks } = await supabase
    .from('tasks')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('status', 'pending');
  
  // 获取商机金额统计
  const { data: oppStats } = await supabase
    .from('opportunities')
    .select('stage, amount')
    .eq('user_id', userId);
  
  const totalAmount = (oppStats || []).reduce((sum, opp) => sum + (Number(opp.amount) || 0), 0);
  const wonAmount = (oppStats || []).filter(opp => opp.stage === 'won').reduce((sum, opp) => sum + (Number(opp.amount) || 0), 0);
  
  // 计算转化率
  const conversionRate = (totalCustomers ?? 0) > 0 ? ((wonCustomers ?? 0) / (totalCustomers ?? 1) * 100).toFixed(1) : '0';
  
  // 按客户类型统计
  const { data: typeStats } = await supabase
    .from('customers')
    .select('customer_type')
    .eq('user_id', userId);
  
  const typeDistribution = {
    full_designer: 0,
    building_materials: 0,
  };
  (typeStats || []).forEach((c) => {
    if (typeDistribution[c.customer_type as keyof typeof typeDistribution] !== undefined) {
      typeDistribution[c.customer_type as keyof typeof typeDistribution]++;
    }
  });
  
  // 按地区统计
  const { data: regionStats } = await supabase
    .from('customers')
    .select('region')
    .eq('user_id', userId);
  
  const regionDistribution: Record<string, number> = {};
  (regionStats || []).forEach((c) => {
    if (c.region) {
      regionDistribution[c.region] = (regionDistribution[c.region] || 0) + 1;
    }
  });
  
  // 近7天线索趋势
  const last7Days = [];
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    
    const { count: dayCount } = await supabase
      .from('leads')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .gte('created_at', dateStr)
      .lt('created_at', date.toISOString().split('T')[0] + 'T23:59:59');
    
    last7Days.push({
      date: dateStr,
      count: dayCount || 0,
    });
  }
  
  // 最近跟进记录（作为活动动态）
  const { data: recentFollowUps } = await supabase
    .from('follow_up_records')
    .select('id, customer_id, type, content, created_at')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(10);
  
  return {
    todayNewLeads: todayLeads || 0,
    followingCustomers: followingCustomers || 0,
    wonCustomers: wonCustomers || 0,
    totalCustomers: totalCustomers || 0,
    conversionRate: conversionRate,
    pendingTasks: pendingTasks || 0,
    totalAmount: totalAmount,
    wonAmount: wonAmount,
    typeDistribution,
    regionDistribution,
    weeklyLeads: last7Days,
    recentActivities: recentFollowUps || [],
  };
}

// ========== 公海池 ==========

export async function getPoolCustomers(releaseDays: number = 30) {
  const supabase = getSupabaseAdmin();
  
  const cutoffDate = new Date();
  cutoffDate.setDate(cutoffDate.getDate() - releaseDays);
  
  const { data, error, count } = await supabase
    .from('customers')
    .select('*', { count: 'exact' })
    .or(`last_follow_up_time.lt.${cutoffDate.toISOString()},last_follow_up_time.is.null`)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  
  return { data: data as CustomerDB[], total: count || 0 };
}

export async function claimCustomer(userId: string, customerId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('customers')
    .update({
      user_id: userId,
      status: 'new',
      last_follow_up_time: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    })
    .eq('id', customerId)
    .select()
    .single();
  
  if (error) throw error;
  
  return data as CustomerDB;
}

// ========== 团队成员 ==========

export async function getTeamMembers(userId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('team_members')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  
  return data;
}

// ========== 用户角色 ==========

export async function getUserRole(userId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('user_roles')
    .select('*')
    .eq('user_id', userId)
    .single();
  
  if (error) {
    // 如果没有角色记录，返回默认member
    return { role: 'member' };
  }
  
  return data;
}

export async function setUserRole(userId: string, role: 'admin' | 'member') {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('user_roles')
    .upsert({ user_id: userId, role, updated_at: new Date().toISOString() })
    .select()
    .single();
  
  if (error) throw error;
  
  return data;
}

// 检查是否有管理员
export async function hasAdmin() {
  const supabase = getSupabaseAdmin();
  
  const { count } = await supabase
    .from('user_roles')
    .select('*', { count: 'exact', head: true })
    .eq('role', 'admin');
  
  return (count || 0) > 0;
}

// ========== 辅助查询函数 ==========

// 获取单个线索详情
export async function getLeadById(userId: string, leadId: string) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('leads')
    .select('*')
    .eq('user_id', userId)
    .eq('id', leadId)
    .single();
  
  if (error) throw error;
  
  return data as LeadDB;
}

// 检查客户手机号是否重复
export async function checkDuplicateCustomer(userId: string, phone: string | null) {
  if (!phone) return null;
  
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('customers')
    .select('*')
    .eq('user_id', userId)
    .eq('phone', phone)
    .single();
  
  if (error) {
    // 没找到说明不重复
    return null;
  }
  
  return data as CustomerDB;
}

// 检查线索手机号是否重复
export async function checkDuplicateLead(userId: string, phone: string | null) {
  if (!phone) return null;
  
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('leads')
    .select('*')
    .eq('user_id', userId)
    .eq('phone', phone)
    .single();
  
  if (error) {
    // 没找到说明不重复
    return null;
  }
  
  return data as LeadDB;
}

// 获取所有跟进记录（用于仪表盘）
export async function getAllFollowUpRecords(userId: string, limit = 20) {
  const supabase = getSupabaseAdmin();
  
  const { data, error } = await supabase
    .from('follow_up_records')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit);
  
  if (error) throw error;
  
  return data as FollowUpRecordDB[];
}