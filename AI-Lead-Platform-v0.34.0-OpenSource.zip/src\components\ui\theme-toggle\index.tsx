'use client';

import React from 'react';
import { Button } from '@/components/ui/button';
import { Sun, Moon } from 'lucide-react';
import { useTheme } from '@/lib/theme-context';

export function ThemeToggle() {
  const { theme, toggleTheme } = useTheme();

  return (
    <Button
      variant="ghost"
      size="icon"
      onClick={toggleTheme}
      className="h-9 w-9 rounded-full transition-colors"
      title={theme === 'dark' ? '切换到亮色模式' : '切换到暗色模式'}
    >
      {theme === 'dark' ? (
        <Sun className="h-5 w-5 text-[#94a3b8] hover:text-[#f8fafc]" />
      ) : (
        <Moon className="h-5 w-5 text-[#4a5568] hover:text-[#1a1a2e]" />
      )}
    </Button>
  );
}