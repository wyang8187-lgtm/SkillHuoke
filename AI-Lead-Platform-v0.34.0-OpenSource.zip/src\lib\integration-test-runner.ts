import {
  buildIntegrationStatuses,
  getRawEnvValue,
  type IntegrationId,
} from './integration-diagnostics';

export type IntegrationTestStatus = 'success' | 'failed' | 'unconfigured';

export type IntegrationErrorCategory =
  | 'missing_config'
  | 'invalid_key'
  | 'permission_denied'
  | 'quota_exceeded'
  | 'rate_limited'
  | 'network_error'
  | 'proxy_error'
  | 'timeout'
  | 'service_error'
  | 'unknown';

export interface IntegrationTestResult {
  serviceId: string;
  status: IntegrationTestStatus;
  category: IntegrationErrorCategory;
  message: string;
  suggestion: string;
  httpStatus?: number;
  latencyMs: number;
  testedAt: string;
}

type Fetcher = typeof fetch;

const TEST_QUERY = 'SkillHuoke connection test';

export function mapIntegrationError(status: number, text = ''): Pick<IntegrationTestResult, 'category' | 'message' | 'suggestion'> {
  const lower = text.toLowerCase();
  if (status === 400) {
    return {
      category: 'service_error',
      message: '外部服务认为请求参数不正确。',
      suggestion: '请检查对应服务的配置项是否填写完整，尤其是搜索引擎 CX、Endpoint 或发件邮箱。',
    };
  }
  if (status === 401) {
    return {
      category: 'invalid_key',
      message: '密钥无效或已被撤销。',
      suggestion: '请到对应平台重新复制 API Key，保存到 .env 后重启后端。',
    };
  }
  if (status === 403) {
    return {
      category: 'permission_denied',
      message: '权限不足或服务没有启用。',
      suggestion: '请确认云平台已启用对应 API，并检查密钥的 API 限制。',
    };
  }
  if (status === 402 || lower.includes('quota') || lower.includes('billing')) {
    return {
      category: 'quota_exceeded',
      message: '额度、账单或配额不足。',
      suggestion: '请检查服务商后台的免费额度、账单状态和每日调用限制。',
    };
  }
  if (status === 429) {
    return {
      category: 'rate_limited',
      message: '请求被限流。',
      suggestion: '请稍后再测，或检查服务商后台的并发限制与每日额度。',
    };
  }
  if (status >= 500) {
    return {
      category: 'service_error',
      message: '外部服务暂时异常。',
      suggestion: '请稍后重试；如果持续失败，再检查网络代理或服务状态页。',
    };
  }
  return {
    category: 'unknown',
    message: '连接测试失败。',
    suggestion: '请检查网络、代理和服务商后台配置。',
  };
}

function requestForService(
  serviceId: IntegrationId,
  env: NodeJS.ProcessEnv | Record<string, string | undefined>
): { url: string; init: RequestInit } | null {
  if (serviceId === 'openai') {
    const baseUrl = env.OPENAI_BASE_URL?.trim() || 'https://api.openai.com/v1';
    return {
      url: `${baseUrl.replace(/\/$/, '')}/models`,
      init: { headers: { Authorization: `Bearer ${getRawEnvValue('openai', 'OPENAI_API_KEY', env as NodeJS.ProcessEnv)}` } },
    };
  }
  if (serviceId === 'deepseek') {
    const baseUrl = env.DEEPSEEK_BASE_URL?.trim() || 'https://api.deepseek.com/v1';
    return {
      url: `${baseUrl.replace(/\/$/, '')}/chat/completions`,
      init: {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${getRawEnvValue('deepseek', 'DEEPSEEK_API_KEY', env as NodeJS.ProcessEnv)}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: env.DEEPSEEK_MODEL?.trim() || 'deepseek-chat',
          messages: [{ role: 'user', content: 'ping' }],
          max_tokens: 1,
        }),
      },
    };
  }
  if (serviceId === 'google-search') {
    const url = new URL('https://www.googleapis.com/customsearch/v1');
    url.searchParams.set('key', getRawEnvValue('google-search', 'GOOGLE_SEARCH_API_KEY', env as NodeJS.ProcessEnv));
    url.searchParams.set('cx', getRawEnvValue('google-search', 'GOOGLE_SEARCH_CX', env as NodeJS.ProcessEnv));
    url.searchParams.set('q', TEST_QUERY);
    url.searchParams.set('num', '1');
    return { url: url.toString(), init: {} };
  }
  if (serviceId === 'serpapi') {
    const url = new URL('https://serpapi.com/search.json');
    url.searchParams.set('api_key', getRawEnvValue('serpapi', 'SERPAPI_KEY', env as NodeJS.ProcessEnv));
    url.searchParams.set('engine', 'google');
    url.searchParams.set('q', TEST_QUERY);
    url.searchParams.set('num', '1');
    return { url: url.toString(), init: {} };
  }
  if (serviceId === 'bing-search') {
    const endpoint = env.BING_SEARCH_ENDPOINT?.trim() || 'https://api.bing.microsoft.com/v7.0/search';
    const url = new URL(endpoint);
    url.searchParams.set('q', TEST_QUERY);
    url.searchParams.set('count', '1');
    return {
      url: url.toString(),
      init: { headers: { 'Ocp-Apim-Subscription-Key': getRawEnvValue('bing-search', 'BING_SEARCH_API_KEY', env as NodeJS.ProcessEnv) } },
    };
  }
  if (serviceId === 'resend') {
    return {
      url: 'https://api.resend.com/domains',
      init: { headers: { Authorization: `Bearer ${getRawEnvValue('resend', 'RESEND_API_KEY', env as NodeJS.ProcessEnv)}` } },
    };
  }
  if (serviceId === 'supabase') {
    const baseUrl = getRawEnvValue('supabase', 'COZE_SUPABASE_URL', env as NodeJS.ProcessEnv).replace(/\/$/, '');
    const anonKey = getRawEnvValue('supabase', 'COZE_SUPABASE_ANON_KEY', env as NodeJS.ProcessEnv);
    return {
      url: `${baseUrl}/rest/v1/`,
      init: {
        method: 'GET',
        headers: {
          apikey: anonKey,
          Authorization: `Bearer ${anonKey}`,
        },
      },
    };
  }
  return null;
}

function sanitizeUrl(serviceId: string, url: string) {
  if (serviceId === 'google-search' || serviceId === 'serpapi') {
    const parsed = new URL(url);
    parsed.searchParams.delete('key');
    parsed.searchParams.delete('api_key');
    return parsed.toString();
  }
  return url;
}

export async function runIntegrationTest(
  serviceId: string,
  env: NodeJS.ProcessEnv | Record<string, string | undefined> = process.env,
  fetcher: Fetcher = fetch
): Promise<IntegrationTestResult> {
  const started = Date.now();
  const status = buildIntegrationStatuses(env).find((item) => item.id === serviceId);
  const base = { serviceId, latencyMs: 0, testedAt: new Date().toISOString() };

  if (!status) {
    return {
      ...base,
      status: 'failed',
      category: 'unknown',
      message: '未知接口，已拒绝测试。',
      suggestion: '只能测试系统内置的接口服务，不能从前端传入自定义 URL。',
    };
  }

  if (!status.configured) {
    return {
      ...base,
      status: 'unconfigured',
      category: 'missing_config',
      message: `缺少配置：${status.missingEnv.join('、')}`,
      suggestion: '请在项目根目录 .env 中补齐这些变量，保存后重启后端。',
    };
  }

  const request = requestForService(status.id, env);
  if (!request) {
    return {
      ...base,
      status: 'failed',
      category: 'unknown',
      message: '暂不支持该接口测试。',
      suggestion: '请先查看配置状态，确认接口是否在当前版本支持。',
    };
  }

  try {
    const timeoutSignal = AbortSignal.timeout(15000);
    const response = await fetcher(request.url, {
      ...request.init,
      signal: timeoutSignal,
    });
    const latencyMs = Date.now() - started;
    const text = await response.text().catch(() => '');

    if (!response.ok) {
      const mapped = mapIntegrationError(response.status, text);
      return {
        ...base,
        ...mapped,
        status: 'failed',
        httpStatus: response.status,
        latencyMs,
        testedAt: new Date().toISOString(),
      };
    }

    return {
      ...base,
      status: 'success',
      category: 'unknown',
      message: '连接测试成功，接口可以访问。',
      suggestion: `已完成只读轻量测试：${sanitizeUrl(serviceId, request.url)}`,
      httpStatus: response.status,
      latencyMs,
      testedAt: new Date().toISOString(),
    };
  } catch (error) {
    const latencyMs = Date.now() - started;
    const name = error instanceof Error ? error.name : '';
    const message = error instanceof Error ? error.message : String(error);
    const category: IntegrationErrorCategory = name === 'AbortError'
      ? 'timeout'
      : /proxy/i.test(message)
        ? 'proxy_error'
        : 'network_error';

    return {
      ...base,
      status: 'failed',
      category,
      message: category === 'timeout' ? '连接测试超时。' : '网络连接失败。',
      suggestion: '请检查网络、海外访问能力和代理设置，然后重启后端再测试。',
      latencyMs,
      testedAt: new Date().toISOString(),
    };
  }
}
