import { NextRequest, NextResponse } from 'next/server';

// 数据导出API
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { dataType, fields, filters, format } = body;

    // dataType: customers, leads, opportunities, tasks
    // fields: 要导出的字段列表
    // filters: 筛选条件
    // format: csv, excel

    if (!dataType) {
      return NextResponse.json({ error: '请选择导出数据类型' }, { status: 400 });
    }

    // 模拟导出数据
    const mockData: Record<string, unknown[]> = {
      customers: [
        { id: 'C001', name: '深圳市优筑设计中心', phone: '13983796058', company: '优筑设计', region: '深圳', grade: 'A', type: '设计师' },
        { id: 'C002', name: '佛山市家居贸易公司', phone: '13800138002', company: '家居贸易', region: '佛山', grade: 'B', type: '建材外贸' },
      ],
      leads: [
        { id: 'L001', name: '广州设计师工作室', phone: '13600136001', source: 'AI搜索', region: '广州' },
        { id: 'L002', name: '东莞建材采购商', phone: '13500135002', source: '展会', region: '东莞' },
      ],
      opportunities: [
        { id: 'O001', name: '写字楼定制项目', customer: '优筑设计', amount: 150000, stage: '报价', expected_date: '2025-03-01' },
        { id: 'O002', name: '别墅全屋定制', customer: '家居贸易', amount: 300000, stage: '需求确认', expected_date: '2025-04-15' },
      ],
      tasks: [
        { id: 'T001', title: '跟进优筑设计', customer: '优筑设计', due_date: '2025-02-20', status: '待完成' },
        { id: 'T002', title: '发送报价单', customer: '家居贸易', due_date: '2025-02-25', status: '待完成' },
      ],
    };

    const data = mockData[dataType] || [];

    // 选择导出字段
    const exportFields = fields || Object.keys(data[0] || {});
    const headers = exportFields;

    // 生成CSV内容
    const csvLines = [
      headers.join(','),
      ...data.map(row => 
        headers.map((field: string) => {
          const value = (row as Record<string, unknown>)[field];
          // 处理包含逗号的值
          if (typeof value === 'string' && value.includes(',')) {
            return `"${value}"`;
          }
          return value ?? '';
        }).join(',')
      )
    ];

    const csvContent = csvLines.join('\n');

    // 返回导出结果（模拟）
    return NextResponse.json({
      success: true,
      data: {
        total: data.length,
        format: format || 'csv',
        content: csvContent,
        filename: `${dataType}_export_${Date.now()}.csv`,
      },
      message: `已导出${data.length}条数据`,
    });
  } catch (error) {
    console.error('导出失败:', error);
    return NextResponse.json({ error: '导出处理失败' }, { status: 500 });
  }
}

// 获取导出历史
export async function GET(request: NextRequest) {
  // 模拟导出历史
  const history = [
    {
      id: 'EXP001',
      dataType: 'customers',
      total: 150,
      format: 'csv',
      created_at: '2025-02-15T10:30:00Z',
      operator: '张三',
    },
    {
      id: 'EXP002',
      dataType: 'leads',
      total: 80,
      format: 'excel',
      created_at: '2025-02-14T14:20:00Z',
      operator: '李四',
    },
    {
      id: 'EXP003',
      dataType: 'opportunities',
      total: 25,
      format: 'csv',
      created_at: '2025-02-13T09:15:00Z',
      operator: '张三',
    },
  ];

  return NextResponse.json({
    success: true,
    data: history,
  });
}