'use client';

import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, Check, CheckCheck, Settings, X, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Notification {
  id: string;
  type: string;
  title: string;
  content: string;
  created_at: string;
  is_read: boolean;
  priority: string;
  customer_id?: string;
  customer_name?: string;
  opportunity_id?: string;
  opportunity_name?: string;
  operator_name?: string;
}

interface NotificationBellProps {
  className?: string;
}

export function NotificationBell({ className }: NotificationBellProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showPanel, setShowPanel] = useState(false);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadNotifications();
    // 每5分钟刷新
    const interval = setInterval(loadNotifications, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // 点击外部关闭面板
    const handleClickOutside = (event: MouseEvent) => {
      if (panelRef.current && !panelRef.current.contains(event.target as Node)) {
        setShowPanel(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadNotifications = async () => {
    try {
      const res = await fetch('/api/notifications?limit=20');
      const data = await res.json();
      if (data.success) {
        setNotifications(data.data);
        setUnreadCount(data.unread_count);
      }
    } catch (error) {
      console.error('加载通知失败:', error);
    }
  };

  const handleMarkRead = async (notificationId: string) => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'mark_read',
          notification_ids: [notificationId],
        }),
      });
      
      if (res.ok) {
        setNotifications(prev =>
          prev.map(n => n.id === notificationId ? { ...n, is_read: true } : n)
        );
        setUnreadCount(prev => Math.max(0, prev - 1));
      }
    } catch (error) {
      console.error('标记已读失败:', error);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      const res = await fetch('/api/notifications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'mark_all_read' }),
      });
      
      if (res.ok) {
        setNotifications(prev => prev.map(n => ({ ...n, is_read: true })));
        setUnreadCount(0);
      }
    } catch (error) {
      console.error('全部已读失败:', error);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'follow_up_reminder':
        return '🔔';
      case 'opportunity_change':
        return '📊';
      case 'pool_claim':
        return '👥';
      case 'pool_return':
        return '↩️';
      case 'system_announcement':
        return '📢';
      case 'email_opened':
        return '📧';
      case 'whatsapp_reply':
        return '💬';
      default:
        return '📌';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'follow_up_reminder':
        return 'bg-orange-500/20';
      case 'opportunity_change':
        return 'bg-blue-500/20';
      case 'pool_claim':
        return 'bg-green-500/20';
      case 'pool_return':
        return 'bg-gray-500/20';
      case 'system_announcement':
        return 'bg-red-500/20';
      case 'email_opened':
        return 'bg-purple-500/20';
      case 'whatsapp_reply':
        return 'bg-green-500/20';
      default:
        return 'bg-gray-500/20';
    }
  };

  const formatTime = (dateStr: string) => {
    const date = new Date(dateStr);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    
    if (diff < 60000) return '刚刚';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
    if (diff < 604800000) return `${Math.floor(diff / 86400000)}天前`;
    return date.toLocaleDateString('zh-CN');
  };

  return (
    <div className={cn('relative', className)} ref={panelRef}>
      {/* 铃铛按钮 */}
      <Button
        variant="ghost"
        size="icon"
        className="h-10 w-10 text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)]"
        onClick={() => setShowPanel(!showPanel)}
      >
        <Bell className="h-5 w-5" />
        {unreadCount > 0 && (
          <Badge 
            className="absolute -top-1 -right-1 h-5 min-w-5 px-1 bg-red-500 text-white text-xs flex items-center justify-center"
          >
            {unreadCount > 99 ? '99+' : unreadCount}
          </Badge>
        )}
      </Button>

      {/* 通知面板 */}
      {showPanel && (
        <div className="absolute top-full right-0 mt-2 w-80 bg-[var(--bg-card)] border border-[var(--border-color)] rounded-lg shadow-lg z-50">
          {/* 头部 */}
          <div className="flex items-center justify-between p-3 border-b border-[var(--border-color)]">
            <div className="flex items-center gap-2">
              <span className="font-medium text-[var(--text-primary)]">通知中心</span>
              {unreadCount > 0 && (
                <Badge className="bg-red-500/20 text-red-400 text-xs">
                  {unreadCount} 条未读
                </Badge>
              )}
            </div>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2 text-xs text-[var(--text-muted)] hover:text-[var(--text-primary)]"
                  onClick={handleMarkAllRead}
                >
                  <CheckCheck className="w-3 h-3 mr-1" />
                  全部已读
                </Button>
              )}
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0 text-[var(--text-muted)] hover:text-[var(--text-primary)]"
                onClick={() => setShowPanel(false)}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* 通知列表 */}
          <div className="max-h-[400px] overflow-y-auto">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-[var(--text-muted)]">
                <Bell className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>暂无通知</p>
              </div>
            ) : (
              notifications.map(notification => (
                <div
                  key={notification.id}
                  className={cn(
                    'p-3 border-b border-[var(--border-color)] hover:bg-[var(--bg-hover)] cursor-pointer transition-colors',
                    !notification.is_read && 'bg-blue-500/5'
                  )}
                  onClick={() => !notification.is_read && handleMarkRead(notification.id)}
                >
                  <div className="flex items-start gap-3">
                    {/* 类型图标 */}
                    <div className={cn(
                      'w-8 h-8 rounded-lg flex items-center justify-center text-sm',
                      getTypeColor(notification.type)
                    )}>
                      {getTypeIcon(notification.type)}
                    </div>
                    
                    {/* 内容 */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <span className={cn(
                          'font-medium text-sm',
                          notification.is_read ? 'text-[var(--text-secondary)]' : 'text-[var(--text-primary)]'
                        )}>
                          {notification.title}
                        </span>
                        <span className="text-xs text-[var(--text-muted)] flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {formatTime(notification.created_at)}
                        </span>
                      </div>
                      <p className={cn(
                        'text-xs line-clamp-2',
                        notification.is_read ? 'text-[var(--text-muted)]' : 'text-[var(--text-secondary)]'
                      )}>
                        {notification.content}
                      </p>
                    </div>
                    
                    {/* 未读标记 */}
                    {!notification.is_read && (
                      <div className="w-2 h-2 rounded-full bg-blue-500 mt-2" />
                    )}
                  </div>
                </div>
              ))
            )}
          </div>

          {/* 底部 */}
          <div className="p-3 border-t border-[var(--border-color)]">
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-xs text-[var(--text-muted)] hover:text-[var(--text-primary)]"
              onClick={() => {
                window.location.href = '/notifications';
                setShowPanel(false);
              }}
            >
              <Settings className="w-3 h-3 mr-1" />
              通知设置
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}