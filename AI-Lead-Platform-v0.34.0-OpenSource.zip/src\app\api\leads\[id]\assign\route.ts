// 线索分配 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 分配线索给团队成员
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const body = await req.json();
    const { assigneeId, assigneeName } = body;

    if (!assigneeId) {
      return NextResponse.json({ error: '请指定分配对象' }, { status: 400 });
    }

    // 更新线索的负责人
    const lead = await dbService.updateLead(user.id, id, {
      assignee_id: assigneeId,
      assignee_name: assigneeName,
      status: '已跟进', // 分配后状态变为已跟进
    });

    return NextResponse.json({ 
      success: true, 
      data: lead,
      message: '线索已成功分配'
    });
  } catch (error) {
    console.error('线索分配失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '线索分配失败' 
    }, { status: 400 });
  }
}