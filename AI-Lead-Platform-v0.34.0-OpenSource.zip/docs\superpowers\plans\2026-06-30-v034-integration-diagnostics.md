# v0.34.0 Integration Diagnostics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a read-only API integration diagnostics center that checks `.env` configuration and runs safe connection tests without exposing full secrets to the browser.

**Architecture:** Server-only libraries define integration metadata, mask sensitive values, and execute fixed allowlisted tests. Next.js route handlers expose sanitized status and test results. The `/settings/api-keys` page becomes a Chinese diagnostics console with local result history, no key inputs, and release documentation updated to v0.34.0.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, Node fetch, localStorage, Node assert tests, PowerShell packaging.

---

### Task 1: Integration Status Registry

**Files:**
- Create: `src/lib/integration-diagnostics.ts`
- Create: `tests/integration-diagnostics.test.ts`

- [ ] Write tests for masking, missing config, aliases, and proxy summaries.
- [ ] Run `corepack pnpm exec tsx tests/integration-diagnostics.test.ts` and verify it fails because the library does not exist.
- [ ] Implement service definitions for OpenAI, DeepSeek, Google Custom Search, SerpAPI, Bing Search, Resend, and Supabase.
- [ ] Ensure secret fields reveal only the last 4 characters and status output never returns a full API key.
- [ ] Run the test file again and verify it passes.

### Task 2: Server-Side Connection Test Runner

**Files:**
- Create: `src/lib/integration-test-runner.ts`
- Create: `tests/integration-test-runner.test.ts`
- Create: `src/app/api/integrations/status/route.ts`
- Create: `src/app/api/integrations/test/route.ts`

- [ ] Write tests for unknown service rejection, missing config result, HTTP error mapping, timeout mapping, and safe allowlisted request building.
- [ ] Run `corepack pnpm exec tsx tests/integration-test-runner.test.ts` and verify it fails because the runner does not exist.
- [ ] Implement real lightweight checks with fixed URLs and server-side env only.
- [ ] Implement Chinese error categories and suggested actions.
- [ ] Add route handlers returning sanitized JSON only.
- [ ] Run the test file again and verify it passes.

### Task 3: Replace API Key Page With Diagnostics UI

**Files:**
- Replace: `src/app/settings/api-keys/page.tsx`

- [ ] Render summary counters, service cards, proxy diagnostics, `.env` guidance, and safety note.
- [ ] Add single-service testing and “一键检测全部” with concurrency limit 2.
- [ ] Store only sanitized diagnostic outcomes in `localStorage` key `skillhuoke_integration_diagnostics_v034`.
- [ ] Remove all full-key inputs, save buttons, show/hide key buttons, and false encrypted database copy.

### Task 4: Release Metadata, Env Example, README

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/release-experience.ts`

- [ ] Set app version to `0.34.0`.
- [ ] Add `.env.example` variables for OpenAI, DeepSeek, Google, SerpAPI, Bing, Resend, Supabase, and proxy.
- [ ] Update release metadata with v0.34.0 title, package name, GitHub remark, highlights, and review pages.
- [ ] Add Chinese configuration guidance explaining that `.env` changes require backend restart.

### Task 5: Verification and Upload Package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.34.0-OpenSource.zip`

- [ ] Run `corepack pnpm exec tsx tests/integration-diagnostics.test.ts`.
- [ ] Run `corepack pnpm exec tsx tests/integration-test-runner.test.ts`.
- [ ] Run `corepack pnpm run ts-check`.
- [ ] Run `corepack pnpm run lint:build`.
- [ ] Run `corepack pnpm run build`.
- [ ] Start or reuse the local server and verify HTTP 200 for `/settings/api-keys`, `/api/integrations/status`, and `/release`.
- [ ] Create the ZIP while excluding `node_modules`, `.next`, `.git`, `.env`, `.env.local`, logs, and `tsconfig.tsbuildinfo`.
- [ ] Final response must include the ZIP link, login URL, key pages, GitHub remark, update summary, and verification results.

## Self-Review

- Spec coverage: The plan covers read-only `.env` diagnostics, seven service groups, masked secrets, real tests, Chinese error mapping, proxy diagnostics, localStorage safety, release docs, verification, and ZIP packaging.
- Placeholder scan: No `TBD`, open-ended “handle edge cases,” or “similar to” placeholders remain.
- Type consistency: Service IDs, route paths, localStorage key, version, and package name are consistent across tasks.
