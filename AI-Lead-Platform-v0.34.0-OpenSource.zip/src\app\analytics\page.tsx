'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Users, TrendingUp, Zap, ArrowRight } from 'lucide-react';

export default function AnalyticsPage() {
  const pathname = usePathname();

  const tabs = [
    {
      id: 'customers',
      name: '客户分析',
      icon: Users,
      path: '/analytics/customers',
      description: '客户增长趋势、行业分布、区域分布、分级占比'
    },
    {
      id: 'sales',
      name: '销售分析',
      icon: TrendingUp,
      path: '/analytics/sales',
      description: '商机漏斗、月度业绩、开发信效果、成功率'
    },
    {
      id: 'acquisition',
      name: '获客效率',
      icon: Zap,
      path: '/analytics/acquisition',
      description: '渠道对比、AI搜客效果、最佳联系时间'
    }
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">数据分析</h1>

      {/* 分析模块入口 */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {tabs.map(tab => {
          const isActive = pathname === tab.path;
          const Icon = tab.icon;
          
          return (
            <Link key={tab.id} href={tab.path}>
              <Card className={`hover:border-blue-500 transition-colors cursor-pointer ${isActive ? 'border-blue-500 bg-blue-500/5' : ''}`}>
                <CardContent className="p-6">
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`p-3 rounded-lg ${isActive ? 'bg-blue-500/20' : 'bg-muted/20'}`}>
                      <Icon className={`w-6 h-6 ${isActive ? 'text-blue-500' : 'text-muted-foreground'}`} />
                    </div>
                    <div className="flex-1">
                      <div className="font-semibold">{tab.name}</div>
                      <div className="text-sm text-muted-foreground">{tab.description}</div>
                    </div>
                    <ArrowRight className={`w-5 h-5 ${isActive ? 'text-blue-500' : 'text-muted-foreground'}`} />
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      {/* 快速概览 */}
      <Card>
        <CardContent className="p-6">
          <div className="text-center text-muted-foreground">
            <p>点击上方模块卡片进入详细数据分析页面</p>
            <p className="text-sm mt-2">数据从 Supabase 数据库实时查询，图表使用 Recharts 库展示</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}