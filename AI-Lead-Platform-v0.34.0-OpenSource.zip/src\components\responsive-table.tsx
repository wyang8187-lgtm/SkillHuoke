'use client';

import React from 'react';
import { cn } from '@/lib/utils';

interface ResponsiveTableProps {
  children: React.ReactNode;
  className?: string;
}

interface ResponsiveTableRowProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

interface ResponsiveTableCellProps {
  children: React.ReactNode;
  className?: string;
  label?: string; // 移动端显示的标签
  hideOnMobile?: boolean; // 移动端隐藏
}

interface ResponsiveTableHeaderProps {
  children: React.ReactNode;
  className?: string;
  hideOnMobile?: boolean;
}

// 响应式表格容器
export function ResponsiveTable({ children, className }: ResponsiveTableProps) {
  return (
    <div className={cn(
      "w-full",
      // 桌面端显示表格
      "hidden md:block",
      className
    )}>
      {children}
    </div>
  );
}

// 响应式卡片列表（移动端）
export function ResponsiveCardList({ children, className }: ResponsiveTableProps) {
  return (
    <div className={cn(
      "space-y-3",
      // 移动端显示
      "block md:hidden",
      className
    )}>
      {children}
    </div>
  );
}

// 响应式卡片项
export function ResponsiveCard({ 
  children, 
  className, 
  onClick 
}: ResponsiveTableRowProps) {
  return (
    <div 
      className={cn(
        "bg-[#1a1f2c] border border-[#2d3548] rounded-lg p-4",
        onClick && "cursor-pointer hover:bg-[#232a3c] transition-colors",
        className
      )}
      onClick={onClick}
    >
      {children}
    </div>
  );
}

// 卡片行（一组标签+值）
export function CardRow({ 
  label, 
  value, 
  className 
}: { 
  label: string; 
  value: React.ReactNode; 
  className?: string;
}) {
  return (
    <div className={cn("flex justify-between items-start py-1", className)}>
      <span className="text-[#64748b] text-sm">{label}</span>
      <span className="text-[#f8fafc] text-sm font-medium">{value}</span>
    </div>
  );
}

// 响应式表格头
export function ResponsiveTableHeader({ 
  children, 
  className,
  hideOnMobile 
}: ResponsiveTableHeaderProps) {
  return (
    <div className={cn(
      "px-4 py-3 text-left text-xs font-medium text-[#64748b] uppercase tracking-wider",
      // 桌面端显示
      hideOnMobile ? "" : "",
      className
    )}>
      {children}
    </div>
  );
}

// 响应式表格行
export function ResponsiveTableRow({ 
  children, 
  className, 
  onClick 
}: ResponsiveTableRowProps) {
  return (
    <tr className={cn(
      "border-b border-[#2d3548] hover:bg-[#1a1f2c] transition-colors",
      onClick && "cursor-pointer",
      className
    )} onClick={onClick}>
      {children}
    </tr>
  );
}

// 响应式表格单元格
export function ResponsiveTableCell({ 
  children, 
  className,
  label,
  hideOnMobile
}: ResponsiveTableCellProps) {
  return (
    <td className={cn(
      "px-4 py-3 text-sm text-[#f8fafc]",
      hideOnMobile && "hidden md:table-cell",
      className
    )}>
      {label ? (
        <div className="md:hidden">
          <span className="text-[#64748b]">{label}: </span>
          {children}
        </div>
      ) : (
        children
      )}
    </td>
  );
}

// 响应式操作按钮容器
export function ResponsiveActions({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex gap-2 justify-end mt-3 pt-3 border-t border-[#2d3548]">
      {children}
    </div>
  );
}

// 响应式表格包装器（自动处理桌面表格+移动卡片）
export function ResponsiveTableWrapper({ 
  tableContent,
  cardContent,
  className 
}: { 
  tableContent: React.ReactNode;
  cardContent: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("w-full", className)}>
      {/* 桌面端表格 */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          {tableContent}
        </table>
      </div>
      {/* 移动端卡片 */}
      <div className="block md:hidden space-y-3">
        {cardContent}
      </div>
    </div>
  );
}