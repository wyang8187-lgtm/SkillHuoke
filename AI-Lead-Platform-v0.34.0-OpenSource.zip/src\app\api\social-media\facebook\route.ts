import { NextRequest, NextResponse } from 'next/server';

// Facebook获客模拟API
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyword, category } = body;

    if (!keyword) {
      return NextResponse.json({ error: '请输入搜索关键词' }, { status: 400 });
    }

    // 模拟Facebook企业主页搜索结果
    const mockResults = [
      {
        id: 'fb_001',
        type: 'page',
        name: '深圳市某某家居设计',
        category: category || '家居设计',
        followers: 15000,
        likes: 12000,
        location: '深圳',
        phone: '13912345678',
        email: 'contact@shenzhen-home.com',
        website: 'https://www.shenzhen-home.com',
        description: '专注全屋定制设计，打造温馨家居',
        verified: true,
        page_url: 'https://facebook.com/shenzhen-home',
      },
      {
        id: 'fb_002',
        type: 'page',
        name: '广州某某建材商城',
        category: '建材零售',
        followers: 25000,
        likes: 20000,
        location: '广州',
        phone: '13812345679',
        email: 'sales@gz-material.com',
        website: 'https://www.gz-material.com',
        description: '一站式建材采购，品类齐全价格优惠',
        verified: true,
        page_url: 'https://facebook.com/gz-material',
      },
      {
        id: 'fb_003',
        type: 'page',
        name: '佛山某某家具定制',
        category: '家具定制',
        followers: 8000,
        likes: 6500,
        location: '佛山',
        phone: '13712345680',
        email: 'info@foshan-furniture.com',
        website: 'https://www.foshan-furniture.com',
        description: '佛山本土家具定制品牌，品质保证',
        verified: true,
        page_url: 'https://facebook.com/foshan-furniture',
      },
      {
        id: 'fb_004',
        type: 'page',
        name: '东莞某某装饰工程',
        category: '装饰工程',
        followers: 5000,
        likes: 4000,
        location: '东莞',
        phone: '13612345681',
        email: 'service@dg-decor.com',
        website: 'https://www.dg-decor.com',
        description: '专业室内装饰工程施工团队',
        verified: true,
        page_url: 'https://facebook.com/dg-decor',
      },
      {
        id: 'fb_005',
        type: 'page',
        name: '中山某某全屋定制',
        category: '全屋定制',
        followers: 3000,
        likes: 2500,
        location: '中山',
        phone: '13512345682',
        email: 'custom@zs-custom.com',
        website: 'https://www.zs-custom.com',
        description: '中山本地全屋定制服务商',
        verified: true,
        page_url: 'https://facebook.com/zs-custom',
      },
    ];

    // 根据关键词过滤
    const filteredResults = mockResults.filter(result => {
      const searchText = `${result.name} ${result.category} ${result.location} ${result.description}`.toLowerCase();
      return searchText.includes(keyword.toLowerCase());
    });

    // 过滤无手机号的结果
    const validResults = filteredResults.filter(r => r.phone && r.phone.length === 11);

    return NextResponse.json({
      success: true,
      data: validResults.length > 0 ? validResults : mockResults.filter(r => r.phone && r.phone.length === 11),
      total: validResults.length > 0 ? validResults.length : mockResults.filter(r => r.phone && r.phone.length === 11).length,
      platform: 'Facebook',
      note: '当前为模拟数据，接入真实API后可获取实时Facebook数据',
    });
  } catch (error) {
    console.error('Facebook搜索失败:', error);
    return NextResponse.json({ error: '搜索失败，请稍后重试' }, { status: 500 });
  }
}