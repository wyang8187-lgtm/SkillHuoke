'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Briefcase, Users, AlertCircle, Loader2 } from 'lucide-react';
import { SocialSearchResultCard } from '@/components/ui/social-search-card';
import { EmptyState } from '@/components/ui/empty-state';

export default function LinkedInAcquisitionPage() {
  const router = useRouter();
  const [keyword, setKeyword] = useState('');
  const [location, setLocation] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');

  const handleSearch = async () => {
    if (!keyword.trim()) {
      setError('请输入搜索关键词');
      return;
    }

    setLoading(true);
    setError('');
    setResults([]);

    try {
      const response = await fetch('/api/social-media/linkedin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword, location }),
      });

      const data = await response.json();
      
      if (data.success) {
        setResults(data.data);
        setSearched(true);
      } else {
        setError(data.error || '搜索失败');
      }
    } catch (err) {
      setError('网络错误，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToLeads = async (result: any) => {
    // 模拟添加到线索池
    console.log('添加到线索池:', result);
    // TODO: 调用实际API
  };

  const handleAddToCustomer = async (result: any) => {
    // 模拟添加到客户
    console.log('添加到客户:', result);
    // TODO: 调用实际API
  };

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="p-6">
        {/* 页面标题 */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Briefcase className="h-6 w-6 text-blue-500" />
            <h1 className="text-2xl font-bold text-[var(--foreground)]">LinkedIn获客</h1>
          </div>
          <p className="text-[var(--muted-foreground)]">
            通过LinkedIn搜索潜在客户，查找企业决策人和设计师
          </p>
        </div>

        {/* 搜索区域 */}
        <Card className="bg-[var(--card)] border-[var(--border)] mb-6">
          <CardHeader>
            <CardTitle className="text-[var(--foreground)]">搜索条件</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="block text-sm font-medium text-[var(--muted-foreground)] mb-2">
                  搜索关键词
                </label>
                <Input
                  placeholder="输入职位、公司或行业关键词..."
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  className="bg-[var(--background)] border-[var(--border)]"
                />
              </div>
              <div className="w-48">
                <label className="block text-sm font-medium text-[var(--muted-foreground)] mb-2">
                  地区筛选
                </label>
                <Select value={location} onValueChange={setLocation}>
                  <SelectTrigger className="bg-[var(--background)] border-[var(--border)]">
                    <SelectValue placeholder="不限地区" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">不限地区</SelectItem>
                    <SelectItem value="深圳">深圳</SelectItem>
                    <SelectItem value="广州">广州</SelectItem>
                    <SelectItem value="佛山">佛山</SelectItem>
                    <SelectItem value="东莞">东莞</SelectItem>
                    <SelectItem value="中山">中山</SelectItem>
                    <SelectItem value="珠海">珠海</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button 
                onClick={handleSearch}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                搜索
              </Button>
            </div>

            {error && (
              <div className="mt-4 flex items-center gap-2 text-red-500">
                <AlertCircle className="h-4 w-4" />
                <span>{error}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 搜索结果 */}
        {searched && (
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-blue-500/10 text-blue-500 border-blue-500">
                <Briefcase className="h-3 w-3 mr-1" />
                LinkedIn
              </Badge>
              <span className="text-[var(--muted-foreground)]">
                共找到 {results.length} 条有效结果（已过滤无手机号）
              </span>
            </div>
          </div>
        )}

        {/* 结果列表 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {results.map((result) => (
            <SocialSearchResultCard
              key={result.id}
              result={result}
              platform="LinkedIn"
              onAddToLeads={handleAddToLeads}
              onAddToCustomer={handleAddToCustomer}
            />
          ))}
        </div>

        {/* 空状态 */}
        {searched && results.length === 0 && !loading && (
          <EmptyState
            icon={<Users className="h-12 w-12 text-[var(--muted-foreground)]" />}
            title="未找到匹配结果"
            description="请尝试调整搜索关键词或筛选条件"
          />
        )}

        {/* 提示信息 */}
        <Card className="bg-[var(--card)] border-[var(--border)] mt-6">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
              <div className="text-sm text-[var(--muted-foreground)]">
                <p className="font-medium text-[var(--foreground)] mb-1">LinkedIn获客说明</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>当前为模拟数据演示，接入真实API后可获取实时LinkedIn数据</li>
                  <li>搜索结果已自动过滤无手机号的记录，确保联系方式有效</li>
                  <li>可直接将搜索结果转为客户或线索池</li>
                  <li>建议搜索关键词：设计师、采购经理、总经理、全屋定制等</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}