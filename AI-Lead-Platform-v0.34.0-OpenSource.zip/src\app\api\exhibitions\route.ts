import { NextRequest, NextResponse } from 'next/server';

// 展会信息模块 - 模拟展会数据

interface Exhibition {
  id: string;
  name: string;
  name_en: string;
  start_date: string;
  end_date: string;
  location: string;
  city: string;
  country: string;
  industry: string;
  exhibitor_count: number;
  expected_visitors: number;
  status: '即将开始' | '进行中' | '已结束';
  highlights: string[];
  recommended: boolean;
}

// 模拟展会数据
const mockExhibitions: Exhibition[] = [
  {
    id: 'EXH-001',
    name: '中国（广州）国际家具博览会',
    name_en: 'China International Furniture Expo Guangzhou',
    start_date: '2025-03-18',
    end_date: '2025-03-21',
    location: '广州保利世贸博览馆',
    city: '广州',
    country: '中国',
    industry: '家具/家居',
    exhibitor_count: 500,
    expected_visitors: 30000,
    status: '即将开始',
    highlights: ['全屋定制专区', '智能家居展区', '设计师论坛'],
    recommended: true,
  },
  {
    id: 'EXH-002',
    name: '深圳国际家居设计展览会',
    name_en: 'Shenzhen International Home Design Exhibition',
    start_date: '2025-04-15',
    end_date: '2025-04-18',
    location: '深圳会展中心',
    city: '深圳',
    country: '中国',
    industry: '家居设计',
    exhibitor_count: 300,
    expected_visitors: 20000,
    status: '即将开始',
    highlights: ['原创设计展', '定制家居论坛', '设计师大赛'],
    recommended: true,
  },
  {
    id: 'EXH-003',
    name: '米兰国际家具展',
    name_en: 'Salone del Mobile Milano',
    start_date: '2025-04-08',
    end_date: '2025-04-14',
    location: '米兰国际展览中心',
    city: '米兰',
    country: '意大利',
    industry: '家具/设计',
    exhibitor_count: 2000,
    expected_visitors: 300000,
    status: '即将开始',
    highlights: ['国际顶级品牌', '设计创新展区', '可持续发展论坛'],
    recommended: true,
  },
  {
    id: 'EXH-004',
    name: '中国（佛山）国际建材博览会',
    name_en: 'China International Building Materials Expo Foshan',
    start_date: '2025-05-10',
    end_date: '2025-05-13',
    location: '佛山国际会展中心',
    city: '佛山',
    country: '中国',
    industry: '建材',
    exhibitor_count: 400,
    expected_visitors: 25000,
    status: '即将开始',
    highlights: ['陶瓷专区', '板材专区', '木业专区'],
    recommended: false,
  },
  {
    id: 'EXH-005',
    name: '东莞国际家具机械及材料展',
    name_en: 'Dongguan International Furniture Machinery & Materials Fair',
    start_date: '2025-03-15',
    end_date: '2025-03-19',
    location: '东莞厚街广东现代国际展览中心',
    city: '东莞',
    country: '中国',
    industry: '家具制造',
    exhibitor_count: 350,
    expected_visitors: 18000,
    status: '即将开始',
    highlights: ['智能制造设备', '原材料专区', '技术研讨会'],
    recommended: false,
  },
  {
    id: 'EXH-006',
    name: '上海国际家具博览会',
    name_en: 'China International Furniture Expo Shanghai',
    start_date: '2025-09-08',
    end_date: '2025-09-12',
    location: '上海国家会展中心',
    city: '上海',
    country: '中国',
    industry: '家具',
    exhibitor_count: 600,
    expected_visitors: 40000,
    status: '即将开始',
    highlights: ['全屋定制', '智能家居', '外贸专区'],
    recommended: true,
  },
  {
    id: 'EXH-007',
    name: '德国科隆国际家具展',
    name_en: 'imm Cologne',
    start_date: '2025-01-13',
    end_date: '2025-01-17',
    location: '科隆国际展览中心',
    city: '科隆',
    country: '德国',
    industry: '家具',
    exhibitor_count: 1200,
    expected_visitors: 100000,
    status: '已结束',
    highlights: ['欧洲顶级品牌', '创新设计', '行业趋势发布'],
    recommended: false,
  },
  {
    id: 'EXH-008',
    name: '中国国际建筑装饰博览会',
    name_en: 'China International Building Decoration Expo',
    start_date: '2025-07-08',
    end_date: '2025-07-11',
    location: '广州国际会展中心',
    city: '广州',
    country: '中国',
    industry: '建筑装饰',
    exhibitor_count: 800,
    expected_visitors: 50000,
    status: '即将开始',
    highlights: ['定制家居', '门窗专区', '装饰材料'],
    recommended: false,
  },
];

// GET: 获取展会列表
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const industry = searchParams.get('industry');
  const status = searchParams.get('status');
  const city = searchParams.get('city');
  
  let filtered = [...mockExhibitions];
  
  if (industry) {
    filtered = filtered.filter(e => e.industry.includes(industry));
  }
  
  if (status) {
    filtered = filtered.filter(e => e.status === status);
  }
  
  if (city) {
    filtered = filtered.filter(e => e.city.includes(city));
  }
  
  // 按日期排序，即将开始的排在前面
  filtered.sort((a, b) => {
    if (a.status === '即将开始' && b.status !== '即将开始') return -1;
    if (a.status !== '即将开始' && b.status === '即将开始') return 1;
    return new Date(a.start_date).getTime() - new Date(b.start_date).getTime();
  });
  
  return NextResponse.json({
    success: true,
    data: filtered,
    total: filtered.length,
    industries: ['家具/家居', '家居设计', '建材', '家具制造', '建筑装饰'],
    cities: ['广州', '深圳', '佛山', '东莞', '上海', '米兰', '科隆'],
  });
}