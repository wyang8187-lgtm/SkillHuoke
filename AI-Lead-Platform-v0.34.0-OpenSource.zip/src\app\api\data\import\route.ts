import { NextRequest, NextResponse } from 'next/server';

// 数据导入API
export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get('file') as File;
    const dataType = formData.get('dataType') as string; // customers, leads, opportunities
    const fieldMapping = JSON.parse(formData.get('fieldMapping') as string || '{}');

    if (!file) {
      return NextResponse.json({ error: '请上传文件' }, { status: 400 });
    }

    // 读取文件内容
    const content = await file.text();
    const lines = content.split('\n').filter(line => line.trim());
    
    if (lines.length < 2) {
      return NextResponse.json({ error: '文件内容不足' }, { status: 400 });
    }

    // 解析CSV（假设第一行是标题）
    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const dataRows = lines.slice(1);

    // 模拟导入处理
    const results = {
      total: dataRows.length,
      success: 0,
      failed: 0,
      skipped: 0,
      errors: [] as { row: number; field: string; message: string }[],
      imported_ids: [] as string[],
    };

    // 模拟数据校验和导入
    for (let i = 0; i < dataRows.length; i++) {
      const row = dataRows[i].split(',').map(v => v.trim().replace(/^"|"$/g, ''));
      const rowData: Record<string, string> = {};
      
      headers.forEach((header, idx) => {
        const mappedField = fieldMapping[header] || header;
        rowData[mappedField] = row[idx] || '';
      });

      // 校验必填字段
      if (!rowData['name'] && !rowData['姓名'] && !rowData['客户名称']) {
        results.failed++;
        results.errors.push({ row: i + 2, field: 'name', message: '缺少客户名称' });
        continue;
      }

      // 校验手机号格式
      const phone = rowData['phone'] || rowData['手机号'] || rowData['联系电话'] || '';
      if (phone && !/^1[3-9]\d{9}$/.test(phone)) {
        results.failed++;
        results.errors.push({ row: i + 2, field: 'phone', message: '手机号格式不正确（需要11位）' });
        continue;
      }

      // 模拟导入成功
      results.success++;
      results.imported_ids.push(`import_${Date.now()}_${i}`);
    }

    return NextResponse.json({
      success: true,
      data: results,
      message: `导入完成：成功${results.success}条，失败${results.failed}条`,
    });
  } catch (error) {
    console.error('导入失败:', error);
    return NextResponse.json({ error: '导入处理失败' }, { status: 500 });
  }
}

// 获取导入模板
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const dataType = searchParams.get('dataType') || 'customers';

  // 返回对应数据类型的导入模板字段
  const templates: Record<string, string[]> = {
    customers: ['客户名称', '手机号', '公司名称', '地区', '客户类型', '客户等级', '备注'],
    leads: ['线索名称', '手机号', '公司名称', '来源', '地区', '备注'],
    opportunities: ['商机名称', '客户名称', '金额', '阶段', '预计成交日期', '备注'],
  };

  const fields = templates[dataType] || templates.customers;

  return NextResponse.json({
    success: true,
    data: {
      dataType,
      fields,
      template: fields.join(',') + '\n' + '(示例数据行)',
    },
  });
}