import { NextRequest, NextResponse } from 'next/server';

// 通知设置API
export async function GET(request: NextRequest) {
  try {
    // 模拟通知设置
    const settings = {
      follow_up_reminder: {
        enabled: true,
        channels: ['app', 'email'],
        threshold_days: 7,
      },
      opportunity_change: {
        enabled: true,
        channels: ['app'],
        stages: ['报价', '成交', '输单'],
      },
      pool_claim: {
        enabled: true,
        channels: ['app'],
      },
      pool_return: {
        enabled: true,
        channels: ['app'],
      },
      system_announcement: {
        enabled: true,
        channels: ['app', 'email'],
      },
      email_opened: {
        enabled: true,
        channels: ['app'],
      },
      whatsapp_reply: {
        enabled: true,
        channels: ['app'],
      },
    };

    return NextResponse.json({
      success: true,
      data: settings,
    });
  } catch (error) {
    console.error('获取通知设置失败:', error);
    return NextResponse.json({ error: '获取失败' }, { status: 500 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    return NextResponse.json({
      success: true,
      message: '通知设置已更新',
      data: body,
    });
  } catch (error) {
    console.error('更新通知设置失败:', error);
    return NextResponse.json({ error: '更新失败' }, { status: 500 });
  }
}