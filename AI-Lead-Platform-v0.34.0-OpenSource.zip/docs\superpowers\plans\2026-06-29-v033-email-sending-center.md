# v0.33.0 Email Sending Center Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a unified email center that creates contextual English drafts, safely sends confirmed messages and PDF attachments through Resend, and falls back to local drafts when Resend is unconfigured.

**Architecture:** A browser-safe email domain owns records, templates, context resolution, validation, and local persistence. A server-only route validates multipart payloads and calls Resend without exposing credentials. Business pages link to one compose workflow, and backup v8 stores only text records and attachment metadata.

**Tech Stack:** Next.js 16 App Router and Route Handlers, React 19, TypeScript, localStorage, Resend REST API through native fetch, multipart FormData, Node assert tests.

---

### Task 1: Email Domain and Templates

**Files:**
- Create: `tests/email-records.test.ts`
- Create: `src/lib/email-records.ts`
- Create: `src/lib/email-templates.ts`

- [ ] Write failing tests for email validation, six template outputs, missing context, attachment metadata, and local record persistence shape.
- [ ] Verify RED with `.\node_modules\.bin\tsx.cmd tests\email-records.test.ts`.
- [ ] Define `EmailRecordStatus`, `EmailSourceType`, `EmailTemplateId`, `EmailAttachmentMetadata`, and `SavedEmailRecord`.
- [ ] Implement six English templates with source-specific variables and no Chinese/undefined placeholders.
- [ ] Implement `validateEmailDraft`, `loadSavedEmailRecords`, `saveEmailRecords`, `saveEmailRecord`, `deleteEmailRecord`, and `createEmailDraft`.
- [ ] Verify GREEN and confirm saved records contain no attachment bytes or Base64.

### Task 2: Resend Server Route and Attachment Safety

**Files:**
- Create: `src/lib/email-server-validation.ts`
- Create: `tests/email-server-validation.test.ts`
- Create: `src/app/api/email/send-resend/route.ts`
- Modify: `.env.example`

- [ ] Write failing tests for recipient/CC/reply-to validation, subject/body limits, maximum 3 PDFs, 10MB per file, 20MB total, MIME, extension, and `%PDF-` header.
- [ ] Implement pure server validators and verify GREEN.
- [ ] Implement `GET` returning HTTP 200 with `configured`, `provider`, and safe from-address information.
- [ ] Implement `POST` parsing multipart data, validating again, converting PDFs to Base64, and calling `https://api.resend.com/emails`.
- [ ] Never log API keys, full bodies, or attachment content; map provider and network failures to readable JSON errors.
- [ ] Add `RESEND_API_KEY`, `RESEND_FROM_EMAIL`, `RESEND_FROM_NAME`, and `RESEND_REPLY_TO` to `.env.example`.

### Task 3: Email Center and Compose Workflow

**Files:**
- Create: `src/app/email-center/page.tsx`
- Create: `src/app/email-center/compose/page.tsx`
- Create: `src/app/email-center/[id]/page.tsx`
- Create: `src/components/email/email-compose-form.tsx`
- Modify: `src/components/layout/sidebar.tsx`

- [ ] Build metrics for total, draft, sent, failed, and sent in the last seven days.
- [ ] Add keyword, status, and source filters plus detail, continue, copy, retry, and delete actions.
- [ ] Resolve quotation, order, document, shipment, or manual context from query parameters.
- [ ] Build recipient, CC, reply-to, subject, body, template, preview, and PDF selection controls.
- [ ] Query Resend configuration; show real-send or local-draft mode clearly.
- [ ] Require final confirmation before POST, then save sent/failed status, provider ID, error, timestamp, and attachment metadata.
- [ ] Add a `邮件中心` sidebar entry and safe missing-record detail state.

### Task 4: Business Entry Points

**Files:**
- Modify: `src/app/crm-quotations/[id]/print/page.tsx`
- Modify: `src/app/crm-orders/[id]/page.tsx`
- Modify: `src/app/trade-documents/[id]/page.tsx`
- Modify: `src/app/shipments/[id]/page.tsx`

- [ ] Add exact compose links with `sourceType`, `sourceId`, and recommended template.
- [ ] Quotation uses `quotation_send`; order uses `order_confirmation`.
- [ ] PI/CI/PL select `pi_send`, `commercial_invoice_send`, or `packing_list_send`.
- [ ] Shipment provides `shipment_notice` and `arrival_reminder`.
- [ ] Missing source context preserves manual compose and displays a non-blocking warning.

### Task 5: Backup v8

**Files:**
- Create: `tests/data-backup-v8.test.ts`
- Modify: `src/lib/data-backup.ts`
- Modify: `src/app/data-backup/page.tsx`

- [ ] Write a failing test proving v7 normalizes `emailRecords` to `[]` and v8 preserves text records without binary content.
- [ ] Set `BACKUP_VERSION = 8`, add `emailRecords` to data and summary, and accept versions 1 through 8.
- [ ] Include records in load, save, merge, overwrite, undo, preview, and counts.
- [ ] Update backup badge to v8 and add the email record count.
- [ ] Run v5 through v8 compatibility tests.

### Task 6: Release, Verification, and Package

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `README.md`
- Modify: `package.json`
- Create: `AI-Lead-Platform-v0.33.0-OpenSource.zip`

- [ ] Set version `v0.33.0`, title `邮件发送中心`, package name `AI-Lead-Platform-v0.33.0-OpenSource.zip`, and GitHub remark `v0.33.0：新增 Resend 邮件发送、PDF 附件、英文模板与本地草稿降级`.
- [ ] Document Chinese Resend domain verification and local-draft fallback instructions.
- [ ] Run all tests, TypeScript, ESLint, and production build.
- [ ] Check email center, compose manual/missing-source, missing record, configuration API, backup, and release on desktop and mobile.
- [ ] Package while excluding dependencies, build output, Git data, `.env*`, logs, user data, and caches; verify `.env.example` remains included.
