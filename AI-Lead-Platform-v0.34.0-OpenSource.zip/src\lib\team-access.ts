import { demoWorkspace } from './workspace';

export type TeamRoleId = 'owner' | 'admin' | 'sales' | 'operator';
export type TeamMemberStatus = 'active' | 'pending' | 'disabled';

export interface TeamRole {
  id: TeamRoleId;
  name: string;
  shortName: string;
  description: string;
  colorClass: string;
  scope: string;
}

export interface TeamPermission {
  id: string;
  category: string;
  name: string;
  description: string;
}

export interface DemoTeamMember {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: TeamRoleId;
  status: TeamMemberStatus;
  team: string;
  customerCount: number;
  taskCount: number;
  lastLogin: string;
  joinedAt: string;
  workspaceId: string;
}

export interface TeamDataScope {
  role: TeamRoleId;
  title: string;
  scope: string;
  description: string;
}

export const teamRoles: TeamRole[] = [
  {
    id: 'owner',
    name: '老板 / 超级管理员',
    shortName: '老板',
    description: '拥有公司工作空间、套餐、成员、客户数据和 API 配置的最高权限。',
    colorClass: 'bg-amber-500/15 text-amber-300 border-amber-500/25',
    scope: '全部客户、全部任务、全部设置',
  },
  {
    id: 'admin',
    name: '管理员',
    shortName: '管理员',
    description: '负责团队运营、客户分配、任务监督和基础系统配置。',
    colorClass: 'bg-blue-500/15 text-blue-300 border-blue-500/25',
    scope: '全部客户、全部任务、部分系统设置',
  },
  {
    id: 'sales',
    name: '销售',
    shortName: '销售',
    description: '负责客户开发、CRM 跟进、开发信发送和成交推进。',
    colorClass: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25',
    scope: '自己负责的客户和任务',
  },
  {
    id: 'operator',
    name: '运营',
    shortName: '运营',
    description: '负责批量获客任务、线索核验、模板维护和数据导出准备。',
    colorClass: 'bg-violet-500/15 text-violet-300 border-violet-500/25',
    scope: '获客任务、候选池、模板和导出草稿',
  },
];

export const teamPermissions: TeamPermission[] = [
  { id: 'customers.read', category: '客户数据', name: '查看客户池', description: '查看客户资料、真实性评分、联系方式可信度和跟进建议。' },
  { id: 'customers.write', category: '客户数据', name: '编辑客户资料', description: '修改客户公司、联系人、标签、CRM 状态和备注。' },
  { id: 'leads.run', category: '获客任务', name: '运行获客任务', description: '创建搜索任务、批量搜索、沉淀候选客户。' },
  { id: 'leads.verify', category: '获客任务', name: '核验线索质量', description: '确认官网、邮箱、电话、社媒账号和风险信号。' },
  { id: 'templates.manage', category: '营销跟进', name: '维护开发模板', description: '维护首次开发、二次跟进、报价邀请等英文模板。' },
  { id: 'exports.create', category: '数据导出', name: '导出客户数据', description: '导出中文字段 CSV，交给 Excel、业务同事或老板审核。' },
  { id: 'team.manage', category: '团队与权限', name: '管理团队成员', description: '邀请成员、调整角色、停用账号、查看成员工作量。' },
  { id: 'settings.manage', category: '团队与权限', name: '管理系统设置', description: '配置 API Key、搜索源、OpenAI、数据隔离和 SaaS 参数。' },
  { id: 'billing.manage', category: '套餐与安全', name: '管理套餐与额度', description: '查看套餐、搜索额度、导出额度和付费升级入口。' },
];

export const rolePermissionMap: Record<TeamRoleId, string[]> = {
  owner: teamPermissions.map((permission) => permission.id),
  admin: ['customers.read', 'customers.write', 'leads.run', 'leads.verify', 'templates.manage', 'exports.create', 'team.manage', 'settings.manage'],
  sales: ['customers.read', 'customers.write', 'leads.verify', 'templates.manage'],
  operator: ['customers.read', 'leads.run', 'leads.verify', 'templates.manage', 'exports.create'],
};

export const demoTeamMembers: DemoTeamMember[] = [
  {
    id: 'member-owner',
    name: '王总',
    email: 'owner@skillhuoke.demo',
    phone: '+86 138 0000 0001',
    role: 'owner',
    status: 'active',
    team: '公司管理层',
    customerCount: 128,
    taskCount: 12,
    lastLogin: '今天 09:18',
    joinedAt: '2026-06-01',
    workspaceId: demoWorkspace.id,
  },
  {
    id: 'member-admin',
    name: 'Linda Zhang',
    email: 'admin@skillhuoke.demo',
    phone: '+86 138 0000 0002',
    role: 'admin',
    status: 'active',
    team: '外贸运营组',
    customerCount: 86,
    taskCount: 18,
    lastLogin: '今天 10:42',
    joinedAt: '2026-06-03',
    workspaceId: demoWorkspace.id,
  },
  {
    id: 'member-sales',
    name: 'Jason Li',
    email: 'sales@skillhuoke.demo',
    phone: '+86 138 0000 0003',
    role: 'sales',
    status: 'active',
    team: '澳洲市场组',
    customerCount: 42,
    taskCount: 9,
    lastLogin: '昨天 17:20',
    joinedAt: '2026-06-06',
    workspaceId: demoWorkspace.id,
  },
  {
    id: 'member-operator',
    name: 'Mia Chen',
    email: 'operator@skillhuoke.demo',
    phone: '+86 138 0000 0004',
    role: 'operator',
    status: 'pending',
    team: '数据核验组',
    customerCount: 0,
    taskCount: 5,
    lastLogin: '等待激活',
    joinedAt: '2026-06-24',
    workspaceId: demoWorkspace.id,
  },
];

export const teamDataScopes: TeamDataScope[] = [
  { role: 'owner', title: '公司级视角', scope: '全部工作空间数据', description: '老板可以查看公司全部客户、搜索任务、导出记录、团队成员和系统配置。' },
  { role: 'admin', title: '团队级视角', scope: '全部业务数据 + 部分设置', description: '管理员可以分配客户、管理任务和查看团队数据，但不能直接管理付费套餐。' },
  { role: 'sales', title: '个人跟进视角', scope: '自己负责的客户', description: '销售只看到自己负责或被分配的客户，避免客户资源混乱。' },
  { role: 'operator', title: '获客运营视角', scope: '候选池、任务和模板', description: '运营可以跑批量获客任务、核验线索和维护模板，正式客户分配给销售跟进。' },
];

export function getRole(roleId: TeamRoleId) {
  return teamRoles.find((role) => role.id === roleId) ?? teamRoles[2];
}

export function getStatusLabel(status: TeamMemberStatus) {
  const labels: Record<TeamMemberStatus, string> = {
    active: '已启用',
    pending: '待激活',
    disabled: '已停用',
  };
  return labels[status];
}

export function getStatusClass(status: TeamMemberStatus) {
  const classes: Record<TeamMemberStatus, string> = {
    active: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25',
    pending: 'bg-amber-500/15 text-amber-300 border-amber-500/25',
    disabled: 'bg-slate-500/15 text-slate-300 border-slate-500/25',
  };
  return classes[status];
}

export function roleHasPermission(roleId: TeamRoleId, permissionId: string) {
  return rolePermissionMap[roleId]?.includes(permissionId) ?? false;
}

export function getTeamSummary() {
  const activeMembers = demoTeamMembers.filter((member) => member.status === 'active').length;
  const pendingMembers = demoTeamMembers.filter((member) => member.status === 'pending').length;
  const totalCustomers = demoTeamMembers.reduce((sum, member) => sum + member.customerCount, 0);
  const openTasks = demoTeamMembers.reduce((sum, member) => sum + member.taskCount, 0);

  return {
    activeMembers,
    pendingMembers,
    totalMembers: demoTeamMembers.length,
    totalCustomers,
    openTasks,
  };
}
