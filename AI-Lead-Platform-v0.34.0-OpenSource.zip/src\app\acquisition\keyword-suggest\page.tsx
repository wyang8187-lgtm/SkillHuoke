'use client';

import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@/components/ui/empty-state';
import { Search, Lightbulb, TrendingUp, Target, Copy, Plus, RefreshCw, ArrowRight, BarChart3 } from 'lucide-react';

interface KeywordSuggestion {
  keyword: string;
  relevance: 'high' | 'medium' | 'low';
  search_volume: string;
  competition: 'high' | 'medium' | 'low';
  potential_score: number;
  reason: string;
}

interface KeywordSuggestResult {
  input_keyword: string;
  suggestions: KeywordSuggestion[];
  industry_insights: string;
  search_tips: string;
}

export default function KeywordSuggestPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<KeywordSuggestResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copiedKeyword, setCopiedKeyword] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setError(null);
    setResult(null);
    
    try {
      const response = await fetch('/api/ai/keyword-suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword: searchQuery.trim() })
      });
      
      if (!response.ok) {
        throw new Error('分析失败');
      }
      
      const data = await response.json();
      setResult(data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : '分析失败，请重试');
    } finally {
      setIsSearching(false);
    }
  };

  const handleCopy = (keyword: string) => {
    navigator.clipboard.writeText(keyword);
    setCopiedKeyword(keyword);
    setTimeout(() => setCopiedKeyword(null), 2000);
  };

  const getRelevanceColor = (relevance: string) => {
    switch (relevance) {
      case 'high': return 'bg-green-500/20 text-green-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'low': return 'bg-gray-500/20 text-gray-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getCompetitionColor = (competition: string) => {
    switch (competition) {
      case 'high': return 'bg-red-500/20 text-red-400';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400';
      case 'low': return 'bg-green-500/20 text-green-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getPotentialScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    return 'text-gray-400';
  };

  return (
    <MainLayout 
      title="AI拓词建议"
      breadcrumbs={[
        { label: 'AI获客中心', href: '/acquisition' },
        { label: 'AI拓词建议' }
      ]}
    >
      <div className="space-y-6">
        {/* 页面说明 */}
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc] flex items-center gap-2">
              <Lightbulb className="w-5 h-5 text-[#3b82f6]" />
              AI拓词建议
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              输入行业关键词，AI智能推荐相关搜索词，帮助您拓展获客关键词覆盖面，发现更多潜在客户
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="输入关键词，如：全屋定制、整木家装、建材外贸"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc] placeholder:text-[#64748b]"
                />
              </div>
              <Button 
                onClick={handleSearch}
                disabled={isSearching || !searchQuery.trim()}
                className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] hover:from-[#2563eb] hover:to-[#1e40af]"
              >
                {isSearching ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    正在分析...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    查找推荐词
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* 错误提示 */}
        {error && (
          <Card className="bg-[#1a1f2c] border-red-500/30">
            <CardContent className="py-6">
              <p className="text-red-400">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* 加载状态 */}
        {isSearching && (
          <Card className="bg-[#1a1f2c] border-[#2d3548]">
            <CardContent className="py-6 space-y-4">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </CardContent>
          </Card>
        )}

        {/* 分析结果 */}
        {result && !isSearching && (
          <div className="space-y-4">
            {/* 行业洞察 */}
            <Card className="bg-[#1a1f2c] border-[#2d3548]">
              <CardHeader className="pb-3">
                <CardTitle className="text-[#f8fafc] flex items-center gap-2">
                  <Target className="w-5 h-5 text-[#3b82f6]" />
                  "{result.input_keyword}" 关键词分析
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-[#0f1419] p-4 rounded-lg border border-[#2d3548]">
                  <h4 className="text-sm font-medium text-[#3b82f6] mb-2">行业洞察</h4>
                  <p className="text-sm text-[#94a3b8]">{result.industry_insights}</p>
                </div>
                <div className="bg-[#0f1419] p-4 rounded-lg border border-[#2d3548]">
                  <h4 className="text-sm font-medium text-green-400 mb-2">搜索技巧</h4>
                  <p className="text-sm text-[#94a3b8]">{result.search_tips}</p>
                </div>
                <Badge className="bg-[#3b82f6]/20 text-[#3b82f6]">
                  共推荐 {result.suggestions.length} 个相关关键词
                </Badge>
              </CardContent>
            </Card>

            {/* 关键词列表 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {result.suggestions.map((suggestion, index) => (
                <Card key={index} className="bg-[#1a1f2c] border-[#2d3548] hover:border-[#3b82f6]/30 transition-colors">
                  <CardContent className="py-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="text-[#f8fafc] font-medium">{suggestion.keyword}</h4>
                          <Badge className={`${getRelevanceColor(suggestion.relevance)} text-xs`}>
                            {suggestion.relevance === 'high' ? '高相关' : suggestion.relevance === 'medium' ? '中相关' : '相关'}
                          </Badge>
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm mb-2">
                          <div className="flex items-center gap-1 text-[#94a3b8]">
                            <BarChart3 className="w-4 h-4" />
                            <span>搜索量：{suggestion.search_volume}</span>
                          </div>
                          <Badge className={`${getCompetitionColor(suggestion.competition)} text-xs`}>
                            竞争度：{suggestion.competition}
                          </Badge>
                        </div>
                        
                        {/* 潜力评分 */}
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-xs text-[#64748b]">潜力评分</span>
                          <div className="flex-1 h-2 bg-[#0f1419] rounded-full overflow-hidden">
                            <div 
                              className={`h-full ${suggestion.potential_score >= 80 ? 'bg-green-500' : suggestion.potential_score >= 60 ? 'bg-yellow-500' : 'bg-gray-500'}`}
                              style={{ width: `${suggestion.potential_score}%` }}
                            />
                          </div>
                          <span className={`text-xs font-medium ${getPotentialScoreColor(suggestion.potential_score)}`}>
                            {suggestion.potential_score}
                          </span>
                        </div>
                        
                        <p className="text-xs text-[#64748b]">{suggestion.reason}</p>
                      </div>
                      
                      {/* 操作按钮 */}
                      <div className="flex flex-col gap-2 ml-4">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 w-8 p-0 text-[#64748b] hover:text-[#f8fafc]"
                          onClick={() => handleCopy(suggestion.keyword)}
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="h-8 w-8 p-0 text-[#3b82f6] hover:bg-[#3b82f6]/10"
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    
                    {/* 复制提示 */}
                    {copiedKeyword === suggestion.keyword && (
                      <div className="absolute top-2 right-2 text-xs text-green-400">已复制</div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* 快捷操作 */}
            <Card className="bg-[#1a1f2c] border-[#2d3548]">
              <CardContent className="py-4">
                <div className="flex items-center justify-between">
                  <div className="text-sm text-[#94a3b8]">
                    发现高潜力关键词？立即开始搜索获客
                  </div>
                  <Button className="bg-[#3b82f6] hover:bg-[#2563eb]">
                    <ArrowRight className="w-4 h-4 mr-2" />
                    去智能搜索
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 空状态 */}
        {!result && !isSearching && !error && (
          <EmptyState
            icon={<Lightbulb className="w-12 h-12" />}
            title="输入关键词获取拓词建议"
            description="AI将基于行业数据、搜索趋势分析，为您推荐更多高潜力获客关键词"
          />
        )}
      </div>
    </MainLayout>
  );
}