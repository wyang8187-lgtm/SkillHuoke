// 线索转客户 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 线索转客户
export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  const { id } = await params;

  try {
    const body = await req.json();
    
    // 获取线索详情
    const lead = await dbService.getLeadById(user.id, id);
    if (!lead) {
      return NextResponse.json({ error: '线索不存在' }, { status: 404 });
    }

    // 检查手机号是否已在客户中存在
    const duplicate = await dbService.checkDuplicateCustomer(user.id, lead.phone || null);
    if (duplicate) {
      return NextResponse.json({ 
        success: false, 
        error: '该手机号已存在客户中，无法转换' 
      }, { status: 400 });
    }

    // 创建客户 - 使用正确的字段名（移除不存在的address字段）
    const customer = await dbService.createCustomer(user.id, {
      company_name: lead.company_name || '',
      customer_type: body.type || 'full_designer', // 可由前端指定客户类型
      contact_name: lead.contact_name || '',
      phone: lead.phone || '',
      region: lead.region || '',
      grade: 'C', // 新客户默认C类
      status: 'new',
      source: lead.source,
    });

    // 更新线索状态为已转客户
    await dbService.updateLead(user.id, id, { status: 'converted' });

    return NextResponse.json({ 
      success: true, 
      data: { 
        customer,
        leadId: id,
        leadStatus: 'converted'
      },
      message: '线索已成功转为客户'
    });
  } catch (error) {
    console.error('线索转客户失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '线索转客户失败' 
    }, { status: 400 });
  }
}