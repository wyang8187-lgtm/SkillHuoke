import { NextRequest, NextResponse } from 'next/server';

// AI客户动态监测 - 模拟企业动态数据
// 真实实现需要接入工商数据API、企查查、天眼查等

interface CompanyDynamics {
  company_name: string;
  company_id: string;
  dynamics: DynamicItem[];
  last_updated: string;
}

interface DynamicItem {
  id: string;
  type: '工商变更' | '新项目' | '招聘信息' | '中标信息' | '行政处罚' | '司法风险';
  title: string;
  content: string;
  date: string;
  importance: 'high' | 'medium' | 'low';
  source: string;
}

// 模拟企业动态数据生成
function generateMockDynamics(companyName: string): CompanyDynamics {
  const dynamicsTypes = [
    { type: '工商变更', templates: [
      { title: '注册资本变更', content: '注册资本从500万变更为1000万' },
      { title: '经营范围变更', content: '新增"室内装饰设计"经营范围' },
      { title: '股东变更', content: '新增股东李某某，持股比例20%' },
    ]},
    { type: '新项目', templates: [
      { title: '中标深圳某商业项目', content: '中标金额约200万，项目周期6个月' },
      { title: '签约广州某酒店项目', content: '签约全屋定制项目，合同金额150万' },
      { title: '启动佛山展厅建设', content: '计划投资80万建设新展厅' },
    ]},
    { type: '招聘信息', templates: [
      { title: '招聘设计师', content: '招聘职位：全案设计师，薪资15-25K' },
      { title: '招聘销售经理', content: '招聘职位：销售经理，薪资20-30K' },
      { title: '招聘外贸专员', content: '招聘职位：外贸专员，薪资10-15K' },
    ]},
    { type: '中标信息', templates: [
      { title: '中标东莞某住宅项目', content: '中标50套全屋定制，金额约300万' },
      { title: '中标深圳某写字楼项目', content: '中标办公家具定制，金额约100万' },
    ]},
  ];

  // 随机选择2-4条动态
  const selectedDynamics: DynamicItem[] = [];
  const numDynamics = 2 + Math.floor(Math.random() * 3);
  
  for (let i = 0; i < numDynamics; i++) {
    const typeIndex = Math.floor(Math.random() * dynamicsTypes.length);
    const templateIndex = Math.floor(Math.random() * dynamicsTypes[typeIndex].templates.length);
    const template = dynamicsTypes[typeIndex].templates[templateIndex];
    
    const importance = template.title.includes('中标') || template.title.includes('签约') ? 'high' : 
                       template.title.includes('招聘') ? 'medium' : 'low';
    
    // 生成过去30天内的随机日期
    const daysAgo = Math.floor(Math.random() * 30);
    const date = new Date();
    date.setDate(date.getDate() - daysAgo);
    
    selectedDynamics.push({
      id: `dynamic_${i}_${Date.now()}`,
      type: dynamicsTypes[typeIndex].type as DynamicItem['type'],
      title: template.title,
      content: template.content,
      date: date.toISOString().split('T')[0],
      importance,
      source: '公开数据',
    });
  }

  // 按日期排序
  selectedDynamics.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return {
    company_name: companyName,
    company_id: `company_${Date.now()}`,
    dynamics: selectedDynamics,
    last_updated: new Date().toISOString(),
  };
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { company_name } = body;

    if (!company_name) {
      return NextResponse.json({ error: '请提供公司名称' }, { status: 400 });
    }

    // 模拟生成企业动态
    // 真实实现：调用企查查/天眼查API获取真实数据
    const dynamics = generateMockDynamics(company_name);

    return NextResponse.json({
      success: true,
      data: dynamics,
      note: '当前为模拟数据，接入真实API后可获取实时企业动态'
    });
  } catch (error) {
    console.error('Customer dynamics API error:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const companyName = searchParams.get('company_name');

    if (!companyName) {
      return NextResponse.json({ error: '请提供公司名称' }, { status: 400 });
    }

    const dynamics = generateMockDynamics(companyName);

    return NextResponse.json({
      success: true,
      data: dynamics,
      note: '当前为模拟数据，接入真实API后可获取实时企业动态'
    });
  } catch (error) {
    console.error('Customer dynamics GET API error:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}