import { NextRequest, NextResponse } from 'next/server';

// 行业信息类型定义
interface IndustryInfo {
  overview: string;
  mainExportMarkets: { region: string; percentage: string; features: string }[];
  leadingCompanies: string[];
  commonChallenges: string[];
  keyProducts: string[];
  certificationRequirements: string[];
}

// 建材行业知识库数据
const INDUSTRY_LIBRARY: Record<string, IndustryInfo> = {
  '灯饰照明': {
    overview: '中国是全球最大的灯饰照明生产国和出口国，年产值超过5000亿元。广东省中山市古镇镇被誉为"中国灯饰之都"，占全国灯饰产量的60%以上。',
    mainExportMarkets: [
      { region: '中东', percentage: '35%', features: '偏好奢华风格水晶灯、大型吊灯，价格敏感度中等' },
      { region: '东南亚', percentage: '25%', features: '注重性价比，LED灯具需求量大，电商渠道发达' },
      { region: '非洲', percentage: '15%', features: '需要户外照明、太阳能灯具，基础设施项目多' },
      { region: '欧美', percentage: '15%', features: '高端定制灯具、智能照明，认证要求严格' },
      { region: '南美', percentage: '10%', features: '商业照明需求大，价格敏感' },
    ],
    leadingCompanies: [
      '中山欧普照明股份有限公司',
      '佛山照明股份有限公司',
      '惠州雷士光电科技有限公司',
      '中山华艺灯饰照明股份有限公司',
      '江门金达照明有限公司',
    ],
    commonChallenges: [
      '中东客户要求SASO认证，需提前准备',
      '欧美客户对能效认证要求严格（Energy Star、CE）',
      '大件灯具运输易损坏，需加强包装',
      '古镇竞争激烈，需差异化定位',
      '智能照明技术更新快，需持续研发投入',
    ],
    keyProducts: ['吊灯', '壁灯', '筒灯', 'LED灯具', '水晶灯', '户外灯', '吸顶灯', '台灯'],
    certificationRequirements: ['CE', 'UL', 'SASO', 'Energy Star', 'CCC', 'RoHS'],
  },

  '油漆涂料': {
    overview: '中国涂料产量连续多年位居世界第一，年产量超过2000万吨。顺德、东莞是涂料产业集聚地，拥有完整的产业链。',
    mainExportMarkets: [
      { region: '东南亚', percentage: '30%', features: '环保水性漆需求增长，建筑涂料市场大' },
      { region: '非洲', percentage: '25%', features: '工业涂料、船舶涂料需求旺盛' },
      { region: '南美', percentage: '20%', features: '防水涂料、外墙涂料需求大' },
      { region: '中东', percentage: '15%', features: '高端建筑涂料市场' },
      { region: '中亚', percentage: '10%', features: '基础设施建设项目驱动' },
    ],
    leadingCompanies: [
      '广东华润涂料有限公司',
      '立邦涂料（中国）有限公司',
      '嘉宝莉化工集团股份有限公司',
      '三棵树涂料股份有限公司',
      '广东美涂士建材股份有限公司',
    ],
    commonChallenges: [
      '环保法规日趋严格，水性漆转型压力',
      '危化品运输资质要求高',
      '客户对技术支持要求高',
      '配方保密与定制矛盾',
      '原材料价格波动大',
    ],
    keyProducts: ['木器漆', '墙面漆', '防水涂料', '艺术涂料', '乳胶漆', 'PU漆'],
    certificationRequirements: ['ISO 9001', 'ISO 14001', '绿色产品认证', '十环认证'],
  },

  '岩板大板': {
    overview: '岩板是近年来兴起的建材品类，中国市场规模快速增长。佛山、清远是主要生产基地，年产能超过5000万平方米。',
    mainExportMarkets: [
      { region: '中东', percentage: '35%', features: '高端市场，偏好奢华纹理，价格敏感度低' },
      { region: '欧美', percentage: '25%', features: '注重环保认证和可持续性，高端定制需求' },
      { region: '澳洲', percentage: '20%', features: '橱柜台面市场大，对品质要求高' },
      { region: '东南亚', percentage: '15%', features: '性价比市场，墙面装饰需求' },
      { region: '非洲', percentage: '5%', features: '基础设施项目驱动' },
    ],
    leadingCompanies: [
      '佛山蒙娜丽莎集团股份有限公司',
      '广东东鹏控股股份有限公司',
      '佛山市简一陶瓷有限公司',
      '佛山市德利丰科技有限公司',
      '广东金牌陶瓷有限公司',
    ],
    commonChallenges: [
      '大板运输成本高，需优化物流',
      '欧美环保认证要求严格',
      '产能过剩，价格竞争激烈',
      '应用场景推广需加强',
      '定制化生产效率问题',
    ],
    keyProducts: ['岩板台面', '大板瓷砖', '薄板', '陶瓷大板', '石英岩板'],
    certificationRequirements: ['CE', 'ISO 9001', '绿色建材认证', '抗弯强度测试'],
  },

  '橱柜定制': {
    overview: '中国橱柜产业产值超过2000亿元，广东、江苏、浙江为主要生产基地。出口市场以中东、澳洲、北美为主。',
    mainExportMarkets: [
      { region: '中东', percentage: '30%', features: '偏好豪华欧式橱柜，高端市场需求旺盛' },
      { region: '澳洲', percentage: '25%', features: '注重环保认证和耐用性，法规严格' },
      { region: '北美', percentage: '25%', features: 'RTA橱柜市场增长迅速，性价比导向' },
      { region: '东南亚', percentage: '15%', features: '性价比市场，电商渠道发达' },
      { region: '欧洲', percentage: '5%', features: '高端定制需求，设计导向' },
    ],
    leadingCompanies: [
      '广州欧派家居集团股份有限公司',
      '广州尚品宅配家居股份有限公司',
      '佛山市志邦家居股份有限公司',
      '广东好莱客创意家居股份有限公司',
      '广东皮阿诺科学艺术家居股份有限公司',
    ],
    commonChallenges: [
      '出口认证要求多（CARB、FSC等）',
      '定制化生产效率与成本平衡',
      'RTA柜组装说明书需完善',
      '运输易损坏，包装成本高',
      '设计能力与国际接轨',
    ],
    keyProducts: ['整体橱柜', '橱柜门板', '橱柜台面', '衣柜', '浴室柜'],
    certificationRequirements: ['CARB', 'FSC', 'ISO 9001', '环保认证', '防火认证'],
  },

  // 其他行业基础信息
  '建材外贸': {
    overview: '建材外贸涵盖多种建材产品出口，是中国传统优势产业。',
    mainExportMarkets: [{ region: '全球', percentage: '100%', features: '覆盖全球主要市场' }],
    leadingCompanies: ['各类建材贸易公司'],
    commonChallenges: ['市场竞争激烈', '认证要求多样'],
    keyProducts: ['各类建材产品'],
    certificationRequirements: ['CE', 'ISO'],
  },

  '家具出口': {
    overview: '中国是全球最大的家具出口国，年出口额超过500亿美元。',
    mainExportMarkets: [{ region: '全球', percentage: '100%', features: '北美、欧洲、中东为主' }],
    leadingCompanies: ['各类家具制造企业'],
    commonChallenges: ['环保认证', '运输成本'],
    keyProducts: ['沙发', '床', '餐桌', '办公家具'],
    certificationRequirements: ['CARB', 'FSC'],
  },
};

// 其他行业填充默认数据
const ALL_INDUSTRIES = [
  '建材外贸', '家具出口', '全屋定制', '橱柜衣柜', '陶瓷卫浴', '五金配件',
  '照明灯饰', '地板门窗', '涂料化工', '机械装备', '纺织服装', '家电出口',
  '跨境电商', '进出口贸易', '国际物流',
  // 新增8个行业
  '灯饰照明', '油漆涂料', '岩板大板', '橱柜定制', '门业出口', '玻璃制品', '石材出口', '硅胶密封',
];

// 为未详细定义的行业填充默认信息
ALL_INDUSTRIES.forEach(industry => {
  if (!INDUSTRY_LIBRARY[industry]) {
    INDUSTRY_LIBRARY[industry] = {
      overview: `${industry}是建材行业的重要组成部分，中国市场具有完整产业链优势。`,
      mainExportMarkets: [
        { region: '全球', percentage: '100%', features: '覆盖全球主要市场' },
      ],
      leadingCompanies: ['行业领先企业'],
      commonChallenges: ['市场竞争', '认证要求', '物流成本'],
      keyProducts: [`${industry}相关产品`],
      certificationRequirements: ['CE', 'ISO'],
    };
  }
});

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const industry = searchParams.get('industry');

  if (industry && INDUSTRY_LIBRARY[industry]) {
    return NextResponse.json({
      success: true,
      data: INDUSTRY_LIBRARY[industry],
      industry,
    });
  }

  // 返回所有行业列表
  const industriesList = ALL_INDUSTRIES.map(industry => ({
    name: industry,
    hasDetailedInfo: ['灯饰照明', '油漆涂料', '岩板大板', '橱柜定制'].includes(industry),
  }));

  return NextResponse.json({
    success: true,
    data: industriesList,
    total: industriesList.length,
    detailedIndustries: ['灯饰照明', '油漆涂料', '岩板大板', '橱柜定制'],
    note: '4个重点行业有详细数据，其他行业为基础信息',
  });
}