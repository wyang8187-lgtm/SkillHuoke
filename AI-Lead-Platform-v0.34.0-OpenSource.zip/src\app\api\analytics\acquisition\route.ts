import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 获客效率分析API
export async function GET(request: NextRequest) {
  try {
    const supabase = getSupabaseServiceRoleClient();

    // 1. 获取客户来源数据
    const { data: customers, error: customersError } = await supabase
      .from('customers')
      .select('id, source, created_at, grade')
      .order('created_at', { ascending: true });

    if (customersError) {
      console.error('获取客户数据失败:', customersError);
    }

    // 2. 获取线索数据
    const { data: leads, error: leadsError } = await supabase
      .from('leads')
      .select('id, source, created_at, status')
      .order('created_at', { ascending: true });

    if (leadsError) {
      console.error('获取线索数据失败:', leadsError);
    }

    // 3. 获取邮件记录 - 只查询存在的列
    const { data: emails, error: emailsError } = await supabase
      .from('email_records')
      .select('id, status, created_at')
      .order('created_at', { ascending: true });

    if (emailsError) {
      console.error('获取邮件数据失败:', emailsError);
    }

    // 4. 渠道对比分析
    const channelComparison = calculateChannelComparison(customers || [], leads || []);

    // 5. AI搜客效果统计
    const aiSearchStats = calculateAISearchStats(leads || [], customers || []);

    // 6. 开发信效果统计
    const devLetterStats = calculateDevLetterStats(emails || []);

    // 7. 最佳联系时间分析
    const bestContactTime = calculateBestContactTime(emails || []);

    return NextResponse.json({
      success: true,
      data: {
        channels: channelComparison,
        aiSearch: aiSearchStats,
        devLetter: devLetterStats,
        bestContactTime: bestContactTime,
        totalCustomers: customers?.length || 0,
        totalLeads: leads?.length || 0
      }
    });
  } catch (error) {
    console.error('获客效率分析错误:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}

// 渠道对比分析
function calculateChannelComparison(customers: any[], leads: any[]) {
  const channels = ['搜索引擎', '社媒获客', '展会', '转介绍', 'AI搜客', '其他'];
  const channelData: Record<string, { leads: number; customers: number; conversionRate: number }> = {};

  channels.forEach(channel => {
    const channelLeads = leads.filter(l => l.source?.includes(channel)).length;
    const channelCustomers = customers.filter(c => c.source?.includes(channel)).length;
    const rate = channelLeads > 0 ? Math.round((channelCustomers / channelLeads) * 100) : 0;
    
    channelData[channel] = {
      leads: channelLeads,
      customers: channelCustomers,
      conversionRate: rate
    };
  });

  return Object.entries(channelData).map(([channel, data]) => ({
    channel,
    leads: data.leads,
    customers: data.customers,
    conversionRate: data.conversionRate
  }));
}

// AI搜客效果统计
function calculateAISearchStats(leads: any[], customers: any[]) {
  const aiLeads = leads.filter(l => l.source?.includes('AI') || l.source?.includes('搜客'));
  const aiCustomers = customers.filter(c => c.source?.includes('AI') || c.source?.includes('搜客'));

  // A级客户占比
  const gradeACustomers = aiCustomers.filter(c => c.grade === 'A').length;

  return {
    totalLeads: aiLeads.length,
    convertedCustomers: aiCustomers.length,
    conversionRate: aiLeads.length > 0 ? Math.round((aiCustomers.length / aiLeads.length) * 100) : 0,
    highQualityRate: aiCustomers.length > 0 ? Math.round((gradeACustomers / aiCustomers.length) * 100) : 0,
    avgConversionDays: 7 // 模拟平均转化天数
  };
}

// 开发信效果统计
function calculateDevLetterStats(emails: any[]) {
  const total = emails.length;
  const opened = emails.filter(e => e.opened_at).length;
  const replied = emails.filter(e => e.replied_at).length;

  // 模拟各时段打开率
  const hourlyOpenRate = [
    { hour: '08:00', rate: 15 },
    { hour: '09:00', rate: 25 },
    { hour: '10:00', rate: 30 },
    { hour: '11:00', rate: 28 },
    { hour: '12:00', rate: 10 },
    { hour: '13:00', rate: 8 },
    { hour: '14:00', rate: 22 },
    { hour: '15:00', rate: 35 },
    { hour: '16:00', rate: 32 },
    { hour: '17:00', rate: 20 },
    { hour: '18:00', rate: 12 },
    { hour: '19:00', rate: 18 }
  ];

  return {
    totalSent: total,
    opened,
    replied,
    openRate: total > 0 ? Math.round((opened / total) * 100) : 0,
    replyRate: total > 0 ? Math.round((replied / total) * 100) : 0,
    hourlyOpenRate
  };
}

// 最佳联系时间分析
function calculateBestContactTime(emails: any[]) {
  // 分析邮件打开时间
  const openedEmails = emails.filter(e => e.opened_at);
  
  // 统计各时段打开数量
  const hourlyStats: Record<number, number> = {};
  openedEmails.forEach(email => {
    if (email.opened_at) {
      const hour = new Date(email.opened_at).getHours();
      hourlyStats[hour] = (hourlyStats[hour] || 0) + 1;
    }
  });

  // 找出最佳时段
  const bestHours = Object.entries(hourlyStats)
    .map(([hour, count]) => ({ hour: parseInt(hour), count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 3);

  return {
    bestHours: bestHours.map(h => `${h.hour}:00-${h.hour + 1}:00`),
    recommendation: bestHours.length > 0 
      ? `建议在 ${bestHours[0].hour}:00-${bestHours[0].hour + 1}:00 发送开发信，打开率最高`
      : '暂无足够数据分析最佳联系时间'
  };
}