'use client';

import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@/components/ui/empty-state';
import { Search, Ship, Globe, DollarSign, Calendar, MapPin, Building, TrendingUp, RefreshCw, ArrowUpDown, Filter } from 'lucide-react';

interface CustomsRecord {
  id: string;
  product_name: string;
  importer_name: string;
  importer_country: string;
  exporter_name: string;
  exporter_country: string;
  trade_amount: number;
  trade_amount_unit: string;
  trade_date: string;
  hs_code: string;
  port: string;
  trade_type: '进口' | '出口';
}

interface CustomsSearchResult {
  keyword: string;
  total_records: number;
  records: CustomsRecord[];
  top_importers: { name: string; country: string; total_amount: number }[];
  top_exporters: { name: string; country: string; total_amount: number }[];
}

export default function CustomsDataPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<CustomsSearchResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<'amount' | 'date'>('amount');

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setError(null);
    setResult(null);
    
    try {
      const response = await fetch('/api/customs-data', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword: searchQuery.trim() })
      });
      
      if (!response.ok) {
        throw new Error('查询失败');
      }
      
      const data = await response.json();
      setResult(data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : '查询失败，请重试');
    } finally {
      setIsSearching(false);
    }
  };

  const sortedRecords = result?.records ? 
    [...result.records].sort((a, b) => 
      sortBy === 'amount' ? b.trade_amount - a.trade_amount : 
      new Date(b.trade_date).getTime() - new Date(a.trade_date).getTime()
    ) : [];

  return (
    <MainLayout 
      title="海关数据查询"
      breadcrumbs={[
        { label: '外贸数据', href: '/customs' },
        { label: '海关数据查询' }
      ]}
    >
      <div className="space-y-6">
        {/* 页面说明 */}
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc] flex items-center gap-2">
              <Ship className="w-5 h-5 text-[#3b82f6]" />
              海关数据查询
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              输入产品关键词，查询相关进出口贸易数据，分析采购商、供应商、交易金额等信息，发现潜在外贸客户
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="输入产品关键词，如：全屋定制、家具、建材、木材"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc] placeholder:text-[#64748b]"
                />
              </div>
              <Button 
                onClick={handleSearch}
                disabled={isSearching || !searchQuery.trim()}
                className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] hover:from-[#2563eb] hover:to-[#1e40af]"
              >
                {isSearching ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    正在查询...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    查询数据
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* 错误提示 */}
        {error && (
          <Card className="bg-[#1a1f2c] border-red-500/30">
            <CardContent className="py-6">
              <p className="text-red-400">{error}</p>
            </CardContent>
          </Card>
        )}

        {/* 加载状态 */}
        {isSearching && (
          <Card className="bg-[#1a1f2c] border-[#2d3548]">
            <CardContent className="py-6 space-y-4">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-20 w-full" />
              <Skeleton className="h-20 w-full" />
            </CardContent>
          </Card>
        )}

        {/* 查询结果 */}
        {result && !isSearching && (
          <div className="space-y-4">
            {/* 统计汇总 */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-[#1a1f2c] border-[#2d3548]">
                <CardContent className="py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-[#3b82f6]/20">
                      <TrendingUp className="w-5 h-5 text-[#3b82f6]" />
                    </div>
                    <div>
                      <p className="text-sm text-[#64748b]">总记录数</p>
                      <p className="text-xl font-semibold text-[#f8fafc]">{result.total_records}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1a1f2c] border-[#2d3548]">
                <CardContent className="py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-green-500/20">
                      <DollarSign className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <p className="text-sm text-[#64748b]">总交易金额</p>
                      <p className="text-xl font-semibold text-[#f8fafc]">
                        ${sortedRecords.reduce((sum, r) => sum + r.trade_amount, 0).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-[#1a1f2c] border-[#2d3548]">
                <CardContent className="py-4">
                  <div className="flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-orange-500/20">
                      <Globe className="w-5 h-5 text-orange-400" />
                    </div>
                    <div>
                      <p className="text-sm text-[#64748b]">涉及国家</p>
                      <p className="text-xl font-semibold text-[#f8fafc]">
                        {new Set([...sortedRecords.map(r => r.importer_country), ...sortedRecords.map(r => r.exporter_country)]).size}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Top进口商 */}
            <Card className="bg-[#1a1f2c] border-[#2d3548]">
              <CardHeader className="pb-3">
                <CardTitle className="text-[#f8fafc] flex items-center gap-2 text-base">
                  <Building className="w-4 h-4 text-[#3b82f6]" />
                  TOP采购商（潜在客户）
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {result.top_importers.map((importer, index) => (
                    <div key={index} className="flex items-center justify-between bg-[#0f1419] p-3 rounded-lg border border-[#2d3548]">
                      <div className="flex items-center gap-3">
                        <Badge className={`w-6 h-6 rounded-full flex items-center justify-center ${index === 0 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-500/20 text-gray-400'}`}>
                          {index + 1}
                        </Badge>
                        <div>
                          <p className="text-[#f8fafc] font-medium">{importer.name}</p>
                          <p className="text-xs text-[#64748b]">{importer.country}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-green-400 font-medium">${importer.total_amount.toLocaleString()}</span>
                        <Button size="sm" variant="outline" className="border-[#3b82f6]/30 text-[#3b82f6]">
                          添加客户
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Top出口商 */}
            <Card className="bg-[#1a1f2c] border-[#2d3548]">
              <CardHeader className="pb-3">
                <CardTitle className="text-[#f8fafc] flex items-center gap-2 text-base">
                  <Building className="w-4 h-4 text-orange-400" />
                  TOP供应商（竞争对手分析）
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {result.top_exporters.map((exporter, index) => (
                    <div key={index} className="flex items-center justify-between bg-[#0f1419] p-3 rounded-lg border border-[#2d3548]">
                      <div className="flex items-center gap-3">
                        <Badge className={`w-6 h-6 rounded-full flex items-center justify-center ${index === 0 ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-500/20 text-gray-400'}`}>
                          {index + 1}
                        </Badge>
                        <div>
                          <p className="text-[#f8fafc] font-medium">{exporter.name}</p>
                          <p className="text-xs text-[#64748b]">{exporter.country}</p>
                        </div>
                      </div>
                      <span className="text-orange-400 font-medium">${exporter.total_amount.toLocaleString()}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* 记录列表 */}
            <Card className="bg-[#1a1f2c] border-[#2d3548]">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-[#f8fafc] text-base">贸易记录详情</CardTitle>
                  <div className="flex items-center gap-2">
                    <Button 
                      size="sm" 
                      variant={sortBy === 'amount' ? 'default' : 'outline'}
                      className={sortBy === 'amount' ? 'bg-[#3b82f6]' : 'border-[#2d3548] text-[#94a3b8]'}
                      onClick={() => setSortBy('amount')}
                    >
                      <ArrowUpDown className="w-4 h-4 mr-1" />
                      按金额
                    </Button>
                    <Button 
                      size="sm" 
                      variant={sortBy === 'date' ? 'default' : 'outline'}
                      className={sortBy === 'date' ? 'bg-[#3b82f6]' : 'border-[#2d3548] text-[#94a3b8]'}
                      onClick={() => setSortBy('date')}
                    >
                      <Calendar className="w-4 h-4 mr-1" />
                      按日期
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {sortedRecords.slice(0, 10).map((record) => (
                    <div key={record.id} className="bg-[#0f1419] p-4 rounded-lg border border-[#2d3548] hover:border-[#3b82f6]/30 transition-colors">
                      <div className="flex items-start justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Badge className={record.trade_type === '进口' ? 'bg-green-500/20 text-green-400' : 'bg-orange-500/20 text-orange-400'}>
                              {record.trade_type}
                            </Badge>
                            <span className="text-xs text-[#64748b]">{record.id}</span>
                            <span className="text-xs text-[#64748b]">HS: {record.hs_code}</span>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-[#64748b]">采购商</p>
                              <p className="text-[#f8fafc]">{record.importer_name}</p>
                              <p className="text-xs text-[#94a3b8]">{record.importer_country}</p>
                            </div>
                            <div>
                              <p className="text-[#64748b]">供应商</p>
                              <p className="text-[#f8fafc]">{record.exporter_name}</p>
                              <p className="text-xs text-[#94a3b8]">{record.exporter_country}</p>
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-4 text-xs text-[#64748b]">
                            <span className="flex items-center gap-1">
                              <MapPin className="w-3 h-3" />
                              {record.port}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              {record.trade_date}
                            </span>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <p className="text-lg font-semibold text-green-400">
                            ${record.trade_amount.toLocaleString()}
                          </p>
                          <p className="text-xs text-[#64748b]">{record.trade_amount_unit}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 空状态 */}
        {!result && !isSearching && !error && (
          <EmptyState
            icon={<Ship className="w-12 h-12" />}
            title="输入产品关键词查询海关数据"
            description="查询进出口贸易记录，分析采购商和供应商信息，发现外贸商机"
          />
        )}
      </div>
    </MainLayout>
  );
}