'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter
} from '@/components/ui/dialog';
import { 
  Database, Download, Upload, Trash2, RefreshCw, Loader2, 
  AlertTriangle, CheckCircle, FileDown, FileUp 
} from 'lucide-react';

export default function DataManagePage() {
  const [loading, setLoading] = useState(false);
  const [operation, setOperation] = useState<string | null>(null);
  const [confirmDialogOpen, setConfirmDialogOpen] = useState(false);
  const [confirmAction, setConfirmAction] = useState<string | null>(null);

  // 数据统计
  const stats = {
    customers: 128,
    leads: 256,
    opportunities: 45,
    emailRecords: 312,
    campaigns: 12,
    tasks: 89
  };

  // 备份数据
  const handleBackup = async () => {
    setLoading(true);
    setOperation('backup');
    try {
      // 模拟备份操作
      await new Promise(resolve => setTimeout(resolve, 2000));
      alert('数据备份成功！备份文件已下载到本地');
    } finally {
      setLoading(false);
      setOperation(null);
    }
  };

  // 导入数据
  const handleImport = async () => {
    setLoading(true);
    setOperation('import');
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      alert('数据导入成功！');
    } finally {
      setLoading(false);
      setOperation(null);
    }
  };

  // 清空数据（需要二次确认）
  const handleClear = async () => {
    setConfirmAction('clear');
    setConfirmDialogOpen(true);
  };

  // 确认清空
  const confirmClear = async () => {
    setLoading(true);
    setOperation('clear');
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setConfirmDialogOpen(false);
      alert('数据已清空！');
    } finally {
      setLoading(false);
      setOperation(null);
    }
  };

  // 重置为示例数据
  const handleReset = async () => {
    setConfirmAction('reset');
    setConfirmDialogOpen(true);
  };

  // 确认重置
  const confirmReset = async () => {
    setLoading(true);
    setOperation('reset');
    try {
      await new Promise(resolve => setTimeout(resolve, 1500));
      setConfirmDialogOpen(false);
      alert('数据已重置为示例数据！');
    } finally {
      setLoading(false);
      setOperation(null);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold flex items-center gap-2">
        <Database className="w-6 h-6" />
        数据管理
      </h1>

      {/* 数据统计 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="w-5 h-5" />
            数据概览
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <div className="bg-muted/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold">{stats.customers}</div>
              <div className="text-sm text-muted-foreground">客户</div>
            </div>
            <div className="bg-muted/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold">{stats.leads}</div>
              <div className="text-sm text-muted-foreground">线索</div>
            </div>
            <div className="bg-muted/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold">{stats.opportunities}</div>
              <div className="text-sm text-muted-foreground">商机</div>
            </div>
            <div className="bg-muted/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold">{stats.emailRecords}</div>
              <div className="text-sm text-muted-foreground">邮件记录</div>
            </div>
            <div className="bg-muted/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold">{stats.campaigns}</div>
              <div className="text-sm text-muted-foreground">营销活动</div>
            </div>
            <div className="bg-muted/10 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold">{stats.tasks}</div>
              <div className="text-sm text-muted-foreground">任务</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 操作按钮 */}
      <Card>
        <CardHeader>
          <CardTitle>数据操作</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* 备份数据 */}
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center gap-2"
              onClick={handleBackup}
              disabled={loading}
            >
              {loading && operation === 'backup' ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <FileDown className="w-6 h-6" />
              )}
              <span>备份数据</span>
              <span className="text-xs text-muted-foreground">下载完整数据备份文件</span>
            </Button>

            {/* 导入数据 */}
            <Button 
              variant="outline" 
              className="h-20 flex flex-col items-center gap-2"
              onClick={handleImport}
              disabled={loading}
            >
              {loading && operation === 'import' ? (
                <Loader2 className="w-6 h-6 animate-spin" />
              ) : (
                <FileUp className="w-6 h-6" />
              )}
              <span>导入数据</span>
              <span className="text-xs text-muted-foreground">从备份文件恢复数据</span>
            </Button>
          </div>

          <div className="border-t pt-4">
            <div className="flex items-center gap-2 mb-4">
              <AlertTriangle className="w-5 h-5 text-red-500" />
              <span className="font-medium text-red-500">危险操作区域</span>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* 重置为示例数据 */}
              <Button 
                variant="outline" 
                className="h-20 flex flex-col items-center gap-2 border-orange-500/50 hover:bg-orange-500/10"
                onClick={handleReset}
                disabled={loading}
              >
                {loading && operation === 'reset' ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <RefreshCw className="w-6 h-6 text-orange-500" />
                )}
                <span className="text-orange-500">重置为示例数据</span>
                <span className="text-xs text-muted-foreground">清除并恢复为演示数据</span>
              </Button>

              {/* 清空所有数据 */}
              <Button 
                variant="outline" 
                className="h-20 flex flex-col items-center gap-2 border-red-500/50 hover:bg-red-500/10"
                onClick={handleClear}
                disabled={loading}
              >
                {loading && operation === 'clear' ? (
                  <Loader2 className="w-6 h-6 animate-spin" />
                ) : (
                  <Trash2 className="w-6 h-6 text-red-500" />
                )}
                <span className="text-red-500">清空所有数据</span>
                <span className="text-xs text-muted-foreground">删除所有客户、线索、商机等数据</span>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* 说明 */}
      <Card className="bg-muted/10">
        <CardContent className="p-4">
          <div className="text-sm text-muted-foreground">
            <p className="font-medium mb-2">数据管理说明：</p>
            <ul className="list-disc list-inside space-y-1">
              <li>备份文件包含所有业务数据，可用于数据迁移或恢复</li>
              <li>导入数据会覆盖现有数据，请谨慎操作</li>
              <li>清空数据后无法恢复，建议先备份再清空</li>
              <li>重置为示例数据用于演示和测试场景</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* 确认对话框 */}
      <Dialog open={confirmDialogOpen} onOpenChange={setConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-red-500">
              <AlertTriangle className="w-5 h-5" />
              确认操作
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {confirmAction === 'clear' && (
              <p className="text-sm">
                您即将清空所有数据，包括客户、线索、商机、邮件记录等全部内容。
                <br />
                <span className="text-red-500 font-medium">此操作不可恢复！</span>
                <br />
                建议您先备份数据后再执行此操作。
              </p>
            )}
            {confirmAction === 'reset' && (
              <p className="text-sm">
                您即将重置所有数据为示例数据。
                <br />
                现有的所有数据将被清除并替换为演示数据。
                <br />
                此操作可用于测试或演示场景。
              </p>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirmDialogOpen(false)}>
              取消
            </Button>
            <Button 
              variant="destructive" 
              onClick={confirmAction === 'clear' ? confirmClear : confirmReset}
              disabled={loading}
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : '确认执行'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}