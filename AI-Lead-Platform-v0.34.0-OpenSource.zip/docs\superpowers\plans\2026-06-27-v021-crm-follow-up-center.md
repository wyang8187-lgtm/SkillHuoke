# v0.21.0 CRM Customer Follow-up Center Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a local CRM customer detail workspace with follow-up history, next-contact scheduling, and reusable English email and WhatsApp outreach copy.

**Architecture:** Extend the existing localStorage CRM model without breaking v0.20.0 records. Keep persistence and copy-generation helpers in `lead-wizard.ts`, render customer details through a focused dynamic route, and keep the CRM list optimized for scanning and navigation.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, localStorage, shadcn UI, Lucide icons, pnpm.

---

### Task 1: Extend the CRM persistence model

**Files:**
- Modify: `src/lib/lead-wizard.ts`

- [ ] Add optional `nextFollowUpAt`, required normalized `updatedAt`, follow-up channel types, and `SavedCrmFollowUp`.
- [ ] Add a dedicated `skillhuoke_crm_follow_ups_v021` storage key.
- [ ] Normalize old v0.20.0 customers while loading so missing fields receive safe defaults.
- [ ] Add helpers to find one customer, update scheduling fields, load/add/delete follow-up records, and preserve advanced CRM stages when contact records are added.
- [ ] Add deterministic English email and WhatsApp copy generators using company, country, customer type, and product context.
- [ ] Run `corepack pnpm run ts-check` and confirm there are no TypeScript errors.

### Task 2: Build the customer detail workspace

**Files:**
- Create: `src/app/crm-customers/[id]/page.tsx`

- [ ] Read the customer ID from the App Router params and load the matching local customer.
- [ ] Render the company profile, score, priority, status, source, and public contact summary.
- [ ] Add editable CRM status, next action, follow-up date, and note controls.
- [ ] Add a follow-up form with channel, contact date, and required content validation.
- [ ] Render newest-first follow-up history with delete controls.
- [ ] Render English email subject/body and WhatsApp copy with browser clipboard actions and visible success/error feedback.
- [ ] Render a stable empty state for an unknown customer ID.
- [ ] Run `corepack pnpm run ts-check`.

### Task 3: Simplify and repair the CRM list

**Files:**
- Modify: `src/app/crm-customers/page.tsx`

- [ ] Replace mojibake text with correct Simplified Chinese.
- [ ] Update the release badges to v0.21.0.
- [ ] Keep list filtering and quick status updates.
- [ ] Replace large inline note editors with concise next-action summaries.
- [ ] Add a clear “查看详情” link for every customer.
- [ ] Run `corepack pnpm run lint:build`.

### Task 4: Update release metadata and documentation

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `package.json`
- Modify: `README.md`

- [ ] Set the package version and displayed release to v0.21.0.
- [ ] Add the CRM detail page to the release review pages.
- [ ] Replace release-center mojibake strings touched by current release metadata with correct Chinese.
- [ ] Set package name to `AI-Lead-Platform-v0.21.0-OpenSource.zip`.
- [ ] Set GitHub remark to `v0.21.0：新增 CRM 客户详情、跟进时间线和英文开发动作`.
- [ ] Document the new detail workflow and local-only storage limitation.

### Task 5: Verify the release and create the upload package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.21.0-OpenSource.zip`

- [ ] Run `corepack pnpm run ts-check`.
- [ ] Run `corepack pnpm run lint:build`.
- [ ] Run `corepack pnpm run build`.
- [ ] Start or reuse the local server and verify HTTP 200 for `/login`, `/crm-customers`, `/release`, and a customer detail route.
- [ ] Inspect the CRM list and customer detail page in the in-app browser at desktop size.
- [ ] Package the source while excluding `node_modules`, `.next`, `.git`, `.env`, `.env.local`, log files, and TypeScript build cache.
- [ ] Inspect the ZIP entries to confirm no secret or generated dependency directories were included.
