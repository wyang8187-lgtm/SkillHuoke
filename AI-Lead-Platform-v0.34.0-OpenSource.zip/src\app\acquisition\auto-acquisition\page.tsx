'use client';

import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Zap,
  Clock,
  Play,
  Pause,
  Settings,
  Plus,
  History,
  Target,
  Loader2,
  ChevronDown,
  ChevronRight,
  Search,
  MapPin,
  Users,
  Calendar,
  RefreshCw,
  CheckCircle,
  AlertCircle,
  Trash2,
  Edit,
} from 'lucide-react';

// 自动获客任务类型
interface AutoTask {
  id: string;
  name: string;
  keywords: string[];
  regions: string[];
  customer_types: string[];
  frequency: string; // daily, weekly, hourly
  status: 'running' | 'paused' | 'completed' | 'error';
  last_run_time: string | null;
  next_run_time: string | null;
  total_results: number;
  created_at: string;
}

// 执行记录类型
interface ExecutionRecord {
  id: string;
  task_id: string;
  task_name: string;
  run_time: string;
  duration: number; // 秒
  results_count: number;
  new_leads: number;
  duplicates_filtered: number;
  status: 'success' | 'error';
  error_message?: string;
}

export default function AutoAcquisitionPage() {
  const [tasks, setTasks] = useState<AutoTask[]>([]);
  const [records, setRecords] = useState<ExecutionRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'tasks' | 'records' | 'create'>('tasks');
  const [showTaskDetails, setShowTaskDetails] = useState<string | null>(null);
  
  // 新任务表单
  const [newTask, setNewTask] = useState({
    name: '',
    keywords: '',
    regions: '',
    customer_types: '',
    frequency: 'daily',
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/auto-acquisition');
      if (res.ok) {
        const data = await res.json();
        setTasks(data.tasks || []);
        setRecords(data.records || []);
      }
    } catch (error) {
      console.error('加载自动获客数据失败', error);
    } finally {
      setLoading(false);
    }
  };

  // 创建任务
  const handleCreateTask = async () => {
    if (!newTask.name || !newTask.keywords) {
      alert('请填写任务名称和关键词');
      return;
    }

    try {
      const res = await fetch('/api/auto-acquisition', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newTask.name,
          keywords: newTask.keywords.split(',').map(k => k.trim()),
          regions: newTask.regions.split(',').map(r => r.trim()).filter(Boolean),
          customer_types: newTask.customer_types.split(',').map(t => t.trim()).filter(Boolean),
          frequency: newTask.frequency,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setTasks([...tasks, data.task]);
        setNewTask({ name: '', keywords: '', regions: '', customer_types: '', frequency: 'daily' });
        setActiveTab('tasks');
        alert('任务创建成功！');
      } else {
        const data = await res.json();
        alert(data.error || '创建失败');
      }
    } catch (error) {
      alert('创建失败，请重试');
    }
  };

  // 启动/暂停任务
  const handleToggleTask = async (taskId: string, currentStatus: string) => {
    const action = currentStatus === 'running' ? 'pause' : 'start';
    
    try {
      const res = await fetch('/api/auto-acquisition/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task_id: taskId, action }),
      });

      if (res.ok) {
        setTasks(tasks.map(t => 
          t.id === taskId 
            ? { ...t, status: action === 'start' ? 'running' : 'paused' }
            : t
        ));
      }
    } catch (error) {
      console.error('切换任务状态失败', error);
    }
  };

  // 删除任务
  const handleDeleteTask = async (taskId: string) => {
    if (!confirm('确定要删除此任务吗？')) return;
    
    try {
      const res = await fetch(`/api/auto-acquisition?task_id=${taskId}`, {
        method: 'DELETE',
      });

      if (res.ok) {
        setTasks(tasks.filter(t => t.id !== taskId));
      }
    } catch (error) {
      console.error('删除任务失败', error);
    }
  };

  // 手动执行任务
  const handleRunNow = async (taskId: string) => {
    try {
      const res = await fetch('/api/auto-acquisition/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task_id: taskId }),
      });

      if (res.ok) {
        const data = await res.json();
        setRecords([data.record, ...records]);
        setTasks(tasks.map(t => 
          t.id === taskId 
            ? { ...t, last_run_time: data.record.run_time, total_results: t.total_results + data.record.results_count }
            : t
        ));
        alert(`执行成功，发现 ${data.record.results_count} 条新线索！`);
      }
    } catch (error) {
      alert('执行失败，请重试');
    }
  };

  // 获取状态颜色
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'text-green-500';
      case 'paused': return 'text-yellow-500';
      case 'completed': return 'text-blue-500';
      case 'error': return 'text-red-500';
      default: return 'text-muted-foreground';
    }
  };

  // 获取状态Badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'running': 
        return <Badge className="bg-green-500/20 text-green-500">运行中</Badge>;
      case 'paused': 
        return <Badge className="bg-yellow-500/20 text-yellow-500">已暂停</Badge>;
      case 'completed': 
        return <Badge className="bg-blue-500/20 text-blue-500">已完成</Badge>;
      case 'error': 
        return <Badge className="bg-red-500/20 text-red-500">错误</Badge>;
      default: 
        return <Badge variant="outline">未知</Badge>;
    }
  };

  if (loading) {
    return (
      <MainLayout title="AI 7×24自动获客" breadcrumbs={[{ label: 'AI获客中心' }, { label: '自动获客' }]}>
        <div className="flex items-center justify-center h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="AI 7×24自动获客" breadcrumbs={[{ label: 'AI获客中心' }, { label: '自动获客' }]}>
      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center">
                <Play className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">运行中任务</p>
                <p className="text-2xl font-bold text-foreground">
                  {tasks.filter(t => t.status === 'running').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                <Zap className="h-5 w-5 text-purple-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">总获客数</p>
                <p className="text-2xl font-bold text-foreground">
                  {tasks.reduce((sum, t) => sum + t.total_results, 0)}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <Clock className="h-5 w-5 text-cyan-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">执行记录</p>
                <p className="text-2xl font-bold text-foreground">{records.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                <Target className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">成功率</p>
                <p className="text-2xl font-bold text-foreground">
                  {records.length > 0 
                    ? Math.round(records.filter(r => r.status === 'success').length / records.length * 100)
                    : 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tab切换 */}
      <div className="flex gap-2 mb-4">
        <Button
          variant={activeTab === 'tasks' ? 'default' : 'outline'}
          onClick={() => setActiveTab('tasks')}
          className={activeTab === 'tasks' ? 'bg-primary' : ''}
        >
          <Zap className="h-4 w-4 mr-2" />
          任务列表 ({tasks.length})
        </Button>
        <Button
          variant={activeTab === 'records' ? 'default' : 'outline'}
          onClick={() => setActiveTab('records')}
          className={activeTab === 'records' ? 'bg-primary' : ''}
        >
          <History className="h-4 w-4 mr-2" />
          执行记录 ({records.length})
        </Button>
        <Button
          variant={activeTab === 'create' ? 'default' : 'outline'}
          onClick={() => setActiveTab('create')}
          className={activeTab === 'create' ? 'bg-green-500' : ''}
        >
          <Plus className="h-4 w-4 mr-2" />
          创建任务
        </Button>
      </div>

      {/* 任务列表 */}
      {activeTab === 'tasks' && (
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            {tasks.length > 0 ? (
              <div className="divide-y divide-border">
                {tasks.map((task) => (
                  <div key={task.id} className="p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-medium text-foreground">{task.name}</h3>
                          {getStatusBadge(task.status)}
                        </div>
                        
                        <div className="flex items-center gap-3 text-sm text-muted-foreground mb-2">
                          <span className="flex items-center gap-1">
                            <Search className="h-3 w-3" />
                            关键词：{task.keywords.join(', ')}
                          </span>
                          {task.regions.length > 0 && (
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              地区：{task.regions.join(', ')}
                            </span>
                          )}
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            频率：{task.frequency === 'hourly' ? '每小时' : task.frequency === 'daily' ? '每天' : '每周'}
                          </span>
                        </div>

                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-muted-foreground">
                            已获取：{task.total_results} 条线索
                          </span>
                          {task.last_run_time && (
                            <span className="text-muted-foreground">
                              上次执行：{new Date(task.last_run_time).toLocaleString('zh-CN')}
                            </span>
                          )}
                          {task.next_run_time && task.status === 'running' && (
                            <span className="text-cyan-500">
                              下次执行：{new Date(task.next_run_time).toLocaleString('zh-CN')}
                            </span>
                          )}
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleRunNow(task.id)}
                          title="立即执行"
                        >
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                        <Button
                          variant={task.status === 'running' ? 'default' : 'outline'}
                          size="sm"
                          onClick={() => handleToggleTask(task.id, task.status)}
                          className={task.status === 'running' ? 'bg-yellow-500' : ''}
                        >
                          {task.status === 'running' ? (
                            <><Pause className="h-4 w-4 mr-1" />暂停</>
                          ) : (
                            <><Play className="h-4 w-4 mr-1" />启动</>
                          )}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteTask(task.id)}
                          className="text-red-500 hover:text-red-600"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <Zap className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>暂无自动获客任务</p>
                <p className="text-sm mt-1">点击"创建任务"开始设置自动获客</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* 执行记录 */}
      {activeTab === 'records' && (
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            {records.length > 0 ? (
              <div className="divide-y divide-border">
                {records.map((record) => (
                  <div key={record.id} className="p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                          record.status === 'success' ? 'bg-green-500/20' : 'bg-red-500/20'
                        }`}>
                          {record.status === 'success' 
                            ? <CheckCircle className="h-4 w-4 text-green-500" />
                            : <AlertCircle className="h-4 w-4 text-red-500" />
                          }
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{record.task_name}</p>
                          <p className="text-sm text-muted-foreground">
                            {new Date(record.run_time).toLocaleString('zh-CN')} · 
                            执行耗时 {record.duration}秒
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-foreground">
                          发现 {record.results_count} 条线索
                        </p>
                        <p className="text-sm text-muted-foreground">
                          新增 {record.new_leads} 条 · 过滤重复 {record.duplicates_filtered} 条
                        </p>
                      </div>
                    </div>
                    {record.error_message && (
                      <div className="mt-2 p-2 bg-red-500/10 rounded text-sm text-red-500">
                        错误：{record.error_message}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <History className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>暂无执行记录</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* 创建任务 */}
      {activeTab === 'create' && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <Plus className="h-5 w-5" />
              创建自动获客任务
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">任务名称 *</label>
                <input
                  type="text"
                  value={newTask.name}
                  onChange={(e) => setNewTask({ ...newTask, name: e.target.value })}
                  placeholder="如：深圳设计师自动获客"
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground focus:border-primary"
                />
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-1 block">搜索关键词 *</label>
                <input
                  type="text"
                  value={newTask.keywords}
                  onChange={(e) => setNewTask({ ...newTask, keywords: e.target.value })}
                  placeholder="多个关键词用逗号分隔，如：全屋定制,室内设计"
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground focus:border-primary"
                />
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-1 block">目标地区（可选）</label>
                <input
                  type="text"
                  value={newTask.regions}
                  onChange={(e) => setNewTask({ ...newTask, regions: e.target.value })}
                  placeholder="多个地区用逗号分隔，如：深圳,广州,佛山"
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground focus:border-primary"
                />
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-1 block">客户类型（可选）</label>
                <input
                  type="text"
                  value={newTask.customer_types}
                  onChange={(e) => setNewTask({ ...newTask, customer_types: e.target.value })}
                  placeholder="如：全案设计师,建材外贸公司"
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground focus:border-primary"
                />
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-1 block">执行频率</label>
                <select
                  value={newTask.frequency}
                  onChange={(e) => setNewTask({ ...newTask, frequency: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-border bg-background text-foreground focus:border-primary"
                >
                  <option value="hourly">每小时执行一次</option>
                  <option value="daily">每天执行一次</option>
                  <option value="weekly">每周执行一次</option>
                </select>
              </div>

              <div className="pt-4 flex gap-3">
                <Button
                  variant="default"
                  onClick={handleCreateTask}
                  className="bg-green-500 hover:bg-green-600"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  创建并启动
                </Button>
                <Button
                  variant="outline"
                  onClick={() => setActiveTab('tasks')}
                >
                  取消
                </Button>
              </div>

              <div className="mt-4 p-4 rounded-lg bg-muted/50">
                <h4 className="font-medium text-foreground mb-2">说明</h4>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• 任务创建后会自动开始运行，按设定频率定期搜索</li>
                  <li>• 每次执行会自动过滤重复线索，只保留新发现</li>
                  <li>• 发现新线索时会发送通知提醒</li>
                  <li>• 可随时暂停/启动任务，或手动立即执行</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </MainLayout>
  );
}