import { NextRequest, NextResponse } from 'next/server';

// 线索自动发现API - 基于已有客户画像推荐相似潜在客户

// 行业标签库
const INDUSTRY_TAGS = [
  '建材外贸', '家具出口', '全屋定制', '橱柜衣柜', '陶瓷卫浴', 
  '五金配件', '照明灯饰', '地板门窗', '涂料化工', '机械装备',
  '纺织服装', '家电出口', '跨境电商', '进出口贸易', '国际物流'
];

// 区域库 - 大湾区重点区域
const BAY_AREA_DISTRICTS = {
  '顺德': ['大良', '容桂', '乐从', '龙江', '北滘', '陈村', '均安', '杏坛', '勒流'],
  '南海': ['桂城', '大沥', '里水', '狮山', '丹灶', '九江', '西樵'],
  '禅城': ['石湾', '张槎', '南庄'],
  '三水': ['西南', '云东海', '白坭', '乐平'],
  '高明': ['荷城', '杨和', '明城', '更合'],
  '东莞': ['厚街', '大岭山', '寮步', '常平', '虎门', '长安', '塘厦', '凤岗'],
  '深圳': ['宝安', '龙岗', '龙华', '南山', '福田', '罗田', '光明'],
  '广州': ['白云', '番禺', '花都', '增城', '南沙', '天河', '荔湾']
};

// 客户规模分类
const COMPANY_SIZES = ['大型(500人以上)', '中型(100-500人)', '小型(50-100人)', '微型(50人以下)'];

// 意向度分类
const INTENT_LEVELS = ['A类(高意向)', 'B类(中意向)', 'C类(低意向)', '待评估'];

// 根据客户画像生成相似潜在客户推荐
function generateSimilarCustomers(customerProfile: {
  industry?: string;
  region?: string;
  city?: string;
  companySize?: string;
  tags?: string[];
}): Array<{
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  address: string;
  industry: string;
  companySize: string;
  similarityScore: number;
  reasons: string[];
  source: string;
}> {
  const results = [];
  const count = Math.floor(Math.random() * 8) + 5;
  
  // 基于画像参数
  const baseIndustry = customerProfile.industry || INDUSTRY_TAGS[Math.floor(Math.random() * INDUSTRY_TAGS.length)];
  const baseRegion = customerProfile.region || '广东';
  const baseCity = customerProfile.city || '佛山';
  
  // 获取区域下的镇街
  const districts = BAY_AREA_DISTRICTS[baseCity as keyof typeof BAY_AREA_DISTRICTS] || ['某区'];
  
  // 公司名称库
  const companyPrefixes: Record<string, string[]> = {
    '建材外贸': ['宏达建材', '盈科建材', '鑫源建材', '恒信建材', '博远建材', '联创建材', '兴达建材'],
    '家具出口': ['雅居家具', '美克家具', '华达家具', '恒久家具', '欧派家居', '索菲亚家居', '尚品宅配'],
    '全屋定制': ['全屋定制中心', '家定制', '优家定制', '尚品定制', '雅定制', '定制家居馆'],
    '橱柜衣柜': ['橱柜世界', '衣柜定制', '厨柜之家', '衣柜工坊', '橱柜定制馆'],
    '陶瓷卫浴': ['陶瓷总汇', '卫浴世界', '瓷砖中心', '洁具馆', '陶瓷批发'],
    '五金配件': ['五金城', '配件总汇', '五金批发', '配件中心', '五金建材'],
    '照明灯饰': ['灯饰城', '照明中心', '灯具批发', '灯饰世界'],
    '地板门窗': ['地板世界', '门窗中心', '木地板馆', '门窗批发'],
    '涂料化工': ['涂料总汇', '化工建材', '油漆批发', '涂料中心'],
    '机械装备': ['机械总汇', '装备中心', '机械批发', '设备公司'],
    '纺织服装': ['纺织总汇', '服装批发', '布匹中心', '纺织城'],
    '家电出口': ['家电总汇', '电器批发', '家电中心', '电器城'],
    '跨境电商': ['跨境电商', '贸易公司', '进出口', '电商中心'],
    '进出口贸易': ['贸易公司', '进出口', '外贸中心', '贸易总汇'],
    '国际物流': ['物流公司', '货运中心', '物流总汇', '运输公司']
  };
  
  const suffixes = ['有限公司', '集团有限公司', '贸易有限公司', '实业有限公司', '制造有限公司'];
  const surnames = ['王', '李', '张', '刘', '陈', '杨', '黄', '赵', '周', '吴', '郑', '孙', '林', '何', '郭'];
  const givenNames = ['伟', '芳', '娜', '敏', '静', '丽', '强', '磊', '洋', '艳', '勇', '军', '明', '华', '杰'];
  
  for (let i = 0; i < count; i++) {
    // 生成真实手机号
    const phonePrefixes = ['138', '139', '150', '151', '152', '158', '159', '186', '187', '188', '189', '199'];
    const prefix = phonePrefixes[Math.floor(Math.random() * phonePrefixes.length)];
    const phoneSuffix = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    const phone = prefix + phoneSuffix;
    
    // 验证手机号格式
    if (!/^1[3-9]\d{9}$/.test(phone)) continue;
    
    const prefixes = companyPrefixes[baseIndustry] || companyPrefixes['建材外贸'];
    const companyPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)];
    const companyName = baseCity + companyPrefix + suffix;
    
    const surname = surnames[Math.floor(Math.random() * surnames.length)];
    const givenName = givenNames[Math.floor(Math.random() * givenNames.length)];
    const contactName = surname + givenName;
    
    const district = districts[Math.floor(Math.random() * districts.length)];
    const address = `${baseRegion}${baseCity}${district}某路${Math.floor(Math.random() * 200) + 1}号`;
    
    // 计算相似度分数
    const similarityScore = Math.floor(Math.random() * 30) + 70;
    
    // 生成推荐理由
    const reasons = [];
    if (customerProfile.industry === baseIndustry) {
      reasons.push(`同行业(${baseIndustry})`);
    }
    if (customerProfile.city === baseCity) {
      reasons.push(`同城(${baseCity})`);
    }
    if (customerProfile.companySize === COMPANY_SIZES[Math.floor(Math.random() * COMPANY_SIZES.length)]) {
      reasons.push(`相近规模`);
    }
    if (reasons.length === 0) {
      reasons.push('行业特征相似');
    }
    
    results.push({
      id: `recommend_${Date.now()}_${i}`,
      companyName,
      contactName,
      phone,
      address,
      industry: baseIndustry,
      companySize: COMPANY_SIZES[Math.floor(Math.random() * COMPANY_SIZES.length)],
      similarityScore,
      reasons,
      source: 'AI智能推荐'
    });
  }
  
  // 按相似度排序
  return results.sort((a, b) => b.similarityScore - a.similarityScore);
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    
    // 支持两种模式：
    // 1. 基于单个客户画像推荐
    // 2. 基于整体客户特征统计推荐
    
    if (body.customerId) {
      // 单个客户画像模式 - 实际应用中从数据库获取客户信息
      // 这里模拟获取客户画像
      const customerProfile = {
        industry: body.industry || INDUSTRY_TAGS[Math.floor(Math.random() * INDUSTRY_TAGS.length)],
        region: body.region || '广东',
        city: body.city || '佛山',
        companySize: body.companySize || COMPANY_SIZES[Math.floor(Math.random() * COMPANY_SIZES.length)],
        tags: body.tags || []
      };
      
      const recommendations = generateSimilarCustomers(customerProfile);
      
      return NextResponse.json({
        success: true,
        data: {
          mode: 'single_customer',
          basedOn: {
            customerId: body.customerId,
            profile: customerProfile
          },
          recommendations,
          total: recommendations.length,
          note: '基于客户画像的相似客户推荐，当前为模拟数据'
        }
      });
    } else {
      // 整体客户特征统计模式
      // 分析已有客户的行业分布、区域分布等特征，推荐潜在客户
      
      // 模拟已有客户统计数据
      const customerStats = {
        industryDistribution: {
          '建材外贸': 35,
          '家具出口': 25,
          '全屋定制': 20,
          '陶瓷卫浴': 10,
          '其他': 10
        },
        regionDistribution: {
          '佛山顺德': 40,
          '东莞厚街': 25,
          '深圳宝安': 15,
          '广州番禺': 10,
          '其他': 10
        },
        sizeDistribution: {
          '中型(100-500人)': 45,
          '小型(50-100人)': 30,
          '大型(500人以上)': 15,
          '微型(50人以下)': 10
        },
        totalCustomers: 156
      };
      
      // 根据统计数据生成推荐
      const recommendations = [];
      
      // 主要行业推荐
      const topIndustries = Object.entries(customerStats.industryDistribution)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([industry]) => industry);
      
      // 主要区域推荐
      const topRegions = Object.entries(customerStats.regionDistribution)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([region]) => region);
      
      for (let i = 0; i < 10; i++) {
        const industry = topIndustries[Math.floor(Math.random() * topIndustries.length)];
        const regionStr = topRegions[Math.floor(Math.random() * topRegions.length)];
        const [baseCity, district] = regionStr.split(' ');
        
        const phonePrefixes = ['138', '139', '150', '151', '152', '158', '159', '186', '187', '188', '189', '199'];
        const phone = phonePrefixes[Math.floor(Math.random() * phonePrefixes.length)] + 
          Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
        
        if (!/^1[3-9]\d{9}$/.test(phone)) continue;
        
        recommendations.push({
          id: `stat_recommend_${Date.now()}_${i}`,
          companyName: `${baseCity || '佛山'}${industry === '建材外贸' ? '宏达建材' : industry === '家具出口' ? '雅居家具' : '鑫源实业'}有限公司`,
          contactName: ['王伟', '李芳', '张娜', '陈敏', '杨静'][Math.floor(Math.random() * 5)],
          phone,
          address: `广东${baseCity || '佛山'}${district || '大良'}某路${Math.floor(Math.random() * 100) + 1}号`,
          industry,
          companySize: COMPANY_SIZES[Math.floor(Math.random() * COMPANY_SIZES.length)],
          similarityScore: Math.floor(Math.random() * 30) + 75,
          reasons: ['主力客户行业', '主力客户区域', '潜力市场'],
          source: 'AI统计分析推荐'
        });
      }
      
      return NextResponse.json({
        success: true,
        data: {
          mode: 'global_stats',
          basedOn: customerStats,
          recommendations,
          total: recommendations.length,
          insights: [
            `您的主力客户集中在${topIndustries.join('、')}行业`,
            `主要客户区域为${topRegions.join('、')}`,
            `建议拓展${topIndustries[0]}行业在${topRegions[0]}周边的潜在客户`
          ],
          note: '基于客户统计数据的智能推荐，当前为模拟数据'
        }
      });
    }
  } catch (error) {
    console.error('Lead discovery error:', error);
    return NextResponse.json(
      { success: false, error: '线索发现失败' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  // GET模式 - 获取整体推荐
  try {
    // 模拟获取所有客户统计数据并生成推荐
    const recommendations = generateSimilarCustomers({
      industry: '建材外贸',
      region: '广东',
      city: '佛山'
    });
    
    return NextResponse.json({
      success: true,
      data: {
        recommendations,
        total: recommendations.length,
        note: '基于客户画像的智能推荐，当前为模拟数据'
      }
    });
  } catch (error) {
    console.error('Lead discovery GET error:', error);
    return NextResponse.json(
      { success: false, error: '获取推荐失败' },
      { status: 500 }
    );
  }
}