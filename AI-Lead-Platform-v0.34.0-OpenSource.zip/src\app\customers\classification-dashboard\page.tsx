'use client';

import { useState, useEffect } from 'react';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { RefreshCw, Filter, PieChartIcon, MapPin, Users, Tag } from 'lucide-react';

// 预置行业分布数据
const industryData = [
  { name: '建材外贸', value: 156, color: '#3b82f6' },
  { name: '家具出口', value: 128, color: '#f97316' },
  { name: '全屋定制', value: 98, color: '#22c55e' },
  { name: '橱柜衣柜', value: 76, color: '#8b5cf6' },
  { name: '陶瓷卫浴', value: 65, color: '#ec4899' },
  { name: '五金配件', value: 54, color: '#14b8a6' },
  { name: '照明灯饰', value: 43, color: '#f59e0b' },
  { name: '地板门窗', value: 32, color: '#06b6d4' },
];

// 预置区域分布数据
const regionData = [
  { name: '深圳', count: 145, fill: '#3b82f6' },
  { name: '广州', count: 98, fill: '#22c55e' },
  { name: '佛山', count: 87, fill: '#f97316' },
  { name: '东莞', count: 65, fill: '#8b5cf6' },
  { name: '中山', count: 45, fill: '#ec4899' },
  { name: '珠海', count: 32, fill: '#14b8a6' },
  { name: '顺德', count: 78, fill: '#f59e0b' },
  { name: '海外', count: 292, fill: '#64748b' },
];

// 预置规模分布数据
const scaleData = [
  { name: '大型企业', value: 45, color: '#3b82f6' },
  { name: '中型企业', value: 128, color: '#22c55e' },
  { name: '小型企业', value: 256, color: '#f97316' },
];

// 预置意向度分布数据
const intentData = [
  { name: 'A类(高意向)', value: 78, color: '#22c55e' },
  { name: 'B类(中意向)', value: 156, color: '#f97316' },
  { name: 'C类(低意向)', value: 195, color: '#64748b' },
];

// 预置行业标签
const INDUSTRY_TAGS = [
  '建材外贸', '家具出口', '全屋定制', '橱柜衣柜', '陶瓷卫浴',
  '五金配件', '照明灯饰', '地板门窗', '涂料化工', '机械装备',
  '纺织服装', '家电出口', '跨境电商', '进出口贸易', '国际物流',
];

// 预置区域标签 - 国内
const DOMESTIC_REGIONS = {
  '广东': ['深圳', '广州', '佛山', '东莞', '中山', '珠海', '惠州', '江门', '肇庆', '顺德', '南海', '大良', '容桂', '乐从', '龙江', '北滘'],
  '浙江': ['杭州', '宁波', '温州', '嘉兴', '湖州', '绍兴', '金华', '台州'],
  '江苏': ['苏州', '南京', '无锡', '常州', '南通', '扬州', '镇江', '徐州'],
  '福建': ['福州', '厦门', '泉州', '漳州', '莆田'],
};

// 预置区域标签 - 海外
const OVERSEAS_REGIONS = {
  '东南亚': ['越南', '泰国', '马来西亚', '印尼', '新加坡', '菲律宾'],
  '中东': ['沙特', '阿联酋', '卡塔尔', '科威特', '伊朗'],
  '欧洲': ['德国', '法国', '英国', '意大利', '西班牙', '荷兰'],
  '北美': ['美国', '加拿大', '墨西哥'],
  '南美': ['巴西', '阿根廷', '智利'],
};

export default function ClassificationDashboardPage() {
  const [filters, setFilters] = useState({
    industry: '',
    region: '',
    scale: '',
    intent: '',
    source: '',
  });
  const [isLoading, setIsLoading] = useState(false);

  // 热力地图组件
  const HeatmapChart = () => (
    <div className="relative h-[400px] w-full bg-[var(--card)] rounded-lg overflow-hidden">
      <svg viewBox="0 0 800 400" className="w-full h-full">
        {/* 标题 */}
        <text x="400" y="30" textAnchor="middle" fill="var(--foreground)" fontSize="16" fontWeight="bold">大湾区客户分布热力图</text>
        
        {/* 深圳 */}
        <circle cx="500" cy="150" r="60" fill="#3b82f6" opacity="0.7" />
        <text x="500" y="150" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">深圳</text>
        <text x="500" y="165" textAnchor="middle" fill="white" fontSize="10">145客户</text>
        
        {/* 广州 */}
        <circle cx="400" cy="120" r="50" fill="#22c55e" opacity="0.7" />
        <text x="400" y="120" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">广州</text>
        <text x="400" y="135" textAnchor="middle" fill="white" fontSize="10">98客户</text>
        
        {/* 佛山 */}
        <circle cx="300" cy="180" r="45" fill="#f97316" opacity="0.7" />
        <text x="300" y="180" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">佛山</text>
        <text x="300" y="195" textAnchor="middle" fill="white" fontSize="10">87客户</text>
        
        {/* 顺德 */}
        <circle cx="280" cy="250" r="40" fill="#f59e0b" opacity="0.7" />
        <text x="280" y="250" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">顺德</text>
        <text x="280" y="265" textAnchor="middle" fill="white" fontSize="10">78客户</text>
        
        {/* 东莞 */}
        <circle cx="550" cy="200" r="35" fill="#8b5cf6" opacity="0.7" />
        <text x="550" y="200" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">东莞</text>
        <text x="550" y="215" textAnchor="middle" fill="white" fontSize="10">65客户</text>
        
        {/* 中山 */}
        <circle cx="200" cy="280" r="30" fill="#ec4899" opacity="0.7" />
        <text x="200" y="280" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">中山</text>
        <text x="200" y="295" textAnchor="middle" fill="white" fontSize="10">45客户</text>
        
        {/* 珠海 */}
        <circle cx="150" cy="350" r="25" fill="#14b8a6" opacity="0.7" />
        <text x="150" y="350" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">珠海</text>
        <text x="150" y="365" textAnchor="middle" fill="white" fontSize="10">32客户</text>
        
        {/* 连接线 */}
        <line x1="400" y1="120" x2="300" y2="180" stroke="var(--border)" strokeWidth="2" opacity="0.5" />
        <line x1="400" y1="120" x2="500" y2="150" stroke="var(--border)" strokeWidth="2" opacity="0.5" />
        <line x1="500" y1="150" x2="550" y2="200" stroke="var(--border)" strokeWidth="2" opacity="0.5" />
        <line x1="300" y1="180" x2="280" y2="250" stroke="var(--border)" strokeWidth="2" opacity="0.5" />
        <line x1="280" y1="250" x2="200" y2="280" stroke="var(--border)" strokeWidth="2" opacity="0.5" />
        <line x1="200" y1="280" x2="150" y2="350" stroke="var(--border)" strokeWidth="2" opacity="0.5" />
        
        {/* 海外区域 */}
        <rect x="50" y="50" width="120" height="60" fill="#64748b" opacity="0.3" rx="4" />
        <text x="110" y="85" textAnchor="middle" fill="var(--foreground)" fontSize="12">海外客户</text>
        <text x="110" y="100" textAnchor="middle" fill="var(--foreground)" fontSize="10">292客户</text>
      </svg>
      
      {/* 图例 */}
      <div className="absolute bottom-4 left-4 flex gap-2 text-xs flex-wrap">
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-[#3b82f6]" />
          <span>深圳</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-[#22c55e]" />
          <span>广州</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-[#f97316]" />
          <span>佛山</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-[#f59e0b]" />
          <span>顺德</span>
        </div>
        <div className="flex items-center gap-1">
          <div className="w-3 h-3 rounded-full bg-[#8b5cf6]" />
          <span>东莞</span>
        </div>
      </div>
    </div>
  );

  const handleRefresh = async () => {
    setIsLoading(true);
    // 模拟刷新
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsLoading(false);
  };

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--foreground)]">客户分类看板</h1>
          <p className="text-[var(--muted-foreground)]">可视化展示客户分布情况，支持智能筛选</p>
        </div>
        <Button variant="outline" onClick={handleRefresh} disabled={isLoading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
          刷新数据
        </Button>
      </div>

      {/* 筛选面板 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            多维度筛选
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">行业分类</label>
              <select 
                className="w-full px-3 py-2 rounded-md border border-[var(--border)] bg-[var(--background)] text-[var(--foreground)]"
                value={filters.industry}
                onChange={(e) => setFilters({ ...filters, industry: e.target.value })}
              >
                <option value="">全部行业</option>
                {INDUSTRY_TAGS.map(tag => (
                  <option key={tag} value={tag}>{tag}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">区域分类</label>
              <select 
                className="w-full px-3 py-2 rounded-md border border-[var(--border)] bg-[var(--background)] text-[var(--foreground)]"
                value={filters.region}
                onChange={(e) => setFilters({ ...filters, region: e.target.value })}
              >
                <option value="">全部区域</option>
                <optgroup label="国内 - 广东">
                  {DOMESTIC_REGIONS['广东'].map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </optgroup>
                <optgroup label="国内 - 浙江">
                  {DOMESTIC_REGIONS['浙江'].map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </optgroup>
                <optgroup label="国内 - 江苏">
                  {DOMESTIC_REGIONS['江苏'].map(city => (
                    <option key={city} value={city}>{city}</option>
                  ))}
                </optgroup>
                <optgroup label="海外 - 东南亚">
                  {OVERSEAS_REGIONS['东南亚'].map(country => (
                    <option key={country} value={country}>{country}</option>
                  ))}
                </optgroup>
                <optgroup label="海外 - 欧洲">
                  {OVERSEAS_REGIONS['欧洲'].map(country => (
                    <option key={country} value={country}>{country}</option>
                  ))}
                </optgroup>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">客户规模</label>
              <select 
                className="w-full px-3 py-2 rounded-md border border-[var(--border)] bg-[var(--background)] text-[var(--foreground)]"
                value={filters.scale}
                onChange={(e) => setFilters({ ...filters, scale: e.target.value })}
              >
                <option value="">全部规模</option>
                <option value="large">大型企业(500人+)</option>
                <option value="medium">中型企业(100-500人)</option>
                <option value="small">小型企业(100人以下)</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">意向度</label>
              <select 
                className="w-full px-3 py-2 rounded-md border border-[var(--border)] bg-[var(--background)] text-[var(--foreground)]"
                value={filters.intent}
                onChange={(e) => setFilters({ ...filters, intent: e.target.value })}
              >
                <option value="">全部意向</option>
                <option value="A">A类(高意向)</option>
                <option value="B">B类(中意向)</option>
                <option value="C">C类(低意向)</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">来源渠道</label>
              <select 
                className="w-full px-3 py-2 rounded-md border border-[var(--border)] bg-[var(--background)] text-[var(--foreground)]"
                value={filters.source}
                onChange={(e) => setFilters({ ...filters, source: e.target.value })}
              >
                <option value="">全部来源</option>
                <option value="ai_search">AI搜索</option>
                <option value="linkedin">LinkedIn</option>
                <option value="facebook">Facebook</option>
                <option value="exhibition">展会</option>
                <option value="referral">客户推荐</option>
              </select>
            </div>
          </div>
          
          {/* 已选筛选条件展示 */}
          <div className="mt-4 flex gap-2 flex-wrap">
            {Object.entries(filters).filter(([_, v]) => v).map(([key, value]) => (
              <Badge key={key} variant="secondary" className="gap-1">
                {key === 'industry' ? '行业' : key === 'region' ? '区域' : key === 'scale' ? '规模' : key === 'intent' ? '意向' : '来源'}: {value}
                <button onClick={() => setFilters({ ...filters, [key]: '' })} className="ml-1 hover:text-red-500">×</button>
              </Badge>
            ))}
            {Object.values(filters).some(v => v) && (
              <Button size="sm" variant="ghost" onClick={() => setFilters({ industry: '', region: '', scale: '', intent: '', source: '' })}>
                清除全部
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* 数据卡片概览 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-500" />
              <span className="text-sm text-[var(--muted-foreground)]">总客户数</span>
            </div>
            <div className="text-2xl font-bold mt-2">429</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Tag className="h-5 w-5 text-green-500" />
              <span className="text-sm text-[var(--muted-foreground)]">已分类客户</span>
            </div>
            <div className="text-2xl font-bold mt-2">386</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <PieChartIcon className="h-5 w-5 text-orange-500" />
              <span className="text-sm text-[var(--muted-foreground)]">行业分类数</span>
            </div>
            <div className="text-2xl font-bold mt-2">15</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <MapPin className="h-5 w-5 text-purple-500" />
              <span className="text-sm text-[var(--muted-foreground)]">区域分类数</span>
            </div>
            <div className="text-2xl font-bold mt-2">48</div>
          </CardContent>
        </Card>
      </div>

      {/* 图表区域 */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* 行业分布饼图 */}
        <Card>
          <CardHeader>
            <CardTitle>行业分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={industryData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {industryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 区域分布柱状图 */}
        <Card>
          <CardHeader>
            <CardTitle>区域分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={regionData}>
                <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'var(--card)', border: '1px solid var(--border)' }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 规模分布 */}
        <Card>
          <CardHeader>
            <CardTitle>客户规模分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={scaleData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {scaleData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* 意向度分布 */}
        <Card>
          <CardHeader>
            <CardTitle>意向度分布</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={intentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  fill="#8884d8"
                  paddingAngle={5}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {intentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* 热力地图 */}
      <Card>
        <CardHeader>
          <CardTitle>大湾区客户热力分布图</CardTitle>
        </CardHeader>
        <CardContent>
          <HeatmapChart />
        </CardContent>
      </Card>

      {/* 标签体系展示 */}
      <Card>
        <CardHeader>
          <CardTitle>智能标签体系</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 行业标签 */}
          <div>
            <h4 className="text-sm font-medium mb-2 text-[var(--muted-foreground)]">行业标签</h4>
            <div className="flex gap-2 flex-wrap">
              {INDUSTRY_TAGS.map(tag => (
                <Badge key={tag} variant="outline" className="cursor-pointer hover:bg-[var(--accent)]">
                  {tag}
                </Badge>
              ))}
            </div>
          </div>
          
          {/* 国内区域标签 */}
          <div>
            <h4 className="text-sm font-medium mb-2 text-[var(--muted-foreground)]">国内区域标签</h4>
            <div className="flex gap-2 flex-wrap">
              {Object.entries(DOMESTIC_REGIONS).map(([province, cities]) => (
                <Badge key={province} variant="secondary" className="bg-blue-500/20">
                  {province}
                </Badge>
              ))}
            </div>
          </div>
          
          {/* 海外区域标签 */}
          <div>
            <h4 className="text-sm font-medium mb-2 text-[var(--muted-foreground)]">海外区域标签</h4>
            <div className="flex gap-2 flex-wrap">
              {Object.entries(OVERSEAS_REGIONS).map(([region, countries]) => (
                <Badge key={region} variant="secondary" className="bg-purple-500/20">
                  {region}
                </Badge>
              ))}
            </div>
          </div>
          
          {/* 规模标签 */}
          <div>
            <h4 className="text-sm font-medium mb-2 text-[var(--muted-foreground)]">规模标签</h4>
            <div className="flex gap-2">
              <Badge variant="outline" className="bg-green-500/20">大型企业</Badge>
              <Badge variant="outline" className="bg-yellow-500/20">中型企业</Badge>
              <Badge variant="outline" className="bg-red-500/20">小型企业</Badge>
            </div>
          </div>
          
          {/* 意向度标签 */}
          <div>
            <h4 className="text-sm font-medium mb-2 text-[var(--muted-foreground)]">意向度标签</h4>
            <div className="flex gap-2">
              <Badge variant="outline" className="bg-green-500/20 border-green-500">A类(高意向)</Badge>
              <Badge variant="outline" className="bg-orange-500/20 border-orange-500">B类(中意向)</Badge>
              <Badge variant="outline" className="bg-gray-500/20 border-gray-500">C类(低意向)</Badge>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}