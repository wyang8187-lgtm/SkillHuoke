'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Search, 
  Shield, 
  Building2, 
  Phone, 
  Mail, 
  MapPin, 
  Calendar, 
  AlertCircle, 
  Loader2,
  Plus,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';
import { EmptyState } from '@/components/ui/empty-state';

interface TrademarkResult {
  id: string;
  trademark_name: string;
  trademark_no: string;
  registrant: string;
  registrant_address: string;
  category: string;
  status: string;
  register_date: string;
  valid_until: string;
  phone?: string;
  email?: string;
  related_companies: Array<{
    name: string;
    type: string;
    industry: string;
    location: string;
  }>;
}

export default function TrademarkSearchPage() {
  const [keyword, setKeyword] = useState('');
  const [trademarkNo, setTrademarkNo] = useState('');
  const [results, setResults] = useState<TrademarkResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [error, setError] = useState('');
  const [selectedTrademark, setSelectedTrademark] = useState<TrademarkResult | null>(null);

  const handleSearch = async () => {
    if (!keyword.trim() && !trademarkNo.trim()) {
      setError('请输入品牌名或商标注册号');
      return;
    }

    setLoading(true);
    setError('');
    setResults([]);
    setSelectedTrademark(null);

    try {
      const params = new URLSearchParams();
      if (keyword) params.append('keyword', keyword);
      if (trademarkNo) params.append('trademarkNo', trademarkNo);

      const response = await fetch(`/api/trademark-search?${params.toString()}`);
      const data = await response.json();
      
      if (data.success) {
        setResults(data.data);
        setSearched(true);
      } else {
        setError(data.error || '搜索失败');
      }
    } catch (err) {
      setError('网络错误，请稍后重试');
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case '已注册':
        return 'bg-green-500';
      case '审核中':
        return 'bg-yellow-500';
      case '已驳回':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const handleAddToCustomer = (trademark: TrademarkResult) => {
    // 模拟添加到客户
    console.log('添加到客户:', trademark);
  };

  return (
    <div className="min-h-screen bg-[var(--background)]">
      <div className="p-6">
        {/* 页面标题 */}
        <div className="mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Shield className="h-6 w-6 text-blue-500" />
            <h1 className="text-2xl font-bold text-[var(--foreground)]">品牌商标库</h1>
          </div>
          <p className="text-[var(--muted-foreground)]">
            搜索品牌商标信息，查找注册人及相关企业，可一键转为客户
          </p>
        </div>

        {/* 搜索区域 */}
        <Card className="bg-[var(--card)] border-[var(--border)] mb-6">
          <CardHeader>
            <CardTitle className="text-[var(--foreground)]">搜索条件</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="block text-sm font-medium text-[var(--muted-foreground)] mb-2">
                  品牌名称
                </label>
                <Input
                  placeholder="输入品牌名称..."
                  value={keyword}
                  onChange={(e) => setKeyword(e.target.value)}
                  className="bg-[var(--background)] border-[var(--border)]"
                />
              </div>
              <div className="w-48">
                <label className="block text-sm font-medium text-[var(--muted-foreground)] mb-2">
                  商标注册号
                </label>
                <Input
                  placeholder="输入商标号..."
                  value={trademarkNo}
                  onChange={(e) => setTrademarkNo(e.target.value)}
                  className="bg-[var(--background)] border-[var(--border)]"
                />
              </div>
              <Button 
                onClick={handleSearch}
                disabled={loading}
                className="bg-blue-500 hover:bg-blue-600"
              >
                {loading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                搜索
              </Button>
            </div>

            {error && (
              <div className="mt-4 flex items-center gap-2 text-red-500">
                <AlertCircle className="h-4 w-4" />
                <span>{error}</span>
              </div>
            )}
          </CardContent>
        </Card>

        {/* 搜索结果 */}
        {searched && (
          <div className="mb-4">
            <span className="text-[var(--muted-foreground)]">
              共找到 {results.length} 条商标记录
            </span>
          </div>
        )}

        {/* 结果列表 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {results.map((trademark) => (
            <Card 
              key={trademark.id} 
              className="bg-[var(--card)] border-[var(--border)] hover:border-[var(--primary)] transition-all cursor-pointer"
              onClick={() => setSelectedTrademark(trademark)}
            >
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  {/* 商标图标 */}
                  <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Shield className="h-6 w-6 text-blue-500" />
                  </div>

                  {/* 主要信息 */}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-semibold text-[var(--foreground)]">
                        {trademark.trademark_name}
                      </h3>
                      <Badge className={getStatusColor(trademark.status)}>
                        {trademark.status}
                      </Badge>
                    </div>

                    <p className="text-sm text-[var(--muted-foreground)] mb-2">
                      注册号：{trademark.trademark_no} · {trademark.category}
                    </p>

                    <p className="text-sm text-[var(--foreground)] mb-2">
                      <Building2 className="h-3 w-3 inline mr-1" />
                      注册人：{trademark.registrant}
                    </p>

                    <div className="flex items-center gap-3 text-xs text-[var(--muted-foreground)]">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        注册：{trademark.register_date}
                      </span>
                      {trademark.valid_until !== '-' && (
                        <span className="flex items-center gap-1">
                          有效期至：{trademark.valid_until}
                        </span>
                      )}
                    </div>

                    {trademark.phone && (
                      <p className="text-sm mt-2 flex items-center gap-1 text-green-500">
                        <Phone className="h-3 w-3" />
                        {trademark.phone}
                      </p>
                    )}
                  </div>
                </div>

                {/* 关联企业 */}
                {trademark.related_companies.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-[var(--border)]">
                    <p className="text-xs text-[var(--muted-foreground)] mb-1">关联企业：</p>
                    {trademark.related_companies.map((company, idx) => (
                      <Badge key={idx} variant="outline" className="mr-1 mb-1 text-xs">
                        {company.name}
                      </Badge>
                    ))}
                  </div>
                )}

                {/* 操作按钮 */}
                <div className="mt-3 pt-3 border-t border-[var(--border)] flex gap-2">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedTrademark(trademark);
                    }}
                  >
                    <ExternalLink className="h-4 w-4 mr-1" />
                    详情
                  </Button>
                  {trademark.phone && (
                    <Button 
                      variant="default" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleAddToCustomer(trademark);
                      }}
                    >
                      <Plus className="h-4 w-4 mr-1" />
                      转客户
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* 空状态 */}
        {searched && results.length === 0 && !loading && (
          <EmptyState
            icon={<Shield className="h-12 w-12 text-[var(--muted-foreground)]" />}
            title="未找到商标记录"
            description="请尝试调整搜索关键词或商标号"
          />
        )}

        {/* 详情弹窗 */}
        {selectedTrademark && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
            <Card className="bg-[var(--card)] border-[var(--border)] w-full max-w-lg mx-4">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="text-[var(--foreground)]">商标详情</CardTitle>
                <Button variant="ghost" size="sm" onClick={() => setSelectedTrademark(null)}>
                  <span className="text-lg">×</span>
                </Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-lg bg-blue-500/10 flex items-center justify-center">
                    <Shield className="h-8 w-8 text-blue-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-[var(--foreground)]">
                      {selectedTrademark.trademark_name}
                    </h3>
                    <p className="text-sm text-[var(--muted-foreground)]">
                      注册号：{selectedTrademark.trademark_no}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <span className="text-[var(--muted-foreground)]">类别：</span>
                    <span className="text-[var(--foreground)]">{selectedTrademark.category}</span>
                  </div>
                  <div>
                    <span className="text-[var(--muted-foreground)]">状态：</span>
                    <Badge className={getStatusColor(selectedTrademark.status)}>
                      {selectedTrademark.status}
                    </Badge>
                  </div>
                  <div>
                    <span className="text-[var(--muted-foreground)]">注册日期：</span>
                    <span className="text-[var(--foreground)]">{selectedTrademark.register_date}</span>
                  </div>
                  <div>
                    <span className="text-[var(--muted-foreground)]">有效期：</span>
                    <span className="text-[var(--foreground)]">{selectedTrademark.valid_until}</span>
                  </div>
                </div>

                <div className="pt-3 border-t border-[var(--border)]">
                  <h4 className="font-medium text-[var(--foreground)] mb-2">注册人信息</h4>
                  <p className="text-sm text-[var(--foreground)]">
                    <Building2 className="h-3 w-3 inline mr-1" />
                    {selectedTrademark.registrant}
                  </p>
                  <p className="text-sm text-[var(--muted-foreground)] mt-1">
                    <MapPin className="h-3 w-3 inline mr-1" />
                    {selectedTrademark.registrant_address}
                  </p>
                  {selectedTrademark.phone && (
                    <p className="text-sm text-green-500 mt-1">
                      <Phone className="h-3 w-3 inline mr-1" />
                      {selectedTrademark.phone}
                    </p>
                  )}
                  {selectedTrademark.email && (
                    <p className="text-sm text-[var(--muted-foreground)] mt-1">
                      <Mail className="h-3 w-3 inline mr-1" />
                      {selectedTrademark.email}
                    </p>
                  )}
                </div>

                {selectedTrademark.related_companies.length > 0 && (
                  <div className="pt-3 border-t border-[var(--border)]">
                    <h4 className="font-medium text-[var(--foreground)] mb-2">关联企业</h4>
                    {selectedTrademark.related_companies.map((company, idx) => (
                      <div key={idx} className="flex items-center justify-between py-2 border-b border-[var(--border)] last:border-0">
                        <div>
                          <p className="text-sm text-[var(--foreground)]">{company.name}</p>
                          <p className="text-xs text-[var(--muted-foreground)]">
                            {company.type} · {company.industry} · {company.location}
                          </p>
                        </div>
                        <Button variant="outline" size="sm">
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}

                <div className="flex gap-2 pt-3">
                  <Button variant="outline" className="w-full" onClick={() => setSelectedTrademark(null)}>
                    关闭
                  </Button>
                  {selectedTrademark.phone && (
                    <Button variant="default" className="w-full" onClick={() => handleAddToCustomer(selectedTrademark)}>
                      <Plus className="h-4 w-4 mr-1" />
                      添加为客户
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* 提示信息 */}
        <Card className="bg-[var(--card)] border-[var(--border)] mt-6">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-yellow-500 mt-0.5" />
              <div className="text-sm text-[var(--muted-foreground)]">
                <p className="font-medium text-[var(--foreground)] mb-1">商标库搜索说明</p>
                <ul className="list-disc list-inside space-y-1">
                  <li>当前为模拟数据演示，接入真实API后可获取实时商标数据</li>
                  <li>可搜索品牌名称或商标注册号</li>
                  <li>商标信息包含注册人、类别、状态、有效期等</li>
                  <li>可查看注册人关联企业信息，一键转为客户</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}