import assert from 'node:assert/strict';
import { createDefaultCompanyProfile } from '../src/lib/company-profile';
import {
  calculatePackingSummary,
  createTradeDocumentFromOrder,
  validateTradeDocument,
} from '../src/lib/trade-documents';
import type { SavedCrmOrder } from '../src/lib/crm-orders';

const order: SavedCrmOrder = {
  id: 'order-1', number: 'SO-20260627-TEST', customerId: 'customer-1', customerName: 'Example Builder',
  contactName: 'Alex', opportunityId: '', quotationId: 'quote-1', quotationNumber: 'SH-TEST', currency: 'USD',
  items: [{ id: 'line-1', product: 'Cabinet', specification: 'Oak', quantity: 6, unit: 'set', unitPrice: 1000 }],
  subtotal: 6000, discount: 0, shipping: 500, tax: 0, total: 6500, tradeTerm: 'FOB',
  paymentTerms: '30% deposit', deliveryTime: '30 days', quotationNote: '', depositPercent: 30,
  depositReceived: 0, depositReceivedAt: '', balanceReceived: 0, balanceReceivedAt: '',
  expectedDeliveryDate: '', deliveredAt: '', status: 'production', internalNote: '',
  createdAt: '2026-06-27T00:00:00.000Z', updatedAt: '2026-06-27T00:00:00.000Z',
};

assert.deepEqual(calculatePackingSummary([{
  id: 'pack-1', product: 'Cabinet', specification: 'Oak', cartons: 2, quantityPerCarton: 3,
  totalQuantity: 6, netWeightPerCarton: 10, grossWeightPerCarton: 12,
  lengthCm: 100, widthCm: 50, heightCm: 20,
}]), { cartons: 2, quantity: 6, netWeight: 20, grossWeight: 24, volume: 0.2 });

const document = createTradeDocumentFromOrder(order, createDefaultCompanyProfile(), 'proforma_invoice');
assert.equal(document.type, 'proforma_invoice');
assert.equal(document.orderId, order.id);
assert.notEqual(document.items, order.items);
assert.deepEqual(validateTradeDocument({ ...document, number: '' }, []), ['单据编号不能为空。']);

console.log('trade-documents tests passed');
