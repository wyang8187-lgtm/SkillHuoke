import Link from 'next/link';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { demoWorkspace } from '@/lib/workspace';
import { demoTeamMembers, getTeamSummary, teamRoles } from '@/lib/team-access';
import { ArrowRight, LockKeyhole, MailCheck, Settings2, ShieldCheck, Users } from 'lucide-react';

export default function TeamSettingsPage() {
  const summary = getTeamSummary();

  return (
    <MainLayout title="团队设置">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">SaaS 团队设置</Badge>
            <Badge className="border-slate-500/25 bg-slate-500/15 text-slate-300">{demoWorkspace.plan}</Badge>
          </div>
          <h2 className="text-2xl font-semibold text-[#f8fafc]">团队账号、邀请和权限入口</h2>
          <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
            这里是老板或管理员配置团队的地方。当前版本保留演示数据，后续接入数据库后可以变成真实成员邀请、账号停用、权限生效和客户分配。
          </p>
        </section>

        <section className="grid gap-4 md:grid-cols-3">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="flex items-center gap-4 p-5">
              <Users className="h-9 w-9 text-blue-300" />
              <div>
                <p className="text-sm text-[#94a3b8]">团队成员</p>
                <p className="mt-1 text-2xl font-semibold text-[#f8fafc]">{summary.totalMembers} / {demoWorkspace.quota.membersLimit}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="flex items-center gap-4 p-5">
              <MailCheck className="h-9 w-9 text-amber-300" />
              <div>
                <p className="text-sm text-[#94a3b8]">待激活邀请</p>
                <p className="mt-1 text-2xl font-semibold text-[#f8fafc]">{summary.pendingMembers}</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="flex items-center gap-4 p-5">
              <ShieldCheck className="h-9 w-9 text-emerald-300" />
              <div>
                <p className="text-sm text-[#94a3b8]">权限角色</p>
                <p className="mt-1 text-2xl font-semibold text-[#f8fafc]">{teamRoles.length} 类</p>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="text-[#f8fafc]">设置入口</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4 md:grid-cols-2">
              <Link href="/team" className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4 transition hover:border-blue-500/50">
                <div className="flex items-center justify-between">
                  <Users className="h-6 w-6 text-blue-300" />
                  <ArrowRight className="h-4 w-4 text-[#64748b]" />
                </div>
                <h3 className="mt-4 font-medium text-[#f8fafc]">团队成员管理</h3>
                <p className="mt-2 text-sm leading-6 text-[#94a3b8]">查看成员、角色、状态、客户数和任务数，预留邀请成员流程。</p>
              </Link>
              <Link href="/team/permissions" className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4 transition hover:border-emerald-500/50">
                <div className="flex items-center justify-between">
                  <LockKeyhole className="h-6 w-6 text-emerald-300" />
                  <ArrowRight className="h-4 w-4 text-[#64748b]" />
                </div>
                <h3 className="mt-4 font-medium text-[#f8fafc]">权限矩阵</h3>
                <p className="mt-2 text-sm leading-6 text-[#94a3b8]">查看老板、管理员、销售、运营分别能访问哪些功能和数据。</p>
              </Link>
            </CardContent>
          </Card>

          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <Settings2 className="h-5 w-5 text-violet-300" />
                后续接入清单
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-[#94a3b8]">
              <p className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">接入 Supabase Auth 或企业微信/邮箱登录。</p>
              <p className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">成员邀请邮件和激活链接接入真实邮件服务。</p>
              <p className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">API 层按 workspaceId、role、ownerId 做权限校验。</p>
              <p className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">客户分配、转移和离职成员客户交接。</p>
            </CardContent>
          </Card>
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">当前演示成员</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            {demoTeamMembers.map((member) => (
              <div key={member.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                <p className="font-medium text-[#f8fafc]">{member.name}</p>
                <p className="mt-1 text-xs text-[#94a3b8]">{member.email}</p>
                <p className="mt-3 text-sm text-[#cbd5e1]">{member.team}</p>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
