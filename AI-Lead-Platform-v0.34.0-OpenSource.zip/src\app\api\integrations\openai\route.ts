import { NextRequest, NextResponse } from 'next/server';
import {
  generateCustomerOutreach,
  runOpenAITask,
  type OpenAIInput,
  type OpenAITask,
  type OutreachContentType,
  type OutreachTone,
} from '@/lib/integrations/openai-provider';

const allowedTasks = new Set<OpenAITask>([
  'write_email',
  'write_whatsapp',
  'score_lead',
  'summarize_customer',
  'next_action',
  'generate_customer_outreach',
]);

const allowedContentTypes = new Set<OutreachContentType>([
  'first_email',
  'follow_up_email',
  'whatsapp',
  'linkedin',
]);
const allowedTones = new Set<OutreachTone>(['professional', 'concise', 'friendly']);

function readString(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const task = readString(body.task) as OpenAITask;
    const prompt = readString(body.prompt);

    if (!allowedTasks.has(task)) {
      return NextResponse.json(
        { success: false, error: 'Unsupported OpenAI task' },
        { status: 400 }
      );
    }

    const context = typeof body.context === 'object' && body.context ? body.context as Record<string, unknown> : {};

    if (task === 'generate_customer_outreach') {
      const contentType = readString(context.contentType) as OutreachContentType;
      const tone = readString(context.tone) as OutreachTone;
      if (!allowedContentTypes.has(contentType) || !allowedTones.has(tone)) {
        return NextResponse.json(
          { success: false, error: 'Valid contentType and tone are required' },
          { status: 400 }
        );
      }

      const result = await generateCustomerOutreach(context);
      return NextResponse.json({ success: true, ...result });
    }

    if (!prompt) {
      return NextResponse.json(
        { success: false, error: 'prompt is required' },
        { status: 400 }
      );
    }

    const input: OpenAIInput = {
      task,
      prompt,
      context,
    };

    const result = await runOpenAITask(input);
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'OpenAI task failed' },
      { status: 500 }
    );
  }
}
