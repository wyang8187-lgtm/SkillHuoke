// 邮件发送 API（模拟发送）
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient, getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 发送邮件（模拟）
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { 
      customerIds, // 支持批量发送
      templateId,
      customSubject,
      customContent,
      scheduledTime // 定时发送时间
    } = body;

    if (!customerIds || customerIds.length === 0) {
      return NextResponse.json({ error: '请选择收件人' }, { status: 400 });
    }

    const serviceClient = getSupabaseServiceRoleClient();

    // 获取模板信息
    let template = null;
    if (templateId) {
      const { data: templateData } = await serviceClient
        .from('email_templates')
        .select('*')
        .eq('id', templateId)
        .eq('user_id', user.id)
        .single();
      template = templateData;

      // 更新模板使用次数
      if (template) {
        await serviceClient
          .from('email_templates')
          .update({ 
            usage_count: (template.usage_count || 0) + 1,
            last_used_at: new Date().toISOString()
          })
          .eq('id', templateId);
      }
    }

    // 获取客户信息
    const { data: customers } = await serviceClient
      .from('customers')
      .select('*')
      .in('id', customerIds)
      .eq('user_id', user.id);

    if (!customers || customers.length === 0) {
      return NextResponse.json({ error: '客户信息不存在' }, { status: 400 });
    }

    // 创建邮件记录（模拟发送）
    const emailRecords = customers.map(customer => {
      // 替换模板中的占位符
      let subject = customSubject || (template?.subject || '');
      let content = customContent || (template?.content || '');

      // 替换占位符
      const replacements: Record<string, string> = {
        '{contact_name}': customer.contact_name || '客户',
        '{company_name}': customer.company_name || '',
        '{industry}': customer.customer_type === 'designer' ? '全案设计' : '建材外贸',
        '{sender_name}': user.email?.split('@')[0] || '业务经理',
        '{sender_company}': '您的公司名称',
        '{sender_phone}': '联系电话',
      };

      Object.entries(replacements).forEach(([key, value]) => {
        subject = subject.replace(key, value);
        content = content.replace(new RegExp(key, 'g'), value);
      });

      return {
        user_id: user.id,
        customer_id: customer.id,
        template_id: templateId || null,
        recipient_email: customer.email || '',
        recipient_name: customer.contact_name || '',
        subject,
        content,
        status: scheduledTime ? 'scheduled' : 'sent', // 如果是定时发送，状态为scheduled
        scheduled_at: scheduledTime || null,
        sent_at: scheduledTime ? null : new Date().toISOString(),
        opened_at: null,
        clicked_at: null,
        error_message: null,
      };
    });

    const { data: insertedRecords, error: insertError } = await serviceClient
      .from('email_records')
      .insert(emailRecords)
      .select();

    if (insertError) {
      throw insertError;
    }

    // 模拟邮件发送成功（实际项目中接入真实邮件服务API）
    // 这里模拟30%的邮件会在"发送后"被打开（用于演示效果）
    const simulationRecords = insertedRecords?.filter(r => !scheduledTime).map(record => ({
      id: record.id,
      opened: Math.random() > 0.7, // 30%概率模拟打开
      clicked: Math.random() > 0.85, // 15%概率模拟点击
    })) || [];

    // 更新模拟的打开/点击状态
    for (const sim of simulationRecords) {
      if (sim.opened) {
        await serviceClient
          .from('email_records')
          .update({ 
            status: 'opened',
            opened_at: new Date(Date.now() + Math.random() * 3600000).toISOString()
          })
          .eq('id', sim.id);
        
        if (sim.clicked) {
          await serviceClient
            .from('email_records')
            .update({ 
              status: 'clicked',
              clicked_at: new Date(Date.now() + Math.random() * 7200000).toISOString()
            })
            .eq('id', sim.id);
        }
      }
    }

    return NextResponse.json({
      success: true,
      sentCount: insertedRecords?.length || 0,
      message: scheduledTime 
        ? `已定时${scheduledTime}发送${insertedRecords?.length || 0}封邮件`
        : `已成功发送${insertedRecords?.length || 0}封邮件`
    });
  } catch (error) {
    console.error('发送邮件失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '发送邮件失败' 
    }, { status: 500 });
  }
}