'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import {
  Zap,
  Play,
  Pause,
  Edit,
  Trash2,
  Eye,
  Plus,
  Target,
  Mail,
  MousePointerClick,
  ArrowRight,
  Clock,
  Users,
  CheckCircle,
  Settings,
  Sparkles,
  TrendingUp,
  Loader2,
  Save,
} from 'lucide-react';

// 自动化规则类型
interface AutomationFlow {
  id: string;
  user_id: string;
  name: string;
  description?: string;
  trigger_type: string;
  trigger_config: Record<string, unknown>;
  action_type: string;
  action_config: Record<string, unknown>;
  status: string;
  execution_count: number;
  last_execution_time?: string;
  created_at: string;
  updated_at?: string;
}

// 触发类型选项
const triggerOptions = [
  { value: 'new_lead', label: '新线索入库', icon: <Users className="h-4 w-4" /> },
  { value: 'no_follow_up_7days', label: '7天未跟进', icon: <Clock className="h-4 w-4" /> },
  { value: 'opportunity_stage_change', label: '商机阶段变更', icon: <Target className="h-4 w-4" /> },
  { value: 'email_opened', label: '邮件被打开', icon: <Mail className="h-4 w-4" /> },
  { value: 'email_clicked', label: '邮件链接被点击', icon: <MousePointerClick className="h-4 w-4" /> },
  { value: 'time_based', label: '定时触发', icon: <Clock className="h-4 w-4" /> },
];

// 动作类型选项
const actionOptions = [
  { value: 'create_task', label: '创建跟进任务', icon: <CheckCircle className="h-4 w-4" /> },
  { value: 'send_email', label: '发送邮件', icon: <Mail className="h-4 w-4" /> },
  { value: 'update_status', label: '更新客户状态', icon: <Settings className="h-4 w-4" /> },
  { value: 'notify', label: '发送通知提醒', icon: <Sparkles className="h-4 w-4" /> },
];

const statusColors: Record<string, string> = {
  'active': '#22c55e',
  'paused': '#f97316',
  'deleted': '#ef4444',
};

const statusLabels: Record<string, string> = {
  'active': '运行中',
  'paused': '已暂停',
  'deleted': '已删除',
};

export default function MarketingAutomationPage() {
  const [flows, setFlows] = useState<AutomationFlow[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [showCreate, setShowCreate] = useState(false);
  const [showEdit, setShowEdit] = useState(false);
  const [editFlow, setEditFlow] = useState<AutomationFlow | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);

  // 创建/编辑表单状态
  const [formName, setFormName] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formTriggerType, setFormTriggerType] = useState('new_lead');
  const [formTriggerDays, setFormTriggerDays] = useState('7');
  const [formActionType, setFormActionType] = useState('create_task');
  const [formActionTitle, setFormActionTitle] = useState('');
  const [formActionContent, setFormActionContent] = useState('');

  // 加载自动化规则
  const loadFlows = useCallback(async () => {
    setLoading(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const params = new URLSearchParams();
      if (selectedStatus !== 'all') {
        params.append('status', selectedStatus);
      }

      const res = await fetch(`/api/automation-flows?${params.toString()}`, {
        headers: { 'x-session': session || '' }
      });

      if (!res.ok) throw new Error('加载失败');
      const data = await res.json();
      setFlows(data.data || []);
    } catch (error) {
      toast.error('加载自动化规则失败');
    } finally {
      setLoading(false);
    }
  }, [selectedStatus]);

  useEffect(() => {
    loadFlows();
  }, [loadFlows]);

  // 重置表单
  const resetForm = () => {
    setFormName('');
    setFormDescription('');
    setFormTriggerType('new_lead');
    setFormTriggerDays('7');
    setFormActionType('create_task');
    setFormActionTitle('');
    setFormActionContent('');
  };

  // 创建规则
  const handleCreate = async () => {
    if (!formName) {
      toast.error('请填写规则名称');
      return;
    }
    setProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const triggerConfig: Record<string, unknown> = {};
      if (formTriggerType === 'no_follow_up_7days' || formTriggerType === 'time_based') {
        triggerConfig.days = parseInt(formTriggerDays) || 7;
      }

      const actionConfig: Record<string, unknown> = {};
      if (formActionType === 'create_task') {
        actionConfig.title = formActionTitle || '跟进任务';
        actionConfig.description = formActionContent;
      } else if (formActionType === 'send_email') {
        actionConfig.subject = formActionTitle || '邮件主题';
        actionConfig.content = formActionContent;
      }

      const res = await fetch('/api/automation-flows', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': session || ''
        },
        body: JSON.stringify({
          name: formName,
          description: formDescription,
          trigger_type: formTriggerType,
          trigger_config: triggerConfig,
          action_type: formActionType,
          action_config: actionConfig,
          status: 'active'
        })
      });

      if (!res.ok) throw new Error('创建失败');
      toast.success('自动化规则已创建');
      setShowCreate(false);
      resetForm();
      loadFlows();
    } catch (error) {
      toast.error('创建自动化规则失败');
    } finally {
      setProcessing(false);
    }
  };

  // 编辑规则
  const handleEdit = async () => {
    if (!editFlow || !formName) {
      toast.error('请填写规则名称');
      return;
    }
    setProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const triggerConfig: Record<string, unknown> = editFlow.trigger_config || {};
      if (formTriggerType === 'no_follow_up_7days' || formTriggerType === 'time_based') {
        triggerConfig.days = parseInt(formTriggerDays) || 7;
      }

      const actionConfig: Record<string, unknown> = editFlow.action_config || {};
      if (formActionType === 'create_task') {
        actionConfig.title = formActionTitle || '跟进任务';
        actionConfig.description = formActionContent;
      } else if (formActionType === 'send_email') {
        actionConfig.subject = formActionTitle || '邮件主题';
        actionConfig.content = formActionContent;
      }

      const res = await fetch(`/api/automation-flows/${editFlow.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'x-session': session || ''
        },
        body: JSON.stringify({
          name: formName,
          description: formDescription,
          trigger_type: formTriggerType,
          trigger_config: triggerConfig,
          action_type: formActionType,
          action_config: actionConfig
        })
      });

      if (!res.ok) throw new Error('更新失败');
      toast.success('自动化规则已更新');
      setShowEdit(false);
      setEditFlow(null);
      resetForm();
      loadFlows();
    } catch (error) {
      toast.error('更新自动化规则失败');
    } finally {
      setProcessing(false);
    }
  };

  // 删除规则
  const handleDelete = async () => {
    if (!deleteId) return;
    setProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const res = await fetch(`/api/automation-flows/${deleteId}`, {
        method: 'DELETE',
        headers: { 'x-session': session || '' }
      });

      if (!res.ok) throw new Error('删除失败');
      toast.success('自动化规则已删除');
      setDeleteId(null);
      loadFlows();
    } catch (error) {
      toast.error('删除自动化规则失败');
    } finally {
      setProcessing(false);
    }
  };

  // 启用/停用规则
  const handleToggle = async (flow: AutomationFlow) => {
    const newStatus = flow.status === 'active' ? 'paused' : 'active';
    setProcessing(true);
    try {
      const session = localStorage.getItem('supabase_session');
      const res = await fetch(`/api/automation-flows/${flow.id}/toggle`, {
        method: 'POST',
        headers: { 'x-session': session || '' }
      });

      if (!res.ok) throw new Error('操作失败');
      toast.success(newStatus === 'active' ? '规则已启用' : '规则已暂停');
      loadFlows();
    } catch (error) {
      toast.error('操作失败');
    } finally {
      setProcessing(false);
    }
  };

  // 打开编辑对话框
  const openEdit = (flow: AutomationFlow) => {
    setEditFlow(flow);
    setFormName(flow.name);
    setFormDescription(flow.description || '');
    setFormTriggerType(flow.trigger_type);
    setFormTriggerDays((flow.trigger_config as Record<string, unknown>)?.days?.toString() || '7');
    setFormActionType(flow.action_type);
    setFormActionTitle((flow.action_config as Record<string, unknown>)?.title?.toString() || 
                       (flow.action_config as Record<string, unknown>)?.subject?.toString() || '');
    setFormActionContent((flow.action_config as Record<string, unknown>)?.description?.toString() || 
                         (flow.action_config as Record<string, unknown>)?.content?.toString() || '');
    setShowEdit(true);
  };

  // 统计数据
  const activeCount = flows.filter(f => f.status === 'active').length;
  const pausedCount = flows.filter(f => f.status === 'paused').length;
  const totalExecutions = flows.reduce((sum, f) => sum + f.execution_count, 0);

  return (
    <MainLayout title="自动化营销">
      {/* 操作栏 */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-2">
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-[140px] h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]">
              <SelectValue placeholder="筛选状态" />
            </SelectTrigger>
            <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
              <SelectItem value="all" className="text-[#f8fafc]">全部</SelectItem>
              <SelectItem value="active" className="text-[#f8fafc]">运行中</SelectItem>
              <SelectItem value="paused" className="text-[#f8fafc]">已暂停</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <Button 
          onClick={() => { resetForm(); setShowCreate(true); }}
          className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]"
        >
          <Plus className="h-4 w-4 mr-2" />
          创建自动化流程
        </Button>
      </div>

      {/* 统计 */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <Zap className="h-5 w-5 text-[#3b82f6]" />
          <div>
            <p className="text-xs text-[#94a3b8]">自动化流程</p>
            <p className="text-xl font-bold text-[#f8fafc]">{flows.length}</p>
          </div>
        </div>
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <Play className="h-5 w-5 text-[#22c55e]" />
          <div>
            <p className="text-xs text-[#94a3b8]">运行中</p>
            <p className="text-xl font-bold text-[#22c55e]">{activeCount}</p>
          </div>
        </div>
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <Pause className="h-5 w-5 text-[#f97316]" />
          <div>
            <p className="text-xs text-[#94a3b8]">已暂停</p>
            <p className="text-xl font-bold text-[#f97316]">{pausedCount}</p>
          </div>
        </div>
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <TrendingUp className="h-5 w-5 text-[#8b5cf6]" />
          <div>
            <p className="text-xs text-[#94a3b8]">总执行次数</p>
            <p className="text-xl font-bold text-[#8b5cf6]">{totalExecutions}</p>
          </div>
        </div>
      </div>

      {/* 流程列表 */}
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-[#3b82f6]" />
        </div>
      ) : flows.length === 0 ? (
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Zap className="h-12 w-12 text-[#64748b] mb-4" />
            <p className="text-[#64748b] mb-4">暂无自动化规则</p>
            <Button 
              onClick={() => { resetForm(); setShowCreate(true); }}
              className="bg-[#3b82f6]"
            >
              创建第一个自动化流程
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {flows.map(flow => {
            const triggerOption = triggerOptions.find(t => t.value === flow.trigger_type);
            const actionOption = actionOptions.find(a => a.value === flow.action_type);
            
            return (
              <Card key={flow.id} className="bg-[#1a1f2c] border-[#2d3548]">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Zap className="h-5 w-5 text-[#3b82f6]" />
                        <h3 className="text-[#f8fafc] font-medium">{flow.name}</h3>
                        <Badge 
                          style={{
                            backgroundColor: `${statusColors[flow.status]}20`,
                            color: statusColors[flow.status],
                            border: `1px solid ${statusColors[flow.status]}30`
                          }}
                        >
                          {statusLabels[flow.status] || flow.status}
                        </Badge>
                      </div>
                      <p className="text-sm text-[#94a3b8] mb-4">{flow.description || '暂无描述'}</p>
                      
                      {/* 触发条件 */}
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#0f1419]">
                          {triggerOption?.icon || <Target className="h-4 w-4" />}
                          <span className="text-sm text-[#f8fafc]">
                            触发: {triggerOption?.label || flow.trigger_type}
                          </span>
                        </div>
                        <ArrowRight className="h-4 w-4 text-[#64748b]" />
                        <div className="flex items-center gap-2 px-3 py-1.5 rounded-md bg-[#0f1419]">
                          {actionOption?.icon || <Settings className="h-4 w-4" />}
                          <span className="text-sm text-[#f8fafc]">
                            动作: {actionOption?.label || flow.action_type}
                          </span>
                        </div>
                      </div>

                      {/* 执行统计 */}
                      <div className="flex items-center gap-4 text-xs text-[#64748b]">
                        <span>执行次数: {flow.execution_count}</span>
                        <span>创建时间: {new Date(flow.created_at).toLocaleDateString()}</span>
                        {flow.last_execution_time && (
                          <span>最后执行: {new Date(flow.last_execution_time).toLocaleString()}</span>
                        )}
                      </div>
                    </div>

                    {/* 操作按钮 */}
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleToggle(flow)}
                        disabled={processing}
                        className={
                          flow.status === 'active' 
                            ? 'text-[#f97316] hover:bg-[#f97316]/10' 
                            : 'text-[#22c55e] hover:bg-[#22c55e]/10'
                        }
                      >
                        {flow.status === 'active' ? (
                          <><Pause className="h-4 w-4 mr-1" />暂停</>
                        ) : (
                          <><Play className="h-4 w-4 mr-1" />启用</>
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => openEdit(flow)}
                        className="text-[#3b82f6] hover:bg-[#3b82f6]/10"
                      >
                        <Edit className="h-4 w-4 mr-1" />编辑
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setDeleteId(flow.id)}
                        className="text-[#ef4444] hover:bg-[#ef4444]/10"
                      >
                        <Trash2 className="h-4 w-4 mr-1" />删除
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* 创建规则对话框 */}
      <Dialog open={showCreate} onOpenChange={setShowCreate}>
        <DialogContent className="bg-[#1a1f2c] border-[#2d3548] max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-[#f8fafc]">创建自动化流程</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">规则名称</label>
              <Input
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="例如：新线索自动跟进"
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">描述</label>
              <Textarea
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                placeholder="规则描述（可选）"
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">触发条件</label>
              <Select value={formTriggerType} onValueChange={setFormTriggerType}>
                <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                  <SelectValue placeholder="选择触发条件" />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                  {triggerOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value} className="text-[#f8fafc]">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {(formTriggerType === 'no_follow_up_7days' || formTriggerType === 'time_based') && (
                <Input
                  type="number"
                  value={formTriggerDays}
                  onChange={(e) => setFormTriggerDays(e.target.value)}
                  placeholder="天数"
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc] mt-2"
                />
              )}
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">执行动作</label>
              <Select value={formActionType} onValueChange={setFormActionType}>
                <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                  <SelectValue placeholder="选择执行动作" />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                  {actionOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value} className="text-[#f8fafc]">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">
                {formActionType === 'send_email' ? '邮件主题' : '任务标题'}
              </label>
              <Input
                value={formActionTitle}
                onChange={(e) => setFormActionTitle(e.target.value)}
                placeholder={formActionType === 'send_email' ? '邮件主题' : '任务标题'}
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">
                {formActionType === 'send_email' ? '邮件内容' : '任务详情'}
              </label>
              <Textarea
                value={formActionContent}
                onChange={(e) => setFormActionContent(e.target.value)}
                placeholder={formActionType === 'send_email' ? '邮件正文...' : '任务描述...'}
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => setShowCreate(false)} className="border-[#2d3548]">
                取消
              </Button>
              <Button onClick={handleCreate} disabled={processing} className="bg-[#3b82f6]">
                {processing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                创建规则
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 编辑规则对话框 */}
      <Dialog open={showEdit} onOpenChange={setShowEdit}>
        <DialogContent className="bg-[#1a1f2c] border-[#2d3548] max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-[#f8fafc]">编辑自动化流程</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">规则名称</label>
              <Input
                value={formName}
                onChange={(e) => setFormName(e.target.value)}
                placeholder="例如：新线索自动跟进"
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">描述</label>
              <Textarea
                value={formDescription}
                onChange={(e) => setFormDescription(e.target.value)}
                placeholder="规则描述（可选）"
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">触发条件</label>
              <Select value={formTriggerType} onValueChange={setFormTriggerType}>
                <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                  <SelectValue placeholder="选择触发条件" />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                  {triggerOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value} className="text-[#f8fafc]">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {(formTriggerType === 'no_follow_up_7days' || formTriggerType === 'time_based') && (
                <Input
                  type="number"
                  value={formTriggerDays}
                  onChange={(e) => setFormTriggerDays(e.target.value)}
                  placeholder="天数"
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc] mt-2"
                />
              )}
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">执行动作</label>
              <Select value={formActionType} onValueChange={setFormActionType}>
                <SelectTrigger className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]">
                  <SelectValue placeholder="选择执行动作" />
                </SelectTrigger>
                <SelectContent className="bg-[#1a1f2c] border-[#2d3548]">
                  {actionOptions.map(opt => (
                    <SelectItem key={opt.value} value={opt.value} className="text-[#f8fafc]">
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">
                {formActionType === 'send_email' ? '邮件主题' : '任务标题'}
              </label>
              <Input
                value={formActionTitle}
                onChange={(e) => setFormActionTitle(e.target.value)}
                placeholder={formActionType === 'send_email' ? '邮件主题' : '任务标题'}
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div>
              <label className="text-sm text-[#94a3b8] mb-1 block">
                {formActionType === 'send_email' ? '邮件内容' : '任务详情'}
              </label>
              <Textarea
                value={formActionContent}
                onChange={(e) => setFormActionContent(e.target.value)}
                placeholder={formActionType === 'send_email' ? '邮件正文...' : '任务描述...'}
                className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => setShowEdit(false)} className="border-[#2d3548]">
                取消
              </Button>
              <Button onClick={handleEdit} disabled={processing} className="bg-[#3b82f6]">
                {processing ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Save className="h-4 w-4 mr-2" />}
                保存修改
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 删除确认对话框 */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent className="bg-[#1a1f2c] border-[#2d3548]">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-[#f8fafc]">确认删除</AlertDialogTitle>
            <AlertDialogDescription className="text-[#94a3b8]">
              删除后此自动化规则将无法恢复，确定要删除吗？
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-[#2d3548]">取消</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-[#ef4444]">
              确认删除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </MainLayout>
  );
}