import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const query = searchParams.get('q')?.trim();

  if (!query) {
    return NextResponse.json({ results: [] });
  }

  const supabase = getSupabaseServiceRoleClient();
  const results: any[] = [];

  try {
    // Search customers
    const customersRes = await supabase
      .from('customers')
      .select('id, company_name, contact_name, region')
      .or(`company_name.ilike.%${query}%,contact_name.ilike.%${query}%`)
      .limit(5);

    if (customersRes.data) {
      customersRes.data.forEach((c) => {
        results.push({
          id: c.id,
          type: 'customer',
          title: c.company_name || '未命名客户',
          subtitle: c.contact_name ? `${c.contact_name} · ${c.region || ''}` : c.region,
          href: '/customers/list',
        });
      });
    }

    // Search leads
    const leadsRes = await supabase
      .from('leads')
      .select('id, company_name, contact_name, region')
      .or(`company_name.ilike.%${query}%,contact_name.ilike.%${query}%`)
      .limit(5);

    if (leadsRes.data) {
      leadsRes.data.forEach((l) => {
        results.push({
          id: l.id,
          type: 'lead',
          title: l.company_name || '未命名线索',
          subtitle: l.contact_name ? `${l.contact_name} · ${l.region || ''}` : l.region,
          href: '/leads',
        });
      });
    }

    // Search opportunities
    const opportunitiesRes = await supabase
      .from('opportunities')
      .select('id, name, stage, amount')
      .ilike('name', `%${query}%`)
      .limit(5);

    if (opportunitiesRes.data) {
      opportunitiesRes.data.forEach((o) => {
        results.push({
          id: o.id,
          type: 'opportunity',
          title: o.name || '未命名商机',
          subtitle: `${o.stage || '未知阶段'} · ¥${o.amount || 0}`,
          href: '/opportunities',
        });
      });
    }

    // Search tasks
    const tasksRes = await supabase
      .from('tasks')
      .select('id, title, status')
      .ilike('title', `%${query}%`)
      .limit(5);

    if (tasksRes.data) {
      tasksRes.data.forEach((t) => {
        results.push({
          id: t.id,
          type: 'task',
          title: t.title || '未命名任务',
          subtitle: t.status || '待完成',
          href: '/dashboard',
        });
      });
    }

    // Sort results by relevance (type order)
    const typeOrder: Record<string, number> = { customer: 0, lead: 1, opportunity: 2, task: 3 };
    results.sort((a, b) => {
      return (typeOrder[a.type] || 0) - (typeOrder[b.type] || 0);
    });

    return NextResponse.json({ results });
  } catch (error) {
    console.error('Global search error:', error);
    return NextResponse.json({ results: [] });
  }
}