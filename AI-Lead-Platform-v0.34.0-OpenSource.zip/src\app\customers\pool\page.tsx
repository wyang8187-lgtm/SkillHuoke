'use client';

import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SearchSelect, presetOptions } from '@/components/ui/search-select';
import {
  Users,
  Target,
  Clock,
  AlertTriangle,
  RefreshCw,
  UserPlus,
  ArrowRightLeft,
  Settings,
  Filter,
  Loader2,
  ChevronDown,
  ChevronRight,
  Building2,
  Phone,
  MapPin,
  Calendar,
  Star,
  CheckCircle,
} from 'lucide-react';

// 公海池客户类型
interface PoolCustomer {
  id: string;
  company_name: string;
  contact_name: string;
  phone: string;
  region: string;
  customer_type: string;
  grade: string;
  status: string;
  last_follow_up_time: string | null;
  days_since_follow_up: number;
  original_owner: string | null;
  entered_pool_time: string;
  enter_reason: string;
  source: string;
}

// 公海池规则配置
interface PoolRule {
  id: string;
  name: string;
  description: string;
  days_threshold: number;
  action: string;
  is_active: boolean;
}

export default function CustomerPoolPage() {
  const [customers, setCustomers] = useState<PoolCustomer[]>([]);
  const [leads, setLeads] = useState<PoolCustomer[]>([]);
  const [rules, setRules] = useState<PoolRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'customers' | 'leads' | 'rules'>('customers');
  
  // 筛选条件
  const [filters, setFilters] = useState({
    type: '',
    region: '',
    grade: '',
    daysThreshold: '',
  });
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // 加载公海池数据
      const res = await fetch('/api/customer-pool');
      if (res.ok) {
        const data = await res.json();
        setCustomers(data.customers || []);
        setLeads(data.leads || []);
        setRules(data.rules || []);
      }
    } catch (error) {
      console.error('加载公海池数据失败', error);
    } finally {
      setLoading(false);
    }
  };

  // 认领客户
  const handleClaim = async (customerId: string, type: 'customer' | 'lead') => {
    try {
      const res = await fetch('/api/customer-pool/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: customerId, type }),
      });
      
      if (res.ok) {
        // 从列表中移除
        if (type === 'customer') {
          setCustomers(customers.filter(c => c.id !== customerId));
        } else {
          setLeads(leads.filter(l => l.id !== customerId));
        }
        alert('认领成功！客户已分配给您');
      } else {
        const data = await res.json();
        alert(data.error || '认领失败');
      }
    } catch (error) {
      alert('认领失败，请重试');
    }
  };

  // 退回公海池
  const handleReturn = async (customerId: string, reason: string) => {
    try {
      const res = await fetch('/api/customer-pool/return', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: customerId, reason }),
      });
      
      if (res.ok) {
        loadData();
        alert('已退回公海池');
      } else {
        const data = await res.json();
        alert(data.error || '退回失败');
      }
    } catch (error) {
      alert('退回失败，请重试');
    }
  };

  // 更新规则
  const handleUpdateRule = async (ruleId: string, isActive: boolean) => {
    try {
      const res = await fetch('/api/customer-pool/rules', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: ruleId, is_active: isActive }),
      });
      
      if (res.ok) {
        setRules(rules.map(r => r.id === ruleId ? { ...r, is_active: isActive } : r));
      }
    } catch (error) {
      console.error('更新规则失败', error);
    }
  };

  // 筛选客户
  const filteredCustomers = customers.filter(c => {
    if (filters.type && c.customer_type !== filters.type) return false;
    if (filters.region && c.region !== filters.region) return false;
    if (filters.grade && c.grade !== filters.grade) return false;
    if (filters.daysThreshold && c.days_since_follow_up < parseInt(filters.daysThreshold)) return false;
    return true;
  });

  // 筛选线索
  const filteredLeads = leads.filter(l => {
    if (filters.type && l.customer_type !== filters.type) return false;
    if (filters.region && l.region !== filters.region) return false;
    return true;
  });

  // 获取进入原因颜色
  const getReasonColor = (reason: string) => {
    if (reason.includes('超期')) return 'text-orange-500';
    if (reason.includes('未分配')) return 'text-cyan-500';
    if (reason.includes('主动退回')) return 'text-purple-500';
    return 'text-muted-foreground';
  };

  // 获取天数颜色
  const getDaysColor = (days: number) => {
    if (days >= 60) return 'text-red-500';
    if (days >= 30) return 'text-orange-500';
    if (days >= 14) return 'text-yellow-500';
    return 'text-muted-foreground';
  };

  if (loading) {
    return (
      <MainLayout title="公海池" breadcrumbs={[{ label: '客户管理' }, { label: '公海池' }]}>
        <div className="flex items-center justify-center h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout title="公海池" breadcrumbs={[{ label: '客户管理' }, { label: '公海池' }]}>
      {/* 统计卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-orange-500/20 flex items-center justify-center">
                <Users className="h-5 w-5 text-orange-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">公海池客户</p>
                <p className="text-2xl font-bold text-foreground">{customers.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <Target className="h-5 w-5 text-cyan-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">公海池线索</p>
                <p className="text-2xl font-bold text-foreground">{leads.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-red-500/20 flex items-center justify-center">
                <AlertTriangle className="h-5 w-5 text-red-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">超期30天+</p>
                <p className="text-2xl font-bold text-foreground">
                  {customers.filter(c => c.days_since_follow_up >= 30).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-full bg-green-500/20 flex items-center justify-center">
                <CheckCircle className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">活跃规则</p>
                <p className="text-2xl font-bold text-foreground">
                  {rules.filter(r => r.is_active).length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tab切换 */}
      <div className="flex gap-2 mb-4">
        <Button
          variant={activeTab === 'customers' ? 'default' : 'outline'}
          onClick={() => setActiveTab('customers')}
          className={activeTab === 'customers' ? 'bg-primary' : ''}
        >
          <Users className="h-4 w-4 mr-2" />
          公海客户 ({customers.length})
        </Button>
        <Button
          variant={activeTab === 'leads' ? 'default' : 'outline'}
          onClick={() => setActiveTab('leads')}
          className={activeTab === 'leads' ? 'bg-primary' : ''}
        >
          <Target className="h-4 w-4 mr-2" />
          公海线索 ({leads.length})
        </Button>
        <Button
          variant={activeTab === 'rules' ? 'default' : 'outline'}
          onClick={() => setActiveTab('rules')}
          className={activeTab === 'rules' ? 'bg-primary' : ''}
        >
          <Settings className="h-4 w-4 mr-2" />
          规则配置
        </Button>
      </div>

      {/* 筛选区域 */}
      {activeTab !== 'rules' && (
        <Card className="bg-card border-border mb-4">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
              >
                <Filter className="h-4 w-4" />
                筛选条件
                {showFilters ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </button>
              {(filters.type || filters.region || filters.grade || filters.daysThreshold) && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setFilters({ type: '', region: '', grade: '', daysThreshold: '' })}
                  className="text-muted-foreground"
                >
                  清除筛选
                </Button>
              )}
            </div>

            {showFilters && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">客户类型</label>
                  <SearchSelect
                    options={presetOptions.customerType}
                    value={filters.type}
                    onChange={(v) => setFilters({ ...filters, type: v })}
                    placeholder="全部类型"
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">地区</label>
                  <SearchSelect
                    options={presetOptions.region}
                    value={filters.region}
                    onChange={(v) => setFilters({ ...filters, region: v })}
                    placeholder="全部地区"
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">客户等级</label>
                  <SearchSelect
                    options={presetOptions.customerGrade}
                    value={filters.grade}
                    onChange={(v) => setFilters({ ...filters, grade: v })}
                    placeholder="全部等级"
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1 block">超期天数</label>
                  <SearchSelect
                    options={[
                      { value: '7', label: '7天以上' },
                      { value: '14', label: '14天以上' },
                      { value: '30', label: '30天以上' },
                      { value: '60', label: '60天以上' },
                    ]}
                    value={filters.daysThreshold}
                    onChange={(v) => setFilters({ ...filters, daysThreshold: v })}
                    placeholder="全部"
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* 内容区域 */}
      {activeTab === 'customers' && (
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            {filteredCustomers.length > 0 ? (
              <div className="divide-y divide-border">
                {filteredCustomers.map((customer) => (
                  <div key={customer.id} className="p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="h-12 w-12 rounded-lg bg-muted flex items-center justify-center">
                          <Building2 className="h-6 w-6 text-muted-foreground" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium text-foreground">{customer.company_name}</h3>
                            <Badge variant="outline" className={
                              customer.grade === 'A' ? 'border-green-500 text-green-500' :
                              customer.grade === 'B' ? 'border-orange-500 text-orange-500' :
                              'border-gray-500 text-gray-500'
                            }>
                              {customer.grade}类
                            </Badge>
                            <Badge variant="outline" className={
                              customer.customer_type === '全案设计师' ? 'border-blue-500 text-blue-500' :
                              'border-orange-500 text-orange-500'
                            }>
                              {customer.customer_type}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {customer.phone}
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {customer.region}
                            </span>
                            <span className="flex items-center gap-1">
                              <Clock className="h-3 w-3" />
                              <span className={getDaysColor(customer.days_since_follow_up)}>
                                {customer.days_since_follow_up}天未跟进
                              </span>
                            </span>
                          </div>
                          <div className="mt-2 text-sm">
                            <span className={getReasonColor(customer.enter_reason)}>
                              进入原因：{customer.enter_reason}
                            </span>
                            {customer.original_owner && (
                              <span className="ml-4 text-muted-foreground">
                                原负责人：{customer.original_owner}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleClaim(customer.id, 'customer')}
                          className="bg-primary"
                        >
                          <UserPlus className="h-4 w-4 mr-1" />
                          认领
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <Users className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>公海池中暂无客户</p>
                <p className="text-sm mt-1">超期未跟进的客户会自动进入公海池</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {activeTab === 'leads' && (
        <Card className="bg-card border-border">
          <CardContent className="p-0">
            {filteredLeads.length > 0 ? (
              <div className="divide-y divide-border">
                {filteredLeads.map((lead) => (
                  <div key={lead.id} className="p-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className="h-12 w-12 rounded-lg bg-cyan-500/20 flex items-center justify-center">
                          <Target className="h-6 w-6 text-cyan-500" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-medium text-foreground">{lead.company_name}</h3>
                            <Badge variant="outline" className="border-cyan-500 text-cyan-500">
                              待分配
                            </Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span className="flex items-center gap-1">
                              <Phone className="h-3 w-3" />
                              {lead.phone}
                            </span>
                            <span className="flex items-center gap-1">
                              <MapPin className="h-3 w-3" />
                              {lead.region}
                            </span>
                            <span className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              进入时间：{new Date(lead.entered_pool_time).toLocaleDateString('zh-CN')}
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="default"
                          size="sm"
                          onClick={() => handleClaim(lead.id, 'lead')}
                          className="bg-cyan-500 hover:bg-cyan-600"
                        >
                          <UserPlus className="h-4 w-4 mr-1" />
                          认领
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-muted-foreground">
                <Target className="h-12 w-12 mx-auto mb-3 opacity-50" />
                <p>公海池中暂未分配线索</p>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {activeTab === 'rules' && (
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <Settings className="h-5 w-5" />
              公海池规则配置
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {rules.map((rule) => (
                <div key={rule.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                  <div>
                    <h4 className="font-medium text-foreground">{rule.name}</h4>
                    <p className="text-sm text-muted-foreground mt-1">{rule.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline">
                        {rule.days_threshold}天未跟进
                      </Badge>
                      <Badge variant="outline">
                        自动{rule.action}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {rule.is_active ? '已启用' : '已禁用'}
                    </span>
                    <Button
                      variant={rule.is_active ? 'default' : 'outline'}
                      size="sm"
                      onClick={() => handleUpdateRule(rule.id, !rule.is_active)}
                      className={rule.is_active ? 'bg-green-500' : ''}
                    >
                      {rule.is_active ? '禁用' : '启用'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 rounded-lg border border-border">
              <h4 className="font-medium text-foreground mb-2">规则说明</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>• 当客户超过设定天数未跟进时，系统会自动将其移入公海池</li>
                <li>• 公海池中的客户可以被任何团队成员认领</li>
                <li>• 认领后客户会自动分配给认领人，成为其负责的客户</li>
                <li>• 负责人也可以主动将客户退回公海池</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </MainLayout>
  );
}