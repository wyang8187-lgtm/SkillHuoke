'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { MainLayout } from '@/components/layout';
import { OrderDetailForm } from '@/components/crm/order-detail-form';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { loadSavedCrmOrders, orderStatusOptions } from '@/lib/crm-orders';
import { loadDocumentsForOrder } from '@/lib/trade-documents';
import { loadShipmentsForOrder } from '@/lib/shipments';
import { ArrowLeft, Building2, FilePlus2, FileText, Ship } from 'lucide-react';

export default function OrderDetailPage() {
  const params = useParams<{ id: string }>();
  const order = loadSavedCrmOrders().find((item) => item.id === decodeURIComponent(params.id));
  if (!order) return <MainLayout title="订单详情"><div className="rounded-lg border border-[#2d3548] bg-[#121823] p-10 text-center"><h2 className="text-xl font-semibold text-[#f8fafc]">没有找到该订单</h2><p className="mt-2 text-sm text-[#94a3b8]">订单可能已删除，或当前浏览器没有这条本地数据。</p><Button asChild className="mt-5"><Link href="/crm-orders"><ArrowLeft className="mr-2 h-4 w-4" />返回订单中心</Link></Button></div></MainLayout>;
  const documents = loadDocumentsForOrder(order.id);
  const shipments = loadShipmentsForOrder(order.id);

  return (
    <MainLayout title="订单详情">
      <div className="space-y-6">
        <section className="flex flex-col gap-4 rounded-lg border border-[#2d3548] bg-[#121823] p-6 lg:flex-row lg:items-end lg:justify-between">
          <div><Badge className="bg-emerald-500/15 text-emerald-300">{orderStatusOptions.find((item) => item.value === order.status)?.label}</Badge><h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">{order.number}</h2><p className="mt-2 text-sm text-[#94a3b8]">{order.customerName || '客户已删除'} · 报价 {order.quotationNumber}</p></div>
          <div className="flex flex-wrap gap-2"><Button asChild><Link href={`/shipments/new?orderId=${order.id}`}><Ship className="mr-2 h-4 w-4"/>创建出货</Link></Button><Button asChild variant="outline"><Link href={`/trade-documents/new?orderId=${order.id}`}><FilePlus2 className="mr-2 h-4 w-4"/>生成单据</Link></Button><Button asChild variant="outline"><Link href={`/crm-customers/${order.customerId}`}><Building2 className="mr-2 h-4 w-4" />查看客户</Link></Button><Button asChild variant="outline"><Link href={`/crm-quotations/${order.quotationId}/print`}><FileText className="mr-2 h-4 w-4" />查看报价</Link></Button><Button asChild><Link href="/crm-orders"><ArrowLeft className="mr-2 h-4 w-4" />订单中心</Link></Button></div>
        </section>
        {documents.length?<section className="rounded-lg border border-[#2d3548] bg-[#121823] p-5"><h3 className="font-semibold text-[#f8fafc]">关联外贸单据</h3><div className="mt-3 flex flex-wrap gap-2">{documents.map(d=><Button key={d.id} asChild size="sm" variant="outline"><Link href={`/trade-documents/${d.id}`}>{d.number}</Link></Button>)}</div></section>:null}
        {shipments.length?<section className="rounded-lg border border-[#2d3548] bg-[#121823] p-5"><h3 className="font-semibold text-[#f8fafc]">关联海运出货</h3><div className="mt-3 flex flex-wrap gap-2">{shipments.map(s=><Button key={s.id} asChild size="sm" variant="outline"><Link href={`/shipments/${s.id}`}>{s.number}</Link></Button>)}</div></section>:null}
        <OrderDetailForm order={order} />
      </div>
    </MainLayout>
  );
}
