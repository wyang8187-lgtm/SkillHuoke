'use client';

import React, { useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Instagram,
  Facebook,
  Youtube,
  Share2,
  Send,
  Eye,
  Heart,
  MessageCircle,
  TrendingUp,
  Users,
  Plus,
  Edit,
  Trash2,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle,
  Play,
  Pause,
  Settings,
  Image,
  Video,
  FileText,
  Zap,
  Target,
} from 'lucide-react';
import type { SocialMediaAccount, SocialMediaPost } from '@/types';
import { mockSocialAccounts, mockSocialPosts } from '@/lib/mock-data';

export default function MarketingSocialPage() {
  const [activeTab, setActiveTab] = useState<'accounts' | 'posts' | 'comments'>('accounts');
  const [accounts] = useState<SocialMediaAccount[]>(mockSocialAccounts);
  const [posts] = useState<SocialMediaPost[]>(mockSocialPosts);
  const [searchKeyword, setSearchKeyword] = useState('');

  const platformColors: Record<string, string> = {
    '抖音': '#000000',
    '小红书': '#ff2442',
    '微信视频号': '#07c160',
    'Instagram': '#e1306c',
    'Facebook': '#1877f2',
    'YouTube': '#ff0000',
  };

  const statusColors: Record<string, string> = {
    '已发布': '#22c55e',
    '草稿': '#6b7280',
    '定时发布': '#f97316',
    '审核中': '#3b82f6',
    '已删除': '#ef4444',
  };

  const filteredPosts = posts.filter(p => 
    p.title.includes(searchKeyword) || p.content.includes(searchKeyword)
  );

  return (
    <MainLayout title="社媒营销">
      {/* 子标签页 */}
      <div className="flex gap-2 mb-6">
        <Button
          onClick={() => setActiveTab('accounts')}
          className={activeTab === 'accounts' 
            ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
            : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
          }
        >
          <Share2 className="h-4 w-4 mr-2" />
          账号管理
        </Button>
        <Button
          onClick={() => setActiveTab('posts')}
          className={activeTab === 'posts' 
            ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
            : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
          }
        >
          <FileText className="h-4 w-4 mr-2" />
          内容管理
        </Button>
        <Button
          onClick={() => setActiveTab('comments')}
          className={activeTab === 'comments' 
            ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
            : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
          }
        >
          <MessageCircle className="h-4 w-4 mr-2" />
          评论监控
        </Button>
      </div>

      {/* 账号管理 */}
      {activeTab === 'accounts' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-[#f8fafc] font-medium">已绑定账号</h3>
            <Button className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
              <Plus className="h-4 w-4 mr-2" />
              添加账号
            </Button>
          </div>
          
          {/* 统计 */}
          <div className="grid grid-cols-4 gap-4">
            <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
              <Share2 className="h-5 w-5 text-[#3b82f6]" />
              <div>
                <p className="text-xs text-[#94a3b8]">总账号</p>
                <p className="text-xl font-bold text-[#f8fafc]">{accounts.length}</p>
              </div>
            </div>
            <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
              <Users className="h-5 w-5 text-[#22c55e]" />
              <div>
                <p className="text-xs text-[#94a3b8]">总粉丝</p>
                <p className="text-xl font-bold text-[#22c55e]">
                  {(accounts.reduce((sum, a) => sum + a.followers, 0) / 1000).toFixed(1)}K
                </p>
              </div>
            </div>
            <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
              <Eye className="h-5 w-5 text-[#f97316]" />
              <div>
                <p className="text-xs text-[#94a3b8]">总播放</p>
                <p className="text-xl font-bold text-[#f97316]">15.8K</p>
              </div>
            </div>
            <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
              <TrendingUp className="h-5 w-5 text-[#8b5cf6]" />
              <div>
                <p className="text-xs text-[#94a3b8]">周增长率</p>
                <p className="text-xl font-bold text-[#8b5cf6]">+8.5%</p>
              </div>
            </div>
          </div>

          {/* 账号列表 */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {accounts.map(account => (
              <Card key={account.id} className="stat-card">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-[#0f1419] flex items-center justify-center">
                        {account.platform === '抖音' && <Video className="h-5 w-5" style={{ color: platformColors[account.platform] }} />}
                        {account.platform === '小红书' && <Image className="h-5 w-5" style={{ color: platformColors[account.platform] }} />}
                        {account.platform === 'Instagram' && <Instagram className="h-5 w-5" style={{ color: platformColors[account.platform] }} />}
                        {account.platform === 'Facebook' && <Facebook className="h-5 w-5" style={{ color: platformColors[account.platform] }} />}
                      </div>
                      <div>
                        <h3 className="text-[#f8fafc] font-medium">{account.accountName}</h3>
                        <Badge 
                          style={{
                            backgroundColor: `${platformColors[account.platform]}20`,
                            color: platformColors[account.platform],
                            border: `1px solid ${platformColors[account.platform]}30`
                          }}
                        >
                          {account.platform}
                        </Badge>
                      </div>
                    </div>
                    <Badge className={account.status === '正常' ? 'status-badge-A' : 'status-badge-D'}>
                      {account.status}
                    </Badge>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-sm text-[#94a3b8]">粉丝</p>
                      <p className="text-lg font-bold text-[#f8fafc]">{(account.followers / 1000).toFixed(1)}K</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#94a3b8]">发布</p>
                      <p className="text-lg font-bold text-[#f8fafc]">{account.posts}</p>
                    </div>
                    <div>
                      <p className="text-sm text-[#94a3b8]">互动</p>
                      <p className="text-lg font-bold text-[#f8fafc]">{account.engagement}%</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 mt-4">
                    <Button size="sm" className="flex-1 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
                      <Send className="h-4 w-4 mr-1" />
                      发布内容
                    </Button>
                    <Button size="sm" variant="outline" className="border-[#2d3548] text-[#94a3b8]">
                      <Settings className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {/* 内容管理 */}
      {activeTab === 'posts' && (
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Input
                placeholder="搜索内容..."
                value={searchKeyword}
                onChange={(e) => setSearchKeyword(e.target.value)}
                className="pl-10 h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]"
              />
            </div>
            <Button className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
              <Plus className="h-4 w-4 mr-2" />
              新建内容
            </Button>
            <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]">
              <Calendar className="h-4 w-4 mr-2" />
              定时发布
            </Button>
          </div>

          {/* 内容列表 */}
          <Card className="stat-card">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="bg-[#1a1f2c] border-[#2d3548]">
                    <TableHead className="text-[#94a3b8]">标题</TableHead>
                    <TableHead className="text-[#94a3b8]">平台</TableHead>
                    <TableHead className="text-[#94a3b8]">类型</TableHead>
                    <TableHead className="text-[#94a3b8]">状态</TableHead>
                    <TableHead className="text-[#94a3b8]">发布时间</TableHead>
                    <TableHead className="text-[#94a3b8]">数据</TableHead>
                    <TableHead className="text-[#94a3b8]">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredPosts.map(post => (
                    <TableRow key={post.id} className="border-[#2d3548] hover:bg-[#1a1f2c]">
                      <TableCell className="text-[#f8fafc] max-w-[200px] truncate">{post.title}</TableCell>
                      <TableCell>
                        <Badge 
                          style={{
                            backgroundColor: `${platformColors[post.platform]}20`,
                            color: platformColors[post.platform],
                            border: `1px solid ${platformColors[post.platform]}30`
                          }}
                        >
                          {post.platform}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#94a3b8]">{post.type}</TableCell>
                      <TableCell>
                        <Badge 
                          style={{
                            backgroundColor: `${statusColors[post.status]}20`,
                            color: statusColors[post.status],
                            border: `1px solid ${statusColors[post.status]}30`
                          }}
                        >
                          {post.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[#64748b] text-xs">{post.publishTime}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 text-xs">
                          <Eye className="h-3 w-3 text-[#f97316]" />
                          <span className="text-[#94a3b8]">{post.views}</span>
                          <Heart className="h-3 w-3 text-[#ef4444]" />
                          <span className="text-[#94a3b8]">{post.likes}</span>
                          <MessageCircle className="h-3 w-3 text-[#3b82f6]" />
                          <span className="text-[#94a3b8]">{post.comments}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="sm" variant="ghost" className="h-8 px-2 text-[#94a3b8]">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-8 px-2 text-[#94a3b8]">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="h-8 px-2 text-[#ef4444]">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
      )}

      {/* 评论监控 */}
      {activeTab === 'comments' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-[#f8fafc] font-medium">评论监控</h3>
            <Button variant="outline" className="border-[#2d3548] text-[#94a3b8]">
              <Settings className="h-4 w-4 mr-2" />
              监控设置
            </Button>
          </div>
          
          {/* 待处理评论 */}
          <Card className="stat-card">
            <CardHeader className="pb-4">
              <CardTitle className="text-[#f8fafc] flex items-center gap-2">
                <MessageCircle className="h-5 w-5 text-[#f97316]" />
                待回复评论
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[1, 2, 3].map(i => (
                <div key={i} className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548]">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge className="bg-[#ff2442]/20 text-[#ff2442] border border-[#ff2442]/30">小红书</Badge>
                        <span className="text-xs text-[#64748b]">来自「全屋定制案例分享」</span>
                      </div>
                      <p className="text-[#f8fafc] mb-2">请问这个案例是哪个设计师的作品？可以合作吗？</p>
                      <div className="flex items-center gap-2 text-xs text-[#64748b]">
                        <Clock className="h-3 w-3" />
                        <span>2小时前</span>
                      </div>
                    </div>
                    <Button size="sm" className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
                      <Send className="h-4 w-4 mr-1" />
                      回复
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* 敏感词监控 */}
          <Card className="stat-card">
            <CardHeader className="pb-4">
              <CardTitle className="text-[#f8fafc] flex items-center gap-2">
                <AlertCircle className="h-5 w-5 text-[#ef4444]" />
                敏感词监控
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[#f8fafc]">监控关键词</p>
                  <p className="text-sm text-[#94a3b8]">当评论包含这些关键词时自动提醒</p>
                </div>
                <Button size="sm" variant="outline" className="border-[#2d3548] text-[#94a3b8]">
                  <Settings className="h-4 w-4 mr-1" />
                  设置关键词
                </Button>
              </div>
              <div className="flex gap-2">
                <Badge className="bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30">投诉</Badge>
                <Badge className="bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30">质量问题</Badge>
                <Badge className="bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30">退款</Badge>
                <Badge className="bg-[#ef4444]/20 text-[#ef4444] border border-[#ef4444]/30">差评</Badge>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </MainLayout>
  );
}