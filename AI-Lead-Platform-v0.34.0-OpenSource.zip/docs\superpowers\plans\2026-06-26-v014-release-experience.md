# v0.14.0 Release Experience Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a release experience center that tells users how to log in, what changed, and which pages to inspect after each release.

**Architecture:** Keep release metadata in a focused library file, render it in a new `/release` page, and reuse the same information on the login page. The sidebar gets one new navigation item so the page is easy to find.

**Tech Stack:** Next.js App Router, React, TypeScript, Tailwind CSS, shadcn-style local UI components, lucide-react icons.

---

### Task 1: Release Metadata

**Files:**
- Create: `src/lib/release-experience.ts`

- [ ] Add current version metadata, demo roles, review pages, and upload note.
- [ ] Export small arrays that can be reused by `/release` and `/login`.

### Task 2: Release Page

**Files:**
- Create: `src/app/release/page.tsx`

- [ ] Render current version summary.
- [ ] Render login instructions.
- [ ] Render key pages to review.
- [ ] Render demo role cards.
- [ ] Render upload package and GitHub remark guidance.

### Task 3: Login Page Demo Role Notes

**Files:**
- Modify: `src/app/login/page.tsx`

- [ ] Import demo role data.
- [ ] Add a compact role explanation block near the demo login button.
- [ ] Keep existing demo login behavior unchanged.

### Task 4: Navigation And Docs

**Files:**
- Modify: `src/components/layout/sidebar.tsx`
- Modify: `README.md`
- Modify: `package.json`

- [ ] Add sidebar entry for `/release`.
- [ ] Update README current version and v0.14 notes.
- [ ] Update package version to `0.14.0`.

### Task 5: Verification And Package

**Files:**
- Create output zip: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.14.0-OpenSource.zip`

- [ ] Run `corepack pnpm run ts-check`.
- [ ] Run `corepack pnpm run lint:build`.
- [ ] Run `corepack pnpm run build`.
- [ ] Check `/release` and `/login` with local HTTP requests.
- [ ] Package without `node_modules`, `.next`, `.git`, `.env`, or `.env.local`.
