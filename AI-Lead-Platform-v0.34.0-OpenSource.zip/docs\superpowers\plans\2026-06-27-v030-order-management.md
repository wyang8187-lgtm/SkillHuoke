# v0.30.0 Order Management Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a local-first foreign-trade order center that converts accepted quotations into trackable orders with deposit, balance, production, shipping, and delivery states.

**Architecture:** Add a focused `crm-orders` domain module that owns order snapshots, calculations, validation, persistence, and idempotent quotation conversion. UI pages consume this module without mutating quotation snapshots, while quotation status updates call one conversion boundary. Backup v5 extends the existing versioned payload with orders and preserves v1-v4 compatibility.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, localStorage, shadcn/Radix UI, Tailwind CSS, Node assert tests through `tsx`.

---

### Task 1: Order Domain and Calculation Tests

**Files:**
- Create: `tests/crm-orders.test.ts`
- Create: `src/lib/crm-orders.ts`
- Read: `src/lib/crm-quotations.ts`
- Read: `src/lib/crm-opportunities.ts`

- [ ] **Step 1: Write the failing domain test**

```ts
import assert from 'node:assert/strict';
import {
  calculateOrderPayments,
  createOrderFromQuotation,
  validateOrder,
} from '../src/lib/crm-orders';

const quotation = {
  id: 'quote-1',
  number: 'SH-20260627-TEST',
  language: 'en' as const,
  customerId: 'customer-1',
  opportunityId: 'opportunity-1',
  contactName: 'Alex',
  currency: 'USD' as const,
  quotationDate: '2026-06-27',
  validUntil: '2026-07-27',
  tradeTerm: 'FOB' as const,
  paymentTerms: '30% deposit, 70% before shipment',
  deliveryTime: '30-45 days',
  note: 'Quote note',
  status: 'accepted' as const,
  items: [{ id: 'line-1', product: 'Kitchen Cabinet', specification: 'Oak', quantity: 2, unit: 'set', unitPrice: 5000 }],
  discount: 0,
  shipping: 500,
  tax: 0,
  createdAt: '2026-06-27T00:00:00.000Z',
  updatedAt: '2026-06-27T00:00:00.000Z',
};

const payments = calculateOrderPayments(10500, 30, 3150, 0);
assert.deepEqual(payments, {
  depositDue: 3150,
  balanceDue: 7350,
  received: 3150,
  outstanding: 7350,
});

const order = createOrderFromQuotation(quotation, {
  company: 'Example Builder',
  contactName: 'Alex',
});
assert.equal(order.quotationId, 'quote-1');
assert.equal(order.total, 10500);
assert.equal(order.items[0].product, 'Kitchen Cabinet');
assert.notEqual(order.items, quotation.items);
assert.deepEqual(validateOrder({ ...order, depositReceived: 20000 }), ['已收金额不能超过订单总额。']);

console.log('crm-orders tests passed');
```

- [ ] **Step 2: Run the test and verify RED**

Run:

```powershell
.\node_modules\.bin\tsx.cmd tests\crm-orders.test.ts
```

Expected: FAIL with `Cannot find module '../src/lib/crm-orders'`.

- [ ] **Step 3: Implement the order domain**

Create `src/lib/crm-orders.ts` with:

```ts
export type CrmOrderStatus =
  | 'deposit_pending'
  | 'deposit_received'
  | 'production'
  | 'shipping_pending'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

export const CRM_ORDERS_STORAGE_KEY = 'skillhuoke_crm_orders_v030';

export interface SavedCrmOrder {
  id: string;
  number: string;
  customerId: string;
  customerName: string;
  contactName: string;
  opportunityId: string;
  quotationId: string;
  quotationNumber: string;
  currency: OpportunityCurrency;
  items: QuotationLineItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  tax: number;
  total: number;
  tradeTerm: TradeTerm;
  paymentTerms: string;
  deliveryTime: string;
  quotationNote: string;
  depositPercent: number;
  depositReceived: number;
  depositReceivedAt: string;
  balanceReceived: number;
  balanceReceivedAt: string;
  expectedDeliveryDate: string;
  deliveredAt: string;
  status: CrmOrderStatus;
  internalNote: string;
  createdAt: string;
  updatedAt: string;
}
```

Implement `generateOrderNumber`, `calculateOrderPayments`, `validateOrder`, `createOrderFromQuotation`, `loadSavedCrmOrders`, `saveCrmOrders`, `saveCrmOrder`, `findOrderByQuotationId`, and `deleteCrmOrder`. Clone each line item when taking the snapshot.

- [ ] **Step 4: Run the domain test and verify GREEN**

Run:

```powershell
.\node_modules\.bin\tsx.cmd tests\crm-orders.test.ts
```

Expected: `crm-orders tests passed`.

### Task 2: Quotation Conversion and Company Setting

**Files:**
- Modify: `src/lib/company-profile.ts`
- Modify: `tests/company-profile.test.ts`
- Modify: `src/app/settings/company-profile/page.tsx`
- Modify: `src/lib/crm-quotations.ts`
- Modify: `src/app/crm-quotations/page.tsx`

- [ ] **Step 1: Extend the failing company-profile test**

Add:

```ts
assert.equal(defaults.orderConversionMode, 'manual');
assert.equal(
  normalizeCompanyProfile({ ...defaults, orderConversionMode: undefined }).orderConversionMode,
  'manual',
);
```

Run the company profile test and expect a type or assertion failure because the field does not exist.

- [ ] **Step 2: Add the conversion setting**

Add to `CompanyProfile`:

```ts
orderConversionMode: 'manual' | 'automatic';
```

Set the default to `manual`, normalize unknown values to `manual`, and add a segmented select to `/settings/company-profile` with:

- `manual`: 手动确认转换
- `automatic`: 报价接受后自动转换

- [ ] **Step 3: Add an idempotent conversion boundary**

In `src/lib/crm-orders.ts`, implement:

```ts
export function convertAcceptedQuotationToOrder(
  quotation: SavedCrmQuotation,
  customer?: Pick<SavedCrmCustomer, 'company' | 'contactName'>,
) {
  if (quotation.status !== 'accepted') throw new Error('只有已接受报价可以转为订单。');
  const existing = findOrderByQuotationId(quotation.id);
  if (existing) return existing;
  return saveCrmOrder(createOrderFromQuotation(quotation, {
    company: customer?.company || '',
    contactName: customer?.contactName || quotation.contactName,
  }));
}
```

- [ ] **Step 4: Wire manual and automatic conversion**

- On quotation list, accepted quotations without an order show `转为订单`.
- Existing converted quotations show `查看订单`.
- When quotation status is saved as `accepted`, check `loadCompanyProfile().orderConversionMode`.
- In automatic mode, call `convertAcceptedQuotationToOrder`.
- Manual conversion uses `window.confirm` before creating an order.
- `deleteCrmQuotation` throws a Chinese error if an order references the quotation.

- [ ] **Step 5: Re-run both domain tests**

Run:

```powershell
.\node_modules\.bin\tsx.cmd tests\company-profile.test.ts
.\node_modules\.bin\tsx.cmd tests\crm-orders.test.ts
```

Expected: both print their pass messages.

### Task 3: Order List and Detail

**Files:**
- Create: `src/app/crm-orders/page.tsx`
- Create: `src/app/crm-orders/[id]/page.tsx`
- Create: `src/components/crm/order-detail-form.tsx`
- Modify: `src/components/layout/sidebar.tsx`

- [ ] **Step 1: Build the order list**

Create a client page using `MainLayout` that:

- Loads orders once through lazy state initialization.
- Displays total count, total value, received value, outstanding value, and deliveries due within 14 days.
- Filters by keyword, customer, status, and currency.
- Uses stable table columns for order number, customer, quotation, total, payment progress, status, delivery date, and action.
- Shows an empty state linking to `/crm-quotations`.

- [ ] **Step 2: Build the detail form**

The form edits only:

- `depositPercent`
- `depositReceived`
- `depositReceivedAt`
- `balanceReceived`
- `balanceReceivedAt`
- `expectedDeliveryDate`
- `deliveredAt`
- `status`
- `internalNote`

Display quotation snapshot fields and line items as read-only. Call `validateOrder` before saving and preserve form state when validation fails.

- [ ] **Step 3: Add navigation**

Add a top-level sidebar item:

```tsx
{
  title: '订单管理',
  href: '/crm-orders',
  icon: <PackageCheck className="h-5 w-5" />,
}
```

Place it immediately after `正式报价`.

- [ ] **Step 4: Verify routes respond**

Run:

```powershell
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:5000/crm-orders
Invoke-WebRequest -UseBasicParsing http://127.0.0.1:5000/crm-orders/missing
```

Expected: both return HTTP 200; the missing detail shows a safe empty state.

### Task 4: Backup v5

**Files:**
- Modify: `src/lib/data-backup.ts`
- Modify: `src/app/data-backup/page.tsx`
- Create: `tests/data-backup-v5.test.ts`

- [ ] **Step 1: Write the backup compatibility test**

Test that a v4 payload without `crmOrders` parses into:

```ts
assert.deepEqual(parsed.data.crmOrders, []);
assert.equal(parsed.version, 5);
```

Also test that a v5 payload preserves an order.

- [ ] **Step 2: Run the test and verify RED**

Expected: FAIL because `crmOrders` and backup version 5 do not exist.

- [ ] **Step 3: Upgrade the backup schema**

- Set `BACKUP_VERSION = 5`.
- Add `crmOrders: SavedCrmOrder[]` to `BackupData` and `BackupSummary`.
- Load, save, summarize, merge, overwrite, and undo orders.
- Accept backup versions `[1, 2, 3, 4, 5]`.
- For versions below 5, normalize missing `crmOrders` to `[]`.

- [ ] **Step 4: Update the backup page**

- Change the badge to `备份格式 v5`.
- Add an `订单` count card.
- Add order counts to import preview.
- Keep the sensitive bank-data warning.

- [ ] **Step 5: Run backup tests**

Expected: the v4 compatibility and v5 preservation assertions pass.

### Task 5: Release, Verification, and Package

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `README.md`
- Modify: `package.json`
- Create: `AI-Lead-Platform-v0.30.0-OpenSource.zip`

- [ ] **Step 1: Update release metadata**

Use:

```ts
version: 'v0.30.0'
title: '外贸订单管理中心'
packageName: 'AI-Lead-Platform-v0.30.0-OpenSource.zip'
githubRemark: 'v0.30.0：新增报价转订单、定金尾款、生产出货与交付跟踪'
```

Add `/crm-orders` and an order detail review entry. Update README and package version to `0.30.0`.

- [ ] **Step 2: Run fresh verification**

Run:

```powershell
.\node_modules\.bin\tsx.cmd tests\company-profile.test.ts
.\node_modules\.bin\tsx.cmd tests\crm-orders.test.ts
.\node_modules\.bin\tsx.cmd tests\data-backup-v5.test.ts
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

Expected: all tests pass and all commands exit 0.

- [ ] **Step 3: Browser QA**

Verify:

- `/crm-orders`
- `/crm-orders/missing`
- `/crm-quotations`
- `/settings/company-profile`
- `/data-backup`
- `/release`

Check desktop and mobile widths for horizontal overflow, clipped text, broken controls, console errors, and safe empty states.

- [ ] **Step 4: Create the open-source ZIP**

Copy the project to a temporary staging directory while excluding:

- `node_modules`
- `.next`
- `.git`
- `.env`
- `.env.local`
- server logs
- TypeScript build cache

Compress to:

`C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.30.0-OpenSource.zip`

Verify the ZIP contains the order domain, list page, detail page, tests, README, and package metadata, and contains none of the excluded files.
