'use client';

import Link from 'next/link';
import { useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { convertAcceptedQuotationToOrder, findOrderByQuotationId } from '@/lib/crm-orders';
import { loadSavedCrmCustomers } from '@/lib/lead-wizard';
import {
  calculateQuotationTotals,
  copyCrmQuotation,
  deleteCrmQuotation,
  loadSavedCrmQuotations,
  quotationStatusOptions,
  type SavedCrmQuotation,
} from '@/lib/crm-quotations';
import { Copy, PackageCheck, Plus, Printer, Trash2 } from 'lucide-react';

export default function QuotationsPage() {
  const [quotations, setQuotations] = useState<SavedCrmQuotation[]>(() => loadSavedCrmQuotations());
  const customers = loadSavedCrmCustomers();
  const customerNames = new Map(customers.map((item) => [item.id, item.company]));
  const [message, setMessage] = useState('');

  const convert = (quotation: SavedCrmQuotation) => {
    if (!window.confirm(`确认把报价 ${quotation.number} 转为正式订单吗？`)) return;
    const customer = customers.find((item) => item.id === quotation.customerId);
    const order = convertAcceptedQuotationToOrder(quotation, customer);
    setMessage(`订单 ${order.number} 已创建。`);
    setQuotations([...loadSavedCrmQuotations()]);
  };

  const remove = (quotation: SavedCrmQuotation) => {
    if (findOrderByQuotationId(quotation.id)) {
      setMessage('该报价已经生成订单，不能直接删除。请先处理关联订单。');
      return;
    }
    if (window.confirm('确认删除报价单吗？')) setQuotations(deleteCrmQuotation(quotation.id));
  };

  return (
    <MainLayout title="报价单">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="flex justify-between gap-4">
            <div><Badge className="bg-blue-500/15 text-blue-300">v0.30.0</Badge><h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">正式报价单</h2></div>
            <Button asChild><Link href="/crm-quotations/new"><Plus className="mr-2 h-4 w-4" />新建报价</Link></Button>
          </div>
        </section>
        {message ? <div className="rounded-lg border border-blue-500/25 bg-blue-500/10 p-4 text-sm text-blue-200">{message}</div> : null}
        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader><CardTitle className="text-[#f8fafc]">报价记录</CardTitle></CardHeader>
          <CardContent>
            {quotations.length === 0 ? <p className="p-8 text-center text-[#94a3b8]">还没有报价单。</p> : (
              <div className="grid gap-4 xl:grid-cols-2">
                {quotations.map((quotation) => {
                  const totals = calculateQuotationTotals(quotation);
                  const order = findOrderByQuotationId(quotation.id);
                  return (
                    <article key={quotation.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                      <div className="flex justify-between gap-3">
                        <div><Badge className="bg-violet-500/15 text-violet-300">{quotationStatusOptions.find((item) => item.value === quotation.status)?.label}</Badge><h3 className="mt-3 font-semibold text-[#f8fafc]">{quotation.number}</h3><p className="mt-1 text-sm text-[#94a3b8]">{customerNames.get(quotation.customerId) || '客户已删除'} · {quotation.quotationDate}</p></div>
                        <p className="font-semibold text-blue-300">{quotation.currency} {totals.total.toFixed(2)}</p>
                      </div>
                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button asChild size="sm"><Link href={`/crm-quotations/${quotation.id}/print`}><Printer className="mr-2 h-4 w-4" />预览</Link></Button>
                        <Button asChild size="sm" variant="outline"><Link href={`/crm-quotations/${quotation.id}/edit`}>编辑</Link></Button>
                        {order ? <Button asChild size="sm" variant="outline"><Link href={`/crm-orders/${order.id}`}><PackageCheck className="mr-2 h-4 w-4" />查看订单</Link></Button> : quotation.status === 'accepted' ? <Button size="sm" variant="outline" onClick={() => convert(quotation)}><PackageCheck className="mr-2 h-4 w-4" />转为订单</Button> : null}
                        <Button size="icon" variant="ghost" title="复制报价" onClick={() => { const copied = copyCrmQuotation(quotation); setQuotations([copied, ...quotations]); }}><Copy className="h-4 w-4" /></Button>
                        <Button size="icon" variant="ghost" title="删除报价" onClick={() => remove(quotation)}><Trash2 className="h-4 w-4 text-red-300" /></Button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
