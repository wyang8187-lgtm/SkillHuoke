'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { demoWorkspace, getApiStatusLabel, getQuotaPercent, getWorkspaceModeLabel } from '@/lib/workspace';
import {
  ArrowRight,
  Building2,
  Database,
  Key,
  LockKeyhole,
  Settings,
  ShieldCheck,
  User,
  Users,
} from 'lucide-react';

const menuItems = [
  {
    id: 'personal',
    name: '个人设置',
    icon: User,
    path: '/settings/personal',
    description: '管理个人资料、通知偏好和登录信息',
    badge: null,
  },
  {
    id: 'api-keys',
    name: 'API密钥',
    icon: Key,
    path: '/settings/api-keys',
    description: '配置 OpenAI、搜索源、邮件和 WhatsApp API',
    badge: '核心',
  },
  {
    id: 'team',
    name: '团队设置',
    icon: Users,
    path: '/settings/team',
    description: '后续用于邀请成员、分配角色和管理权限',
    badge: 'SaaS',
  },
  {
    id: 'params',
    name: '系统参数',
    icon: Settings,
    path: '/settings/params',
    description: '设置查重规则、客户评分规则和开发信签名',
    badge: null,
  },
  {
    id: 'data',
    name: '数据管理',
    icon: Database,
    path: '/settings/data',
    description: '管理导入导出、备份恢复和示例数据重置',
    badge: '谨慎',
  },
];

function QuotaRow({ label, used, limit }: { label: string; used: number; limit: number }) {
  const percent = getQuotaPercent(used, limit);

  return (
    <div>
      <div className="mb-1 flex items-center justify-between text-sm">
        <span className="text-muted-foreground">{label}</span>
        <span className="font-medium text-foreground">{used}/{limit}</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-muted">
        <div className="h-full rounded-full bg-blue-500" style={{ width: `${percent}%` }} />
      </div>
    </div>
  );
}

export default function SettingsPage() {
  const pathname = usePathname();

  return (
    <MainLayout title="系统设置">
      <div className="space-y-6">
        <div>
          <Badge className="mb-3 bg-blue-500/15 text-blue-300 border border-blue-500/20">
            v0.12 SaaS 底座
          </Badge>
          <h1 className="text-2xl font-semibold text-foreground">SaaS 工作空间设置</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            这里开始把系统从演示工具升级为多公司、多成员、可计费的 SaaS 平台。
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-4">
          <Card className="lg:col-span-2">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5 text-blue-500" />
                公司工作空间
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="text-xs text-muted-foreground">工作空间名称</div>
                <div className="text-xl font-semibold text-foreground">{demoWorkspace.name}</div>
              </div>
              <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                <div className="rounded-lg bg-muted/40 p-3">
                  <div className="text-xs text-muted-foreground">模式</div>
                  <div className="mt-1 font-medium text-foreground">{getWorkspaceModeLabel(demoWorkspace.mode)}</div>
                </div>
                <div className="rounded-lg bg-muted/40 p-3">
                  <div className="text-xs text-muted-foreground">市场</div>
                  <div className="mt-1 font-medium text-foreground">{demoWorkspace.region}</div>
                </div>
                <div className="rounded-lg bg-muted/40 p-3">
                  <div className="text-xs text-muted-foreground">身份</div>
                  <div className="mt-1 font-medium text-foreground">{demoWorkspace.ownerRole}</div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">{demoWorkspace.dataScope}</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-green-500" />
                当前套餐
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-xl font-semibold text-foreground">{demoWorkspace.plan}</div>
              <p className="mt-2 text-sm text-muted-foreground">
                后续可扩展为免费版、基础版、专业版和企业版。
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <LockKeyhole className="h-5 w-5 text-amber-500" />
                数据隔离
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm font-medium text-foreground">workspaceId 已预留</div>
              <p className="mt-2 text-sm text-muted-foreground">{demoWorkspace.isolationStatus}</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>本月使用额度</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <QuotaRow label="搜索次数" used={demoWorkspace.quota.searchesUsed} limit={demoWorkspace.quota.searchesLimit} />
              <QuotaRow label="客户数量" used={demoWorkspace.quota.customersUsed} limit={demoWorkspace.quota.customersLimit} />
              <QuotaRow label="导出次数" used={demoWorkspace.quota.exportsUsed} limit={demoWorkspace.quota.exportsLimit} />
              <QuotaRow label="团队成员" used={demoWorkspace.quota.membersUsed} limit={demoWorkspace.quota.membersLimit} />
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>API 配置状态</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between rounded-lg bg-muted/40 p-3">
                <span>OpenAI</span>
                <Badge variant="outline">{getApiStatusLabel(demoWorkspace.apiStatus.openai)}</Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-muted/40 p-3">
                <span>获客搜索源</span>
                <Badge variant="outline">{getApiStatusLabel(demoWorkspace.apiStatus.leadSearch)}</Badge>
              </div>
              <div className="flex items-center justify-between rounded-lg bg-muted/40 p-3">
                <span>Supabase 数据库</span>
                <Badge variant="outline">{getApiStatusLabel(demoWorkspace.apiStatus.supabase)}</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                v0.12 先显示 SaaS 配置结构，真实密钥仍通过 `.env.local` 或后续密钥管理页接入。
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {menuItems.map((item) => {
            const isActive = pathname === item.path;
            const Icon = item.icon;

            return (
              <Link key={item.id} href={item.path}>
                <Card className={`h-full cursor-pointer transition-colors hover:border-blue-500 ${isActive ? 'border-blue-500 bg-blue-500/5' : ''}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className={`rounded-lg p-2 ${isActive ? 'bg-blue-500/20' : 'bg-muted/40'}`}>
                        <Icon className={`h-5 w-5 ${isActive ? 'text-blue-500' : 'text-muted-foreground'}`} />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-foreground">{item.name}</span>
                          {item.badge && (
                            <Badge variant={item.badge === '谨慎' ? 'destructive' : 'default'} className="text-xs">
                              {item.badge}
                            </Badge>
                          )}
                        </div>
                        <div className="mt-1 text-sm text-muted-foreground">{item.description}</div>
                      </div>
                      <ArrowRight className={`h-4 w-4 shrink-0 ${isActive ? 'text-blue-500' : 'text-muted-foreground'}`} />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>
    </MainLayout>
  );
}
