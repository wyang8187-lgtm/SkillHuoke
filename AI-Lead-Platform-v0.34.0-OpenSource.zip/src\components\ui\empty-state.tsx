'use client';

import React from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface EmptyStateProps {
  icon: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}

export function EmptyState({ icon, title, description, action }: EmptyStateProps) {
  return (
    <Card className="bg-muted/10">
      <CardContent className="p-8">
        <div className="flex flex-col items-center text-center">
          <div className="text-muted-foreground mb-4">
            {icon}
          </div>
          <h3 className="text-lg font-medium text-muted-foreground mb-2">{title}</h3>
          {description && (
            <p className="text-sm text-muted-foreground mb-4">{description}</p>
          )}
          {action && (
            <div className="mt-4">
              {action}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}