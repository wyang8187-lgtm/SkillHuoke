import type { CompanyProfile } from './company-profile';
import type { SavedCrmOrder } from './crm-orders';
import type { OpportunityCurrency } from './crm-opportunities';
import type { QuotationLineItem, TradeTerm } from './crm-quotations';

export type TradeDocumentType = 'proforma_invoice' | 'commercial_invoice' | 'packing_list';
export type TradeDocumentStatus = 'draft' | 'issued' | 'sent' | 'confirmed' | 'void';
export const TRADE_DOCUMENTS_STORAGE_KEY = 'skillhuoke_trade_documents_v031';

export const tradeDocumentTypeOptions = [
  { value: 'proforma_invoice' as const, label: '形式发票 PI', short: 'PI' },
  { value: 'commercial_invoice' as const, label: '商业发票 CI', short: 'CI' },
  { value: 'packing_list' as const, label: '装箱单 PL', short: 'PL' },
];
export const tradeDocumentStatusOptions = [
  { value: 'draft' as const, label: '草稿' }, { value: 'issued' as const, label: '已签发' },
  { value: 'sent' as const, label: '已发送' }, { value: 'confirmed' as const, label: '已确认' },
  { value: 'void' as const, label: '已作废' },
];

export interface PackingItem {
  id: string; product: string; specification: string; cartons: number; quantityPerCarton: number;
  totalQuantity: number; netWeightPerCarton: number; grossWeightPerCarton: number;
  lengthCm: number; widthCm: number; heightCm: number;
}
export interface PackingSummary { cartons: number; quantity: number; netWeight: number; grossWeight: number; volume: number; }

export interface SavedTradeDocument {
  id: string; type: TradeDocumentType; number: string; status: TradeDocumentStatus; issueDate: string;
  orderId: string; orderNumber: string; customerId: string; customerName: string; contactName: string;
  currency: OpportunityCurrency; tradeTerm: TradeTerm; paymentTerms: string; items: QuotationLineItem[];
  discount: number; shipping: number; tax: number; packingItems: PackingItem[];
  declaredCartons: number | null; declaredQuantity: number | null; declaredNetWeight: number | null;
  declaredGrossWeight: number | null; declaredVolume: number | null;
  companyNameZh: string; companyNameEn: string; addressZh: string; addressEn: string;
  phone: string; email: string; website: string; logoDataUrl: string;
  bankName: string; bankAccountName: string; bankAccountNumber: string; bankSwift: string;
  bankAddress: string; showBankDetails: boolean; note: string; createdAt: string; updatedAt: string;
}

const round = (value: number, digits: number) => Number(value.toFixed(digits));
const today = () => new Date().toISOString().slice(0, 10);

export function calculatePackingSummary(items: PackingItem[]): PackingSummary {
  const result = items.reduce((sum, item) => {
    const cartons = Math.max(0, item.cartons);
    sum.cartons += cartons; sum.quantity += Math.max(0, item.totalQuantity);
    sum.netWeight += cartons * Math.max(0, item.netWeightPerCarton);
    sum.grossWeight += cartons * Math.max(0, item.grossWeightPerCarton);
    sum.volume += cartons * Math.max(0, item.lengthCm) * Math.max(0, item.widthCm) * Math.max(0, item.heightCm) / 1_000_000;
    return sum;
  }, { cartons: 0, quantity: 0, netWeight: 0, grossWeight: 0, volume: 0 });
  return { cartons: result.cartons, quantity: result.quantity, netWeight: round(result.netWeight, 2), grossWeight: round(result.grossWeight, 2), volume: round(result.volume, 3) };
}

export function calculateTradeDocumentTotals(document: Pick<SavedTradeDocument, 'items' | 'discount' | 'shipping' | 'tax'>) {
  const subtotal = document.items.reduce((sum, item) => sum + Math.max(0, item.quantity) * Math.max(0, item.unitPrice), 0);
  return { subtotal: round(subtotal, 2), total: round(Math.max(0, subtotal - Math.max(0, document.discount) + Math.max(0, document.shipping) + Math.max(0, document.tax)), 2) };
}

export function generateTradeDocumentNumber(type: TradeDocumentType) {
  const prefix = type === 'proforma_invoice' ? 'PI' : type === 'commercial_invoice' ? 'CI' : 'PL';
  const date = new Date(); const pad = (value: number) => String(value).padStart(2, '0');
  return `${prefix}-${date.getFullYear()}${pad(date.getMonth() + 1)}${pad(date.getDate())}-${date.getTime().toString(36).slice(-4).toUpperCase()}`;
}

export function createTradeDocumentFromOrder(order: SavedCrmOrder, company: CompanyProfile, type: TradeDocumentType): SavedTradeDocument {
  const now = new Date().toISOString();
  return {
    id: `document-${Date.now()}`, type, number: generateTradeDocumentNumber(type), status: 'draft', issueDate: today(),
    orderId: order.id, orderNumber: order.number, customerId: order.customerId, customerName: order.customerName, contactName: order.contactName,
    currency: order.currency, tradeTerm: order.tradeTerm, paymentTerms: order.paymentTerms,
    items: order.items.map((item) => ({ ...item })), discount: order.discount, shipping: order.shipping, tax: order.tax,
    packingItems: order.items.map((item) => ({ id: `pack-${item.id}`, product: item.product, specification: item.specification, cartons: 0, quantityPerCarton: 0, totalQuantity: item.quantity, netWeightPerCarton: 0, grossWeightPerCarton: 0, lengthCm: 0, widthCm: 0, heightCm: 0 })),
    declaredCartons: null, declaredQuantity: null, declaredNetWeight: null, declaredGrossWeight: null, declaredVolume: null,
    companyNameZh: company.companyNameZh, companyNameEn: company.companyNameEn, addressZh: company.addressZh, addressEn: company.addressEn,
    phone: company.phone, email: company.email, website: company.website, logoDataUrl: company.logoDataUrl,
    bankName: company.bankName, bankAccountName: company.bankAccountName, bankAccountNumber: company.bankAccountNumber,
    bankSwift: company.bankSwift, bankAddress: company.bankAddress, showBankDetails: company.showBankDetails,
    note: '', createdAt: now, updatedAt: now,
  };
}

export function validateTradeDocument(document: SavedTradeDocument, all: SavedTradeDocument[]) {
  const errors: string[] = [];
  if (!document.number.trim()) errors.push('单据编号不能为空。');
  if (all.some((item) => item.id !== document.id && item.number.trim().toLowerCase() === document.number.trim().toLowerCase())) errors.push('单据编号已存在，请修改。');
  if (!document.issueDate) errors.push('签发日期不能为空。');
  if (!document.items.length) errors.push('单据至少需要一个产品项目。');
  if (document.type === 'packing_list') {
    for (const item of document.packingItems) {
      const values = [item.cartons, item.quantityPerCarton, item.totalQuantity, item.netWeightPerCarton, item.grossWeightPerCarton, item.lengthCm, item.widthCm, item.heightCm];
      if (values.some((value) => value < 0)) { errors.push(`${item.product || '产品'}的包装数据不能为负数。`); break; }
      if (item.grossWeightPerCarton < item.netWeightPerCarton) { errors.push(`${item.product || '产品'}的毛重不能小于净重。`); break; }
    }
  } else if (document.items.some((item) => !item.product.trim() || item.quantity < 0 || item.unitPrice < 0)) errors.push('产品名称、数量和单价必须有效。');
  return errors;
}

export function loadSavedTradeDocuments(): SavedTradeDocument[] {
  if (typeof window === 'undefined') return [];
  try { const value = JSON.parse(window.localStorage.getItem(TRADE_DOCUMENTS_STORAGE_KEY) || '[]'); return Array.isArray(value) ? value : []; } catch { return []; }
}
export function saveTradeDocuments(items: SavedTradeDocument[]) { if (typeof window !== 'undefined') window.localStorage.setItem(TRADE_DOCUMENTS_STORAGE_KEY, JSON.stringify(items)); }
export function saveTradeDocument(document: SavedTradeDocument) {
  const all = loadSavedTradeDocuments(); const errors = validateTradeDocument(document, all); if (errors.length) throw new Error(errors[0]);
  const existing = all.find((item) => item.id === document.id); const saved = { ...document, createdAt: existing?.createdAt || document.createdAt, updatedAt: new Date().toISOString() };
  saveTradeDocuments(existing ? all.map((item) => item.id === saved.id ? saved : item) : [saved, ...all]); return saved;
}
export function copyTradeDocument(source: SavedTradeDocument) {
  const now = new Date().toISOString(); const copy = { ...source, id: `document-${Date.now()}`, number: generateTradeDocumentNumber(source.type), status: 'draft' as const, items: source.items.map((item) => ({ ...item })), packingItems: source.packingItems.map((item) => ({ ...item, id: `pack-${Date.now()}-${item.id}` })), createdAt: now, updatedAt: now };
  return saveTradeDocument(copy);
}
export function deleteTradeDocument(id: string) { const next = loadSavedTradeDocuments().filter((item) => item.id !== id); saveTradeDocuments(next); return next; }
export function loadDocumentsForOrder(orderId: string) { return loadSavedTradeDocuments().filter((item) => item.orderId === orderId); }
