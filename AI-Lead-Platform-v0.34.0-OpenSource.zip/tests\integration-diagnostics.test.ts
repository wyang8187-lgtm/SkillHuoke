import assert from 'node:assert/strict';
import {
  buildIntegrationStatuses,
  getIntegrationById,
  maskSecret,
  summarizeProxyConfig,
} from '../src/lib/integration-diagnostics';

const env = {
  OPENAI_API_KEY: 'sk-openai-1234567890abcd',
  GOOGLE_SEARCH_API_KEY: 'google-secret-9999',
  RESEND_FROM_EMAIL: 'sales@example.com',
  HTTPS_PROXY: 'http://user:pass@127.0.0.1:7890',
  SERPAPI_API_KEY: 'serp-old-name-1111',
};

assert.equal(maskSecret('abcd'), '••••abcd');
assert.equal(maskSecret('sk-openai-1234567890abcd'), '••••abcd');
assert.equal(maskSecret(''), '');

const statuses = buildIntegrationStatuses(env);
const openai = statuses.find((item) => item.id === 'openai');
assert.ok(openai);
assert.equal(openai.configured, true);
assert.equal(openai.fields.find((field) => field.name === 'OPENAI_API_KEY')?.value, '••••abcd');
assert.equal(JSON.stringify(openai).includes('sk-openai-1234567890abcd'), false);

const google = statuses.find((item) => item.id === 'google-search');
assert.ok(google);
assert.equal(google.configured, false);
assert.deepEqual(google.missingEnv, ['GOOGLE_SEARCH_CX']);

const serpapi = statuses.find((item) => item.id === 'serpapi');
assert.ok(serpapi);
assert.equal(serpapi.configured, true);
assert.equal(serpapi.fields.find((field) => field.name === 'SERPAPI_KEY')?.value, '••••1111');

const proxy = summarizeProxyConfig(env);
assert.equal(proxy.hasProxy, true);
const httpsProxy = proxy.items.find((item) => item.name === 'HTTPS_PROXY');
assert.ok(httpsProxy);
assert.equal(httpsProxy.value.includes('user'), false);
assert.equal(httpsProxy.value.includes('pass'), false);
assert.match(httpsProxy.value, /127\.0\.0\.1:7890/);

assert.equal(getIntegrationById('openai')?.name, 'OpenAI');
assert.equal(getIntegrationById('unknown-service'), undefined);

console.log('integration-diagnostics tests passed');
