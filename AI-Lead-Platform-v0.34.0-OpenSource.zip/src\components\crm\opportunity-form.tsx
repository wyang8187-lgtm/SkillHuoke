'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { loadSavedCrmCustomers } from '@/lib/lead-wizard';
import { opportunityCurrencies, opportunityStageOptions, saveCrmOpportunity, type OpportunityCurrency, type OpportunityStage, type SavedCrmOpportunity } from '@/lib/crm-opportunities';

export function OpportunityForm({ opportunity, initialCustomerId = '' }: { opportunity?: SavedCrmOpportunity; initialCustomerId?: string }) {
  const router = useRouter();
  const customers = loadSavedCrmCustomers();
  const [value, setValue] = useState(() => opportunity || {
    customerId: initialCustomerId, name: '', productRequirement: '', amount: 0, currency: 'USD' as OpportunityCurrency,
    stage: 'initial' as OpportunityStage, probability: 10, expectedCloseDate: '', quotationNumber: '', lastQuotationDate: '', note: '',
  });
  const [error, setError] = useState('');
  const patch = (key: string, next: unknown) => setValue((current) => ({ ...current, [key]: next }));
  const save = () => {
    if (!value.customerId || !customers.some((item) => item.id === value.customerId)) return setError('请选择有效客户。');
    if (!value.name.trim() || !value.productRequirement.trim()) return setError('请填写机会名称和产品需求。');
    if (value.amount < 0 || value.probability < 0 || value.probability > 100) return setError('金额不能为负数，概率必须在 0-100。');
    const saved = saveCrmOpportunity(value, opportunity?.id);
    router.push(`/crm-opportunities?selected=${saved.id}`);
  };
  return (
    <Card className="border-[#2d3548] bg-[#121823]">
      <CardHeader><CardTitle className="text-[#f8fafc]">{opportunity ? '编辑销售机会' : '新建销售机会'}</CardTitle></CardHeader>
      <CardContent className="grid gap-4 md:grid-cols-2">
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">关联客户 *</label><Select value={value.customerId} onValueChange={(next) => patch('customerId', next)}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue placeholder="选择客户" /></SelectTrigger><SelectContent>{customers.map((item) => <SelectItem key={item.id} value={item.id}>{item.company} · {item.country}</SelectItem>)}</SelectContent></Select></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">机会名称 *</label><Input value={value.name} onChange={(e) => patch('name', e.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        <div className="md:col-span-2"><label className="mb-2 block text-sm text-[#cbd5e1]">产品需求 *</label><Textarea value={value.productRequirement} onChange={(e) => patch('productRequirement', e.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">预计金额</label><Input type="number" min={0} value={value.amount} onChange={(e) => patch('amount', Number(e.target.value))} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">币种</label><Select value={value.currency} onValueChange={(next) => patch('currency', next as OpportunityCurrency)}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger><SelectContent>{opportunityCurrencies.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">机会阶段</label><Select value={value.stage} onValueChange={(next) => { const stage = opportunityStageOptions.find((item) => item.value === next)!; setValue((current) => ({ ...current, stage: stage.value, probability: stage.probability })); }}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger><SelectContent>{opportunityStageOptions.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">成交概率 %</label><Input type="number" min={0} max={100} value={value.probability} onChange={(e) => patch('probability', Number(e.target.value))} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">预计成交日期</label><Input type="date" value={value.expectedCloseDate} onChange={(e) => patch('expectedCloseDate', e.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">报价编号</label><Input value={value.quotationNumber} onChange={(e) => patch('quotationNumber', e.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        <div><label className="mb-2 block text-sm text-[#cbd5e1]">最近报价日期</label><Input type="date" value={value.lastQuotationDate} onChange={(e) => patch('lastQuotationDate', e.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        <div className="md:col-span-2"><label className="mb-2 block text-sm text-[#cbd5e1]">机会备注</label><Textarea value={value.note} onChange={(e) => patch('note', e.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        {error ? <p className="md:col-span-2 text-sm text-red-300">{error}</p> : null}
        <div className="md:col-span-2"><Button type="button" onClick={save} className="bg-blue-600 text-white hover:bg-blue-500">{opportunity ? '保存修改' : '创建机会'}</Button></div>
      </CardContent>
    </Card>
  );
}
