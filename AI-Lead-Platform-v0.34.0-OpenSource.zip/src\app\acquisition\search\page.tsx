'use client';

import React, { useState } from 'react';
import { Search, MapPin, Building2, User, Phone, Star, Plus, Loader2, Sparkles, CheckCircle2, FileText, Users, X, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { getSupabaseBrowserClientAsync } from '@/lib/supabase-browser';

interface SearchResult {
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  address: string;
  customerType: string;
  matchScore: number;
  source: string;
  verified: boolean;
}

interface ParsedIntent {
  region: string;
  industry: string;
  customerType: string;
  keywords: string[];
  searchStrategy: string;
}

interface ToastState {
  show: boolean;
  message: string;
  type: 'success' | 'error' | 'info';
}

export default function AcquisitionSearchPage() {
  const [keyword, setKeyword] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [parsedIntent, setParsedIntent] = useState<ParsedIntent | null>(null);
  const [results, setResults] = useState<SearchResult[]>([]);
  const [selectedResults, setSelectedResults] = useState<string[]>([]);
  const [actionInProgress, setActionInProgress] = useState<string | null>(null);
  const [toast, setToast] = useState<ToastState>({ show: false, message: '', type: 'info' });

  // 显示提示
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast({ show: false, message: '', type: 'info' }), 3000);
  };

  // AI智能搜索
  const handleSearch = async () => {
    if (!keyword.trim()) {
      showToast('请输入搜索关键词', 'error');
      return;
    }

    setIsSearching(true);
    setParsedIntent(null);
    setResults([]);
    setSelectedResults([]);

    try {
      const response = await fetch('/api/ai/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyword }),
      });

      const data = await response.json();

      if (data.success && data.results) {
        setParsedIntent(data.parsed);
        setResults(data.results);
        showToast(`找到 ${data.results.length} 个匹配结果，均为有效手机号`, 'success');
      } else {
        showToast(data.error || '搜索失败', 'error');
      }
    } catch (error) {
      console.error('搜索错误:', error);
      showToast('搜索服务暂时不可用', 'error');
    } finally {
      setIsSearching(false);
    }
  };

  // 获取认证信息
  const getAuthInfo = async () => {
    const supabase = await getSupabaseBrowserClientAsync();
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      showToast('请先登录', 'error');
      return null;
    }

    const { data: { session } } = await supabase.auth.getSession();
    return { user, token: session?.access_token || '' };
  };

  // 添加到线索池
  const handleAddToLeads = async (result: SearchResult) => {
    const auth = await getAuthInfo();
    if (!auth) return;

    setActionInProgress(`lead_${result.id}`);
    
    try {
      const response = await fetch('/api/leads', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': auth.token,
        },
        body: JSON.stringify({
          company_name: result.companyName,
          contact_name: result.contactName,
          phone: result.phone,
          region: parsedIntent?.region || '',
          source: 'AI智能搜索',
          match_score: result.matchScore,
          notes: `来源：${result.source}，客户类型：${result.customerType}`,
        }),
      });

      if (response.ok) {
        showToast(`${result.companyName} 已添加到线索池`, 'success');
      } else {
        const error = await response.json();
        showToast(error.error || '添加失败', 'error');
      }
    } catch (error) {
      console.error('添加线索错误:', error);
      showToast('添加失败，请重试', 'error');
    } finally {
      setActionInProgress(null);
    }
  };

  // 添加到客户池
  const handleAddToCustomers = async (result: SearchResult) => {
    const auth = await getAuthInfo();
    if (!auth) return;

    setActionInProgress(`customer_${result.id}`);
    
    try {
      const response = await fetch('/api/customers', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-session': auth.token,
        },
        body: JSON.stringify({
          company_name: result.companyName,
          contact_name: result.contactName,
          phone: result.phone,
          region: parsedIntent?.region || '',
          address: result.address,
          customer_type: result.customerType === '全案设计师' ? '设计师' : '建材外贸',
          source: 'AI智能搜索',
          status: '新客户',
          grade: result.matchScore >= 90 ? 'A' : result.matchScore >= 80 ? 'B' : 'C',
        }),
      });

      if (response.ok) {
        showToast(`${result.companyName} 已添加到客户列表`, 'success');
      } else {
        const error = await response.json();
        showToast(error.error || '添加失败', 'error');
      }
    } catch (error) {
      console.error('添加客户错误:', error);
      showToast('添加失败，请重试', 'error');
    } finally {
      setActionInProgress(null);
    }
  };

  // 批量添加到线索池
  const handleBatchAddToLeads = async () => {
    if (selectedResults.length === 0) {
      showToast('请先选择要添加的结果', 'error');
      return;
    }

    const selectedData = results.filter(r => selectedResults.includes(r.id));
    let successCount = 0;
    
    for (const result of selectedData) {
      const auth = await getAuthInfo();
      if (!auth) break;
      
      try {
        const response = await fetch('/api/leads', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-session': auth.token,
          },
          body: JSON.stringify({
            company_name: result.companyName,
            contact_name: result.contactName,
            phone: result.phone,
            region: parsedIntent?.region || '',
            source: 'AI智能搜索',
            match_score: result.matchScore,
          }),
        });
        
        if (response.ok) successCount++;
      } catch {
        // 继续处理下一个
      }
    }
    
    showToast(`成功添加 ${successCount} 个线索`, successCount > 0 ? 'success' : 'error');
    setSelectedResults([]);
  };

  // 批量添加到客户池
  const handleBatchAddToCustomers = async () => {
    if (selectedResults.length === 0) {
      showToast('请先选择要添加的结果', 'error');
      return;
    }

    const selectedData = results.filter(r => selectedResults.includes(r.id));
    let successCount = 0;
    
    for (const result of selectedData) {
      const auth = await getAuthInfo();
      if (!auth) break;
      
      try {
        const response = await fetch('/api/customers', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-session': auth.token,
          },
          body: JSON.stringify({
            company_name: result.companyName,
            contact_name: result.contactName,
            phone: result.phone,
            region: parsedIntent?.region || '',
            address: result.address,
            customer_type: result.customerType === '全案设计师' ? '设计师' : '建材外贸',
            source: 'AI智能搜索',
            status: '新客户',
            grade: result.matchScore >= 90 ? 'A' : result.matchScore >= 80 ? 'B' : 'C',
          }),
        });
        
        if (response.ok) successCount++;
      } catch {
        // 继续处理下一个
      }
    }
    
    showToast(`成功添加 ${successCount} 个客户`, successCount > 0 ? 'success' : 'error');
    setSelectedResults([]);
  };

  return (
    <div className="p-6">
      {/* Toast提示 */}
      {toast.show && (
        <div className={cn(
          "fixed top-4 right-4 z-50 px-4 py-3 rounded-lg shadow-lg flex items-center gap-2 animate-slide-in",
          toast.type === 'success' ? "bg-green-500/90 text-white" :
          toast.type === 'error' ? "bg-red-500/90 text-white" : "bg-blue-500/90 text-white"
        )}>
          {toast.type === 'success' && <CheckCircle2 className="w-4 h-4" />}
          {toast.type === 'error' && <AlertCircle className="w-4 h-4" />}
          <span>{toast.message}</span>
          <button onClick={() => setToast({ show: false, message: '', type: 'info' })} className="ml-2">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 页面标题 */}
      <div className="mb-6">
        <h1 className="text-2xl font-semibold text-white flex items-center gap-2">
          <Sparkles className="w-6 h-6 text-blue-500" />
          AI智能搜索
        </h1>
        <p className="text-gray-400 mt-1">
          输入关键词，AI自动理解意图并搜索目标客户。所有结果均为真实手机号，无座机号。
        </p>
      </div>

      {/* 搜索区域 */}
      <div className="bg-[#1a1f2c] rounded-lg p-6 border border-[#2d3548] mb-6">
        <div className="flex gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={keyword}
              onChange={(e) => setKeyword(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              placeholder="输入搜索关键词，如：深圳全案设计师、佛山建材外贸公司..."
              className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-lg text-white placeholder-gray-500 focus:border-blue-500 focus:outline-none"
            />
          </div>
          <button
            onClick={handleSearch}
            disabled={isSearching}
            className="px-6 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg font-medium flex items-center gap-2 hover:from-blue-600 hover:to-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSearching ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                AI搜索中...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                AI搜索
              </>
            )}
          </button>
        </div>

        {/* 搜索建议 */}
        <div className="mt-4 flex gap-2 flex-wrap">
          <span className="text-gray-400 text-sm">热门搜索：</span>
          {['深圳全案设计师', '佛山建材外贸', '广州室内设计', '东莞家具外贸', '中山灯饰外贸'].map((s) => (
            <button
              key={s}
              onClick={() => setKeyword(s)}
              className="text-sm text-blue-400 hover:text-blue-300 bg-blue-500/10 px-2 py-1 rounded"
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* AI解析结果 */}
      {parsedIntent && (
        <div className="bg-[#1a1f2c] rounded-lg p-4 border border-[#2d3548] mb-6">
          <h2 className="text-lg font-medium text-white mb-3 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-orange-500" />
            AI解析结果
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400">地区：</span>
              <span className="text-white">{parsedIntent.region || '不限'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400">行业：</span>
              <span className="text-white">{parsedIntent.industry || '不限'}</span>
            </div>
            <div className="flex items-center gap-2">
              <User className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400">类型：</span>
              <span className="text-white">{parsedIntent.customerType || '不限'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-gray-400" />
              <span className="text-gray-400">关键词：</span>
              <span className="text-white">{parsedIntent.keywords?.join(', ') || '无'}</span>
            </div>
          </div>
          <div className="mt-3 text-gray-400 text-sm">
            <span className="text-orange-400">搜索策略：</span> {parsedIntent.searchStrategy}
          </div>
        </div>
      )}

      {/* 搜索结果 */}
      {results.length > 0 && (
        <div className="bg-[#1a1f2c] rounded-lg border border-[#2d3548]">
          {/* 批量操作栏 */}
          <div className="p-4 border-b border-[#2d3548] flex justify-between items-center">
            <div className="text-gray-400 flex items-center gap-2">
              找到 <span className="text-white font-medium">{results.length}</span> 个匹配结果
              <span className="text-xs bg-green-500/20 text-green-400 px-2 py-0.5 rounded">
                全部为真实手机号
              </span>
            </div>
            <div className="flex gap-3 items-center">
              <button
                onClick={() => setSelectedResults(results.map(r => r.id))}
                className="text-sm text-blue-400 hover:text-blue-300"
              >
                全选
              </button>
              <button
                onClick={() => setSelectedResults([])}
                className="text-sm text-gray-400 hover:text-gray-300"
              >
                取消选择
              </button>
              <button
                onClick={handleBatchAddToLeads}
                disabled={selectedResults.length === 0}
                className="px-3 py-1.5 bg-blue-500/20 text-blue-400 text-sm rounded hover:bg-blue-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
              >
                <FileText className="w-3 h-3" />
                批量转线索 ({selectedResults.length})
              </button>
              <button
                onClick={handleBatchAddToCustomers}
                disabled={selectedResults.length === 0}
                className="px-3 py-1.5 bg-orange-500/20 text-orange-400 text-sm rounded hover:bg-orange-500/30 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-1"
              >
                <Users className="w-3 h-3" />
                批量转客户 ({selectedResults.length})
              </button>
            </div>
          </div>

          {/* 结果列表 */}
          <div className="divide-y divide-[#2d3548]">
            {results.map((result) => (
              <div key={result.id} className="p-4 hover:bg-[#0f1419]/50 transition-colors">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <input
                      type="checkbox"
                      checked={selectedResults.includes(result.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedResults([...selectedResults, result.id]);
                        } else {
                          setSelectedResults(selectedResults.filter(id => id !== result.id));
                        }
                      }}
                      className="w-4 h-4 rounded border-gray-600 text-blue-500 focus:ring-blue-500"
                    />
                    <div>
                      <div className="font-medium text-white flex items-center gap-2">
                        {result.companyName}
                        {result.verified && (
                          <span className="text-xs bg-green-500/20 text-green-400 px-1.5 py-0.5 rounded flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" />
                            已验证
                          </span>
                        )}
                      </div>
                      <div className="text-sm text-gray-400 mt-1 flex items-center gap-4">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {result.contactName}
                        </span>
                        <span className="flex items-center gap-1 text-green-400">
                          <Phone className="w-3 h-3" />
                          {result.phone}
                          <span className="text-xs bg-green-500/10 px-1 rounded">手机</span>
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="w-3 h-3" />
                          {result.address}
                        </span>
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        类型：{result.customerType} | 来源：{result.source}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <Star className={cn(
                        "w-4 h-4",
                        result.matchScore >= 90 ? "text-green-400 fill-green-400" :
                        result.matchScore >= 80 ? "text-blue-400 fill-blue-400" : "text-gray-400"
                      )} />
                      <span className={cn(
                        "font-medium",
                        result.matchScore >= 90 ? "text-green-400" :
                        result.matchScore >= 80 ? "text-blue-400" : "text-gray-400"
                      )}>
                        {result.matchScore}%
                      </span>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleAddToLeads(result)}
                        disabled={actionInProgress === `lead_${result.id}`}
                        className="px-3 py-1.5 bg-blue-500/20 text-blue-400 text-sm rounded hover:bg-blue-500/30 flex items-center gap-1 disabled:opacity-50"
                      >
                        {actionInProgress === `lead_${result.id}` ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <FileText className="w-3 h-3" />
                        )}
                        转线索
                      </button>
                      <button
                        onClick={() => handleAddToCustomers(result)}
                        disabled={actionInProgress === `customer_${result.id}`}
                        className="px-3 py-1.5 bg-orange-500/20 text-orange-400 text-sm rounded hover:bg-orange-500/30 flex items-center gap-1 disabled:opacity-50"
                      >
                        {actionInProgress === `customer_${result.id}` ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <Users className="w-3 h-3" />
                        )}
                        转客户
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 无结果提示 */}
      {!isSearching && results.length === 0 && parsedIntent === null && keyword === '' && (
        <div className="text-center py-12 text-gray-400">
          <Sparkles className="w-12 h-12 mx-auto mb-4 opacity-30" />
          <p>输入关键词开始AI智能搜索</p>
          <p className="text-sm mt-2">系统将自动过滤座机号，只展示真实手机号</p>
        </div>
      )}
    </div>
  );
}