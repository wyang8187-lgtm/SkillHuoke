// 客户数据导出 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 导出客户数据为CSV
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const ids = searchParams.get('ids'); // 可选：指定导出的客户ID

    // 获取客户数据
    let customers;
    if (ids) {
      // 导出指定客户
      const idList = ids.split(',');
      customers = [];
      for (const id of idList) {
        const customer = await dbService.getCustomerById(user.id, id);
        if (customer) {
          customers.push(customer);
        }
      }
    } else {
      // 导出所有客户
      const result = await dbService.getCustomers(user.id, undefined, 1, 10000);
      customers = result.data;
    }

    // 构建CSV内容
    const headers = [
      '公司名称',
      '客户类型',
      '联系人',
      '手机号',
      '地区',
      '等级',
      '状态',
      '来源',
      '标签',
      '最近跟进时间',
      '创建时间',
    ];

    const csvRows = [headers.join(',')];

    for (const customer of customers) {
      const row = [
        customer.company_name || '',
        customer.customer_type || '',
        customer.contact_name || '',
        customer.phone || '',
        customer.region || '',
        customer.grade || '',
        customer.status || '',
        customer.source || '',
        (customer.tags || []).join(';'),
        customer.last_follow_up_time || '',
        customer.created_at || '',
      ].map(field => {
        // 处理CSV特殊字符
        if (field.includes(',') || field.includes('"') || field.includes('\n')) {
          return `"${field.replace(/"/g, '""')}"`;
        }
        return field;
      });
      
      csvRows.push(row.join(','));
    }

    const csvContent = csvRows.join('\n');

    // 返回CSV文件
    return new NextResponse(csvContent, {
      headers: {
        'Content-Type': 'text/csv; charset=utf-8',
        'Content-Disposition': `attachment; filename="customers_${new Date().toISOString().split('T')[0]}.csv"`,
      },
    });
  } catch (error) {
    console.error('导出失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '导出失败' 
    }, { status: 500 });
  }
}