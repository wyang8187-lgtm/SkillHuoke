import { NextResponse } from 'next/server';
import { getSupabaseCredentials } from '@/storage/database/supabase-client';

export async function GET() {
  try {
    const { url, anonKey } = getSupabaseCredentials();

    if (!url || !anonKey) {
      return NextResponse.json({ enabled: false, mode: 'local' });
    }

    return NextResponse.json({ enabled: true, mode: 'cloud', url, anonKey });
  } catch {
    return NextResponse.json({ enabled: false, mode: 'local' });
  }
}
