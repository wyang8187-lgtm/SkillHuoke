'use client';

import React, { useState, useEffect } from 'react';
import { Sparkles, Loader2, Building2, Star, Target, TrendingUp, AlertTriangle, CheckCircle, Lightbulb, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CustomerData {
  id: string;
  company_name?: string;
  contact_name?: string;
  phone?: string;
  region?: string;
  address?: string;
  customer_type?: string;
  source?: string;
  status?: string;
  grade?: string;
  [key: string]: unknown;
}

interface AIPortraitProps {
  customer: CustomerData;
}

interface PortraitData {
  companyProfile: {
    estimatedScale: string;
    mainProducts: string[];
    businessType: string;
    serviceArea: string;
  };
  cooperationPotential: {
    score: number;
    level: string;
    reasons: string[];
  };
  keyNeeds: string[];
  recommendedApproach: {
    primaryChannel: string;
    timing: string;
    tone: string;
  };
  followUpStrategy: {
    summary: string;
    steps: string[];
    frequency: string;
  };
  riskFactors: string[];
  nextAction: string;
}

export function AIPortraitAnalysis({ customer }: AIPortraitProps) {
  const [portrait, setPortrait] = useState<PortraitData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (customer) {
      analyzeCustomer();
    }
  }, [customer?.id]);

  const analyzeCustomer = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch('/api/ai/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerData: customer }),
      });

      if (!response.ok) {
        throw new Error('AI分析失败');
      }

      const data = await response.json();
      if (data.success && data.data) {
        setPortrait(data.data);
      } else {
        throw new Error(data.error || '分析失败');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'AI分析暂时不可用');
    } finally {
      setLoading(false);
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case '高': return 'text-green-400';
      case '中': return 'text-orange-400';
      case '低': return 'text-gray-400';
      default: return 'text-blue-400';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-orange-400';
    return 'text-gray-400';
  };

  if (loading) {
    return (
      <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548]">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-blue-500" />
          <h3 className="text-sm text-[#94a3b8] uppercase">AI客户画像分析</h3>
        </div>
        <div className="flex items-center justify-center py-8">
          <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
          <span className="ml-2 text-gray-400">AI正在分析客户数据...</span>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548]">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-blue-500" />
          <h3 className="text-sm text-[#94a3b8] uppercase">AI客户画像分析</h3>
        </div>
        <div className="flex items-center justify-center py-4 gap-2">
          <AlertTriangle className="w-4 h-4 text-orange-400" />
          <span className="text-gray-400">{error}</span>
          <button
            onClick={analyzeCustomer}
            className="text-blue-400 hover:text-blue-300 flex items-center gap-1"
          >
            <RefreshCw className="w-4 h-4" />
            重试
          </button>
        </div>
      </div>
    );
  }

  if (!portrait) {
    return null;
  }

  return (
    <div className="p-4 bg-[#0f1419] rounded-lg border border-[#2d3548] space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-blue-500" />
          <h3 className="text-sm text-[#94a3b8] uppercase">AI客户画像分析</h3>
        </div>
        <button
          onClick={analyzeCustomer}
          className="text-gray-400 hover:text-blue-400 flex items-center gap-1 text-xs"
        >
          <RefreshCw className="w-3 h-3" />
          刷新
        </button>
      </div>

      {/* 企业概况 */}
      <div className="space-y-2">
        <h4 className="text-xs text-gray-500 flex items-center gap-1">
          <Building2 className="w-3 h-3" />
          企业概况
        </h4>
        <div className="grid grid-cols-2 gap-2 text-sm">
          <div>
            <span className="text-gray-400">规模：</span>
            <span className="text-white ml-1">{portrait.companyProfile.estimatedScale}</span>
          </div>
          <div>
            <span className="text-gray-400">业务：</span>
            <span className="text-white ml-1">{portrait.companyProfile.businessType}</span>
          </div>
          <div>
            <span className="text-gray-400">区域：</span>
            <span className="text-white ml-1">{portrait.companyProfile.serviceArea}</span>
          </div>
        </div>
        <div className="flex flex-wrap gap-1">
          <span className="text-gray-400 text-sm">主营：</span>
          {portrait.companyProfile.mainProducts.map((product, idx) => (
            <span key={idx} className="text-xs bg-blue-500/20 text-blue-400 px-1.5 py-0.5 rounded">
              {product}
            </span>
          ))}
        </div>
      </div>

      {/* 合作意向 */}
      <div className="space-y-2">
        <h4 className="text-xs text-gray-500 flex items-center gap-1">
          <Target className="w-3 h-3" />
          合作意向评估
        </h4>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <Star className={cn("w-5 h-5", getScoreColor(portrait.cooperationPotential.score))} />
            <span className={cn("text-xl font-semibold", getScoreColor(portrait.cooperationPotential.score))}>
              {portrait.cooperationPotential.score}
            </span>
            <span className="text-gray-400 text-sm">分</span>
          </div>
          <span className={cn("text-sm font-medium", getLevelColor(portrait.cooperationPotential.level))}>
            {portrait.cooperationPotential.level}意向
          </span>
        </div>
        <div className="text-xs text-gray-400 space-y-1">
          {portrait.cooperationPotential.reasons.map((reason, idx) => (
            <div key={idx} className="flex items-center gap-1">
              <CheckCircle className="w-3 h-3 text-gray-500" />
              {reason}
            </div>
          ))}
        </div>
      </div>

      {/* 核心需求 */}
      <div className="space-y-2">
        <h4 className="text-xs text-gray-500 flex items-center gap-1">
          <TrendingUp className="w-3 h-3" />
          客户核心需求
        </h4>
        <div className="flex flex-wrap gap-1">
          {portrait.keyNeeds.map((need, idx) => (
            <span key={idx} className="text-xs bg-orange-500/20 text-orange-400 px-1.5 py-0.5 rounded">
              {need}
            </span>
          ))}
        </div>
      </div>

      {/* 推荐方式 */}
      <div className="space-y-2">
        <h4 className="text-xs text-gray-500 flex items-center gap-1">
          <Lightbulb className="w-3 h-3" />
          推荐接触方式
        </h4>
        <div className="grid grid-cols-3 gap-2 text-sm">
          <div>
            <span className="text-gray-400">渠道：</span>
            <span className="text-blue-400 ml-1">{portrait.recommendedApproach.primaryChannel}</span>
          </div>
          <div>
            <span className="text-gray-400">时机：</span>
            <span className="text-white ml-1">{portrait.recommendedApproach.timing}</span>
          </div>
          <div>
            <span className="text-gray-400">风格：</span>
            <span className="text-white ml-1">{portrait.recommendedApproach.tone}</span>
          </div>
        </div>
      </div>

      {/* 跟进策略 */}
      <div className="space-y-2">
        <h4 className="text-xs text-gray-500">跟进策略建议</h4>
        <p className="text-sm text-white">{portrait.followUpStrategy.summary}</p>
        <div className="text-xs text-gray-400 space-y-1">
          {portrait.followUpStrategy.steps.map((step, idx) => (
            <div key={idx} className="flex items-start gap-1">
              <span className="text-blue-400">{idx + 1}.</span>
              {step}
            </div>
          ))}
        </div>
        <div className="text-xs text-gray-400">
          建议频率：<span className="text-orange-400">{portrait.followUpStrategy.frequency}</span>
        </div>
      </div>

      {/* 风险提示 */}
      {portrait.riskFactors.length > 0 && (
        <div className="space-y-2">
          <h4 className="text-xs text-gray-500 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            风险提示
          </h4>
          <div className="text-xs text-orange-400 space-y-1">
            {portrait.riskFactors.map((factor, idx) => (
              <div key={idx}>• {factor}</div>
            ))}
          </div>
        </div>
      )}

      {/* 下一步行动 */}
      <div className="pt-2 border-t border-[#2d3548]">
        <div className="flex items-center gap-2">
          <Lightbulb className="w-4 h-4 text-green-400" />
          <span className="text-sm text-gray-400">下一步行动：</span>
          <span className="text-sm text-white font-medium">{portrait.nextAction}</span>
        </div>
      </div>
    </div>
  );
}