export type LeadSearchProvider = 'auto' | 'mock' | 'google' | 'serpapi' | 'bing';

export interface LeadSearchInput {
  product: string;
  country: string;
  customerType: string;
  quantity?: number;
  provider?: LeadSearchProvider;
  query?: string;
}

export interface LeadSearchCandidate {
  companyName: string;
  website?: string;
  country: string;
  city?: string;
  customerType: string;
  sourceUrl?: string;
  emailStatus: 'found' | 'not_found' | 'needs_verification';
  phoneStatus: 'found' | 'not_found' | 'needs_verification';
  whatsappStatus: 'found' | 'not_found' | 'needs_verification';
  linkedinStatus: 'found' | 'not_found' | 'needs_verification';
  matchScore: number;
  priority: 'A' | 'B' | 'C' | 'D';
  confidence: number;
  riskSignals: string[];
  nextAction: string;
}

export interface LeadSearchResult {
  provider: LeadSearchProvider;
  query: string;
  candidates: LeadSearchCandidate[];
  warnings: string[];
}

function buildDefaultQuery(input: LeadSearchInput) {
  return [
    input.country,
    input.product,
    input.customerType,
    'company contact email LinkedIn WhatsApp',
  ]
    .filter(Boolean)
    .join(' ');
}

function configuredProviders() {
  return {
    google: Boolean(process.env.GOOGLE_SEARCH_API_KEY && process.env.GOOGLE_SEARCH_CX),
    serpapi: Boolean(process.env.SERPAPI_API_KEY),
    bing: Boolean(process.env.BING_SEARCH_API_KEY),
  };
}

function createMockCandidates(input: LeadSearchInput, query: string): LeadSearchCandidate[] {
  const quantity = Math.min(Math.max(input.quantity || 5, 1), 20);
  const customerTypes = input.customerType
    .split(/[,+，、]/)
    .map((item) => item.trim())
    .filter(Boolean);

  return Array.from({ length: quantity }, (_, index) => {
    const type = customerTypes[index % Math.max(customerTypes.length, 1)] || input.customerType;
    const score = Math.max(62, 92 - index * 3);
    return {
      companyName: `${input.country} ${type} Lead ${index + 1}`,
      website: `https://example-${index + 1}.com`,
      country: input.country,
      city: input.country.toLowerCase().includes('australia') || input.country.includes('澳') ? 'Sydney' : undefined,
      customerType: type,
      sourceUrl: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      emailStatus: 'needs_verification',
      phoneStatus: 'needs_verification',
      whatsappStatus: 'needs_verification',
      linkedinStatus: 'needs_verification',
      matchScore: score,
      priority: score >= 85 ? 'A' : score >= 75 ? 'B' : 'C',
      confidence: score - 8,
      riskSignals: ['mock_data', 'needs_public_source_verification'],
      nextAction: '核验官网、LinkedIn 和邮箱后再加入正式 CRM 跟进。',
    };
  });
}

export async function searchLeadCandidates(input: LeadSearchInput): Promise<LeadSearchResult> {
  const query = input.query?.trim() || buildDefaultQuery(input);
  const provider = input.provider || 'auto';
  const providers = configuredProviders();
  const warnings: string[] = [];

  if (provider !== 'mock' && provider !== 'auto') {
    const hasProviderKey = providers[provider as keyof typeof providers];
    if (!hasProviderKey) {
      warnings.push(`${provider} is not configured. Falling back to mock provider.`);
    }
  }

  if (provider === 'auto' && !providers.google && !providers.serpapi && !providers.bing) {
    warnings.push('No real search provider is configured. Using mock provider.');
  }

  return {
    provider: 'mock',
    query,
    candidates: createMockCandidates(input, query),
    warnings,
  };
}
