'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Search,
  BookOpen,
  TrendingUp,
  Building2,
  AlertTriangle,
  Award,
  Globe,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import Link from 'next/link';

interface IndustryData {
  name: string;
  hasDetailedInfo: boolean;
}

interface IndustryDetail {
  overview: string;
  mainExportMarkets: Array<{ region: string; percentage: string; features: string }>;
  leadingCompanies: string[];
  commonChallenges: string[];
  keyProducts: string[];
  certificationRequirements: string[];
}

const DETAILED_INDUSTRIES = ['灯饰照明', '油漆涂料', '岩板大板', '橱柜定制'];

export default function IndustryLibraryPage() {
  const [industries, setIndustries] = useState<IndustryData[]>([]);
  const [selectedIndustry, setSelectedIndustry] = useState<string>('灯饰照明');
  const [industryDetail, setIndustryDetail] = useState<IndustryDetail | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchIndustries();
  }, []);

  useEffect(() => {
    if (selectedIndustry) {
      fetchIndustryDetail(selectedIndustry);
    }
  }, [selectedIndustry]);

  const fetchIndustries = async () => {
    try {
      const res = await fetch('/api/industry-library');
      const data = await res.json();
      if (data.success) {
        setIndustries(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch industries:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchIndustryDetail = async (industry: string) => {
    try {
      const res = await fetch(`/api/industry-library?industry=${encodeURIComponent(industry)}`);
      const data = await res.json();
      if (data.success) {
        setIndustryDetail(data.data);
      }
    } catch (error) {
      console.error('Failed to fetch industry detail:', error);
    }
  };

  const handleStartSearch = (industry: string) => {
    // 跳转到高级搜索页面，带上行业参数
    window.location.href = `/acquisition/advanced-search?industry=${encodeURIComponent(industry)}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <BookOpen className="h-6 w-6 text-primary" />
            建材行业资源库
          </h1>
          <p className="text-muted-foreground mt-1">
            查看行业概况、市场分析、开发信模板，快速启动AI搜客
          </p>
        </div>
        <Badge variant="secondary" className="text-sm">
          共 {industries.length} 个行业
        </Badge>
      </div>

      {/* 重点行业卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {DETAILED_INDUSTRIES.map(industry => (
          <Card
            key={industry}
            className={`cursor-pointer transition-all hover:shadow-md ${
              selectedIndustry === industry ? 'ring-2 ring-primary' : ''
            }`}
            onClick={() => setSelectedIndustry(industry)}
          >
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium">{industry}</span>
                <Badge variant="default" className="text-xs">详细数据</Badge>
              </div>
              <div className="flex gap-1">
                <Button
                  size="sm"
                  variant="outline"
                  className="flex-1 h-8"
                  onClick={() => setSelectedIndustry(industry)}
                >
                  <BookOpen className="h-3 w-3 mr-1" />
                  查看详情
                </Button>
                <Button
                  size="sm"
                  variant="default"
                  className="flex-1 h-8"
                  onClick={() => handleStartSearch(industry)}
                >
                  <Search className="h-3 w-3 mr-1" />
                  开始搜客
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 行业详情 */}
      {industryDetail && (
        <Tabs defaultValue="overview" className="space-y-4">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">行业概况</TabsTrigger>
            <TabsTrigger value="markets">出口市场</TabsTrigger>
            <TabsTrigger value="companies">头部企业</TabsTrigger>
            <TabsTrigger value="challenges">常见痛点</TabsTrigger>
            <TabsTrigger value="certifications">认证要求</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building2 className="h-5 w-5 text-primary" />
                  {selectedIndustry} - 行业概况
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground leading-relaxed">
                  {industryDetail.overview}
                </p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {industryDetail.keyProducts.map(product => (
                    <Badge key={product} variant="secondary">{product}</Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="markets" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-primary" />
                  主要出口市场
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {industryDetail.mainExportMarkets.map(market => (
                    <div key={market.region} className="flex items-start gap-4 p-3 rounded-lg bg-muted/50">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <span className="font-medium">{market.region}</span>
                          <Badge variant="outline">{market.percentage}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{market.features}</p>
                      </div>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => handleStartSearch(selectedIndustry)}
                      >
                        <ArrowRight className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="companies" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-primary" />
                  行业头部企业
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {industryDetail.leadingCompanies.map((company, index) => (
                    <div key={company} className="flex items-center gap-3 p-2 rounded hover:bg-muted/50">
                      <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-sm flex items-center justify-center">
                        {index + 1}
                      </span>
                      <span className="text-sm">{company}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="challenges" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-orange-500" />
                  常见客户痛点
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {industryDetail.commonChallenges.map(challenge => (
                    <div key={challenge} className="flex items-start gap-2 p-2 rounded bg-orange-500/10">
                      <AlertTriangle className="h-4 w-4 text-orange-500 mt-0.5" />
                      <span className="text-sm">{challenge}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="certifications" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-green-500" />
                  认证要求
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {industryDetail.certificationRequirements.map(cert => (
                    <Badge key={cert} variant="default" className="bg-green-500/10 text-green-600 border-green-500/20">
                      {cert}
                    </Badge>
                  ))}
                </div>
                <p className="mt-4 text-sm text-muted-foreground">
                  建议在出口前提前准备相关认证，避免订单延误
                </p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}

      {/* 全行业列表 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="h-5 w-5" />
            全部行业标签 ({industries.length}个)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-2">
            {industries.map(industry => (
              <Badge
                key={industry.name}
                variant={industry.hasDetailedInfo ? 'default' : 'secondary'}
                className="cursor-pointer hover:opacity-80"
                onClick={() => setSelectedIndustry(industry.name)}
              >
                {industry.name}
                {industry.hasDetailedInfo && ' ★'}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 快捷操作 */}
      <div className="flex justify-end gap-4">
        <Link href="/acquisition/advanced-search">
          <Button variant="outline">
            <Search className="h-4 w-4 mr-2" />
            高级搜客
          </Button>
        </Link>
        <Link href="/acquisition/lead-discovery">
          <Button variant="outline">
            <TrendingUp className="h-4 w-4 mr-2" />
            线索发现
          </Button>
        </Link>
        <Button onClick={() => handleStartSearch(selectedIndustry)}>
          <ArrowRight className="h-4 w-4 mr-2" />
          搜索 {selectedIndustry} 客户
        </Button>
      </div>
    </div>
  );
}