// 邮件模板管理 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient, getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 获取邮件模板列表
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const category = searchParams.get('category');

    const serviceClient = getSupabaseServiceRoleClient();
    
    let query = serviceClient
      .from('email_templates')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (category) {
      query = query.eq('category', category);
    }

    const { data, error } = await query;

    if (error) {
      throw error;
    }

    // 如果用户没有模板，创建5个预设模板
    if (!data || data.length === 0) {
      const defaultTemplates = [
        {
          user_id: user.id,
          name: '初次接触开发信',
          category: '初次接触',
          subject: '【公司名】期待与贵司的合作机会',
          content: `尊敬的{contact_name}：

您好！

我们是{company_name}，一家专注于全屋定制解决方案的企业。通过行业渠道了解到贵司在{industry}领域的卓越表现，希望能有机会与贵司探讨合作可能。

我们的核心优势包括：
• 个性化定制服务，满足多样化需求
• 专业的产品设计团队
• 高效的生产交付体系
• 灵活的合作模式

如有兴趣，欢迎随时沟通，期待您的回复！

祝商祺！

{sender_name}
{sender_company}
联系电话：{sender_phone}`,
          style: '正式',
          is_default: true,
        },
        {
          user_id: user.id,
          name: '产品介绍邮件',
          category: '产品介绍',
          subject: '全屋定制产品方案介绍',
          content: `尊敬的{contact_name}：

您好！

感谢您对我们产品的关注。现附上我们最新的全屋定制产品方案，涵盖以下核心产品线：

【定制橱柜系列】
• 现代简约风格
• 多种材质可选
• 灵活尺寸定制

【定制衣柜系列】
• 智能收纳设计
• 人性化布局
• 精选环保材料

【整体空间解决方案】
• 一站式设计服务
• 专业施工团队
• 品质保障体系

期待为您提供专业的定制服务！

{sender_name}
{sender_company}`,
          style: '正式',
          is_default: true,
        },
        {
          user_id: user.id,
          name: '合作邀请函',
          category: '合作邀请',
          subject: '诚邀合作 - 共创双赢',
          content: `尊敬的{contact_name}：

您好！

我们诚挚邀请贵司成为我们的合作伙伴。

作为全屋定制行业的一员，我们深知优质合作对于双方发展的重要性。通过合作，我们可以：
• 共享市场资源
• 优化供应链效率
• 提升品牌影响力
• 实现互利共赢

我们提供多种合作模式：
- 代理分销
- OEM定制
- 项目合作
- 技术支持

期待您的回复，共同探讨合作细节！

{sender_name}
{sender_company}`,
          style: '友好',
          is_default: true,
        },
        {
          user_id: user.id,
          name: '价格咨询回复',
          category: '价格咨询',
          subject: '关于{product_name}的报价说明',
          content: `尊敬的{contact_name}：

您好！

感谢您对我们产品的询价。现回复如下：

【产品信息】
产品名称：{product_name}
规格尺寸：{dimensions}

【报价说明】
标准配置：¥{standard_price}/套
定制升级：¥{custom_price}/套
批量优惠：{discount_info}

【付款方式】
• 预付30%定金
• 生产完成付60%
• 安装验收付10%

【交货周期】
标准产品：15-20个工作日
定制产品：25-35个工作日

如需详细报价单，请联系我们。

{sender_name}
{sender_company}`,
          style: '简洁',
          is_default: true,
        },
        {
          user_id: user.id,
          name: '跟进提醒邮件',
          category: '跟进提醒',
          subject: '期待您的回复 - {project_name}',
          content: `尊敬的{contact_name}：

您好！

距离我们上次沟通已有一段时间，想确认一下{project_name}项目的进展情况。

如果您有任何疑问或需要进一步信息，请随时联系我们：
• 产品详情补充
• 技术方案说明
• 价格调整协商
• 其他支持需求

我们随时准备为您提供协助！

期待您的回复。

{sender_name}
{sender_company}
联系电话：{sender_phone}`,
          style: '友好',
          is_default: true,
        },
      ];

      const { data: insertedData, error: insertError } = await serviceClient
        .from('email_templates')
        .insert(defaultTemplates)
        .select();

      if (insertError) {
        throw insertError;
      }

      return NextResponse.json({ data: insertedData, total: insertedData.length });
    }

    return NextResponse.json({ data, total: data.length });
  } catch (error) {
    console.error('获取邮件模板失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取模板失败' 
    }, { status: 500 });
  }
}

// 创建新邮件模板
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { name, category, subject, content, style } = body;

    if (!name || !category || !subject || !content) {
      return NextResponse.json({ error: '缺少必要字段' }, { status: 400 });
    }

    const serviceClient = getSupabaseServiceRoleClient();
    
    const { data, error } = await serviceClient
      .from('email_templates')
      .insert({
        user_id: user.id,
        name,
        category,
        subject,
        content,
        style: style || '正式',
        is_default: false,
        usage_count: 0,
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    return NextResponse.json({ data });
  } catch (error) {
    console.error('创建邮件模板失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建模板失败' 
    }, { status: 500 });
  }
}