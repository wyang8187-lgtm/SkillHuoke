'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  addSavedLeadTask,
  createSavedLeadTask,
  defaultLeadWizardInput,
  downloadLeadTaskText,
  generateLeadWizardOutput,
  type LeadWizardInput,
  type SavedLeadTask,
} from '@/lib/lead-wizard';
import {
  ArrowRight,
  CheckCircle2,
  ClipboardList,
  Database,
  FileText,
  Mail,
  Search,
  ShieldCheck,
  Sparkles,
  Target,
} from 'lucide-react';

export default function LeadWizardPage() {
  const [form, setForm] = useState<LeadWizardInput>(defaultLeadWizardInput);
  const [lastSavedTask, setLastSavedTask] = useState<SavedLeadTask | null>(null);
  const output = useMemo(() => generateLeadWizardOutput(form), [form]);

  const updateField = <K extends keyof LeadWizardInput>(key: K, value: LeadWizardInput[K]) => {
    setLastSavedTask(null);
    setForm((current) => ({ ...current, [key]: value }));
  };

  const buildCurrentTask = () => createSavedLeadTask(form, output);

  const handleSaveTask = () => {
    const task = buildCurrentTask();
    addSavedLeadTask(task);
    setLastSavedTask(task);
  };

  const handleExportCurrentTask = () => {
    downloadLeadTaskText(buildCurrentTask());
  };

  const workflowLinks = [
    { title: '智能搜索', href: '/acquisition/search', icon: Search, description: '把关键词复制过去，开始测试搜索结果。' },
    { title: '任务记录', href: '/lead-tasks', icon: ClipboardList, description: '查看已保存任务，更新状态并导出方案。' },
    { title: '线索池', href: '/leads', icon: Database, description: '沉淀候选客户，过滤低质量结果。' },
    { title: '客户列表', href: '/customers/list', icon: ClipboardList, description: '核验真实客户并进入 CRM。' },
    { title: '邮件营销', href: '/marketing/email', icon: Mail, description: '生成英文开发信和二次跟进模板。' },
  ];

  return (
    <MainLayout title="获客任务向导">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.17.0</Badge>
            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">可填写获客任务</Badge>
          </div>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">输入目标，生成获客执行方案</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                填写产品、国家、客户类型和数量，系统会自动生成搜索关键词、推荐渠道、核验规则、优先级逻辑和开发动作。当前版本先在前端生成方案，下一版可以接入后端任务队列。
              </p>
            </div>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/acquisition/search">
                去智能搜索
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="grid gap-4 xl:grid-cols-[420px_1fr]">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <Target className="h-5 w-5 text-blue-300" />
                任务输入
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#cbd5e1]">产品</label>
                <Textarea
                  value={form.product}
                  onChange={(event) => updateField('product', event.target.value)}
                  className="min-h-24 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                  placeholder="例如：全屋定制、橱柜、衣柜、木门、家具出口"
                />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-[#cbd5e1]">目标国家</label>
                <Input
                  value={form.country}
                  onChange={(event) => updateField('country', event.target.value)}
                  className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                  placeholder="Australia"
                />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-[#cbd5e1]">客户类型</label>
                <Textarea
                  value={form.customerType}
                  onChange={(event) => updateField('customerType', event.target.value)}
                  className="min-h-20 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                  placeholder="Builder + Designer + Kitchen Company + Importer"
                />
              </div>
              <div>
                <label className="mb-2 block text-sm font-medium text-[#cbd5e1]">目标数量</label>
                <Input
                  type="number"
                  min={1}
                  max={500}
                  value={form.quantity}
                  onChange={(event) => updateField('quantity', Number(event.target.value))}
                  className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                />
              </div>
              <Button
                type="button"
                variant="outline"
                className="w-full border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]"
                onClick={() => {
                  setForm(defaultLeadWizardInput);
                  setLastSavedTask(null);
                }}
              >
                恢复默认示例
              </Button>
              <Button type="button" className="w-full bg-blue-600 text-white hover:bg-blue-500" onClick={handleSaveTask}>
                保存为获客任务
              </Button>
              <Button
                type="button"
                variant="outline"
                className="w-full border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]"
                onClick={handleExportCurrentTask}
              >
                导出当前方案 TXT
              </Button>
              {lastSavedTask && (
                <div className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 p-3 text-sm leading-6 text-emerald-200">
                  已保存：{lastSavedTask.title}
                  <Link href="/lead-tasks" className="ml-2 text-emerald-100 underline underline-offset-4">
                    查看任务记录
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-4">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                  <Sparkles className="h-5 w-5 text-emerald-300" />
                  自动生成搜索关键词
                </CardTitle>
              </CardHeader>
              <CardContent className="grid gap-3 md:grid-cols-2">
                {output.keywords.map((keyword) => (
                  <div key={keyword} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3 text-sm leading-6 text-[#cbd5e1]">
                    {keyword}
                  </div>
                ))}
              </CardContent>
            </Card>

            <section className="grid gap-4 lg:grid-cols-2">
              <Card className="border-[#2d3548] bg-[#121823]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                    <Search className="h-5 w-5 text-blue-300" />
                    推荐渠道
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {output.channels.map((channel) => (
                    <div key={channel} className="flex gap-3 rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                      <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-300" />
                      <p className="text-sm leading-6 text-[#cbd5e1]">{channel}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              <Card className="border-[#2d3548] bg-[#121823]">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                    <ShieldCheck className="h-5 w-5 text-amber-300" />
                    核验规则
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {output.verificationRules.map((rule) => (
                    <div key={rule} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3 text-sm leading-6 text-[#cbd5e1]">
                      {rule}
                    </div>
                  ))}
                </CardContent>
              </Card>
            </section>
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-2">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <FileText className="h-5 w-5 text-violet-300" />
                开发动作建议
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {output.outreachActions.map((action) => (
                <div key={action} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3 text-sm leading-6 text-[#cbd5e1]">
                  {action}
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <ClipboardList className="h-5 w-5 text-emerald-300" />
                优先级逻辑
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {output.priorityLogic.map((item) => (
                <div key={item} className="flex gap-3 rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-300" />
                  <p className="text-sm leading-6 text-[#cbd5e1]">{item}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc]">下一步进入哪个模块？</CardTitle>
          </CardHeader>
          <CardContent className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
            {workflowLinks.map((item) => {
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4 transition hover:border-blue-500/50">
                  <div className="flex items-center justify-between">
                    <Icon className="h-5 w-5 text-blue-300" />
                    <ArrowRight className="h-4 w-4 text-[#64748b]" />
                  </div>
                  <h3 className="mt-4 font-medium text-[#f8fafc]">{item.title}</h3>
                  <p className="mt-2 text-sm leading-6 text-[#94a3b8]">{item.description}</p>
                </Link>
              );
            })}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
