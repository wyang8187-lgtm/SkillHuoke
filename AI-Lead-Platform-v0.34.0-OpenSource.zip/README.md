# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进、报价、订单、单据、出货、邮件发送和接口诊断。

当前版本：`v0.34.0`

## v0.34.0 更新

- 新增 `/settings/api-keys` 接口配置与连接诊断中心。
- 支持 OpenAI、DeepSeek、Google Custom Search、SerpAPI、Bing Search、Resend 和 Supabase 配置检测。
- 前端不再输入、保存或显示完整密钥，只展示服务器 `.env` 的掩码摘要和缺失字段。
- 新增 `/api/integrations/status` 与 `/api/integrations/test`，后端只允许测试内置服务，避免前端传入任意 URL。
- 支持单项测试和一键检测全部，返回中文错误分类、延迟、HTTP 状态和下一步建议。
- 增加代理诊断，显示 `SKILLHUOKE_PROXY`、`HTTPS_PROXY`、`HTTP_PROXY` 等变量的安全摘要。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

进入后点击“演示模式进入工作台”。

## 接口配置方式

1. 复制 `.env.example` 为 `.env`。
2. 在 `.env` 填写需要接入的服务密钥。
3. 保存后重启后端服务。
4. 打开 `http://127.0.0.1:5000/settings/api-keys` 检测配置和连接状态。

重要说明：不要把真实 API Key 提交到 GitHub。上传开源包时只保留 `.env.example`，不要上传 `.env` 或 `.env.local`。

## 主要页面

- 登录页：`/login`
- 版本体验中心：`/release`
- 接口诊断中心：`/settings/api-keys`
- 获客任务向导：`/lead-wizard`
- 候选客户池：`/candidate-leads`
- CRM 客户池：`/crm-customers`
- 邮件中心：`/email-center`

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 开源协议

MIT
