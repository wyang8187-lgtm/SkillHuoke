'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { calculateOrderPayments, loadSavedCrmOrders, orderStatusOptions } from '@/lib/crm-orders';
import { ArrowRight, PackageCheck } from 'lucide-react';

export default function OrdersPage() {
  const [orders] = useState(() => loadSavedCrmOrders());
  const [loadedAt] = useState(() => Date.now());
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('all');
  const [currency, setCurrency] = useState('all');
  const currencies = Array.from(new Set(orders.map((item) => item.currency)));
  const filtered = useMemo(() => orders.filter((order) => {
    const text = `${order.number} ${order.customerName} ${order.quotationNumber}`.toLowerCase();
    return text.includes(query.trim().toLowerCase()) && (status === 'all' || order.status === status) && (currency === 'all' || order.currency === currency);
  }), [orders, query, status, currency]);
  const totals = orders.reduce((result, order) => {
    const payment = calculateOrderPayments(order.total, order.depositPercent, order.depositReceived, order.balanceReceived);
    result.total += order.total; result.received += payment.received; result.outstanding += payment.outstanding;
    if (order.expectedDeliveryDate) { const days = (Date.parse(order.expectedDeliveryDate) - loadedAt) / 86400000; if (days >= 0 && days <= 14 && order.status !== 'delivered' && order.status !== 'cancelled') result.due += 1; }
    return result;
  }, { total: 0, received: 0, outstanding: 0, due: 0 });

  return (
    <MainLayout title="订单管理">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6"><div className="flex items-center gap-2 text-sm text-blue-300"><PackageCheck className="h-4 w-4" />v0.30.0 订单管理中心</div><h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">从定金到交付，全程跟踪外贸订单</h2><p className="mt-2 text-sm text-[#94a3b8]">已接受报价可转换为订单，订单保存独立快照，不受后续报价修改影响。</p></section>
        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">{[['订单总额', totals.total], ['已收金额', totals.received], ['未收金额', totals.outstanding], ['14 天内交付', totals.due]].map(([label, value]) => <Card key={label} className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">{label}</p><p className="mt-2 text-2xl font-semibold text-blue-300">{label === '14 天内交付' ? value : Number(value).toFixed(2)}</p></CardContent></Card>)}</section>
        <section className="grid gap-3 md:grid-cols-3"><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索订单、客户或报价编号" className="border-[#2d3548] bg-[#121823] text-[#f8fafc]" /><Select value={status} onValueChange={setStatus}><SelectTrigger className="border-[#2d3548] bg-[#121823] text-[#f8fafc]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">全部状态</SelectItem>{orderStatusOptions.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select><Select value={currency} onValueChange={setCurrency}><SelectTrigger className="border-[#2d3548] bg-[#121823] text-[#f8fafc]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="all">全部币种</SelectItem>{currencies.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></section>
        {filtered.length === 0 ? <div className="rounded-lg border border-dashed border-[#2d3548] bg-[#121823] p-12 text-center"><PackageCheck className="mx-auto h-10 w-10 text-[#64748b]" /><h3 className="mt-4 font-semibold text-[#f8fafc]">暂无符合条件的订单</h3><p className="mt-2 text-sm text-[#94a3b8]">先将一张已接受报价转为订单。</p><Button asChild className="mt-5"><Link href="/crm-quotations">前往报价单</Link></Button></div> : <div className="space-y-3">{filtered.map((order) => { const payment = calculateOrderPayments(order.total, order.depositPercent, order.depositReceived, order.balanceReceived); return <article key={order.id} className="grid gap-4 rounded-lg border border-[#2d3548] bg-[#121823] p-5 md:grid-cols-[1.2fr_1fr_1fr_auto] md:items-center"><div><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold text-[#f8fafc]">{order.number}</h3><Badge className="bg-emerald-500/15 text-emerald-300">{orderStatusOptions.find((item) => item.value === order.status)?.label}</Badge></div><p className="mt-1 text-sm text-[#94a3b8]">{order.customerName || '客户已删除'} · {order.quotationNumber}</p></div><div><p className="text-xs text-[#64748b]">订单金额</p><p className="mt-1 font-semibold text-blue-300">{order.currency} {order.total.toFixed(2)}</p></div><div><p className="text-xs text-[#64748b]">收款进度</p><p className="mt-1 text-sm text-[#cbd5e1]">已收 {payment.received.toFixed(2)} / 未收 {payment.outstanding.toFixed(2)}</p><p className="mt-1 text-xs text-[#64748b]">预计交付：{order.expectedDeliveryDate || '未设置'}</p></div><Button asChild size="sm"><Link href={`/crm-orders/${order.id}`}>查看<ArrowRight className="ml-2 h-4 w-4" /></Link></Button></article>; })}</div>}
      </div>
    </MainLayout>
  );
}
