import { NextRequest, NextResponse } from 'next/server';

// 测试API密钥连接
export async function POST(request: NextRequest) {
  try {
    const { keyId, value } = await request.json();

    if (!keyId || !value) {
      return NextResponse.json({ success: false, error: '缺少参数' }, { status: 400 });
    }

    // 根据不同密钥类型进行测试
    let testResult = false;
    let message = '';

    switch (keyId) {
      case 'deepseek':
        testResult = await testDeepSeekKey(value);
        message = testResult ? 'DeepSeek API连接成功' : 'DeepSeek API连接失败，请检查密钥';
        break;

      case 'openai':
        testResult = await testOpenAIKey(value);
        message = testResult ? 'OpenAI API连接成功' : 'OpenAI API连接失败，请检查密钥';
        break;

      case 'smtp_host':
      case 'smtp_port':
      case 'smtp_user':
      case 'smtp_password':
        // SMTP需要组合测试，这里暂时跳过单个测试
        testResult = true;
        message = 'SMTP配置已保存，请确保所有SMTP字段都已填写';
        break;

      case 'whatsapp':
        testResult = await testWhatsAppKey(value);
        message = testResult ? 'WhatsApp Business API连接成功' : 'WhatsApp API连接失败';
        break;

      case 'linkedin':
        testResult = await testLinkedInKey(value);
        message = testResult ? 'LinkedIn API连接成功' : 'LinkedIn API连接失败';
        break;

      default:
        testResult = true;
        message = '密钥已保存';
    }

    return NextResponse.json({
      success: testResult,
      message
    });
  } catch (error) {
    console.error('测试API密钥错误:', error);
    return NextResponse.json({ success: false, error: '测试失败' }, { status: 500 });
  }
}

// 测试DeepSeek API
async function testDeepSeekKey(apiKey: string): Promise<boolean> {
  try {
    const res = await fetch('https://api.deepseek.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'deepseek-chat',
        messages: [{ role: 'user', content: 'test' }],
        max_tokens: 10
      })
    });

    return res.ok;
  } catch {
    return false;
  }
}

// 测试OpenAI API
async function testOpenAIKey(apiKey: string): Promise<boolean> {
  try {
    const res = await fetch('https://api.openai.com/v1/models', {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    return res.ok;
  } catch {
    return false;
  }
}

// 测试WhatsApp Business API
async function testWhatsAppKey(token: string): Promise<boolean> {
  try {
    // WhatsApp Business API验证
    const res = await fetch(`https://graph.facebook.com/v17.0/me?access_token=${token}`);
    const data = await res.json();
    return data.id !== undefined;
  } catch {
    return false;
  }
}

// 测试LinkedIn API
async function testLinkedInKey(apiKey: string): Promise<boolean> {
  try {
    // LinkedIn API验证（简化版）
    // 实际需要完整的OAuth流程
    return apiKey.length > 10;
  } catch {
    return false;
  }
}