'use client';

import { MainLayout } from '@/components/layout';
import { CustomerEditorForm } from '@/components/crm/customer-editor-form';

export default function NewCrmCustomerPage() {
  return <MainLayout title="新建客户"><CustomerEditorForm /></MainLayout>;
}
