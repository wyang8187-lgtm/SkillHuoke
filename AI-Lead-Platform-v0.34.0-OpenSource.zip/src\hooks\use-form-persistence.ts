'use client';

import { useState, useEffect, useCallback } from 'react';

/**
 * 表单状态持久化 Hook
 * 用于在保存失败时保留已填内容，避免数据丢失
 */

interface UseFormPersistenceOptions {
  key: string; // localStorage key
  initialData?: Record<string, string>; // 初始数据
  expireTime?: number; // 过期时间（毫秒），默认24小时
}

interface FormPersistenceResult {
  formData: Record<string, string>;
  setFormData: (data: Record<string, string>) => void;
  updateField: (field: string, value: string) => void;
  clearFormData: () => void;
  saveToStorage: () => void;
  loadFromStorage: () => boolean;
  hasSavedData: boolean;
}

export function useFormPersistence(options: UseFormPersistenceOptions): FormPersistenceResult {
  const { key, initialData = {}, expireTime = 24 * 60 * 60 * 1000 } = options;

  const [formData, setFormDataState] = useState<Record<string, string>>(initialData);
  const [hasSavedData, setHasSavedData] = useState(false);

  // 加载已保存的数据
  const loadFromStorage = useCallback(() => {
    try {
      const stored = localStorage.getItem(key);
      if (!stored) return false;

      const parsed = JSON.parse(stored);
      
      // 检查是否过期
      if (parsed.timestamp && Date.now() - parsed.timestamp > expireTime) {
        localStorage.removeItem(key);
        return false;
      }

      if (parsed.data) {
        setFormDataState(parsed.data);
        setHasSavedData(true);
        return true;
      }
    } catch (e) {
      console.error('加载表单数据失败:', e);
      localStorage.removeItem(key);
    }
    return false;
  }, [key, expireTime]);

  // 初始化时尝试加载
  useEffect(() => {
    // 只有当没有初始数据时才尝试加载保存的数据
    if (Object.keys(initialData).length === 0) {
      loadFromStorage();
    }
  }, [key]); // 仅依赖key，避免重复加载

  // 保存到localStorage
  const saveToStorage = useCallback(() => {
    try {
      const toStore = {
        data: formData,
        timestamp: Date.now(),
      };
      localStorage.setItem(key, JSON.stringify(toStore));
      setHasSavedData(true);
    } catch (e) {
      console.error('保存表单数据失败:', e);
    }
  }, [key, formData]);

  // 更新表单数据
  const setFormData = useCallback((data: Record<string, string>) => {
    setFormDataState(data);
  }, []);

  // 更新单个字段
  const updateField = useCallback((field: string, value: string) => {
    setFormDataState((prev) => ({
      ...prev,
      [field]: value,
    }));
  }, []);

  // 清除保存的数据
  const clearFormData = useCallback(() => {
    setFormDataState(initialData);
    localStorage.removeItem(key);
    setHasSavedData(false);
  }, [key, initialData]);

  // 自动保存（每次formData变化时）
  useEffect(() => {
    // 有数据时自动保存
    if (Object.keys(formData).length > 0) {
      saveToStorage();
    }
  }, [formData, saveToStorage]);

  return {
    formData,
    setFormData,
    updateField,
    clearFormData,
    saveToStorage,
    loadFromStorage,
    hasSavedData,
  };
}

/**
 * 带校验的表单持久化 Hook
 */
interface ValidatedFormResult extends FormPersistenceResult {
  errors: Record<string, string>;
  validateField: (field: string, validator: (value: string) => { valid: boolean; message?: string }) => boolean;
  validateAll: (validators: Record<string, (value: string) => { valid: boolean; message?: string }>) => boolean;
  clearErrors: () => void;
  hasErrors: boolean;
}

export function useValidatedFormPersistence(
  options: UseFormPersistenceOptions
): ValidatedFormResult {
  const baseResult = useFormPersistence(options);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateField = useCallback(
    (field: string, validator: (value: string) => { valid: boolean; message?: string }) => {
      const value = baseResult.formData[field] || '';
      const result = validator(value);
      
      if (!result.valid) {
        setErrors((prev) => ({
          ...prev,
          [field]: result.message || '校验失败',
        }));
        return false;
      } else {
        setErrors((prev) => {
          const newErrors = { ...prev };
          delete newErrors[field];
          return newErrors;
        });
        return true;
      }
    },
    [baseResult.formData]
  );

  const validateAll = useCallback(
    (validators: Record<string, (value: string) => { valid: boolean; message?: string }>) => {
      const newErrors: Record<string, string> = {};
      let allValid = true;

      for (const [field, validator] of Object.entries(validators)) {
        const value = baseResult.formData[field] || '';
        const result = validator(value);
        
        if (!result.valid) {
          newErrors[field] = result.message || '校验失败';
          allValid = false;
        }
      }

      setErrors(newErrors);
      return allValid;
    },
    [baseResult.formData]
  );

  const clearErrors = useCallback(() => {
    setErrors({});
  }, []);

  // 保存成功后清除数据时也清除错误
  const enhancedClearFormData = useCallback(() => {
    baseResult.clearFormData();
    clearErrors();
  }, [baseResult.clearFormData, clearErrors]);

  return {
    ...baseResult,
    errors,
    validateField,
    validateAll,
    clearErrors,
    clearFormData: enhancedClearFormData,
    hasErrors: Object.keys(errors).length > 0,
  };
}