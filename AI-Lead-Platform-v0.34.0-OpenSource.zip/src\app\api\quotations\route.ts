import { NextRequest, NextResponse } from 'next/server';

// 模拟报价单数据
const mockQuotations: Array<{
  id: string;
  customerId: string;
  customerName: string;
  items: Array<{ productId: string; productName: string; quantity: number; unit: string; unitPrice: number; amount: number }>;
  totalAmount: number;
  status: string;
  createdAt: string;
  updatedAt: string;
  validUntil: string;
  notes: string;
}> = [
  {
    id: 'Q001',
    customerId: 'C001',
    customerName: '深圳市某某家居有限公司',
    items: [
      { productId: 'P001', productName: '定制衣柜', quantity: 8, unit: '平方米', unitPrice: 800, amount: 6400 },
      { productId: 'P003', productName: '实木门板', quantity: 6, unit: '平方米', unitPrice: 1200, amount: 7200 },
      { productId: 'P007', productName: '进口五金铰链', quantity: 20, unit: '个', unitPrice: 45, amount: 900 },
    ],
    totalAmount: 14500,
    status: '已发送',
    createdAt: '2026-06-15',
    updatedAt: '2026-06-15',
    validUntil: '2026-07-15',
    notes: '客户要求实木材质，含安装服务'
  },
  {
    id: 'Q002',
    customerId: 'C002',
    customerName: '广州某某室内设计公司',
    items: [
      { productId: 'P002', productName: '定制橱柜', quantity: 12, unit: '平方米', unitPrice: 650, amount: 7800 },
      { productId: 'P005', productName: '石英石台面', quantity: 5, unit: '平方米', unitPrice: 1500, amount: 7500 },
      { productId: 'P009', productName: '嵌入式洗碗机', quantity: 1, unit: '台', unitPrice: 3500, amount: 3500 },
    ],
    totalAmount: 18800,
    status: '草稿',
    createdAt: '2026-06-17',
    updatedAt: '2026-06-17',
    validUntil: '2026-07-17',
    notes: '待客户确认设计方案后发送'
  },
  {
    id: 'Q003',
    customerId: 'C003',
    customerName: '佛山某某建材外贸公司',
    items: [
      { productId: 'P011', productName: '定制书柜', quantity: 15, unit: '平方米', unitPrice: 700, amount: 10500 },
      { productId: 'P004', productName: '烤漆门板', quantity: 10, unit: '平方米', unitPrice: 900, amount: 9000 },
    ],
    totalAmount: 19500,
    status: '已确认',
    createdAt: '2026-06-10',
    updatedAt: '2026-06-12',
    validUntil: '2026-07-10',
    notes: '外贸订单，需要出口包装'
  },
];

// GET - 获取报价单列表
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const status = searchParams.get('status');
  const customerId = searchParams.get('customerId');
  const id = searchParams.get('id');

  // 获取单个报价单详情
  if (id) {
    const quotation = mockQuotations.find(q => q.id === id);
    if (!quotation) {
      return NextResponse.json({ error: '报价单不存在' }, { status: 404 });
    }
    return NextResponse.json({ success: true, data: quotation });
  }

  let filteredQuotations = [...mockQuotations];

  // 按状态筛选
  if (status && status !== '全部') {
    filteredQuotations = filteredQuotations.filter(q => q.status === status);
  }

  // 按客户筛选
  if (customerId) {
    filteredQuotations = filteredQuotations.filter(q => q.customerId === customerId);
  }

  return NextResponse.json({
    success: true,
    data: {
      quotations: filteredQuotations,
      total: filteredQuotations.length
    }
  });
}

// POST - 创建报价单
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { customerId, customerName, items, validUntil, notes } = body;

    if (!customerId || !customerName || !items || items.length === 0) {
      return NextResponse.json({ error: '缺少必填字段' }, { status: 400 });
    }

    // 计算总金额
    const totalAmount = items.reduce((sum: number, item: { quantity: number; unitPrice: number }) => 
      sum + item.quantity * item.unitPrice, 0);

    const newQuotation = {
      id: `Q${String(mockQuotations.length + 1).padStart(3, '0')}`,
      customerId,
      customerName,
      items: items.map((item: { productId: string; productName: string; quantity: number; unit: string; unitPrice: number }, index: number) => ({
        ...item,
        amount: item.quantity * item.unitPrice,
        id: `I${index + 1}`
      })),
      totalAmount,
      status: '草稿',
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
      validUntil: validUntil || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      notes: notes || ''
    };

    mockQuotations.push(newQuotation);

    return NextResponse.json({
      success: true,
      data: newQuotation,
      message: '报价单创建成功'
    });
  } catch {
    return NextResponse.json({ error: '请求处理失败' }, { status: 500 });
  }
}

// PUT - 更新报价单
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, ...updates } = body;

    const quotationIndex = mockQuotations.findIndex(q => q.id === id);
    if (quotationIndex === -1) {
      return NextResponse.json({ error: '报价单不存在' }, { status: 404 });
    }

    // 如果更新了明细，重新计算总金额
    if (updates.items) {
      updates.totalAmount = updates.items.reduce((sum: number, item: { quantity: number; unitPrice: number }) => 
        sum + item.quantity * item.unitPrice, 0);
      updates.items = updates.items.map((item: { productId: string; productName: string; quantity: number; unit: string; unitPrice: number }, index: number) => ({
        ...item,
        amount: item.quantity * item.unitPrice,
        id: `I${index + 1}`
      }));
    }

    updates.updatedAt = new Date().toISOString().split('T')[0];

    mockQuotations[quotationIndex] = { ...mockQuotations[quotationIndex], ...updates };

    return NextResponse.json({
      success: true,
      data: mockQuotations[quotationIndex],
      message: '报价单更新成功'
    });
  } catch {
    return NextResponse.json({ error: '请求处理失败' }, { status: 500 });
  }
}

// DELETE - 删除报价单
export async function DELETE(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const id = searchParams.get('id');

  if (!id) {
    return NextResponse.json({ error: '缺少报价单ID' }, { status: 400 });
  }

  const quotationIndex = mockQuotations.findIndex(q => q.id === id);
  if (quotationIndex === -1) {
    return NextResponse.json({ error: '报价单不存在' }, { status: 404 });
  }

  mockQuotations.splice(quotationIndex, 1);

  return NextResponse.json({
    success: true,
    message: '报价单删除成功'
  });
}