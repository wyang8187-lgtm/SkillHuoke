'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  createManualCrmCustomer,
  crmCustomerStatusOptions,
  loadSavedCrmCustomers,
  updateFullSavedCrmCustomer,
  type SavedCrmCustomer,
} from '@/lib/lead-wizard';
import {
  emptyCrmCustomerEditorValue,
  findDuplicateCustomers,
  normalizeWebsite,
  validateCustomerEditor,
  type CrmCustomerEditorValue,
} from '@/lib/crm-customer-editor';
import { AlertTriangle, Save } from 'lucide-react';

export function CustomerEditorForm({ customer }: { customer?: SavedCrmCustomer }) {
  const router = useRouter();
  const [value, setValue] = useState<CrmCustomerEditorValue>(() => customer ? {
    ...emptyCrmCustomerEditorValue, ...customer,
    nextFollowUpAt: customer.nextFollowUpAt || '', contactName: customer.contactName || '',
    contactTitle: customer.contactTitle || '', email: customer.email || '', phone: customer.phone || '',
    whatsapp: customer.whatsapp || '', linkedin: customer.linkedin || '',
    verificationStatus: customer.verificationStatus || 'pending',
  } : emptyCrmCustomerEditorValue);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [duplicates, setDuplicates] = useState<SavedCrmCustomer[]>([]);
  const [allowDuplicate, setAllowDuplicate] = useState(false);

  const patch = <K extends keyof CrmCustomerEditorValue>(key: K, next: CrmCustomerEditorValue[K]) => {
    setValue((current) => ({ ...current, [key]: next }));
    setErrors((current) => ({ ...current, [key]: '' }));
    setAllowDuplicate(false);
  };

  const save = () => {
    const validationErrors = validateCustomerEditor(value);
    setErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) return;
    const matches = findDuplicateCustomers(value, loadSavedCrmCustomers(), customer?.id);
    if (matches.length > 0 && !allowDuplicate) {
      setDuplicates(matches);
      return;
    }

    const normalized = {
      ...value,
      company: value.company.trim(),
      country: value.country.trim(),
      customerType: value.customerType.trim(),
      website: normalizeWebsite(value.website),
      linkedin: normalizeWebsite(value.linkedin),
      contactStatus: value.verificationStatus === 'verified' ? '主要联系人已核验' : value.verificationStatus === 'partial' ? '联系方式部分核验' : '联系方式待核验',
    };
    const saved = customer
      ? updateFullSavedCrmCustomer(customer.id, normalized)
      : createManualCrmCustomer(normalized);
    if (saved) router.push(`/crm-customers/${encodeURIComponent(saved.id)}`);
  };

  const fields: Array<{ key: keyof CrmCustomerEditorValue; label: string; required?: boolean; type?: string; placeholder?: string }> = [
    { key: 'company', label: '公司名称', required: true },
    { key: 'website', label: '公司官网', placeholder: 'www.example.com' },
    { key: 'country', label: '国家', required: true },
    { key: 'city', label: '城市' },
    { key: 'customerType', label: '客户类型', required: true, placeholder: 'Builder / Designer / Kitchen Company / Importer' },
    { key: 'contactName', label: '联系人姓名' },
    { key: 'contactTitle', label: '联系人职位' },
    { key: 'email', label: '邮箱', type: 'email' },
    { key: 'phone', label: '电话' },
    { key: 'whatsapp', label: 'WhatsApp' },
    { key: 'linkedin', label: 'LinkedIn', placeholder: 'https://linkedin.com/in/...' },
  ];

  return (
    <div className="space-y-6">
      <Card className="border-[#2d3548] bg-[#121823]">
        <CardHeader><CardTitle className="text-[#f8fafc]">公司与主要联系人</CardTitle></CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          {fields.map((field) => (
            <div key={field.key}>
              <label className="mb-2 block text-sm text-[#cbd5e1]">{field.label}{field.required ? ' *' : ''}</label>
              <Input type={field.type || 'text'} value={String(value[field.key] ?? '')} placeholder={field.placeholder} onChange={(event) => patch(field.key, event.target.value as never)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" />
              {errors[field.key] ? <p className="mt-1 text-xs text-red-300">{errors[field.key]}</p> : null}
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="border-[#2d3548] bg-[#121823]">
        <CardHeader><CardTitle className="text-[#f8fafc]">CRM 设置</CardTitle></CardHeader>
        <CardContent className="grid gap-4 md:grid-cols-2">
          <Select value={value.status} onValueChange={(next) => patch('status', next as CrmCustomerEditorValue['status'])}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger><SelectContent>{crmCustomerStatusOptions.map((item) => <SelectItem key={item.value} value={item.value}>{item.label}</SelectItem>)}</SelectContent></Select>
          <Select value={value.priority} onValueChange={(next) => patch('priority', next as 'A' | 'B' | 'C')}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="A">A 级</SelectItem><SelectItem value="B">B 级</SelectItem><SelectItem value="C">C 级</SelectItem></SelectContent></Select>
          <div><label className="mb-2 block text-sm text-[#cbd5e1]">评分</label><Input type="number" min={0} max={100} value={value.score} onChange={(event) => patch('score', Number(event.target.value))} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" />{errors.score ? <p className="mt-1 text-xs text-red-300">{errors.score}</p> : null}</div>
          <div><label className="mb-2 block text-sm text-[#cbd5e1]">核验状态</label><Select value={value.verificationStatus} onValueChange={(next) => patch('verificationStatus', next as CrmCustomerEditorValue['verificationStatus'])}><SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="pending">待核验</SelectItem><SelectItem value="partial">部分核验</SelectItem><SelectItem value="verified">已核验</SelectItem></SelectContent></Select></div>
          <div><label className="mb-2 block text-sm text-[#cbd5e1]">下次跟进时间</label><Input type="datetime-local" value={value.nextFollowUpAt} onChange={(event) => patch('nextFollowUpAt', event.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
          <div className="md:col-span-2"><label className="mb-2 block text-sm text-[#cbd5e1]">下一步动作</label><Textarea value={value.nextAction} onChange={(event) => patch('nextAction', event.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
          <div className="md:col-span-2"><label className="mb-2 block text-sm text-[#cbd5e1]">客户备注</label><Textarea value={value.note} onChange={(event) => patch('note', event.target.value)} className="min-h-24 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" /></div>
        </CardContent>
      </Card>

      {duplicates.length > 0 && !allowDuplicate ? (
        <div className="rounded-lg border border-amber-500/25 bg-amber-500/10 p-4">
          <p className="flex items-center gap-2 font-medium text-amber-200"><AlertTriangle className="h-4 w-4" />发现可能重复客户</p>
          {duplicates.map((item) => <Link key={item.id} href={`/crm-customers/${encodeURIComponent(item.id)}`} className="mt-2 block text-sm text-blue-300">{item.company} · {item.country}</Link>)}
          <Button type="button" size="sm" variant="outline" className="mt-3 border-amber-500/25 text-amber-200" onClick={() => setAllowDuplicate(true)}>仍然创建/保存</Button>
        </div>
      ) : null}

      <div className="flex flex-wrap gap-3">
        <Button type="button" onClick={save} className="bg-blue-600 text-white hover:bg-blue-500"><Save className="mr-2 h-4 w-4" />{customer ? '保存修改' : '创建客户'}</Button>
        <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1]"><Link href={customer ? `/crm-customers/${encodeURIComponent(customer.id)}` : '/crm-customers'}>取消</Link></Button>
      </div>
    </div>
  );
}
