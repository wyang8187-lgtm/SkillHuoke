# v0.24.0 Data Backup and Restore Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add safe local export, import, merge, overwrite, and undo for SkillHuoke business data.

**Architecture:** Create a focused backup module that reads and writes only the four approved storage domains. The page handles file selection and user confirmation, while parsing, validation, deduplication, CSV generation, and restore-point logic remain pure reusable helpers.

**Tech Stack:** Next.js 16, React 19, TypeScript, localStorage, JSON, CSV, browser Blob downloads.

---

### Task 1: Build backup domain module

**Files:**
- Create: `src/lib/data-backup.ts`

- [ ] Define versioned backup, summary, preview, and restore mode types.
- [ ] Build backup payload from approved task, candidate, customer, and follow-up loaders.
- [ ] Validate format, version, arrays, and file size.
- [ ] Implement merge-by-ID with updated-time conflict resolution.
- [ ] Implement overwrite restore, local restore point, and undo.
- [ ] Generate UTF-8 BOM CRM CSV with Chinese headers.

### Task 2: Build backup center page

**Files:**
- Create: `src/app/data-backup/page.tsx`

- [ ] Show current counts and last backup time.
- [ ] Download full JSON and CRM CSV.
- [ ] Select and preview JSON without writing.
- [ ] Show imported counts and merge comparison.
- [ ] Confirm merge, overwrite, and undo actions.
- [ ] Display success and error feedback.

### Task 3: Add navigation and release metadata

**Files:**
- Modify: `src/components/layout/sidebar.tsx`
- Modify: `src/lib/release-experience.ts`
- Modify: `package.json`
- Modify: `README.md`

- [ ] Add data backup navigation entry.
- [ ] Set v0.24.0 package name and GitHub remark.
- [ ] Document backup scope and sensitive-data exclusions.

### Task 4: Verify and package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.24.0-OpenSource.zip`

- [ ] Run TypeScript, ESLint, and production build.
- [ ] Verify login, backup center, CRM, and release pages.
- [ ] Inspect generated package manifest.
- [ ] Confirm package excludes environment files and generated directories.
