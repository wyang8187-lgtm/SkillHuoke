// 任务管理 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取任务列表
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status') || undefined;
    const customerId = searchParams.get('customerId') || undefined;
    const type = searchParams.get('type') || undefined;
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '20');

    const result = await dbService.getTasks(user.id, {
      status,
      customer_id: customerId,
      type,
    }, page, pageSize);

    const tasks = result.data;

    // 统计各状态任务数量
    const statusStats: Record<string, number> = {
      '待完成': 0,
      '已完成': 0,
      '已过期': 0,
    };

    tasks.forEach((task: dbService.TaskDB) => {
      if (statusStats[task.status] !== undefined) {
        statusStats[task.status]++;
      }
    });

    // 转换为前端格式
    const formattedTasks = tasks.map(task => ({
      id: task.id,
      title: task.title,
      status: task.status,
      due_time: task.due_time || null,
      create_time: task.created_at,
      user_id: task.user_id,
    }));

    return NextResponse.json({
      tasks: formattedTasks,
      total: result.total,
      stats: statusStats,
    });
  } catch (error) {
    console.error('获取任务列表失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取任务列表失败' 
    }, { status: 500 });
  }
}

// 创建任务
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    
    // 验证必填字段
    if (!body.title) {
      return NextResponse.json({ error: '请输入任务标题' }, { status: 400 });
    }

    const task = await dbService.createTask(user.id, {
      title: body.title,
      customer_id: body.customer_id || undefined,
      type: body.type || '跟进客户',
      status: '待完成',
      priority: '中',
      due_time: body.due_time || undefined,
      description: body.description || '',
    });

    return NextResponse.json({
      success: true,
      data: task,
      message: '任务创建成功',
    });
  } catch (error) {
    console.error('创建任务失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '创建任务失败' 
    }, { status: 500 });
  }
}