import { NextRequest, NextResponse } from 'next/server';

// TikTok获客模拟API
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyword, category } = body;

    if (!keyword) {
      return NextResponse.json({ error: '请输入搜索关键词' }, { status: 400 });
    }

    // 模拟TikTok账号搜索结果
    const mockResults = [
      {
        id: 'tt_001',
        type: 'account',
        name: '家居设计师张伟',
        username: '@zhangwei_design',
        category: category || '家居设计',
        followers: 50000,
        videos: 120,
        likes: 800000,
        location: '深圳',
        phone: '13912345678',
        email: 'zhangwei@design.com',
        description: '分享全屋定制设计案例，15年行业经验',
        verified: true,
        profile_url: 'https://tiktok.com/@zhangwei_design',
      },
      {
        id: 'tt_002',
        type: 'account',
        name: '广州建材商城',
        username: '@gz_material',
        category: '建材零售',
        followers: 25000,
        videos: 80,
        likes: 350000,
        location: '广州',
        phone: '13812345679',
        email: 'sales@gz-material.com',
        description: '建材选购指南，装修避坑分享',
        verified: true,
        profile_url: 'https://tiktok.com/@gz_material',
      },
      {
        id: 'tt_003',
        type: 'account',
        name: '佛山家具工厂',
        username: '@foshan_factory',
        category: '家具制造',
        followers: 10000,
        videos: 50,
        likes: 150000,
        location: '佛山',
        phone: '13712345680',
        email: 'factory@foshan.com',
        description: '工厂直供，家具定制源头',
        verified: true,
        profile_url: 'https://tiktok.com/@foshan_factory',
      },
      {
        id: 'tt_004',
        type: 'account',
        name: '东莞装修日记',
        username: '@dg_renovation',
        category: '装修分享',
        followers: 30000,
        videos: 100,
        likes: 500000,
        location: '东莞',
        phone: '13612345681',
        email: 'info@dg-renovation.com',
        description: '真实装修案例分享，避坑指南',
        verified: true,
        profile_url: 'https://tiktok.com/@dg_renovation',
      },
      {
        id: 'tt_005',
        type: 'account',
        name: '全屋定制案例',
        username: '@custom_home',
        category: '全屋定制',
        followers: 80000,
        videos: 200,
        likes: 1200000,
        location: '大湾区',
        phone: '13512345682',
        email: 'contact@custom-home.com',
        description: '大湾区全屋定制案例精选',
        verified: true,
        profile_url: 'https://tiktok.com/@custom_home',
      },
    ];

    // 根据关键词过滤
    const filteredResults = mockResults.filter(result => {
      const searchText = `${result.name} ${result.username} ${result.category} ${result.location} ${result.description}`.toLowerCase();
      return searchText.includes(keyword.toLowerCase());
    });

    // 过滤无手机号的结果
    const validResults = filteredResults.filter(r => r.phone && r.phone.length === 11);

    return NextResponse.json({
      success: true,
      data: validResults.length > 0 ? validResults : mockResults.filter(r => r.phone && r.phone.length === 11),
      total: validResults.length > 0 ? validResults.length : mockResults.filter(r => r.phone && r.phone.length === 11).length,
      platform: 'TikTok',
      note: '当前为模拟数据，接入真实API后可获取实时TikTok数据',
    });
  } catch (error) {
    console.error('TikTok搜索失败:', error);
    return NextResponse.json({ error: '搜索失败，请稍后重试' }, { status: 500 });
  }
}