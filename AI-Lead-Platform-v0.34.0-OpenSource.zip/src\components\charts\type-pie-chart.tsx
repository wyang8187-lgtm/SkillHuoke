'use client';

import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts';

interface TypeData {
  name: string;
  value: number;
  color: string;
}

interface TypePieChartProps {
  data: TypeData[];
  title?: string;
}

const COLORS = ['#3b82f6', '#f97316', '#22c55e', '#6b7280'];

export function TypePieChart({ data, title = '客户类型分布' }: TypePieChartProps) {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  
  const renderLabel = (entry: TypeData) => {
    const percentage = ((entry.value / total) * 100).toFixed(1);
    return `${entry.name}: ${percentage}%`;
  };

  return (
    <div className="bg-[#1a1f2c] rounded-lg p-4 border border-[#2d3548]">
      <h3 className="text-base font-semibold text-[#f8fafc] mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height={260}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={50}
            outerRadius={80}
            paddingAngle={2}
            dataKey="value"
            label={renderLabel}
            labelLine={{ stroke: '#64748b', strokeWidth: 1 }}
          >
            {data.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={entry.color || COLORS[index % COLORS.length]} 
                stroke="#1a1f2c"
                strokeWidth={2}
              />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              backgroundColor: '#1a1f2c',
              border: '1px solid #2d3548',
              borderRadius: '8px',
              color: '#f8fafc',
            }}
            formatter={(value: number) => [`${value} 家`, '数量']}
          />
          <Legend 
            wrapperStyle={{ paddingTop: '10px' }}
            formatter={(value) => <span style={{ color: '#94a3b8' }}>{value}</span>}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}