'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { User, Mail, Phone, Lock, Bell, Save, Loader2, CheckCircle } from 'lucide-react';

export default function PersonalSettingsPage() {
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(false);
  
  // 个人信息表单
  const [profile, setProfile] = useState({
    name: '张三',
    phone: '13800138000',
    email: 'zhangsan@example.com',
    avatar: ''
  });

  // 密码修改
  const [password, setPassword] = useState({
    current: '',
    new: '',
    confirm: ''
  });

  // 通知偏好
  const [notifications, setNotifications] = useState({
    emailFollowUp: true,
    emailOpportunityChange: true,
    emailPoolClaim: true,
    pushFollowUp: true,
    pushOpportunityChange: false,
    pushPoolClaim: true
  });

  // 保存个人信息
  const handleSaveProfile = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setSaved(true);
    } finally {
      setLoading(false);
    }
  };

  // 修改密码
  const handleChangePassword = async () => {
    if (password.new !== password.confirm) {
      alert('两次输入的密码不一致');
      return;
    }
    
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setPassword({ current: '', new: '', confirm: '' });
      setSaved(true);
    } finally {
      setLoading(false);
    }
  };

  // 保存通知偏好
  const handleSaveNotifications = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setSaved(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold flex items-center gap-2">
        <User className="w-6 h-6" />
        个人设置
      </h1>

      {/* 基本信息 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            基本信息
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name">姓名</Label>
              <Input
                id="name"
                value={profile.name}
                onChange={(e) => setProfile({ ...profile, name: e.target.value })}
                placeholder="请输入姓名"
              />
            </div>
            <div>
              <Label htmlFor="phone">手机号</Label>
              <Input
                id="phone"
                value={profile.phone}
                onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
                placeholder="请输入手机号"
              />
            </div>
            <div>
              <Label htmlFor="email">邮箱</Label>
              <Input
                id="email"
                type="email"
                value={profile.email}
                onChange={(e) => setProfile({ ...profile, email: e.target.value })}
                placeholder="请输入邮箱"
              />
            </div>
            <div>
              <Label>头像</Label>
              <Button variant="outline" className="w-full">
                上传头像
              </Button>
            </div>
          </div>
          <div className="flex justify-end">
            <Button onClick={handleSaveProfile} disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
              保存修改
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 密码修改 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="w-5 h-5" />
            密码修改
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="current-password">当前密码</Label>
              <Input
                id="current-password"
                type="password"
                value={password.current}
                onChange={(e) => setPassword({ ...password, current: e.target.value })}
                placeholder="请输入当前密码"
              />
            </div>
            <div>
              <Label htmlFor="new-password">新密码</Label>
              <Input
                id="new-password"
                type="password"
                value={password.new}
                onChange={(e) => setPassword({ ...password, new: e.target.value })}
                placeholder="请输入新密码"
              />
            </div>
            <div>
              <Label htmlFor="confirm-password">确认新密码</Label>
              <Input
                id="confirm-password"
                type="password"
                value={password.confirm}
                onChange={(e) => setPassword({ ...password, confirm: e.target.value })}
                placeholder="请再次输入新密码"
              />
            </div>
          </div>
          <div className="flex justify-end">
            <Button onClick={handleChangePassword} disabled={loading || !password.current || !password.new}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Lock className="w-4 h-4 mr-2" />}
              修改密码
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 通知偏好 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            通知偏好设置
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-b pb-4">
              <h3 className="font-medium mb-3 flex items-center gap-2">
                <Mail className="w-4 h-4" />
                邮件通知
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">跟进提醒</div>
                    <div className="text-sm text-muted-foreground">客户跟进时间到期前提醒</div>
                  </div>
                  <Switch
                    checked={notifications.emailFollowUp}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, emailFollowUp: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">商机状态变更</div>
                    <div className="text-sm text-muted-foreground">商机阶段变更时通知</div>
                  </div>
                  <Switch
                    checked={notifications.emailOpportunityChange}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, emailOpportunityChange: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">公海池认领</div>
                    <div className="text-sm text-muted-foreground">公海池有新客户可认领时通知</div>
                  </div>
                  <Switch
                    checked={notifications.emailPoolClaim}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, emailPoolClaim: checked })}
                  />
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-medium mb-3 flex items-center gap-2">
                <Bell className="w-4 h-4" />
                推送通知
              </h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">跟进提醒</div>
                    <div className="text-sm text-muted-foreground">实时推送跟进提醒</div>
                  </div>
                  <Switch
                    checked={notifications.pushFollowUp}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, pushFollowUp: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">商机状态变更</div>
                    <div className="text-sm text-muted-foreground">实时推送商机变更</div>
                  </div>
                  <Switch
                    checked={notifications.pushOpportunityChange}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, pushOpportunityChange: checked })}
                  />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">公海池认领</div>
                    <div className="text-sm text-muted-foreground">实时推送公海池认领通知</div>
                  </div>
                  <Switch
                    checked={notifications.pushPoolClaim}
                    onCheckedChange={(checked) => setNotifications({ ...notifications, pushPoolClaim: checked })}
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end mt-4">
            <Button onClick={handleSaveNotifications} disabled={loading}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
              保存设置
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* 保存成功提示 */}
      {saved && (
        <div className="fixed bottom-4 right-4 bg-green-500 text-white px-4 py-2 rounded-lg flex items-center gap-2 shadow-lg">
          <CheckCircle className="w-5 h-5" />
          设置已保存
        </div>
      )}
    </div>
  );
}