// 客户列表 API - GET获取列表, POST创建新客户
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取客户列表（支持筛选、分页）
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  // 获取查询参数
  const { searchParams } = new URL(req.url);
  const filters = {
    keyword: searchParams.get('search') || searchParams.get('keyword') || undefined,
    customer_type: searchParams.get('type') || searchParams.get('customer_type') || undefined,
    grade: searchParams.get('grade') || undefined,
    status: searchParams.get('status') || undefined,
    region: searchParams.get('region') || undefined,
  };
  const page = parseInt(searchParams.get('page') || '1');
  const pageSize = parseInt(searchParams.get('pageSize') || '20');

  try {
    const result = await dbService.getCustomers(user.id, filters, page, pageSize);
    return NextResponse.json({
      success: true,
      data: result.data,
      total: result.total,
      page: result.page,
      pageSize: result.pageSize,
      totalPages: Math.ceil(result.total / result.pageSize)
    });
  } catch (error) {
    console.error('获取客户列表失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '获取客户列表失败' 
    }, { status: 500 });
  }
}

// 创建新客户
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    
    // 验证必填字段
    if (!body.company_name || !body.phone) {
      return NextResponse.json({ 
        success: false, 
        error: '公司名和手机号为必填项' 
      }, { status: 400 });
    }

    const customer = await dbService.createCustomer(user.id, {
      company_name: body.company_name,
      customer_type: body.customer_type || body.type || 'full_designer',
      contact_name: body.contact_name || '',
      phone: body.phone,
      region: body.region || '',
      address: body.address || '',
      source: body.source || 'manual',
      grade: body.grade || 'C',
      status: body.status || 'new',
      tags: body.tags || [],
      notes: body.notes || '',
    });

    return NextResponse.json({ 
      success: true, 
      data: customer,
      message: '客户创建成功'
    });
  } catch (error) {
    console.error('创建客户失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '创建客户失败' 
    }, { status: 400 });
  }
}

// 批量删除客户
export async function DELETE(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { ids } = body;

    if (!ids || !Array.isArray(ids) || ids.length === 0) {
      return NextResponse.json({ 
        success: false, 
        error: '请选择要删除的客户' 
      }, { status: 400 });
    }

    await dbService.batchDeleteCustomers(user.id, ids);

    return NextResponse.json({ 
      success: true, 
      message: `成功删除 ${ids.length} 个客户`
    });
  } catch (error) {
    console.error('批量删除客户失败:', error);
    return NextResponse.json({ 
      success: false, 
      error: error instanceof Error ? error.message : '批量删除失败' 
    }, { status: 500 });
  }
}