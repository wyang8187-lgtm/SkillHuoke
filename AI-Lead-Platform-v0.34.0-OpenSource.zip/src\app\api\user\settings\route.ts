import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseServiceRoleClient } from '@/storage/database/supabase-client';

// 用户设置表结构（使用user_profiles表）
interface UserProfile {
  id: string;
  user_id: string;
  display_name: string | null;
  avatar_url: string | null;
  phone: string | null;
  company_name: string | null;
  position: string | null;
  email_notification: boolean;
  follow_up_reminder_hours: number;
  created_at: string;
  updated_at: string;
}

// GET - 获取用户设置
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const supabase = getSupabaseServiceRoleClient();
    
    // 验证用户身份
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    if (authError || !user) {
      return NextResponse.json({ error: '身份验证失败' }, { status: 401 });
    }

    // 获取用户设置
    const { data: profile, error } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (error && error.code !== 'PGRST116') {
      console.error('Get profile error:', error);
      return NextResponse.json({ error: '获取设置失败' }, { status: 500 });
    }

    // 如果没有profile，返回默认设置
    const defaultSettings: UserProfile = {
      id: '',
      user_id: user.id,
      display_name: user.email?.split('@')[0] || '',
      avatar_url: null,
      phone: null,
      company_name: null,
      position: null,
      email_notification: true,
      follow_up_reminder_hours: 24,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    return NextResponse.json({ 
      settings: profile || defaultSettings,
      email: user.email 
    });
  } catch (error) {
    console.error('Settings API error:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}

// POST - 更新用户设置
export async function POST(request: NextRequest) {
  try {
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const supabase = getSupabaseServiceRoleClient();
    
    // 验证用户身份
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    if (authError || !user) {
      return NextResponse.json({ error: '身份验证失败' }, { status: 401 });
    }

    const body = await request.json();
    const { display_name, avatar_url, phone, company_name, position, email_notification, follow_up_reminder_hours } = body;

    // 检查是否存在profile
    const { data: existingProfile } = await supabase
      .from('user_profiles')
      .select('id')
      .eq('user_id', user.id)
      .single();

    const updateData = {
      user_id: user.id,
      display_name: display_name || null,
      avatar_url: avatar_url || null,
      phone: phone || null,
      company_name: company_name || null,
      position: position || null,
      email_notification: email_notification ?? true,
      follow_up_reminder_hours: follow_up_reminder_hours ?? 24,
      updated_at: new Date().toISOString(),
    };

    let result;
    if (existingProfile) {
      // 更新
      result = await supabase
        .from('user_profiles')
        .update(updateData)
        .eq('user_id', user.id)
        .select()
        .single();
    } else {
      // 创建
      result = await supabase
        .from('user_profiles')
        .insert({ ...updateData, created_at: new Date().toISOString() })
        .select()
        .single();
    }

    if (result.error) {
      console.error('Update profile error:', result.error);
      return NextResponse.json({ error: '保存设置失败' }, { status: 500 });
    }

    return NextResponse.json({ 
      success: true,
      settings: result.data 
    });
  } catch (error) {
    console.error('Settings POST API error:', error);
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}