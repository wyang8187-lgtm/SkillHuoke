export type WorkspaceMode = 'demo' | 'production';

export interface WorkspaceQuota {
  searchesUsed: number;
  searchesLimit: number;
  customersUsed: number;
  customersLimit: number;
  exportsUsed: number;
  exportsLimit: number;
  membersUsed: number;
  membersLimit: number;
}

export interface WorkspaceApiStatus {
  openai: 'not_configured' | 'configured';
  leadSearch: 'not_configured' | 'configured';
  supabase: 'not_configured' | 'configured';
}

export interface WorkspaceInfo {
  id: string;
  name: string;
  mode: WorkspaceMode;
  plan: string;
  ownerRole: string;
  region: string;
  isolationStatus: string;
  dataScope: string;
  quota: WorkspaceQuota;
  apiStatus: WorkspaceApiStatus;
}

export const demoWorkspace: WorkspaceInfo = {
  id: 'demo-workspace-skillhuoke',
  name: 'SkillHuoke 演示公司工作空间',
  mode: 'demo',
  plan: 'SaaS Pro 试用版',
  ownerRole: '工作空间管理员',
  region: 'Australia / United States',
  isolationStatus: '已预留 workspaceId，等待接入正式数据库隔离',
  dataScope: '客户、线索、任务、API Key 后续都会按工作空间隔离',
  quota: {
    searchesUsed: 118,
    searchesLimit: 500,
    customersUsed: 128,
    customersLimit: 2000,
    exportsUsed: 6,
    exportsLimit: 50,
    membersUsed: 4,
    membersLimit: 10,
  },
  apiStatus: {
    openai: 'not_configured',
    leadSearch: 'not_configured',
    supabase: 'not_configured',
  },
};

export function getWorkspaceModeLabel(mode: WorkspaceMode) {
  return mode === 'demo' ? '演示模式' : '正式 SaaS 模式';
}

export function getQuotaPercent(used: number, limit: number) {
  if (limit <= 0) return 0;
  return Math.min(100, Math.round((used / limit) * 100));
}

export function getApiStatusLabel(status: WorkspaceApiStatus[keyof WorkspaceApiStatus]) {
  return status === 'configured' ? '已配置' : '未配置';
}
