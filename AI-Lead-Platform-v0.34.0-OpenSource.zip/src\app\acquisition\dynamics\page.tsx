'use client';

import React, { useState } from 'react';
import { MainLayout } from '@/components/layout/main-layout';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@/components/ui/empty-state';
import { Search, Activity, AlertTriangle, Briefcase, Users, FileText, Calendar, TrendingUp, Bell, RefreshCw } from 'lucide-react';

interface DynamicItem {
  id: string;
  type: '工商变更' | '新项目' | '招聘信息' | '中标信息' | '行政处罚' | '司法风险';
  title: string;
  content: string;
  date: string;
  importance: 'high' | 'medium' | 'low';
  source: string;
}

interface CompanyDynamics {
  company_name: string;
  company_id: string;
  dynamics: DynamicItem[];
  last_updated: string;
}

export default function CustomerDynamicsPage() {
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [result, setResult] = useState<CompanyDynamics | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setError(null);
    setResult(null);
    
    try {
      const response = await fetch('/api/ai/customer-dynamics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ company_name: searchQuery.trim() })
      });
      
      if (!response.ok) {
        throw new Error('查询失败');
      }
      
      const data = await response.json();
      setResult(data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : '查询失败，请重试');
    } finally {
      setIsSearching(false);
    }
  };

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case 'high': return 'bg-green-500/20 text-green-400 border-green-500/30';
      case 'medium': return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
      case 'low': return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case '工商变更': return <FileText className="w-4 h-4" />;
      case '新项目': return <Briefcase className="w-4 h-4" />;
      case '招聘信息': return <Users className="w-4 h-4" />;
      case '中标信息': return <TrendingUp className="w-4 h-4" />;
      case '行政处罚': return <AlertTriangle className="w-4 h-4" />;
      case '司法风险': return <AlertTriangle className="w-4 h-4" />;
      default: return <Activity className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case '工商变更': return 'bg-blue-500/20 text-blue-400';
      case '新项目': return 'bg-green-500/20 text-green-400';
      case '招聘信息': return 'bg-purple-500/20 text-purple-400';
      case '中标信息': return 'bg-emerald-500/20 text-emerald-400';
      case '行政处罚': return 'bg-red-500/20 text-red-400';
      case '司法风险': return 'bg-red-500/20 text-red-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  return (
    <MainLayout 
      title="AI客户动态监测"
      breadcrumbs={[
        { label: 'AI获客中心', href: '/acquisition' },
        { label: 'AI客户动态监测' }
      ]}
    >
      <div className="space-y-6">
        {/* 页面说明 */}
        <Card className="bg-[#1a1f2c] border-[#2d3548]">
          <CardHeader>
            <CardTitle className="text-[#f8fafc] flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#3b82f6]" />
              AI客户动态监测
            </CardTitle>
            <CardDescription className="text-[#94a3b8]">
              输入客户企业名称，AI自动监测企业工商变更、新项目、招聘、中标等动态信息，帮助您及时把握客户商机
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <div className="flex-1">
                <Input
                  placeholder="输入企业名称，如：深圳市某某家居有限公司"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="bg-[#0f1419] border-[#2d3548] text-[#f8fafc] placeholder:text-[#64748b]"
                />
              </div>
              <Button 
                onClick={handleSearch}
                disabled={isSearching || !searchQuery.trim()}
                className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] hover:from-[#2563eb] hover:to-[#1e40af]"
              >
                {isSearching ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    正在监测...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4 mr-2" />
                    开始监测
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* 搜索结果 */}
        {error && (
          <Card className="bg-[#1a1f2c] border-red-500/30">
            <CardContent className="py-6">
              <p className="text-red-400">{error}</p>
            </CardContent>
          </Card>
        )}

        {isSearching && (
          <Card className="bg-[#1a1f2c] border-[#2d3548]">
            <CardContent className="py-6 space-y-4">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
              <Skeleton className="h-16 w-full" />
            </CardContent>
          </Card>
        )}

        {result && !isSearching && (
          <div className="space-y-4">
            {/* 企业信息汇总 */}
            <Card className="bg-[#1a1f2c] border-[#2d3548]">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-[#f8fafc]">{result.company_name}</CardTitle>
                  <div className="flex items-center gap-2 text-sm text-[#64748b]">
                    <Calendar className="w-4 h-4" />
                    更新时间：{result.last_updated}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-4 mb-4">
                  <Badge className="bg-[#3b82f6]/20 text-[#3b82f6]">
                    共 {result.dynamics.length} 条动态
                  </Badge>
                  {result.dynamics.filter(d => d.importance === 'high').length > 0 && (
                    <Badge className="bg-green-500/20 text-green-400">
                      <Bell className="w-3 h-3 mr-1" />
                      {result.dynamics.filter(d => d.importance === 'high').length} 条重要动态
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* 动态列表 */}
            <div className="space-y-3">
              {result.dynamics.map((dynamic) => (
                <Card key={dynamic.id} className="bg-[#1a1f2c] border-[#2d3548] hover:border-[#3b82f6]/30 transition-colors">
                  <CardContent className="py-4">
                    <div className="flex items-start gap-4">
                      <div className={`p-2 rounded-lg ${getTypeColor(dynamic.type)}`}>
                        {getTypeIcon(dynamic.type)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge className={`${getTypeColor(dynamic.type)} text-xs`}>
                            {dynamic.type}
                          </Badge>
                          <Badge className={`${getImportanceColor(dynamic.importance)} text-xs border`}>
                            {dynamic.importance === 'high' ? '重要' : dynamic.importance === 'medium' ? '关注' : '一般'}
                          </Badge>
                          <span className="text-xs text-[#64748b]">{dynamic.date}</span>
                        </div>
                        <h4 className="text-[#f8fafc] font-medium mb-1">{dynamic.title}</h4>
                        <p className="text-sm text-[#94a3b8]">{dynamic.content}</p>
                        <p className="text-xs text-[#64748b] mt-2">来源：{dynamic.source}</p>
                      </div>
                      {dynamic.importance === 'high' && (
                        <Button size="sm" variant="outline" className="border-[#3b82f6]/30 text-[#3b82f6] hover:bg-[#3b82f6]/10">
                          立即跟进
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* 空状态 */}
        {!result && !isSearching && !error && (
          <EmptyState
            icon={<Activity className="w-12 h-12" />}
            title="输入企业名称开始监测"
            description="AI将自动检索企业工商变更、新项目、招聘信息、中标动态等，帮助您及时把握商机"
          />
        )}
      </div>
    </MainLayout>
  );
}