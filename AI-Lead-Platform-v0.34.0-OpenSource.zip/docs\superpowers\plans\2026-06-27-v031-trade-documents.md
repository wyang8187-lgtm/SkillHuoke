# v0.31.0 Trade Documents Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a local-first trade document center that creates editable PI, commercial invoice, and packing list snapshots from CRM orders and prints each document as A4 PDF.

**Architecture:** A focused `trade-documents` domain owns document types, snapshots, calculations, validation, numbering, persistence, copying, and order lookups. Shared editor and print components branch only where invoice and packing-list fields differ. Backup v6 adds the document array while keeping v1-v5 import compatibility.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, localStorage, shadcn/Radix UI, Tailwind CSS, Node assert tests through `tsx`.

---

### Task 1: Trade Document Domain

**Files:**
- Create: `tests/trade-documents.test.ts`
- Create: `src/lib/trade-documents.ts`
- Read: `src/lib/crm-orders.ts`
- Read: `src/lib/company-profile.ts`

- [ ] **Step 1: Write the failing test**

```ts
import assert from 'node:assert/strict';
import {
  calculatePackingSummary,
  createTradeDocumentFromOrder,
  validateTradeDocument,
} from '../src/lib/trade-documents';

const packing = calculatePackingSummary([{
  id: 'pack-1',
  product: 'Cabinet',
  specification: 'Oak',
  cartons: 2,
  quantityPerCarton: 3,
  totalQuantity: 6,
  netWeightPerCarton: 10,
  grossWeightPerCarton: 12,
  lengthCm: 100,
  widthCm: 50,
  heightCm: 20,
}]);
assert.deepEqual(packing, { cartons: 2, quantity: 6, netWeight: 20, grossWeight: 24, volume: 0.2 });

const document = createTradeDocumentFromOrder(orderFixture, profileFixture, 'proforma_invoice');
assert.equal(document.type, 'proforma_invoice');
assert.equal(document.orderId, orderFixture.id);
assert.notEqual(document.items, orderFixture.items);
assert.deepEqual(validateTradeDocument({ ...document, number: '' }), ['单据编号不能为空。']);

console.log('trade-documents tests passed');
```

- [ ] **Step 2: Verify RED**

Run:

```powershell
.\node_modules\.bin\tsx.cmd tests\trade-documents.test.ts
```

Expected: FAIL with `Cannot find module '../src/lib/trade-documents'`.

- [ ] **Step 3: Implement domain types and calculations**

Create:

```ts
export type TradeDocumentType = 'proforma_invoice' | 'commercial_invoice' | 'packing_list';
export type TradeDocumentStatus = 'draft' | 'issued' | 'sent' | 'confirmed' | 'void';

export interface PackingItem {
  id: string;
  product: string;
  specification: string;
  cartons: number;
  quantityPerCarton: number;
  totalQuantity: number;
  netWeightPerCarton: number;
  grossWeightPerCarton: number;
  lengthCm: number;
  widthCm: number;
  heightCm: number;
}
```

Add `SavedTradeDocument` with these exact groups:

- identity: `id`, `type`, `number`, `status`, `issueDate`
- order/customer: `orderId`, `orderNumber`, `customerId`, `customerName`, `contactName`
- commercial: `currency`, `tradeTerm`, `paymentTerms`, `items`, `discount`, `shipping`, `tax`
- packing: `packingItems`, `declaredCartons`, `declaredQuantity`, `declaredNetWeight`, `declaredGrossWeight`, `declaredVolume`
- company snapshot: `companyNameZh`, `companyNameEn`, `addressZh`, `addressEn`, `phone`, `email`, `website`, `logoDataUrl`
- bank snapshot: `bankName`, `bankAccountName`, `bankAccountNumber`, `bankSwift`, `bankAddress`, `showBankDetails`
- metadata: `note`, `createdAt`, `updatedAt`

Implement:

- `generateTradeDocumentNumber`
- `calculateInvoiceTotals`
- `calculatePackingSummary`
- `createTradeDocumentFromOrder`
- `validateTradeDocument`
- `loadSavedTradeDocuments`
- `saveTradeDocuments`
- `saveTradeDocument`
- `copyTradeDocument`
- `deleteTradeDocument`
- `loadDocumentsForOrder`

Use storage key `skillhuoke_trade_documents_v031`. Volume uses `cartons * length * width * height / 1_000_000`, rounded to three decimals.

- [ ] **Step 4: Verify GREEN**

Run the domain test and expect `trade-documents tests passed`.

### Task 2: Document Center and Order Entry

**Files:**
- Create: `src/app/trade-documents/page.tsx`
- Create: `src/app/trade-documents/new/page.tsx`
- Modify: `src/app/crm-orders/[id]/page.tsx`
- Modify: `src/components/layout/sidebar.tsx`

- [ ] **Step 1: Build the document center**

Use lazy localStorage loading. Show total, PI, CI, PL, and draft/issued counts. Add keyword, type, status, and customer filters. Each row exposes:

- 查看
- 打印
- 复制
- 删除

Require a second `window.confirm` before deleting `issued`, `sent`, or `confirmed` documents.

- [ ] **Step 2: Build the new-document selector**

Read `orderId` from search params. If the order is missing, show a safe empty state. Present three type choices, create the snapshot through `createTradeDocumentFromOrder`, save it, and navigate to `/trade-documents/[id]`.

- [ ] **Step 3: Add order-detail entry points**

On the order detail page:

```tsx
<Link href={`/trade-documents/new?orderId=${order.id}`}>生成外贸单据</Link>
```

Also list existing documents for the order with view and print links.

- [ ] **Step 4: Add navigation**

Add a top-level sidebar item after `订单管理`:

```tsx
{
  title: '外贸单据',
  href: '/trade-documents',
  icon: <Files className="h-5 w-5" />,
}
```

### Task 3: Shared Editor and Print Pages

**Files:**
- Create: `src/components/trade-documents/trade-document-form.tsx`
- Create: `src/components/trade-documents/trade-document-print.tsx`
- Create: `src/app/trade-documents/[id]/page.tsx`
- Create: `src/app/trade-documents/[id]/print/page.tsx`

- [ ] **Step 1: Build the shared editor**

Common fields:

- document number, status, issue date
- customer and contact snapshot
- trade term and payment terms
- bank visibility
- note

For PI/CI, edit product, specification, quantity, unit, unit price, discount, shipping, and tax. For PL, edit cartons, per-carton quantity, total quantity, per-carton net/gross weight, and dimensions. Show calculated packing totals beside optional declared totals.

- [ ] **Step 2: Add validation and save behavior**

Call `validateTradeDocument(document, allDocuments)` before saving. Keep form values on errors. Reject duplicate numbers excluding the current ID. Redirect only after a successful save.

- [ ] **Step 3: Build the A4 renderer**

Use a white `210mm × 297mm` article and `@media print`. Render:

- company brand header
- document title, number, issue date, customer, order
- invoice amount table for PI/CI
- packing table and declared/calculated totals for PL
- terms, optional bank details, notes, and signature area

- [ ] **Step 4: Add safe empty states**

Both detail and print routes return a Chinese empty state if the document ID does not exist.

### Task 4: Backup v6

**Files:**
- Create: `tests/data-backup-v6.test.ts`
- Modify: `src/lib/data-backup.ts`
- Modify: `src/app/data-backup/page.tsx`

- [ ] **Step 1: Write the failing compatibility test**

Create a v5 payload without `tradeDocuments` and assert:

```ts
assert.equal(parsed.version, 6);
assert.deepEqual(parsed.data.tradeDocuments, []);
```

Create a v6 payload with one document and assert the ID survives parsing.

- [ ] **Step 2: Verify RED**

Expected: version remains 5 or `tradeDocuments` is undefined.

- [ ] **Step 3: Upgrade backup schema**

- Set `BACKUP_VERSION = 6`.
- Add `tradeDocuments: SavedTradeDocument[]` to data and summary.
- Accept versions `[1, 2, 3, 4, 5, 6]`.
- Normalize missing documents to `[]` for versions below 6.
- Include documents in load, save, merge, overwrite, preview, and undo.

- [ ] **Step 4: Update backup UI**

Change the badge to `备份格式 v6` and add document counts to the current summary and import preview.

- [ ] **Step 5: Verify backup tests**

Run the existing v5 test and new v6 test. Both must pass.

### Task 5: Release, QA, and Package

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `README.md`
- Modify: `package.json`
- Create: `AI-Lead-Platform-v0.31.0-OpenSource.zip`

- [ ] **Step 1: Update metadata**

Use:

```ts
version: 'v0.31.0'
title: '外贸单据中心'
packageName: 'AI-Lead-Platform-v0.31.0-OpenSource.zip'
githubRemark: 'v0.31.0：新增 PI、商业发票、装箱单和 A4 PDF 打印'
```

- [ ] **Step 2: Run complete verification**

```powershell
.\node_modules\.bin\tsx.cmd tests\company-profile.test.ts
.\node_modules\.bin\tsx.cmd tests\crm-orders.test.ts
.\node_modules\.bin\tsx.cmd tests\trade-documents.test.ts
.\node_modules\.bin\tsx.cmd tests\data-backup-v5.test.ts
.\node_modules\.bin\tsx.cmd tests\data-backup-v6.test.ts
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

Expected: all tests print pass messages and all commands exit 0.

- [ ] **Step 3: Browser QA**

Check desktop and 390×844 mobile layouts for:

- `/trade-documents`
- `/trade-documents/new?orderId=missing`
- `/trade-documents/missing`
- `/trade-documents/missing/print`
- `/crm-orders/missing`
- `/data-backup`
- `/release`

Verify no application error, incoherent overlap, clipped controls, or workbench horizontal overflow.

- [ ] **Step 4: Package**

Create:

`C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.31.0-OpenSource.zip`

Exclude `node_modules`, `.next`, `.git`, `.env`, `.env.local`, server logs, and TypeScript build cache. Verify the ZIP contains the domain, editor, print component, four routes, backup tests, README, and version metadata.
