'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DatePickerProps {
  value?: string;
  onChange: (date: string) => void;
  placeholder?: string;
  showQuickOptions?: boolean;
  minDate?: string;
  maxDate?: string;
  className?: string;
  disabled?: boolean;
}

// 快捷日期选项
const quickOptions = [
  { label: '今天', getValue: () => new Date() },
  { label: '明天', getValue: () => new Date(Date.now() + 24 * 60 * 60 * 1000) },
  { label: '下周', getValue: () => new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) },
  { label: '下月', getValue: () => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth() + 1, now.getDate());
  }},
  { label: '月底', getValue: () => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth() + 1, 0);
  }},
];

// 格式化日期为 YYYY-MM-DD
const formatDate = (date: Date): string => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// 解析日期字符串
const parseDate = (dateStr: string): Date | null => {
  if (!dateStr) return null;
  const parts = dateStr.split('-');
  if (parts.length !== 3) return null;
  return new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, parseInt(parts[2]));
};

export function DatePicker({
  value,
  onChange,
  placeholder = '选择日期',
  showQuickOptions = true,
  minDate,
  maxDate,
  className,
  disabled = false,
}: DatePickerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [currentMonth, setCurrentMonth] = useState(() => {
    const date = parseDate(value || '');
    return date || new Date();
  });
  const [viewMode, setViewMode] = useState<'quick' | 'calendar'>('quick');
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // 生成日历网格
  const generateCalendarDays = () => {
    const year = currentMonth.getFullYear();
    const month = currentMonth.getMonth();
    
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    
    const startDayOfWeek = firstDay.getDay() || 7; // 周日改为7
    const daysInMonth = lastDay.getDate();
    
    const days: (Date | null)[] = [];
    
    // 前面填充空格
    for (let i = 1; i < startDayOfWeek; i++) {
      days.push(null);
    }
    
    // 当月日期
    for (let i = 1; i <= daysInMonth; i++) {
      days.push(new Date(year, month, i));
    }
    
    return days;
  };

  // 检查日期是否可选
  const isDateSelectable = (date: Date): boolean => {
    if (minDate) {
      const min = parseDate(minDate);
      if (min && date < min) return false;
    }
    if (maxDate) {
      const max = parseDate(maxDate);
      if (max && date > max) return false;
    }
    return true;
  };

  // 选择日期
  const handleSelectDate = (date: Date) => {
    if (!isDateSelectable(date)) return;
    onChange(formatDate(date));
    setIsOpen(false);
  };

  // 快捷选择
  const handleQuickSelect = (option: typeof quickOptions[0]) => {
    const date = option.getValue();
    if (isDateSelectable(date)) {
      onChange(formatDate(date));
      setIsOpen(false);
    }
  };

  // 切换月份
  const changeMonth = (delta: number) => {
    setCurrentMonth(new Date(currentMonth.getFullYear(), currentMonth.getMonth() + delta, 1));
  };

  // 选中日期对象
  const selectedDate = parseDate(value || '');

  return (
    <div ref={ref} className={cn('relative', className)}>
      {/* 输入框 */}
      <button
        type="button"
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className={cn(
          'w-full flex items-center gap-2 px-3 py-2 rounded-lg border bg-background text-foreground',
          'transition-colors hover:bg-muted/50',
          disabled && 'opacity-50 cursor-not-allowed',
          isOpen ? 'border-primary ring-2 ring-primary/20' : 'border-border'
        )}
      >
        <Calendar className="h-4 w-4 text-muted-foreground" />
        <span className={value ? 'text-foreground' : 'text-muted-foreground'}>
          {value || placeholder}
        </span>
      </button>

      {/* 下拉面板 */}
      {isOpen && (
        <div className="absolute z-50 mt-1 w-[280px] rounded-lg border border-border bg-popover shadow-lg">
          {/* 快捷选项 */}
          {showQuickOptions && viewMode === 'quick' && (
            <div className="p-2 border-b border-border">
              <div className="flex items-center gap-1 mb-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">快捷选择</span>
              </div>
              <div className="flex flex-wrap gap-1">
                {quickOptions.map((option) => (
                  <button
                    key={option.label}
                    type="button"
                    onClick={() => handleQuickSelect(option)}
                    className={cn(
                      'px-3 py-1.5 rounded-md text-sm font-medium transition-colors',
                      'bg-muted hover:bg-primary hover:text-primary-foreground'
                    )}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
              <button
                type="button"
                onClick={() => setViewMode('calendar')}
                className="w-full mt-2 py-1.5 text-sm text-primary hover:underline"
              >
                更多日期...
              </button>
            </div>
          )}

          {/* 日历视图 */}
          {viewMode === 'calendar' && (
            <>
              {/* 月份导航 */}
              <div className="flex items-center justify-between p-2 border-b border-border">
                <button
                  type="button"
                  onClick={() => changeMonth(-1)}
                  className="p-1 rounded-md hover:bg-muted"
                >
                  <ChevronLeft className="h-4 w-4" />
                </button>
                <span className="font-medium">
                  {currentMonth.getFullYear()}年{currentMonth.getMonth() + 1}月
                </span>
                <button
                  type="button"
                  onClick={() => changeMonth(1)}
                  className="p-1 rounded-md hover:bg-muted"
                >
                  <ChevronRight className="h-4 w-4" />
                </button>
              </div>

              {/* 星期标题 */}
              <div className="grid grid-cols-7 gap-1 p-2 text-center text-xs text-muted-foreground">
                {['一', '二', '三', '四', '五', '六', '日'].map((day) => (
                  <div key={day}>{day}</div>
                ))}
              </div>

              {/* 日期网格 */}
              <div className="grid grid-cols-7 gap-1 p-2">
                {generateCalendarDays().map((date, index) => (
                  <button
                    key={index}
                    type="button"
                    disabled={!date || !isDateSelectable(date)}
                    onClick={() => date && handleSelectDate(date)}
                    className={cn(
                      'h-8 w-8 rounded-md text-sm font-medium transition-colors',
                      !date && 'invisible',
                      date && !isDateSelectable(date) && 'text-muted-foreground opacity-50 cursor-not-allowed',
                      date && isDateSelectable(date) && 'hover:bg-muted',
                      date && selectedDate && date.getTime() === selectedDate.getTime() && 
                        'bg-primary text-primary-foreground hover:bg-primary'
                    )}
                  >
                    {date?.getDate()}
                  </button>
                ))}
              </div>

              {/* 返回快捷选项 */}
              {showQuickOptions && (
                <div className="p-2 border-t border-border">
                  <button
                    type="button"
                    onClick={() => setViewMode('quick')}
                    className="w-full py-1.5 text-sm text-muted-foreground hover:text-primary"
                  >
                    ← 快捷选择
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}