import { NextRequest, NextResponse } from 'next/server';
import * as dbService from '@/lib/db-service';

// 启用/停用自动化规则
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // 从请求头获取用户信息
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    // 解析用户ID
    const supabase = dbService.getSupabaseAdmin();
    const { data: { user }, error: authError } = await supabase.auth.getUser(authHeader);
    
    if (authError || !user) {
      return NextResponse.json({ error: '无效的登录状态' }, { status: 401 });
    }

    // 解析请求体获取目标状态
    const body = await request.json();
    const { status } = body;

    if (!status || (status !== 'active' && status !== 'paused')) {
      return NextResponse.json({ error: '请提供有效的状态（active 或 paused）' }, { status: 400 });
    }

    // 切换状态
    const flow = await dbService.toggleAutomationFlowStatus(user.id, id, status);

    if (!flow) {
      return NextResponse.json({ error: '操作失败，规则不存在' }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      data: flow,
      message: status === 'active' ? '规则已启用' : '规则已停用'
    });

  } catch (error) {
    console.error('切换自动化规则状态错误:', error);
    return NextResponse.json({
      error: '切换状态失败',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}