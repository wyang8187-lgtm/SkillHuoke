'use client';

import { useState } from 'react';
import Link from 'next/link';
import { MainLayout } from '@/components/layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import {
  loadCompanyProfile,
  resetCompanyProfile,
  resizeCompanyLogo,
  saveCompanyProfile,
  validateCompanyProfile,
  type CompanyProfile,
} from '@/lib/company-profile';
import { opportunityCurrencies } from '@/lib/crm-opportunities';
import { Building2, FileText, ImagePlus, RotateCcw, Save, ShieldCheck } from 'lucide-react';

const fieldClass = 'border-[#2d3548] bg-[#0f1419] text-[#f8fafc]';

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-2"><Label className="text-[#cbd5e1]">{label}</Label>{children}</div>;
}

export default function CompanyProfilePage() {
  const [profile, setProfile] = useState<CompanyProfile>(() => loadCompanyProfile());
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const patch = <K extends keyof CompanyProfile>(key: K, value: CompanyProfile[K]) => setProfile((current) => ({ ...current, [key]: value }));

  const save = () => {
    const errors = validateCompanyProfile(profile);
    if (errors.length) {
      setError(errors[0]);
      setMessage('');
      return;
    }
    setProfile(saveCompanyProfile(profile));
    setMessage('公司品牌与报价默认设置已保存。');
    setError('');
  };

  const reset = () => {
    if (!window.confirm('确认恢复 SkillHuoke 演示默认设置吗？')) return;
    setProfile(resetCompanyProfile());
    setMessage('已恢复演示默认设置。');
    setError('');
  };

  const uploadLogo = async (file?: File) => {
    if (!file) return;
    try {
      patch('logoDataUrl', await resizeCompanyLogo(file));
      setError('');
    } catch (uploadError) {
      setError(uploadError instanceof Error ? uploadError.message : 'Logo 处理失败。');
    }
  };

  return (
    <MainLayout title="公司与报价设置">
      <div className="space-y-6">
        <section className="flex flex-col gap-4 rounded-lg border border-[#2d3548] bg-[#121823] p-6 lg:flex-row lg:items-end lg:justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm text-blue-300"><Building2 className="h-4 w-4" />v0.29.0 公司品牌中心</div>
            <h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">统一管理报价单上的公司身份</h2>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">设置仅保存在当前浏览器。新报价会自动使用默认规则，已有报价不会被修改。</p>
          </div>
          <Button asChild variant="outline" className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><Link href="/crm-quotations/new"><FileText className="mr-2 h-4 w-4" />新建报价单</Link></Button>
        </section>

        {message ? <div className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 p-4 text-sm text-emerald-200">{message}</div> : null}
        {error ? <div className="rounded-lg border border-red-500/25 bg-red-500/10 p-4 text-sm text-red-200">{error}</div> : null}

        <div className="grid gap-6 xl:grid-cols-[1fr_360px]">
          <div className="space-y-6">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader><CardTitle className="text-[#f8fafc]">公司资料</CardTitle></CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-2">
                <Field label="中文公司名称"><Input className={fieldClass} value={profile.companyNameZh} onChange={(e) => patch('companyNameZh', e.target.value)} /></Field>
                <Field label="英文公司名称 *"><Input className={fieldClass} value={profile.companyNameEn} onChange={(e) => patch('companyNameEn', e.target.value)} /></Field>
                <Field label="中文地址"><Input className={fieldClass} value={profile.addressZh} onChange={(e) => patch('addressZh', e.target.value)} /></Field>
                <Field label="英文地址"><Input className={fieldClass} value={profile.addressEn} onChange={(e) => patch('addressEn', e.target.value)} /></Field>
                <Field label="电话"><Input className={fieldClass} value={profile.phone} onChange={(e) => patch('phone', e.target.value)} /></Field>
                <Field label="邮箱"><Input type="email" className={fieldClass} value={profile.email} onChange={(e) => patch('email', e.target.value)} /></Field>
                <Field label="官网"><Input className={fieldClass} placeholder="https://example.com" value={profile.website} onChange={(e) => patch('website', e.target.value)} /></Field>
                <Field label="公司 Logo（PNG/JPEG/WebP，最大 1MB）">
                  <div className="flex gap-2"><Input type="file" accept="image/png,image/jpeg,image/webp" className={fieldClass} onChange={(e) => uploadLogo(e.target.files?.[0])} />{profile.logoDataUrl ? <Button type="button" size="icon" variant="outline" title="移除 Logo" onClick={() => patch('logoDataUrl', '')}><ImagePlus className="h-4 w-4" /></Button> : null}</div>
                </Field>
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader><CardTitle className="text-[#f8fafc]">报价默认规则</CardTitle></CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-2">
                <Field label="默认语言"><Select value={profile.defaultLanguage} onValueChange={(value) => patch('defaultLanguage', value as CompanyProfile['defaultLanguage'])}><SelectTrigger className={fieldClass}><SelectValue /></SelectTrigger><SelectContent><SelectItem value="en">English</SelectItem><SelectItem value="zh">中文</SelectItem></SelectContent></Select></Field>
                <Field label="默认币种"><Select value={profile.defaultCurrency} onValueChange={(value) => patch('defaultCurrency', value as CompanyProfile['defaultCurrency'])}><SelectTrigger className={fieldClass}><SelectValue /></SelectTrigger><SelectContent>{opportunityCurrencies.map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></Field>
                <Field label="默认贸易条款"><Select value={profile.defaultTradeTerm} onValueChange={(value) => patch('defaultTradeTerm', value as CompanyProfile['defaultTradeTerm'])}><SelectTrigger className={fieldClass}><SelectValue /></SelectTrigger><SelectContent>{['EXW', 'FOB', 'CIF', 'DDP'].map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></Field>
                <Field label="默认有效天数"><Input type="number" min={1} max={365} className={fieldClass} value={profile.defaultValidityDays} onChange={(e) => patch('defaultValidityDays', Number(e.target.value))} /></Field>
                <Field label="默认付款条款"><Input className={fieldClass} value={profile.defaultPaymentTerms} onChange={(e) => patch('defaultPaymentTerms', e.target.value)} /></Field>
                <Field label="默认交期"><Input className={fieldClass} value={profile.defaultDeliveryTime} onChange={(e) => patch('defaultDeliveryTime', e.target.value)} /></Field>
                <div className="md:col-span-2">
                  <Field label="报价转订单方式">
                    <Select value={profile.orderConversionMode} onValueChange={(value) => patch('orderConversionMode', value as CompanyProfile['orderConversionMode'])}>
                      <SelectTrigger className={fieldClass}><SelectValue /></SelectTrigger>
                      <SelectContent><SelectItem value="manual">手动确认转换</SelectItem><SelectItem value="automatic">报价接受后自动转换</SelectItem></SelectContent>
                    </Select>
                  </Field>
                </div>
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader><div className="flex items-center justify-between gap-4"><CardTitle className="text-[#f8fafc]">收款银行信息</CardTitle><div className="flex items-center gap-2 text-sm text-[#cbd5e1]"><Switch checked={profile.showBankDetails} onCheckedChange={(checked) => patch('showBankDetails', checked)} />打印时显示</div></div></CardHeader>
              <CardContent className="grid gap-4 md:grid-cols-2">
                <Field label="银行名称"><Input className={fieldClass} value={profile.bankName} onChange={(e) => patch('bankName', e.target.value)} /></Field>
                <Field label="账户名称"><Input className={fieldClass} value={profile.bankAccountName} onChange={(e) => patch('bankAccountName', e.target.value)} /></Field>
                <Field label="银行账号"><Input className={fieldClass} value={profile.bankAccountNumber} onChange={(e) => patch('bankAccountNumber', e.target.value)} /></Field>
                <Field label="SWIFT / BIC"><Input className={fieldClass} value={profile.bankSwift} onChange={(e) => patch('bankSwift', e.target.value)} /></Field>
                <div className="md:col-span-2"><Field label="银行地址"><Input className={fieldClass} value={profile.bankAddress} onChange={(e) => patch('bankAddress', e.target.value)} /></Field></div>
              </CardContent>
            </Card>
          </div>

          <aside className="space-y-4">
            <Card className="sticky top-6 border-[#2d3548] bg-white text-slate-900">
              <CardHeader><CardTitle className="text-base">报价抬头预览</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="flex min-h-20 items-center gap-4 border-b border-slate-200 pb-4">
                  {profile.logoDataUrl ? <img src={profile.logoDataUrl} alt="公司 Logo" className="h-16 w-16 object-contain" /> : <div className="flex h-16 w-16 items-center justify-center rounded border border-dashed border-slate-300 text-xs text-slate-400">LOGO</div>}
                  <div><p className="font-semibold">{profile.companyNameEn || 'Company Name'}</p><p className="mt-1 text-sm text-slate-500">{profile.companyNameZh}</p></div>
                </div>
                <div className="space-y-1 text-xs text-slate-600"><p>{profile.addressEn || profile.addressZh || 'Company address'}</p><p>{[profile.phone, profile.email].filter(Boolean).join(' · ') || 'Phone · Email'}</p><p>{profile.website || 'Website'}</p></div>
                <div className="rounded bg-slate-100 p-3 text-xs"><ShieldCheck className="mr-1 inline h-4 w-4 text-emerald-600" />资料只保存在当前浏览器和你的备份文件中。</div>
              </CardContent>
            </Card>
          </aside>
        </div>

        <div className="flex flex-wrap gap-3">
          <Button type="button" onClick={save} className="bg-blue-600 text-white hover:bg-blue-500"><Save className="mr-2 h-4 w-4" />保存设置</Button>
          <Button type="button" variant="outline" onClick={reset} className="border-[#2d3548] bg-[#121823] text-[#f8fafc]"><RotateCcw className="mr-2 h-4 w-4" />恢复演示默认值</Button>
        </div>
      </div>
    </MainLayout>
  );
}
