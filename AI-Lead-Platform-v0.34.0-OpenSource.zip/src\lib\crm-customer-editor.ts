import type { CrmCustomerStatus, CrmVerificationStatus, SavedCrmCustomer } from './lead-wizard';

export interface CrmCustomerEditorValue {
  company: string;
  website: string;
  country: string;
  city: string;
  customerType: string;
  status: CrmCustomerStatus;
  priority: 'A' | 'B' | 'C';
  score: number;
  note: string;
  nextAction: string;
  nextFollowUpAt: string;
  contactName: string;
  contactTitle: string;
  email: string;
  phone: string;
  whatsapp: string;
  linkedin: string;
  verificationStatus: CrmVerificationStatus;
}

export const emptyCrmCustomerEditorValue: CrmCustomerEditorValue = {
  company: '', website: '', country: '', city: '', customerType: '', status: 'new', priority: 'B',
  score: 70, note: '', nextAction: '', nextFollowUpAt: '', contactName: '', contactTitle: '',
  email: '', phone: '', whatsapp: '', linkedin: '', verificationStatus: 'pending',
};

export function customerToEditorValue(customer: SavedCrmCustomer): CrmCustomerEditorValue {
  return {
    ...emptyCrmCustomerEditorValue,
    ...customer,
    nextFollowUpAt: customer.nextFollowUpAt || '',
    contactName: customer.contactName || '',
    contactTitle: customer.contactTitle || '',
    email: customer.email || '',
    phone: customer.phone || '',
    whatsapp: customer.whatsapp || '',
    linkedin: customer.linkedin || '',
    verificationStatus: customer.verificationStatus || 'pending',
  };
}

export function normalizeWebsite(value: string) {
  const trimmed = value.trim();
  if (!trimmed) return '';
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

export function websiteDomain(value: string) {
  try {
    return new URL(normalizeWebsite(value)).hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return '';
  }
}

export function validateCustomerEditor(value: CrmCustomerEditorValue) {
  const errors: Record<string, string> = {};
  if (!value.company.trim()) errors.company = '请填写公司名称。';
  if (!value.country.trim()) errors.country = '请填写国家。';
  if (!value.customerType.trim()) errors.customerType = '请填写客户类型。';
  if (value.website && !websiteDomain(value.website)) errors.website = '请输入有效官网地址。';
  if (value.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.email)) errors.email = '邮箱格式不正确。';
  const phoneValid = (text: string) => !text || (/^[+\d\s()-]+$/.test(text) && (text.match(/\d/g)?.length || 0) >= 7);
  if (!phoneValid(value.phone)) errors.phone = '电话至少需要 7 位数字。';
  if (!phoneValid(value.whatsapp)) errors.whatsapp = 'WhatsApp 至少需要 7 位数字。';
  if (value.linkedin) {
    try {
      if (!new URL(normalizeWebsite(value.linkedin)).hostname.toLowerCase().includes('linkedin.com')) errors.linkedin = '请输入 LinkedIn 链接。';
    } catch {
      errors.linkedin = '请输入有效 LinkedIn 链接。';
    }
  }
  if (!Number.isFinite(value.score) || value.score < 0 || value.score > 100) errors.score = '评分必须在 0 到 100 之间。';
  return errors;
}

export function findDuplicateCustomers(value: CrmCustomerEditorValue, customers: SavedCrmCustomer[], excludeId?: string) {
  const domain = websiteDomain(value.website);
  const company = value.company.trim().toLowerCase();
  const country = value.country.trim().toLowerCase();
  return customers.filter((customer) => {
    if (customer.id === excludeId) return false;
    const sameDomain = domain && websiteDomain(customer.website) === domain;
    const sameNameCountry = customer.company.trim().toLowerCase() === company && customer.country.trim().toLowerCase() === country;
    return Boolean(sameDomain || sameNameCountry);
  });
}
