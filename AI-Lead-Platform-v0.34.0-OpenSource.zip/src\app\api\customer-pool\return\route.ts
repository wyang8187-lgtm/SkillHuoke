// 公海池退回 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';

// 退回公海池
export async function POST(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    const body = await req.json();
    const { id, reason } = body;

    if (!id) {
      return NextResponse.json({ error: '缺少客户ID' }, { status: 400 });
    }

    // 更新客户：移除负责人
    const { error: updateError } = await client
      .from('customers')
      .update({
        assignee_id: null,
        updated_at: new Date().toISOString(),
      })
      .eq('id', id);

    if (updateError) {
      console.error('退回失败:', updateError);
      return NextResponse.json({ error: '退回失败' }, { status: 500 });
    }

    // 创建跟进记录
    await client.from('follow_up_records').insert({
      customer_id: id,
      user_id: user.id,
      content: `退回公海池，原因：${reason || '无'}`,
      type: '退回',
      created_at: new Date().toISOString(),
    });

    return NextResponse.json({ 
      success: true, 
      message: '已退回公海池' 
    });
  } catch (error) {
    console.error('退回失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '退回失败' 
    }, { status: 500 });
  }
}