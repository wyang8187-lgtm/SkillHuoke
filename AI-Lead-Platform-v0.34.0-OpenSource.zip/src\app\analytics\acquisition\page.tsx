'use client';

import { useEffect, useState } from 'react';
import { useTheme } from '@/lib/theme-context';
import {
  BarChart, Bar, XAxis, YAxis, LineChart, Line,
  CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell, RadarChart,
  PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@/components/ui/empty-state';
import { Zap, Globe2, Mail, Clock } from 'lucide-react';

const CHANNEL_COLORS = ['#3b82f6', '#f97316', '#22c55e', '#8b5cf6', '#06b6d4', '#64748b'];

export default function AcquisitionAnalyticsPage() {
  const { theme } = useTheme();
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<any>(null);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const res = await fetch('/api/analytics/acquisition');
      const json = await res.json();
      if (json.success) {
        setData(json.data);
      }
    } catch (error) {
      console.error('获取数据失败:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-32" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  const hasData = data && (data.totalCustomers > 0 || data.totalLeads > 0);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold flex items-center gap-2">
        <Zap className="w-6 h-6" />
        获客效率分析
      </h1>

      {/* 总数卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">总客户数</div>
            <div className="text-2xl font-bold">{data?.totalCustomers || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">总线索数</div>
            <div className="text-2xl font-bold">{data?.totalLeads || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">AI搜客转化率</div>
            <div className="text-2xl font-bold text-green-500">
              {data?.aiSearch?.conversionRate || 0}%
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-sm text-muted-foreground">开发信打开率</div>
            <div className="text-2xl font-bold text-blue-500">
              {data?.devLetter?.openRate || 0}%
            </div>
          </CardContent>
        </Card>
      </div>

      {!hasData ? (
        <EmptyState
          icon={<Globe2 className="w-12 h-12" />}
          title="暂无获客数据"
          description="请先通过AI搜客或其他渠道获取潜在客户"
        />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* 渠道对比 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe2 className="w-5 h-5" />
                各获客渠道对比
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={data?.channels || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#2d3548' : '#e5e7eb'} />
                  <XAxis dataKey="channel" stroke="#64748b" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="left" stroke="#64748b" tick={{ fontSize: 12 }} />
                  <YAxis yAxisId="right" orientation="right" stroke="#64748b" tick={{ fontSize: 12 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: theme === 'dark' ? '#1a1f2c' : '#fff',
                      border: '1px solid #2d3548'
                    }}
                  />
                  <Legend />
                  <Bar yAxisId="left" dataKey="leads" name="线索数" fill="#3b82f6" radius={[4, 4, 0, 0]}>
                    {(data?.channels || []).map((entry: any, index: number) => (
                      <Cell key={`cell-${index}`} fill={CHANNEL_COLORS[index % CHANNEL_COLORS.length]} />
                    ))}
                  </Bar>
                  <Bar yAxisId="left" dataKey="customers" name="成交数" fill="#22c55e" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
              <div className="mt-4 space-y-2">
                {data?.channels?.map((item: any, index: number) => (
                  <div key={index} className="flex items-center justify-between text-sm">
                    <span>{item.channel}</span>
                    <span className="text-muted-foreground">
                      线索{item.leads} · 成交{item.customers} · 转化{item.conversionRate}%
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* AI搜客效果 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5" />
                AI搜客效果统计
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-4">
                  <div className="bg-muted/20 rounded-lg p-4 text-center">
                    <div className="text-xl font-bold">{data?.aiSearch?.totalLeads || 0}</div>
                    <div className="text-xs text-muted-foreground">AI线索</div>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-4 text-center">
                    <div className="text-xl font-bold text-green-500">{data?.aiSearch?.convertedCustomers || 0}</div>
                    <div className="text-xs text-muted-foreground">已成交</div>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-4 text-center">
                    <div className="text-xl font-bold text-blue-500">{data?.aiSearch?.conversionRate || 0}%</div>
                    <div className="text-xs text-muted-foreground">转化率</div>
                  </div>
                  <div className="bg-muted/20 rounded-lg p-4 text-center">
                    <div className="text-xl font-bold text-orange-500">{data?.aiSearch?.highQualityRate || 0}%</div>
                    <div className="text-xs text-muted-foreground">A级占比</div>
                  </div>
                </div>
                <div className="border-t pt-4">
                  <div className="text-sm text-muted-foreground">
                    平均转化周期：{data?.aiSearch?.avgConversionDays || 0}天
                  </div>
                  <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-green-500 rounded-full"
                      style={{ width: `${data?.aiSearch?.conversionRate || 0}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* 开发信效果 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                开发信发送效果
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="bg-muted/20 rounded-lg p-4 text-center">
                  <div className="text-xl font-bold">{data?.devLetter?.totalSent || 0}</div>
                  <div className="text-xs text-muted-foreground">发送总数</div>
                </div>
                <div className="bg-blue-500/10 rounded-lg p-4 text-center">
                  <div className="text-xl font-bold text-blue-500">{data?.devLetter?.openRate || 0}%</div>
                  <div className="text-xs text-muted-foreground">打开率</div>
                </div>
                <div className="bg-green-500/10 rounded-lg p-4 text-center">
                  <div className="text-xl font-bold text-green-500">{data?.devLetter?.replyRate || 0}%</div>
                  <div className="text-xs text-muted-foreground">回复率</div>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={data?.devLetter?.hourlyOpenRate || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#2d3548' : '#e5e7eb'} />
                  <XAxis dataKey="hour" stroke="#64748b" tick={{ fontSize: 10 }} />
                  <YAxis stroke="#64748b" tick={{ fontSize: 10 }} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: theme === 'dark' ? '#1a1f2c' : '#fff',
                      border: '1px solid #2d3548'
                    }}
                    formatter={(value: any) => `${value}%`}
                  />
                  <Line type="monotone" dataKey="rate" name="打开率" stroke="#3b82f6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
              <div className="mt-2 text-xs text-muted-foreground text-center">各时段开发信打开率分布</div>
            </CardContent>
          </Card>

          {/* 最佳联系时间 */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5" />
                最佳联系时间分析
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-green-500/10 rounded-lg p-4">
                  <div className="text-lg font-semibold text-green-500 mb-2">推荐发送时段</div>
                  <div className="text-sm">
                    {data?.bestContactTime?.bestHours?.map((hour: string, index: number) => (
                      <span key={index} className="inline-block bg-green-500/20 rounded px-2 py-1 mr-2 mb-2">
                        {hour}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">
                  {data?.bestContactTime?.recommendation || '暂无足够数据分析最佳联系时间'}
                </div>
                <div className="border-t pt-4">
                  <div className="grid grid-cols-3 gap-2">
                    <div className="text-center">
                      <div className="text-xs text-muted-foreground">上午黄金时段</div>
                      <div className="font-semibold">10:00-11:00</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-muted-foreground">下午黄金时段</div>
                      <div className="font-semibold">15:00-16:00</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-muted-foreground">避免时段</div>
                      <div className="font-semibold text-red-500">12:00-13:00</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}