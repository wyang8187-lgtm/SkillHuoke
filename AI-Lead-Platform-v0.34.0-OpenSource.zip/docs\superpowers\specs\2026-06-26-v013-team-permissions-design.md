# v0.13 Team Members And Permissions Design

## Goal

Turn the project from a single-user demo into a SaaS-like workspace with visible team members, role permissions, and data scope explanations.

## User Value

- 外贸老板可以看到团队里谁负责客户、谁能跑获客任务、谁能导出数据。
- 销售和运营角色被区分，方便后续真实 SaaS 做账号权限、客户分配和数据隔离。
- 页面不再依赖分散 mock 数据，团队成员、角色和权限由统一数据层维护。

## Scope

- Add shared team access model.
- Rewrite team member management page.
- Rewrite permissions matrix page.
- Rewrite team settings overview page.
- Update workspace display data, README, and package version.

## Out Of Scope

- Real email invitation delivery.
- Real database-backed account creation.
- Paid subscription billing.
- Server-side RBAC enforcement.

## Acceptance Criteria

- `/team` shows members, invite preview, role cards, and team metrics.
- `/team/permissions` shows role matrix and data scopes.
- `/settings/team` links team settings back to members and permissions.
- All visible Chinese text is clean.
- Type check, lint, and production build pass.
