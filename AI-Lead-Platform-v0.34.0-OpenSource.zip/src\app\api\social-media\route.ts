import { NextRequest, NextResponse } from 'next/server';

// 社媒获客模拟API
// 真实实现需要接入LinkedIn API、Facebook API等

interface SocialMediaUser {
  id: string;
  platform: string;
  name: string;
  company: string;
  title: string;
  location: string;
  profile_url: string;
  avatar_url: string;
  connection_count?: number;
  followers_count?: number;
  industry: string;
  is_verified: boolean;
  phone?: string;
  email?: string;
  last_active: string;
}

interface SocialMediaPost {
  id: string;
  platform: string;
  author_name: string;
  author_company: string;
  content: string;
  post_time: string;
  likes: number;
  comments: number;
  shares: number;
  post_url: string;
}

// 模拟LinkedIn用户数据
const mockLinkedInUsers: SocialMediaUser[] = [
  {
    id: 'li-001',
    platform: 'LinkedIn',
    name: '张伟',
    company: '深圳全屋定制设计工作室',
    title: '设计总监',
    location: '深圳',
    profile_url: 'https://linkedin.com/in/zhangwei',
    avatar_url: '/avatars/default.png',
    connection_count: 850,
    industry: '室内设计',
    is_verified: true,
    phone: '13800138001',
    email: 'zhangwei@design.com',
    last_active: '2024-01-20',
  },
  {
    id: 'li-002',
    platform: 'LinkedIn',
    name: '李芳',
    company: '广州建材外贸有限公司',
    title: '外贸经理',
    location: '广州',
    profile_url: 'https://linkedin.com/in/lifang',
    avatar_url: '/avatars/default.png',
    connection_count: 1200,
    industry: '外贸',
    is_verified: true,
    last_active: '2024-01-18',
  },
  {
    id: 'li-003',
    platform: 'LinkedIn',
    name: '王明',
    company: '佛山陶瓷出口公司',
    title: 'CEO',
    location: '佛山',
    profile_url: 'https://linkedin.com/in/wangming',
    avatar_url: '/avatars/default.png',
    connection_count: 3500,
    industry: '陶瓷出口',
    is_verified: true,
    phone: '13900139001',
    email: 'wangming@ceramics.com',
    last_active: '2024-01-22',
  },
  {
    id: 'li-004',
    platform: 'LinkedIn',
    name: '陈静',
    company: '东莞家具制造厂',
    title: '销售总监',
    location: '东莞',
    profile_url: 'https://linkedin.com/in/chenjing',
    avatar_url: '/avatars/default.png',
    connection_count: 650,
    industry: '家具制造',
    is_verified: false,
    last_active: '2024-01-15',
  },
];

// 模拟Facebook用户数据
const mockFacebookUsers: SocialMediaUser[] = [
  {
    id: 'fb-001',
    platform: 'Facebook',
    name: 'Mike Johnson',
    company: 'Pacific Home Design',
    title: 'Founder',
    location: 'Los Angeles, USA',
    profile_url: 'https://facebook.com/mikejohnson',
    avatar_url: '/avatars/default.png',
    followers_count: 15000,
    industry: 'Home Design',
    is_verified: true,
    last_active: '2024-01-21',
  },
  {
    id: 'fb-002',
    platform: 'Facebook',
    name: 'Sarah Chen',
    company: 'China Furniture Export',
    title: 'Marketing Manager',
    location: 'San Francisco, USA',
    profile_url: 'https://facebook.com/sarahchen',
    avatar_url: '/avatars/default.png',
    followers_count: 8500,
    industry: 'Furniture Export',
    is_verified: true,
    last_active: '2024-01-19',
  },
];

// GET - 社媒搜索
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('x-session');
    if (!authHeader) {
      return NextResponse.json({ error: '请先登录' }, { status: 401 });
    }

    const searchParams = request.nextUrl.searchParams;
    const platform = searchParams.get('platform') || 'all';
    const keyword = searchParams.get('keyword') || '';
    const industry = searchParams.get('industry') || '';
    const page = parseInt(searchParams.get('page') || '1');
    const pageSize = parseInt(searchParams.get('pageSize') || '10');

    let users = [...mockLinkedInUsers, ...mockFacebookUsers];

    if (platform === 'linkedin') {
      users = mockLinkedInUsers;
    } else if (platform === 'facebook') {
      users = mockFacebookUsers;
    }

    if (keyword) {
      const lowerKeyword = keyword.toLowerCase();
      users = users.filter(u =>
        u.name.toLowerCase().includes(lowerKeyword) ||
        u.company.toLowerCase().includes(lowerKeyword) ||
        u.title.toLowerCase().includes(lowerKeyword) ||
        u.location.toLowerCase().includes(lowerKeyword)
      );
    }

    if (industry) {
      users = users.filter(u => u.industry.toLowerCase().includes(industry.toLowerCase()));
    }

    const total = users.length;
    const startIndex = (page - 1) * pageSize;
    const endIndex = startIndex + pageSize;
    const data = users.slice(startIndex, endIndex);

    return NextResponse.json({
      success: true,
      data: data,
      pagination: {
        total,
        page,
        pageSize,
        totalPages: Math.ceil(total / pageSize),
      },
      platforms: [
        { name: 'LinkedIn', icon: 'linkedin', count: mockLinkedInUsers.length },
        { name: 'Facebook', icon: 'facebook', count: mockFacebookUsers.length },
      ],
      note: '当前为模拟数据，接入LinkedIn/Facebook API后可获取真实用户信息'
    });
  } catch (error) {
    return NextResponse.json({ error: '服务器错误' }, { status: 500 });
  }
}