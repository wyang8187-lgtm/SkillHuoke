import { NextRequest, NextResponse } from 'next/server';
import { searchLeadCandidates, type LeadSearchInput } from '@/lib/integrations/lead-search-provider';

function readString(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const input: LeadSearchInput = {
      product: readString(body.product),
      country: readString(body.country),
      customerType: readString(body.customerType),
      quantity: Number(body.quantity) || 10,
      provider: readString(body.provider) as LeadSearchInput['provider'],
      query: readString(body.query),
    };

    if (!input.product || !input.country || !input.customerType) {
      return NextResponse.json(
        { success: false, error: 'product, country and customerType are required' },
        { status: 400 }
      );
    }

    const result = await searchLeadCandidates(input);
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'lead search failed' },
      { status: 500 }
    );
  }
}
