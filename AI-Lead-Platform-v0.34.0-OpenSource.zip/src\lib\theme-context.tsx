'use client';

import React, { createContext, useContext, useEffect, useState } from 'react';

type Theme = 'dark' | 'light';

interface ThemeContextType {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// 暗色模式配色（当前主题）
export const darkTheme = {
  background: '#0f1419',
  backgroundAlt: '#1a1f2c',
  card: '#1a1f2c',
  cardAlt: '#0f1419',
  border: '#2d3548',
  textPrimary: '#f8fafc',
  textSecondary: '#94a3b8',
  textMuted: '#64748b',
  accent: '#3b82f6',
  accentAlt: '#1d4ed8',
  success: '#22c55e',
  warning: '#f97316',
  error: '#ef4444',
  inputBg: '#0f1419',
  inputBorder: '#2d3548',
  tableHeader: '#1a1f2c',
  tableRowAlt: '#131920',
  sidebarBg: '#0f1419',
  sidebarActive: '#1a1f2c',
};

// 亮色模式配色
export const lightTheme = {
  background: '#f5f7fa',
  backgroundAlt: '#ffffff',
  card: '#ffffff',
  cardAlt: '#f5f7fa',
  border: '#e2e8f0',
  textPrimary: '#1a1a2e',
  textSecondary: '#4a5568',
  textMuted: '#718096',
  accent: '#3b82f6',
  accentAlt: '#1d4ed8',
  success: '#22c55e',
  warning: '#f97316',
  error: '#ef4444',
  inputBg: '#ffffff',
  inputBorder: '#e2e8f0',
  tableHeader: '#f5f7fa',
  tableRowAlt: '#ffffff',
  sidebarBg: '#1a1a2e',
  sidebarActive: '#16213e',
};

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>('dark');
  const [mounted, setMounted] = useState(false);

  // 从localStorage读取主题偏好
  useEffect(() => {
    setMounted(true);
    const savedTheme = localStorage.getItem('theme') as Theme;
    if (savedTheme && (savedTheme === 'dark' || savedTheme === 'light')) {
      setTheme(savedTheme);
    } else {
      // 默认使用暗色模式
      setTheme('dark');
    }
  }, []);

  // 保存主题到localStorage
  useEffect(() => {
    if (mounted) {
      localStorage.setItem('theme', theme);
      // 更新document的class以便CSS使用
      document.documentElement.classList.remove('light', 'dark');
      document.documentElement.classList.add(theme);
    }
  }, [theme, mounted]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  // 避免服务端渲染时主题不一致
  if (!mounted) {
    return null;
  }

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
}

export { ThemeContext };