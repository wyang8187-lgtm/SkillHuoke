import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

// 风格配置
const styleConfigs = {
  formal: {
    name: '正式商务',
    description: '专业严谨，适合首次接触的大型客户',
    tone: '专业、礼貌、正式',
    greeting: '尊敬的',
    signature: '诚挚问候'
  },
  friendly: {
    name: '友好亲切',
    description: '轻松自然，适合建立长期关系',
    tone: '友好、热情、真诚',
    greeting: '您好',
    signature: '期待与您合作'
  },
  concise: {
    name: '简洁高效',
    description: '直接明了，适合已有一定了解的客户',
    tone: '简洁、直接、高效',
    greeting: '您好',
    signature: '祝好'
  }
};

// AI写信接口 - 自动生成专业的开发信邮件，支持多种风格
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { productDescription, customerType, customerName, style, portraitData } = body;

    if (!productDescription) {
      return NextResponse.json({ error: '请提供产品描述' }, { status: 400 });
    }

    // 获取风格配置
    const selectedStyle = styleConfigs[style as keyof typeof styleConfigs] || styleConfigs.formal;

    // 提取请求头用于转发
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    // 使用LLMClient调用AI模型
    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    const systemPrompt = `你是一个专业的商务邮件撰写专家，专门为全屋定制工厂撰写开发信。
目标客户群体：全案设计师、建材外贸公司。
你的任务是撰写专业、有吸引力的商务开发邮件。

邮件要求：
1. 主题简洁有力，引起客户兴趣（10-20字）
2. 正文风格：${selectedStyle.tone}
3. 针对不同客户类型调整内容侧重点：
   - 全案设计师：强调设计支持、案例合作、定制能力、服务响应
   - 建材外贸公司：强调出口品质、认证齐全、稳定供货、价格优势
4. 根据提供的客户画像数据，个性化定制内容
5. 问候语使用"${selectedStyle.greeting}"
6. 结尾包含明确的下一步行动引导
7. 签名使用"${selectedStyle.signature}"

返回JSON格式：
{
  "subject": "邮件主题",
  "greeting": "问候语",
  "opening": "开场白（1-2句）",
  "body": "邮件正文段落（3-4段，每段2-3句）",
  "highlight": "产品/服务亮点（列表形式）",
  "callToAction": "行动号召语",
  "signature": "签名",
  "estimatedReadTime": "预估阅读时间（秒）"
}`;

    const customerTypeText = customerType || '全案设计师';
    const customerNameText = customerName || '贵公司';
    
    // 构建用户消息
    let userMessage = `请为以下场景撰写一封开发信（${selectedStyle.name}风格）：

产品/服务描述：${productDescription}
目标客户类型：${customerTypeText}
客户名称：${customerNameText}
`;

    // 如果有画像数据，添加个性化信息
    if (portraitData) {
      userMessage += `
客户画像信息：
- 企业规模：${portraitData.companyProfile?.estimatedScale || '未知'}
- 主营产品：${portraitData.companyProfile?.mainProducts?.join('、') || '未知'}
- 合作意向：${portraitData.cooperationPotential?.level || '未知'} (${portraitData.cooperationPotential?.score || 0}分)
- 核心需求：${portraitData.keyNeeds?.join('、') || '未知'}
- 推荐渠道：${portraitData.recommendedApproach?.primaryChannel || '邮件'}

请根据以上画像信息，个性化定制邮件内容。
`;
    }

    userMessage += `
请生成专业的开发邮件内容。`;

    const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: userMessage }
    ];

    // 调用AI模型
    let parsedResult;
    try {
      const response = await client.invoke(messages, {
        model: 'doubao-seed-1-8-251228',
        temperature: style === 'friendly' ? 0.8 : 0.6, // 友好风格稍高温度
      });

      // 解析AI返回的JSON
      let content = response.content.trim();
      if (content.startsWith('```json')) {
        content = content.slice(7);
      }
      if (content.startsWith('```')) {
        content = content.slice(3);
      }
      if (content.endsWith('```')) {
        content = content.slice(0, -3);
      }
      content = content.trim();
      parsedResult = JSON.parse(content);
    } catch {
      // AI解析失败时，返回默认邮件
      const defaultBody = customerTypeText === '全案设计师' 
        ? `我们是一家专业的全屋定制工厂，拥有多年的设计服务经验。我们可以为您提供：

• 高品质定制产品：从橱柜到衣柜，满足各类定制需求
• 设计支持服务：配合设计方案，提供技术支持和样品
• 快速响应机制：专业的售后服务团队，确保项目顺利进行

近期我们与多位设计师成功合作，案例遍布大湾区各大城市。`
        : `我们是一家专业的建材出口企业，产品远销全球多个国家和地区。我们的优势包括：

• 出口品质保障：通过多项国际认证，品质稳定可靠
• 竞争力价格：规模化生产，为您提供有竞争力的报价
• 稳定供货能力：充足的产能储备，确保按时交付

我们已与多家外贸公司建立长期合作关系，期待与您携手开拓市场。`;

      parsedResult = {
        subject: '关于全屋定制合作机会',
        greeting: `${selectedStyle.greeting} ${customerNameText}`,
        opening: '感谢您抽出时间阅读这封信件。',
        body: defaultBody,
        highlight: customerTypeText === '全案设计师'
          ? ['设计支持服务', '案例合作经验', '快速响应机制', '高品质定制产品']
          : ['出口品质保障', '竞争力价格', '稳定供货能力', '国际认证齐全'],
        callToAction: '如果您有兴趣了解更多，我们可以安排一次线上会议详细探讨。',
        signature: selectedStyle.signature,
        estimatedReadTime: '60'
      };
    }

    // 组装完整邮件
    const fullEmail = {
      ...parsedResult,
      style: selectedStyle.name,
      styleDescription: selectedStyle.description,
      fullContent: `${parsedResult.greeting || '您好'}\n\n${parsedResult.opening || ''}\n\n${parsedResult.body || ''}\n\n${parsedResult.callToAction || '期待您的回复。'}\n\n${parsedResult.signature || '诚挚问候'}`,
      generatedAt: new Date().toISOString(),
      tips: [
        '建议在邮件中添加公司官网链接',
        '可以附上产品图册或案例图片',
        '首次发送建议选择工作日上午9-11点'
      ]
    };

    return NextResponse.json({
      success: true,
      data: fullEmail
    });

  } catch (error) {
    console.error('AI写信错误:', error);
    return NextResponse.json({ 
      error: 'AI写信失败，请稍后重试',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}