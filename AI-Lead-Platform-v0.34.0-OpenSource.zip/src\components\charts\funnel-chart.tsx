'use client';

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

interface FunnelData {
  stage: string;
  count: number;
  rate: number;
  fill: string;
}

interface FunnelChartProps {
  data: FunnelData[];
  title?: string;
}

const STAGE_COLORS: Record<string, string> = {
  '线索': '#3b82f6',
  '客户': '#22c55e',
  '商机': '#f97316',
  '成交': '#22c55e',
};

export function FunnelChart({ data, title = '转化漏斗' }: FunnelChartProps) {
  // 按数量降序排列形成漏斗效果
  const sortedData = [...data].sort((a, b) => b.count - a.count);
  
  return (
    <div className="bg-[#1a1f2c] rounded-lg p-4 border border-[#2d3548]">
      <h3 className="text-base font-semibold text-[#f8fafc] mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height={200}>
        <BarChart 
          data={sortedData} 
          layout="vertical" 
          margin={{ top: 5, right: 30, left: 60, bottom: 5 }}
        >
          <XAxis type="number" hide />
          <YAxis 
            type="category" 
            dataKey="stage" 
            stroke="#64748b" 
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#1a1f2c',
              border: '1px solid #2d3548',
              borderRadius: '8px',
              color: '#f8fafc',
            }}
            formatter={(value: number, name: string, props: unknown) => {
              const payload = (props as { payload: FunnelData }).payload;
              if (name === 'count') return [`${value} 个`, '数量'];
              if (name === 'rate') return [`${payload.rate}%`, '转化率'];
              return [value, name];
            }}
          />
          <Bar 
            dataKey="count" 
            radius={[0, 4, 4, 0]}
            barSize={24}
          >
            {sortedData.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={STAGE_COLORS[entry.stage] || '#3b82f6'}
                opacity={0.8 + (index * 0.05)}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      {/* 漏斗数据展示 */}
      <div className="mt-4 grid grid-cols-4 gap-2">
        {sortedData.map((item, index) => (
          <div key={index} className="text-center">
            <div className="text-xs text-[#64748b]">{item.stage}</div>
            <div className="text-lg font-bold text-[#f8fafc]">{item.count}</div>
            <div className="text-xs text-[#94a3b8]">{item.rate}%</div>
          </div>
        ))}
      </div>
    </div>
  );
}