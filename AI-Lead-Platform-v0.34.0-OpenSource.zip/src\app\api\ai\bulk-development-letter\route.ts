import { NextRequest, NextResponse } from 'next/server';

// 行业话术模板
const INDUSTRY_TEMPLATES: Record<string, {
  subject: string;
  greeting: string;
  intro: string;
  valueProp: string;
  callToAction: string;
  closing: string;
}> = {
  '建材外贸': {
    subject: '高品质建材出口合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专注于建材出口领域，为全球客户提供优质产品。',
    valueProp: '注意到贵司在建材出口领域有丰富经验，我们产品涵盖陶瓷、卫浴、五金等品类，价格竞争力强，品质稳定，可提供定制化服务。',
    callToAction: '期待与贵司探讨合作机会，如有需要样品或报价，欢迎随时联系。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '家具出口': {
    subject: '全屋定制家具出口合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产全屋定制家具，出口全球多个市场。',
    valueProp: '了解到贵司在家具出口领域深耕多年，我们的产品涵盖橱柜、衣柜、酒柜等全系列，采用优质板材和五金，可按客户需求定制。',
    callToAction: '期待有机会为贵司提供产品支持，欢迎索取产品目录和报价。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '全屋定制': {
    subject: '全屋定制家居方案合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的全屋定制顾问[姓名]，专注于为设计师和项目方提供一站式定制解决方案。',
    valueProp: '注意到贵司在全屋定制设计领域有卓越声誉，我们提供从设计深化到生产安装的全流程服务，配合度高，交付准时。',
    callToAction: '期待与贵司建立长期合作关系，欢迎安排时间详谈。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '橱柜衣柜': {
    subject: '橱柜衣柜定制生产合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的生产负责人[姓名]，我们专业生产橱柜衣柜，服务设计师和经销商群体。',
    valueProp: '了解到贵司在橱柜衣柜定制领域需求稳定，我们配备先进生产线，可承接大批量订单，价格合理，品质可靠。',
    callToAction: '期待成为贵司的优质供应商，欢迎索取样品和报价。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '陶瓷卫浴': {
    subject: '陶瓷卫浴产品出口合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产陶瓷卫浴产品，出口欧美、东南亚等市场。',
    valueProp: '注意到贵司在陶瓷卫浴领域有渠道优势，我们的产品涵盖马桶、浴室柜、淋浴房等，款式丰富，性价比高。',
    callToAction: '期待与贵司探讨合作机会，欢迎索取产品图册。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '五金配件': {
    subject: '高品质五金配件供应',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产家具五金配件，服务家具制造商和出口商。',
    valueProp: '了解到贵司在五金配件领域需求量大，我们的产品涵盖铰链、滑轨、拉手等全系列，品质对标国际品牌。',
    callToAction: '期待成为贵司的五金供应商，欢迎索取样品测试。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '照明灯饰': {
    subject: '照明灯饰产品合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产照明灯饰，涵盖家居照明和商业照明。',
    valueProp: '注意到贵司在灯饰领域有市场资源，我们的产品款式多样，可定制设计，品质稳定，价格合理。',
    callToAction: '期待与贵司建立合作关系，欢迎索取产品图册和报价。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '地板门窗': {
    subject: '地板门窗产品供应合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产地板和门窗产品，服务国内及海外客户。',
    valueProp: '了解到贵司在地板门窗领域有项目需求，我们的产品涵盖实木地板、复合地板、铝合金门窗等。',
    callToAction: '期待为贵司项目提供产品支持，欢迎索取样品。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '涂料化工': {
    subject: '环保涂料化工产品合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产环保涂料化工产品。',
    valueProp: '注意到贵司在涂料化工领域有采购需求，我们的产品涵盖水性涂料、木器涂料等，符合国际环保标准。',
    callToAction: '期待与贵司探讨合作机会，欢迎索取技术参数和报价。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '机械装备': {
    subject: '家具机械装备供应',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业提供家具生产机械装备。',
    valueProp: '了解到贵司在机械装备领域有需求，我们的产品涵盖切割机、封边机、钻孔机等全系列。',
    callToAction: '期待为贵司生产线提供设备支持，欢迎安排技术交流。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '纺织服装': {
    subject: '纺织服装产品合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产纺织服装产品，出口多个市场。',
    valueProp: '注意到贵司在纺织服装领域有渠道优势，我们的产品涵盖面料、辅料、成品服装等。',
    callToAction: '期待与贵司探讨合作机会，欢迎索取产品图册。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '家电出口': {
    subject: '家电产品出口合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专业生产家电产品，出口全球市场。',
    valueProp: '了解到贵司在家电出口领域有丰富经验，我们的产品涵盖小家电、厨电等系列。',
    callToAction: '期待成为贵司的家电供应商，欢迎索取产品目录。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '跨境电商': {
    subject: '跨境电商供应链合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的供应链负责人[姓名]，我们专注为跨境电商提供家居品类产品。',
    valueProp: '注意到贵司在跨境电商领域有运营优势，我们可提供稳定供货、小批量定制、快速发货等服务。',
    callToAction: '期待与贵司建立供应链合作关系，欢迎索取产品清单。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '进出口贸易': {
    subject: '进出口贸易合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们专注家居建材进出口贸易。',
    valueProp: '了解到贵司在进出口贸易领域有渠道资源，我们可提供稳定的产品供应和专业的贸易服务。',
    callToAction: '期待与贵司探讨贸易合作机会，欢迎进一步交流。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  },
  '国际物流': {
    subject: '国际物流服务合作',
    greeting: '尊敬的负责人您好，',
    intro: '我是来自[公司名]的业务负责人[姓名]，我们提供家居建材国际物流服务。',
    valueProp: '注意到贵司在国际物流领域有业务需求，我们可提供海运、空运、报关等一站式服务。',
    callToAction: '期待为贵司提供物流支持，欢迎询价。',
    closing: '祝商祺！[姓名] [电话] [邮箱]'
  }
};

// 默认模板
const DEFAULT_TEMPLATE = {
  subject: '业务合作邀约',
  greeting: '尊敬的负责人您好，',
  intro: '我是来自[公司名]的业务负责人[姓名]，专注家居建材领域。',
  valueProp: '了解到贵司在本行业有良好声誉，期待有机会与贵司建立合作关系。',
  callToAction: '欢迎随时联系沟通，期待您的回复。',
  closing: '祝商祺！[姓名] [电话] [邮箱]'
};

// 风格变体
const STYLE_VARIANTS: Record<string, (template: typeof DEFAULT_TEMPLATE) => typeof DEFAULT_TEMPLATE> = {
  '正式': (t) => ({ ...t, greeting: t.greeting, closing: `祝商祺！[姓名]\n联系电话：[电话]\n电子邮箱：[邮箱]` }),
  '友好': (t) => ({ ...t, greeting: '您好！', closing: `期待您的回复，祝工作顺利！\n[姓名] [电话]` }),
  '简洁': (t) => ({ 
    ...t, 
    greeting: '您好，',
    intro: '我是[公司名]的[姓名]，专注家居建材。',
    valueProp: '期待与贵司合作。',
    callToAction: '欢迎联系。',
    closing: '[姓名] [电话]'
  }),
  '详细': (t) => ({
    ...t,
    intro: `${t.intro}\n\n我们公司成立于[年份]，位于[地区]，拥有现代化生产厂房和专业技术团队，产品畅销国内外市场。`,
    valueProp: `${t.valueProp}\n\n我们的优势包括：\n1. 产品质量稳定，符合国际标准\n2. 价格竞争力强，批量订单更有优势\n3. 交付准时，售后服务完善\n4. 可按客户需求定制生产`
  })
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { 
      customerId,
      companyName,
      contactName,
      industry = '建材外贸',
      region = '佛山',
      companySize = '中型',
      style = '正式',
      senderName = '张经理',
      senderCompany = '广东某某家居有限公司',
      senderPhone = '13912345678',
      senderEmail = 'sales@example.com'
    } = body;
    
    // 获取行业模板
    const baseTemplate = INDUSTRY_TEMPLATES[industry] || DEFAULT_TEMPLATE;
    
    // 应用风格变体
    const styledTemplate = STYLE_VARIANTS[style]?.(baseTemplate) || baseTemplate;
    
    // 组合完整邮件内容
    const fullEmail = `${styledTemplate.greeting}

${styledTemplate.intro.replace('[公司名]', senderCompany).replace('[姓名]', senderName)}

${styledTemplate.valueProp}

${styledTemplate.callToAction}

${styledTemplate.closing.replace('[姓名]', senderName).replace('[电话]', senderPhone).replace('[邮箱]', senderEmail)}`;
    
    // WhatsApp版本（更简洁）
    const whatsappMessage = `您好！我是${senderCompany}的${senderName}。

我们专注${industry}领域，产品品质稳定、价格合理。

期待与贵司建立合作关系，欢迎随时联系：${senderPhone}`;
    
    // 返回结果
    return NextResponse.json({
      success: true,
      data: {
        customerId,
        companyName,
        contactName,
        industry,
        region,
        companySize,
        emailContent: {
          subject: styledTemplate.subject,
          body: fullEmail
        },
        whatsappContent: whatsappMessage,
        metadata: {
          templateUsed: industry,
          styleUsed: style,
          generatedAt: new Date().toISOString()
        }
      },
      note: '当前为基于行业模板生成的开发信，接入AI大模型后可生成更个性化的内容'
    });
    
  } catch (error) {
    console.error('Generate development letter error:', error);
    return NextResponse.json(
      { success: false, error: '生成开发信失败' },
      { status: 500 }
    );
  }
}