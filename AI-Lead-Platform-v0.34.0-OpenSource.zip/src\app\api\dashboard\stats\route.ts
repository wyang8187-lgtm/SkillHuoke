import { NextRequest, NextResponse } from 'next/server';
import { demoWorkspace } from '@/lib/workspace';

function getDemoDashboardStats() {
  return {
    workspaceId: demoWorkspace.id,
    workspace: demoWorkspace,
    totalCustomers: 128,
    totalLeads: 346,
    totalOpportunities: 42,
    totalTasks: 18,
    todayNewLeads: 16,
    followingCustomers: 39,
    closedCustomers: 12,
    conversionRate: 9,
    pendingTasks: 7,
    totalOpportunityAmount: 680,
    wonAmount: 126,
    monthNewCustomers: 26,
    monthNewLeads: 118,
    monthOpportunityAmount: 68,
    monthWonAmount: 13,
    lastMonthNewCustomers: 18,
    lastMonthNewLeads: 92,
    lastMonthOpportunityAmount: 51,
    lastMonthConversionRate: 7,
    weeklyLeads: [
      { date: '06-20', count: 18 },
      { date: '06-21', count: 22 },
      { date: '06-22', count: 19 },
      { date: '06-23', count: 31 },
      { date: '06-24', count: 27 },
      { date: '06-25', count: 35 },
      { date: '06-26', count: 16 },
    ],
    customersByType: [
      { type: 'Builder', count: 42 },
      { type: 'Designer', count: 36 },
      { type: 'Kitchen Company', count: 31 },
      { type: 'Importer', count: 19 },
    ],
    customersByRegion: [
      { region: 'Australia', count: 68 },
      { region: 'United States', count: 44 },
      { region: 'New Zealand', count: 16 },
    ],
    gradeStats: { A: 24, B: 48, C: 42, D: 14 },
    recentActivities: [],
    recommendedFollowUps: [
      {
        customerId: 'demo-1',
        customerName: 'Sydney Custom Kitchens',
        customerType: 'Kitchen Company',
        grade: 'A',
        status: '待核验',
        lastFollowUpTime: null,
        nextFollowUpTime: null,
        score: 92,
        reason: '官网、业务类型和厨房定制关键词匹配度高，建议优先核验采购或项目负责人。',
        suggestedAction: '先查 LinkedIn 联系人，再发送首次开发信。',
      },
      {
        customerId: 'demo-2',
        customerName: 'Melbourne Builder Group',
        customerType: 'Builder',
        grade: 'B',
        status: '新线索',
        lastFollowUpTime: null,
        nextFollowUpTime: null,
        score: 81,
        reason: '项目承包商属性明显，适合推荐橱柜、衣柜和木门配套供应。',
        suggestedAction: '优先通过官网表单和电话确认采购窗口。',
      },
      {
        customerId: 'demo-3',
        customerName: 'Brisbane Interior Studio',
        customerType: 'Designer',
        grade: 'B',
        status: '资料待补全',
        lastFollowUpTime: null,
        nextFollowUpTime: null,
        score: 78,
        reason: '设计类客户适合切入项目合作，但联系人和邮箱需要进一步补全。',
        suggestedAction: '搜索设计总监或项目经理，补全邮箱后再开发。',
      },
    ],
    growthTrendData: [
      { date: '第1周', customers: 8, leads: 31 },
      { date: '第2周', customers: 11, leads: 44 },
      { date: '第3周', customers: 15, leads: 52 },
      { date: '第4周', customers: 19, leads: 63 },
    ],
    typeDistributionData: [
      { name: 'Builder', value: 42, color: '#3b82f6' },
      { name: 'Designer', value: 36, color: '#f97316' },
      { name: 'Kitchen Company', value: 31, color: '#22c55e' },
      { name: 'Importer', value: 19, color: '#8b5cf6' },
    ],
    regionDistributionData: [
      { region: 'Australia', designers: 20, traders: 48 },
      { region: 'United States', designers: 16, traders: 28 },
      { region: 'New Zealand', designers: 6, traders: 10 },
    ],
    funnelData: [
      { stage: '线索', count: 346, rate: 100, fill: '#3b82f6' },
      { stage: '客户', count: 128, rate: 37, fill: '#22c55e' },
      { stage: '商机', count: 42, rate: 33, fill: '#f97316' },
      { stage: '成交', count: 12, rate: 29, fill: '#22c55e' },
    ],
    stageDistributionData: [
      { stage: '新线索', count: 18, amount: 180 },
      { stage: '已核验', count: 12, amount: 230 },
      { stage: '报价中', count: 8, amount: 190 },
      { stage: '已成交', count: 4, amount: 80 },
    ],
  };
}

export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');
  const data = getDemoDashboardStats();

  if (token === 'demo-session' || process.env.AI_LEAD_PLATFORM_DEMO_MODE === 'true') {
    return NextResponse.json(data);
  }

  return NextResponse.json({
    ...data,
    demoNotice: '当前未配置 Supabase，已返回演示数据。',
  });
}
