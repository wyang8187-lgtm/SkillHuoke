'use client';

import React from 'react';

export default function AcquisitionChannelsPage() {
  return null;
}