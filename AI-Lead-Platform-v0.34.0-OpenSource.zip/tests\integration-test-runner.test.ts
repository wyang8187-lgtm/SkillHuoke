import assert from 'node:assert/strict';
import {
  mapIntegrationError,
  runIntegrationTest,
} from '../src/lib/integration-test-runner';

async function main() {
  assert.equal(mapIntegrationError(401).category, 'invalid_key');
  assert.equal(mapIntegrationError(403).category, 'permission_denied');
  assert.equal(mapIntegrationError(429).category, 'rate_limited');
  assert.equal(mapIntegrationError(500).category, 'service_error');

  const missing = await runIntegrationTest('openai', {}, async () => {
    throw new Error('fetch should not run');
  });
  assert.equal(missing.status, 'unconfigured');
  assert.equal(missing.category, 'missing_config');

  const unknown = await runIntegrationTest('bad-service', {}, async () => {
    throw new Error('fetch should not run');
  });
  assert.equal(unknown.status, 'failed');
  assert.equal(unknown.category, 'unknown');

  let requestedUrl = '';
  let requestedAuth = '';
  const success = await runIntegrationTest(
    'openai',
    { OPENAI_API_KEY: 'sk-secret-value' },
    async (input, init) => {
      requestedUrl = String(input);
      requestedAuth = String((init?.headers as Record<string, string>)?.Authorization || '');
      return new Response(JSON.stringify({ data: [] }), { status: 200 });
    }
  );
  assert.equal(success.status, 'success');
  assert.equal(requestedUrl, 'https://api.openai.com/v1/models');
  assert.equal(requestedAuth, 'Bearer sk-secret-value');
  assert.equal(JSON.stringify(success).includes('sk-secret-value'), false);

  const googleFailure = await runIntegrationTest(
    'google-search',
    { GOOGLE_SEARCH_API_KEY: 'google-secret', GOOGLE_SEARCH_CX: 'cx-secret' },
    async () => new Response(JSON.stringify({ error: { message: 'API key not valid' } }), { status: 401 })
  );
  assert.equal(googleFailure.status, 'failed');
  assert.equal(googleFailure.category, 'invalid_key');
  assert.equal(JSON.stringify(googleFailure).includes('google-secret'), false);

  const timeout = await runIntegrationTest(
    'resend',
    { RESEND_API_KEY: 're-secret', RESEND_FROM_EMAIL: 'sales@example.com' },
    async () => {
      throw new DOMException('The operation was aborted', 'AbortError');
    }
  );
  assert.equal(timeout.category, 'timeout');
  assert.match(timeout.suggestion, /网络/);

  console.log('integration-test-runner tests passed');
}

main();
