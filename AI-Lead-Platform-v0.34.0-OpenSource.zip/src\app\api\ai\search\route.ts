import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

// 手机号验证函数 - 只接受真实手机号（13x/15x/18x/19x开头），过滤座机
function isValidMobilePhone(phone: string): boolean {
  // 中国手机号格式：1开头，第二位是3-9，共11位
  const mobileRegex = /^1[3-9]\d{9}$/;
  return mobileRegex.test(phone);
}

// 根据解析意图生成模拟搜索结果
function generateMockSearchResults(parsedIntent: {
  region: string;
  industry: string;
  customerType: string;
  keywords: string[];
}): Array<{
  id: string;
  companyName: string;
  contactName: string;
  phone: string;
  address: string;
  customerType: string;
  matchScore: number;
  source: string;
  verified: boolean;
}> {
  const region = parsedIntent.region || '深圳';
  const customerType = parsedIntent.customerType || '全案设计师';
  
  // 模拟公司名称库
  const designerCompanies = [
    '创意空间设计工作室', '筑梦室内设计有限公司', '雅居全案设计中心',
    '星艺装饰设计公司', '美家设计工作室', '东方设计事务所',
    '筑美设计研究院', '艺境设计工作室', '尚品设计公司',
    '优筑设计中心', '筑道设计工作室', '艺筑设计有限公司'
  ];
  
  const tradingCompanies = [
    '宏达建材贸易有限公司', '盈科建材出口有限公司', '鑫源建材外贸公司',
    '恒信建材进出口有限公司', '博远建材贸易公司', '万通建材外贸有限公司',
    '华建材国际贸易公司', '建材之星贸易有限公司', '建材全球贸易中心',
    '鑫建材出口有限公司', '建材世界贸易公司', '建材先锋外贸有限公司'
  ];
  
  // 常见姓氏
  const surnames = ['王', '李', '张', '刘', '陈', '杨', '黄', '赵', '周', '吴', '郑', '孙'];
  const givenNames = ['伟', '芳', '娜', '敏', '静', '丽', '强', '磊', '洋', '艳', '勇', '军'];
  
  // 生成5-12个结果
  const count = Math.floor(Math.random() * 8) + 5;
  const results = [];
  
  const companies = customerType === '建材外贸公司' ? tradingCompanies : designerCompanies;
  
  for (let i = 0; i < count; i++) {
    // 生成真实手机号格式（13x-19x）
    const phonePrefixes = ['138', '139', '150', '151', '152', '158', '159', '186', '187', '188', '189', '199'];
    const prefix = phonePrefixes[Math.floor(Math.random() * phonePrefixes.length)];
    const phoneSuffix = Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
    const phone = prefix + phoneSuffix;
    
    // 确保手机号有效
    if (!isValidMobilePhone(phone)) continue;
    
    const companyIndex = Math.floor(Math.random() * companies.length);
    const surnameIndex = Math.floor(Math.random() * surnames.length);
    const givenNameIndex = Math.floor(Math.random() * givenNames.length);
    
    // 地址组合
    const districts = ['福田区', '南山区', '龙岗区', '宝安区', '罗湖区', '龙华区', '光明区'];
    const district = districts[Math.floor(Math.random() * districts.length)];
    const streetNum = Math.floor(Math.random() * 100) + 1;
    
    results.push({
      id: `search_${Date.now()}_${i}`,
      companyName: companies[companyIndex],
      contactName: surnames[surnameIndex] + givenNames[givenNameIndex],
      phone: phone,
      address: `${region}${district}某路${streetNum}号`,
      customerType: customerType,
      matchScore: Math.floor(Math.random() * 30) + 70, // 70-99分
      source: '企业数据库',
      verified: Math.random() > 0.3, // 70%已验证
    });
  }
  
  // 按匹配度排序
  return results.sort((a, b) => b.matchScore - a.matchScore);
}

// AI智能搜索接口 - 理解用户搜索意图，返回模拟搜索结果
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { keyword } = body;

    if (!keyword) {
      return NextResponse.json({ error: '请提供搜索关键词' }, { status: 400 });
    }

    // 提取请求头用于转发
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);

    // 使用LLMClient调用AI模型
    const config = new Config();
    const client = new LLMClient(config, customHeaders);

    const systemPrompt = `你是一个智能获客助手，专门帮助全屋定制工厂寻找客户（全案设计师、建材外贸公司）。
请分析用户搜索意图，提取以下信息并以JSON格式返回：
1. region: 目标地区（如"深圳"、"佛山"、"广州"、"东莞"等大湾区城市）
2. industry: 行业类型（如"全案设计师"、"建材外贸"、"室内设计"等）
3. customerType: 客户类型，只能是 "全案设计师" 或 "建材外贸公司" 或 "未知"
4. keywords: 搜索关键词数组（提取核心关键词，最多5个）
5. searchStrategy: 搜索策略建议（一句话说明如何搜索这类客户）

只返回JSON，不要其他内容。示例：
{"region":"深圳","industry":"全案设计","customerType":"全案设计师","keywords":["深圳","全案设计师","设计工作室"],"searchStrategy":"建议搜索深圳地区的设计工作室和装修公司"}`;

    const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
      { role: 'system', content: systemPrompt },
      { role: 'user', content: `用户输入搜索关键词："${keyword}"` }
    ];

    // 调用AI模型（使用豆包模型，适合中文场景）
    let parsedResult;
    try {
      const response = await client.invoke(messages, {
        model: 'doubao-seed-1-8-251228',
        temperature: 0.3,
      });

      // 解析AI返回的JSON
      let content = response.content.trim();
      if (content.startsWith('```json')) {
        content = content.slice(7);
      }
      if (content.startsWith('```')) {
        content = content.slice(3);
      }
      if (content.endsWith('```')) {
        content = content.slice(0, -3);
      }
      content = content.trim();
      parsedResult = JSON.parse(content);
    } catch {
      // AI解析失败时，使用默认值
      parsedResult = {
        region: keyword.includes('深圳') ? '深圳' : 
                keyword.includes('佛山') ? '佛山' : 
                keyword.includes('广州') ? '广州' : 
                keyword.includes('东莞') ? '东莞' : '大湾区',
        industry: keyword.includes('设计师') ? '全案设计' : 
                  keyword.includes('外贸') ? '建材外贸' : '建材行业',
        customerType: keyword.includes('设计师') ? '全案设计师' : 
                      keyword.includes('外贸') ? '建材外贸公司' : '未知',
        keywords: keyword.split(/\s+/).filter((k: string) => k.length > 0),
        searchStrategy: '建议通过设计平台、展会名录、行业协会等渠道获取联系方式',
      };
    }

    // 生成模拟搜索结果
    const mockResults = generateMockSearchResults(parsedResult);

    return NextResponse.json({
      success: true,
      parsed: parsedResult,
      results: mockResults,
      total: mockResults.length,
    });

  } catch (error) {
    console.error('AI搜索错误:', error);
    return NextResponse.json({ 
      error: 'AI搜索失败，请稍后重试',
      details: error instanceof Error ? error.message : '未知错误'
    }, { status: 500 });
  }
}