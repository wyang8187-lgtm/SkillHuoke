'use client';

import React from 'react';
import { MainLayout } from '@/components/layout';
import CustomersListPage from './list/page';

export default function CustomersPage() {
  return <CustomersListPage />;
}