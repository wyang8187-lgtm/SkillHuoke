'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  addSavedCrmFollowUp,
  crmCustomerStatusOptions,
  crmFollowUpChannelOptions,
  deleteSavedCrmFollowUp,
  generateCustomerOutreachCopy,
  getCrmCustomerStatusMeta,
  getSavedCrmCustomer,
  loadSavedCrmFollowUps,
  updateSavedCrmCustomer,
  type CrmCustomerStatus,
  type CrmFollowUpChannel,
  type SavedCrmCustomer,
  type SavedCrmFollowUp,
} from '@/lib/lead-wizard';
import type { OutreachContentType, OutreachTone } from '@/lib/integrations/openai-provider';
import {
  ArrowLeft,
  Building2,
  CalendarClock,
  Check,
  Clipboard,
  ExternalLink,
  Loader2,
  Mail,
  MessageCircle,
  Phone,
  Send,
  Sparkles,
  Trash2,
} from 'lucide-react';

interface AiOutreachResult {
  source: 'openai' | 'fallback';
  subject: string;
  content: string;
  reason?: string;
  model?: string;
  generatedAt: string;
}

const contentTypeOptions: Array<{ value: OutreachContentType; label: string }> = [
  { value: 'first_email', label: '首次开发信' },
  { value: 'follow_up_email', label: '二次跟进邮件' },
  { value: 'whatsapp', label: 'WhatsApp' },
  { value: 'linkedin', label: 'LinkedIn 私信' },
];

const toneOptions: Array<{ value: OutreachTone; label: string }> = [
  { value: 'professional', label: '专业' },
  { value: 'concise', label: '简洁' },
  { value: 'friendly', label: '友好' },
];

const channelIcons = {
  email: Mail,
  whatsapp: MessageCircle,
  linkedin: Send,
  phone: Phone,
  note: Clipboard,
};

function toLocalDateTimeInput(date = new Date()) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60_000).toISOString().slice(0, 16);
}

export default function CrmCustomerDetailPage() {
  const params = useParams<{ id: string }>();
  const customerId = decodeURIComponent(params.id);
  const [customer, setCustomer] = useState<SavedCrmCustomer>();
  const [followUps, setFollowUps] = useState<SavedCrmFollowUp[]>([]);
  const [channel, setChannel] = useState<CrmFollowUpChannel>('email');
  const [followUpContent, setFollowUpContent] = useState('');
  const [contactedAt, setContactedAt] = useState(() => toLocalDateTimeInput());
  const [error, setError] = useState('');
  const [copied, setCopied] = useState('');
  const [contentType, setContentType] = useState<OutreachContentType>('first_email');
  const [tone, setTone] = useState<OutreachTone>('professional');
  const [aiResult, setAiResult] = useState<AiOutreachResult>();
  const [isGenerating, setIsGenerating] = useState(false);

  const refresh = () => {
    setCustomer(getSavedCrmCustomer(customerId));
    setFollowUps(loadSavedCrmFollowUps().filter((item) => item.customerId === customerId));
  };

  useEffect(() => {
    refresh();
    // customerId is the only external value used by refresh.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerId]);

  const localOutreach = useMemo(
    () => (customer ? generateCustomerOutreachCopy(customer) : undefined),
    [customer]
  );

  const displayedOutreach = useMemo(() => {
    if (aiResult) return aiResult;
    if (!localOutreach) return undefined;
    if (contentType === 'whatsapp' || contentType === 'linkedin') {
      return {
        source: 'fallback' as const,
        subject: '',
        content: localOutreach.whatsappMessage,
        reason: '尚未请求 OpenAI，当前显示本地模板。',
        generatedAt: '',
      };
    }
    return {
      source: 'fallback' as const,
      subject: localOutreach.emailSubject,
      content: localOutreach.emailBody,
      reason: '尚未请求 OpenAI，当前显示本地模板。',
      generatedAt: '',
    };
  }, [aiResult, contentType, localOutreach]);

  const updateCustomer = (
    patch: Partial<Pick<SavedCrmCustomer, 'status' | 'note' | 'nextAction' | 'nextFollowUpAt'>>
  ) => {
    updateSavedCrmCustomer(customerId, patch);
    refresh();
  };

  const addFollowUp = () => {
    if (!followUpContent.trim()) {
      setError('请填写本次跟进内容。');
      return;
    }
    addSavedCrmFollowUp(customerId, {
      channel,
      content: followUpContent,
      contactedAt: new Date(contactedAt).toISOString(),
    });
    setFollowUpContent('');
    setContactedAt(toLocalDateTimeInput());
    setError('');
    refresh();
  };

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      window.setTimeout(() => setCopied(''), 1800);
    } catch {
      setError('复制失败，请手动选择文字复制。');
    }
  };

  const generateAiOutreach = async () => {
    if (!customer) return;
    setIsGenerating(true);
    setError('');

    try {
      const response = await fetch('/api/integrations/openai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task: 'generate_customer_outreach',
          context: {
            company: customer.company,
            country: customer.country,
            city: customer.city,
            customerType: customer.customerType,
            score: customer.score,
            priority: customer.priority,
            contactStatus: customer.contactStatus,
            note: customer.note,
            nextAction: customer.nextAction,
            contactName: customer.contactName,
            contactTitle: customer.contactTitle,
            email: customer.email,
            product: 'custom cabinetry, wardrobes, interior doors, and furniture',
            contentType,
            tone,
          },
        }),
      });
      const result = await response.json() as {
        success?: boolean;
        source?: 'openai' | 'fallback';
        subject?: string;
        content?: string;
        reason?: string;
        model?: string;
        error?: string;
      };

      if (!response.ok || !result.success || !result.source || !result.content) {
        throw new Error(result.error || 'AI 开发内容生成失败。');
      }

      setAiResult({
        source: result.source,
        subject: result.subject || '',
        content: result.content,
        reason: result.reason,
        model: result.model,
        generatedAt: new Date().toLocaleString('zh-CN'),
      });
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'AI 开发内容生成失败。');
    } finally {
      setIsGenerating(false);
    }
  };

  if (!customer) {
    return (
      <MainLayout title="客户详情">
        <Card className="border-[#2d3548] bg-[#121823]">
          <CardContent className="p-10 text-center">
            <Building2 className="mx-auto h-10 w-10 text-[#64748b]" />
            <h2 className="mt-4 text-xl font-semibold text-[#f8fafc]">没有找到这个客户</h2>
            <p className="mt-2 text-sm text-[#94a3b8]">客户可能已被删除，或者当前浏览器还没有保存该客户。</p>
            <Button asChild className="mt-6 bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/crm-customers">返回 CRM 客户池</Link>
            </Button>
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  const status = getCrmCustomerStatusMeta(customer.status);

  return (
    <MainLayout title="客户跟进中心">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <Link href="/crm-customers" className="inline-flex items-center text-sm text-blue-300 hover:text-blue-200">
            <ArrowLeft className="mr-2 h-4 w-4" />返回 CRM 客户池
          </Link>
          <div className="mt-5 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className={`border ${status.className}`}>{status.label}</Badge>
                <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{customer.priority} 级客户</Badge>
                <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">{customer.score} 分</Badge>
              </div>
              <h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">{customer.company}</h2>
              <p className="mt-2 text-sm text-blue-300">
                主要联系人：{customer.contactName || '待补全'}{customer.contactTitle ? ` · ${customer.contactTitle}` : ''}
              </p>
              <p className="mt-1 text-xs text-[#94a3b8]">
                {customer.email || customer.whatsapp || customer.phone || customer.linkedin || '联系方式待补全'}
              </p>
              <p className="mt-2 text-sm text-[#94a3b8]">{customer.country} / {customer.city} · {customer.customerType}</p>
            </div>
            {customer.website ? (
              <Button asChild variant="outline" className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]">
                <a href={customer.website} target="_blank" rel="noreferrer">打开公司官网<ExternalLink className="ml-2 h-4 w-4" /></a>
              </Button>
            ) : null}
            <Button asChild variant="outline" className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]">
              <Link href={`/crm-customers/${encodeURIComponent(customer.id)}/edit`}>编辑资料</Link>
            </Button>
          </div>
        </section>

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(360px,0.8fr)]">
          <div className="space-y-6">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader><CardTitle className="text-[#f8fafc]">客户资料</CardTitle></CardHeader>
              <CardContent className="grid gap-4 sm:grid-cols-2">
                {[
                  ['官网', customer.website || '待补全'],
                  ['联系方式', customer.contactStatus || '待核验'],
                  ['客户类型', customer.customerType],
                  ['来源任务', customer.sourceTaskTitle],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                    <p className="text-xs text-[#64748b]">{label}</p>
                    <p className="mt-2 break-words text-sm text-[#cbd5e1]">{value}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader><CardTitle className="text-[#f8fafc]">新增跟进记录</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Select value={channel} onValueChange={(value) => setChannel(value as CrmFollowUpChannel)}>
                    <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {crmFollowUpChannelOptions.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}
                    </SelectContent>
                  </Select>
                  <Input type="datetime-local" value={contactedAt} onChange={(event) => setContactedAt(event.target.value)} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" />
                </div>
                <Textarea value={followUpContent} onChange={(event) => setFollowUpContent(event.target.value)} placeholder="记录本次沟通结果和客户反馈。" className="min-h-28 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" />
                <Button type="button" onClick={addFollowUp} className="bg-blue-600 text-white hover:bg-blue-500">
                  <Send className="mr-2 h-4 w-4" />保存跟进记录
                </Button>
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader><CardTitle className="text-[#f8fafc]">跟进时间线</CardTitle></CardHeader>
              <CardContent>
                {followUps.length === 0 ? (
                  <p className="rounded-lg border border-dashed border-[#2d3548] bg-[#0f1419] p-6 text-center text-sm text-[#94a3b8]">还没有跟进记录。</p>
                ) : (
                  <div className="space-y-3">
                    {followUps.map((item) => {
                      const Icon = channelIcons[item.channel];
                      return (
                        <div key={item.id} className="flex gap-3 rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-blue-500/15 text-blue-300"><Icon className="h-4 w-4" /></div>
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <p className="text-sm font-medium text-[#f8fafc]">{crmFollowUpChannelOptions.find((option) => option.value === item.channel)?.label}</p>
                              <p className="text-xs text-[#64748b]">{new Date(item.contactedAt).toLocaleString('zh-CN')}</p>
                            </div>
                            <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-[#cbd5e1]">{item.content}</p>
                          </div>
                          <Button type="button" size="icon" variant="ghost" title="删除记录" className="shrink-0 text-[#64748b] hover:text-red-300" onClick={() => setFollowUps(deleteSavedCrmFollowUp(item.id).filter((entry) => entry.customerId === customerId))}>
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader><CardTitle className="flex items-center gap-2 text-[#f8fafc]"><CalendarClock className="h-5 w-5 text-amber-300" />跟进安排</CardTitle></CardHeader>
              <CardContent className="space-y-4">
                <Select value={customer.status} onValueChange={(value) => updateCustomer({ status: value as CrmCustomerStatus })}>
                  <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger>
                  <SelectContent>{crmCustomerStatusOptions.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}</SelectContent>
                </Select>
                <Input type="datetime-local" value={customer.nextFollowUpAt || ''} onChange={(event) => updateCustomer({ nextFollowUpAt: event.target.value })} className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" />
                <Textarea value={customer.nextAction} onChange={(event) => updateCustomer({ nextAction: event.target.value })} className="min-h-20 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" placeholder="下一步动作" />
                <Textarea value={customer.note} onChange={(event) => updateCustomer({ note: event.target.value })} className="min-h-20 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]" placeholder="客户备注" />
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <CardTitle className="flex items-center gap-2 text-[#f8fafc]"><Sparkles className="h-5 w-5 text-violet-300" />AI 开发助手</CardTitle>
                  {displayedOutreach ? (
                    <Badge className={displayedOutreach.source === 'openai' ? 'border-violet-500/25 bg-violet-500/15 text-violet-300' : 'border-amber-500/25 bg-amber-500/15 text-amber-300'}>
                      {displayedOutreach.source === 'openai' ? `OpenAI${displayedOutreach.model ? ` · ${displayedOutreach.model}` : ''}` : '本地模板'}
                    </Badge>
                  ) : null}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="mb-2 block text-sm text-[#cbd5e1]">内容类型</label>
                    <Select value={contentType} onValueChange={(value) => { setContentType(value as OutreachContentType); setAiResult(undefined); }}>
                      <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger>
                      <SelectContent>{contentTypeOptions.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="mb-2 block text-sm text-[#cbd5e1]">语气</label>
                    <Select value={tone} onValueChange={(value) => { setTone(value as OutreachTone); setAiResult(undefined); }}>
                      <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><SelectValue /></SelectTrigger>
                      <SelectContent>{toneOptions.map((option) => <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>

                <Button type="button" onClick={generateAiOutreach} disabled={isGenerating} className="w-full bg-violet-600 text-white hover:bg-violet-500">
                  {isGenerating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Sparkles className="mr-2 h-4 w-4" />}
                  {isGenerating ? '正在生成...' : aiResult ? '重新生成' : '生成个性化内容'}
                </Button>

                {error ? <p className="rounded-md border border-red-500/25 bg-red-500/10 p-3 text-sm text-red-200">{error}</p> : null}
                {displayedOutreach?.reason ? <p className="text-xs leading-5 text-amber-200">{displayedOutreach.reason}</p> : null}
                {displayedOutreach?.generatedAt ? <p className="text-xs text-[#64748b]">生成时间：{displayedOutreach.generatedAt}</p> : null}

                {displayedOutreach?.subject ? (
                  <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs text-[#64748b]">邮件主题</p>
                      <Button type="button" size="sm" variant="ghost" className="text-[#94a3b8]" onClick={() => copyText('subject', displayedOutreach.subject)}>
                        {copied === 'subject' ? <Check className="mr-2 h-4 w-4" /> : <Clipboard className="mr-2 h-4 w-4" />}{copied === 'subject' ? '已复制' : '复制'}
                      </Button>
                    </div>
                    <p className="mt-2 text-sm font-medium text-blue-300">{displayedOutreach.subject}</p>
                  </div>
                ) : null}

                {displayedOutreach ? (
                  <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-xs text-[#64748b]">英文正文</p>
                      <Button type="button" size="sm" variant="ghost" className="text-[#94a3b8]" onClick={() => copyText('content', displayedOutreach.content)}>
                        {copied === 'content' ? <Check className="mr-2 h-4 w-4" /> : <Clipboard className="mr-2 h-4 w-4" />}{copied === 'content' ? '已复制' : '复制'}
                      </Button>
                    </div>
                    <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-[#cbd5e1]">{displayedOutreach.content}</p>
                  </div>
                ) : null}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
