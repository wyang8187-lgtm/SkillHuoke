import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.19.0',
  title: '候选客户池管理',
  date: '2026-06-26',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.19.0-OpenSource.zip',
  githubRemark: 'v0.19.0：新增候选客户池管理和加入客户池预览',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '新增候选客户池页面，可管理任务执行台沉淀出的候选客户。',
  '支持按 A/B/C 级筛选候选客户，并标记优先开发、需要核验、暂缓开发、已加入客户池。',
  '任务执行台新增“沉淀到候选池”动作，形成获客向导到候选池的闭环。',
  '版本体验中心继续保留登录方式、重点查看页面、上传包和 GitHub 备注。',
];

export const releaseReviewPages = [
  {
    title: '版本体验中心',
    href: '/release',
    description: '先看这里，确认当前版本、登录方式、演示身份、上传包和 GitHub 备注。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和数量，生成方案并保存为任务。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '管理任务执行结果，筛选 A/B/C 级客户，标记状态并模拟加入客户池。',
  },
  {
    title: '获客任务记录',
    href: '/lead-tasks',
    description: '查看已保存任务，更新状态，导出 TXT，继续进入执行台。',
  },
  {
    title: '新手运营引导',
    href: '/onboarding',
    description: '查看外贸老板第一次使用系统时的 6 步运营流程和获客任务向导预览。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '查看演示模式入口和四种角色说明。',
  },
  {
    title: '团队管理',
    href: '/team',
    description: '检查 v0.13.0 新增的成员、角色和工作量展示。',
  },
  {
    title: '权限矩阵',
    href: '/team/permissions',
    description: '检查老板、管理员、销售、运营的权限差异。',
  },
  {
    title: '团队设置',
    href: '/settings/team',
    description: '检查 SaaS 团队设置入口和后续接入清单。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '看自己负责的客户、CRM 跟进和开发信流程。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '看批量获客任务、线索核验、模板和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '进入版本体验中心，按页面列出的入口逐个查看。',
  '确认本次版本功能、GitHub 备注和上传包名称。',
  '上传压缩包到开源仓库，并使用版本备注作为提交说明。',
];
