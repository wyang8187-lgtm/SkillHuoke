import { NextRequest, NextResponse } from 'next/server';
import { runOpenAITask, type OpenAIInput, type OpenAITask } from '@/lib/integrations/openai-provider';

const allowedTasks = new Set<OpenAITask>([
  'write_email',
  'write_whatsapp',
  'score_lead',
  'summarize_customer',
  'next_action',
]);

function readString(value: unknown) {
  return typeof value === 'string' ? value.trim() : '';
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const task = readString(body.task) as OpenAITask;
    const prompt = readString(body.prompt);

    if (!allowedTasks.has(task)) {
      return NextResponse.json(
        { success: false, error: 'Unsupported OpenAI task' },
        { status: 400 }
      );
    }

    if (!prompt) {
      return NextResponse.json(
        { success: false, error: 'prompt is required' },
        { status: 400 }
      );
    }

    const input: OpenAIInput = {
      task,
      prompt,
      context: typeof body.context === 'object' && body.context ? body.context : {},
    };

    const result = await runOpenAITask(input);
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : 'OpenAI task failed' },
      { status: 500 }
    );
  }
}
