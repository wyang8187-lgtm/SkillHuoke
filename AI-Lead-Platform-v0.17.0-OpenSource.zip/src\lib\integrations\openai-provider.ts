export type OpenAITask =
  | 'write_email'
  | 'write_whatsapp'
  | 'score_lead'
  | 'summarize_customer'
  | 'next_action';

export interface OpenAIInput {
  task: OpenAITask;
  prompt: string;
  context?: Record<string, unknown>;
}

export interface OpenAIResult {
  provider: 'mock' | 'openai';
  task: OpenAITask;
  content: string;
  warnings: string[];
}

function createMockContent(input: OpenAIInput) {
  if (input.task === 'write_email') {
    return [
      'Subject: Potential cooperation for custom cabinetry projects',
      '',
      'Hi there,',
      '',
      'I found your company while researching potential partners for custom cabinetry and interior fit-out projects. We supply kitchen cabinets, wardrobes, doors, and whole-house customization for overseas project and retail channels.',
      '',
      'If you are open to reviewing a supplier option, I would be happy to share our catalog, project references, and export packing details.',
      '',
      'Best regards,',
    ].join('\n');
  }

  if (input.task === 'write_whatsapp') {
    return 'Hi, I found your company while researching cabinetry and interior project partners. May I share our custom cabinet and wardrobe project references for your review?';
  }

  if (input.task === 'score_lead') {
    return 'Suggested score: 82/100. Reason: clear business match, but contact details and decision maker still need verification.';
  }

  if (input.task === 'summarize_customer') {
    return 'This customer appears to be a potential project or trade partner. Verify website, LinkedIn, email, and phone before outreach.';
  }

  return 'Next action: verify public contact sources, identify the right decision maker, then send a short personalized first-touch message.';
}

export async function runOpenAITask(input: OpenAIInput): Promise<OpenAIResult> {
  const warnings: string[] = [];

  if (!process.env.OPENAI_API_KEY) {
    warnings.push('OPENAI_API_KEY is not configured. Using mock OpenAI response.');
    return {
      provider: 'mock',
      task: input.task,
      content: createMockContent(input),
      warnings,
    };
  }

  warnings.push('OPENAI_API_KEY is configured, but the real OpenAI adapter is not implemented yet.');
  return {
    provider: 'mock',
    task: input.task,
    content: createMockContent(input),
    warnings,
  };
}
