# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进和英文开发动作。

当前版本：`v0.27.0`

## v0.27.0 更新

- 新增 `/crm-opportunities` 销售机会与报价管道。
- 支持六个机会阶段、预计金额、币种、成交概率和预计成交日期。
- 按币种分别计算管道总额、加权金额、报价中金额和赢单金额。
- 客户详情显示关联机会，报价阶段自动更新客户 CRM 状态。
- 数据备份升级为版本 2，包含销售机会并兼容版本 1。

客户与跟进记录目前保存在浏览器本地；更换设备或清理浏览器数据后不会自动同步。

## 核心流程

1. 在 `/lead-wizard` 输入产品、国家、客户类型和数量，保存获客任务。
2. 在 `/lead-tasks` 进入任务执行台，把结果沉淀到候选客户池。
3. 在 `/candidate-leads` 核验并筛选客户，把合适客户加入 CRM。
4. 在 `/crm-customers` 查看客户阶段，并进入客户详情持续跟进。
5. 在客户详情记录联系结果，安排下次行动并复制英文开发文案。

## 预留接口

获客搜索：

```text
POST /api/integrations/lead-search
```

OpenAI：

```text
POST /api/integrations/openai
```

没有配置 API Key 时接口返回演示内容，方便开源项目直接运行。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

点击“演示模式进入工作台”即可查看。

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 环境变量

复制 `.env.example` 为 `.env.local`，按需填写：

```text
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5.4-mini
LEAD_SEARCH_API_KEY=
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

## 开源协议

MIT
