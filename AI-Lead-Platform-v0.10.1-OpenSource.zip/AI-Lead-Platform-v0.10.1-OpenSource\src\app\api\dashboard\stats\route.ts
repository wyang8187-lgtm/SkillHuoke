// 仪表盘统计 API
import { NextRequest, NextResponse } from 'next/server';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import * as dbService from '@/lib/db-service';

// 获取仪表盘统计数据
export async function GET(req: NextRequest) {
  const token = req.headers.get('x-session');

  if (!token) {
    return NextResponse.json({ error: '请先登录' }, { status: 401 });
  }

  const client = getSupabaseClient(token);
  const { data: { user }, error: authError } = await client.auth.getUser();

  if (authError || !user) {
    return NextResponse.json({ error: '认证失败' }, { status: 401 });
  }

  try {
    // 获取所有数据 - 使用大pageSize获取所有数据用于统计
    const customersResult = await dbService.getCustomers(user.id, undefined, 1, 1000);
    const leadsResult = await dbService.getLeads(user.id, undefined, 1, 1000);
    const opportunitiesResult = await dbService.getOpportunities(user.id, undefined, 1, 1000);
    const tasksResult = await dbService.getTasks(user.id, undefined, 1, 1000);
    const followUpRecords = await dbService.getAllFollowUpRecords(user.id, 1000);

    // 提取数据数组
    const customers = customersResult.data;
    const leads = leadsResult.data;
    const opportunities = opportunitiesResult.data;
    const tasks = tasksResult.data;

    // 今日新增线索
    const today = new Date().toISOString().split('T')[0];
    const todayNewLeads = leads.filter(lead => 
      lead.created_at?.startsWith(today)
    ).length;

    // 跟进中客户
    const followingCustomers = customers.filter(c => 
      c.status === '初步接触' || c.status === '需求确认' || c.status === '方案报价' || c.status === '谈判中'
    ).length;

    // 已成交客户
    const closedCustomers = customers.filter(c => c.status === '已成交').length;

    // 转化率
    const conversionRate = customers.length > 0 
      ? Math.round((closedCustomers / customers.length) * 100) 
      : 0;

    // 近7天线索趋势
    const weeklyLeads = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const count = leads.filter(lead => 
        lead.created_at?.startsWith(dateStr)
      ).length;
      weeklyLeads.push({
        date: dateStr,
        count,
      });
    }

    // 待完成任务
    const pendingTasks = tasks.filter(t => t.status === '待完成').length;

    // 客户类型分布
    const designerCount = customers.filter(c => c.customer_type === '全案设计师').length;
    const traderCount = customers.filter(c => c.customer_type === '建材外贸公司').length;

    // 客户地区分布
    const regionStats: Record<string, number> = {};
    customers.forEach(c => {
      if (c.region) {
        regionStats[c.region] = (regionStats[c.region] || 0) + 1;
      }
    });

    // 商机金额统计
    const totalOpportunityAmount = opportunities.reduce((sum: number, o) => sum + Number(o.amount || 0), 0);
    const wonAmount = opportunities.filter(o => o.stage === '成交').reduce((sum: number, o) => sum + Number(o.amount || 0), 0);

    // 最近跟进动态（取最近10条）
    const recentActivities = followUpRecords
      .sort((a: { created_at: string }, b: { created_at: string }) => 
        new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 10)
      .map((record: { id: string; content: string; customer_id: string; user_id: string; created_at: string }) => ({
        id: record.id,
        type: '客户跟进',
        content: record.content,
        customerId: record.customer_id,
        customerName: customers.find(c => c.id === record.customer_id)?.company_name || '未知客户',
        userId: record.user_id,
        createTime: record.created_at,
      }));

    // 客户分级分布
    const gradeStats = {
      A: customers.filter(c => c.grade === 'A').length,
      B: customers.filter(c => c.grade === 'B').length,
      C: customers.filter(c => c.grade === 'C').length,
      D: customers.filter(c => c.grade === 'D').length,
    };

    // 构建前端需要的格式
    const customersByType = [
      { type: '全案设计师', count: designerCount },
      { type: '建材外贸公司', count: traderCount },
    ].filter(item => item.count > 0);

    const customersByRegion = Object.entries(regionStats)
      .map(([region, count]) => ({ region, count }))
      .sort((a, b) => b.count - a.count);

    // 今日推荐跟进 - 智能推荐算法
    const todayDate = new Date();
    const sevenDaysAgo = new Date(todayDate.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    // 计算每个客户的推荐分数
    const recommendedFollowUps = customers
      .map(customer => {
        let score = 0;
        let reason = '';
        
        // 1. 超过7天未跟进 +30分
        const lastFollowUp = customer.last_follow_up_time 
          ? new Date(customer.last_follow_up_time) 
          : null;
        if (!lastFollowUp || lastFollowUp < sevenDaysAgo) {
          score += 30;
          reason = '超过7天未跟进';
        }
        
        // 2. A类客户 +25分, B类 +15分
        if (customer.grade === 'A') {
          score += 25;
          if (reason) reason += ' + A类客户';
          else reason = 'A类高价值客户';
        } else if (customer.grade === 'B') {
          score += 15;
          if (!reason) reason = 'B类培育客户';
        }
        
        // 3. 谈判中阶段 +20分
        if (customer.status === '谈判中') {
          score += 20;
          reason = '谈判中客户';
        }
        
        // 4. 有商机关联 +10分
        const hasOpportunity = opportunities.some(o => o.customer_id === customer.id);
        if (hasOpportunity) {
          score += 10;
        }
        
        // 5. 设置了下次跟进时间且临近 +15分
        if (customer.next_follow_up_time) {
          const nextFollowUpDate = new Date(customer.next_follow_up_time);
          const daysUntilNext = Math.ceil((nextFollowUpDate.getTime() - todayDate.getTime()) / (24 * 60 * 60 * 1000));
          if (daysUntilNext <= 3 && daysUntilNext >= 0) {
            score += 15;
            reason = `计划跟进日期临近（${daysUntilNext}天后）`;
          }
        }
        
        return {
          customerId: customer.id,
          customerName: customer.company_name,
          customerType: customer.customer_type,
          grade: customer.grade,
          status: customer.status,
          lastFollowUpTime: customer.last_follow_up_time,
          nextFollowUpTime: customer.next_follow_up_time,
          score,
          reason: reason || '建议跟进'
        };
      })
      .filter(item => item.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 5);

    // ===== 图表数据生成 =====

    // 1. 增长趋势数据 - 近12周按周统计
    const growthTrendData = [];
    for (let i = 11; i >= 0; i--) {
      const weekStart = new Date();
      weekStart.setDate(weekStart.getDate() - i * 7 - (weekStart.getDay() || 7) + 1);
      const weekEnd = new Date(weekStart);
      weekEnd.setDate(weekEnd.getDate() + 6);
      
      const weekLabel = `${weekStart.getMonth() + 1}/${weekStart.getDate()}`;
      
      const weekCustomers = customers.filter(c => {
        const createdDate = new Date(c.created_at);
        return createdDate >= weekStart && createdDate <= weekEnd;
      }).length;
      
      const weekLeads = leads.filter(l => {
        const createdDate = new Date(l.created_at);
        return createdDate >= weekStart && createdDate <= weekEnd;
      }).length;
      
      growthTrendData.push({
        date: weekLabel,
        customers: weekCustomers,
        leads: weekLeads,
      });
    }

    // 2. 客户类型分布饼图数据
    const typeDistributionData = [
      { name: '全案设计师', value: designerCount, color: '#3b82f6' },
      { name: '建材外贸公司', value: traderCount, color: '#f97316' },
    ].filter(item => item.value > 0);

    // 3. 地区分布柱状图数据 - 按客户类型细分
    const regions = ['深圳', '广州', '佛山', '东莞', '其他'];
    const regionDistributionData = regions.map(region => {
      const regionCustomers = region === '其他' 
        ? customers.filter(c => !['深圳', '广州', '佛山', '东莞'].includes(c.region || ''))
        : customers.filter(c => c.region === region);
      
      return {
        region: region === '其他' ? '其他地区' : region,
        designers: regionCustomers.filter(c => c.customer_type === '全案设计师').length,
        traders: regionCustomers.filter(c => c.customer_type === '建材外贸公司').length,
      };
    });

    // 4. 转化漏斗数据
    const funnelData = [
      { stage: '线索', count: leads.length, rate: 100, fill: '#3b82f6' },
      { stage: '客户', count: customers.length, rate: leads.length > 0 ? Math.round((customers.length / leads.length) * 100) : 0, fill: '#22c55e' },
      { stage: '商机', count: opportunities.length, rate: customers.length > 0 ? Math.round((opportunities.length / customers.length) * 100) : 0, fill: '#f97316' },
      { stage: '成交', count: opportunities.filter(o => o.stage === '成交').length, rate: opportunities.length > 0 ? Math.round((opportunities.filter(o => o.stage === '成交').length / opportunities.length) * 100) : 0, fill: '#22c55e' },
    ];

    // 5. 商机阶段分布数据
    const stages = ['初步接触', '需求确认', '方案报价', '谈判', '成交', '输单'];
    const stageDistributionData = stages.map(stage => ({
      stage,
      count: opportunities.filter(o => o.stage === stage).length,
      amount: Math.round(opportunities.filter(o => o.stage === stage).reduce((sum: number, o) => sum + Number(o.amount || 0), 0) / 10000),
    }));

    // 6. 本月核心指标
    const currentMonth = new Date().getMonth();
    const currentYear = new Date().getFullYear();
    const monthStart = new Date(currentYear, currentMonth, 1);
    
    const monthNewCustomers = customers.filter(c => {
      const createdDate = new Date(c.created_at);
      return createdDate >= monthStart;
    }).length;
    
    const monthNewLeads = leads.filter(l => {
      const createdDate = new Date(l.created_at);
      return createdDate >= monthStart;
    }).length;

    const monthWonAmount = opportunities.filter(o => {
      if (o.stage !== '成交') return false;
      const closedDate = new Date(o.updated_at);
      return closedDate >= monthStart;
    }).reduce((sum: number, o) => sum + Number(o.amount || 0), 0);

    // 7. 上月核心指标（环比）
    const lastMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    const lastMonthYear = currentMonth === 0 ? currentYear - 1 : currentYear;
    const lastMonthStart = new Date(lastMonthYear, lastMonth, 1);
    const lastMonthEnd = new Date(currentYear, currentMonth, 0); // 上月最后一天
    
    const lastMonthNewCustomers = customers.filter(c => {
      const createdDate = new Date(c.created_at);
      return createdDate >= lastMonthStart && createdDate <= lastMonthEnd;
    }).length;
    
    const lastMonthNewLeads = leads.filter(l => {
      const createdDate = new Date(l.created_at);
      return createdDate >= lastMonthStart && createdDate <= lastMonthEnd;
    }).length;

    const lastMonthOpportunityAmount = opportunities.filter(o => {
      const createdDate = new Date(o.created_at);
      return createdDate >= lastMonthStart && createdDate <= lastMonthEnd;
    }).reduce((sum: number, o) => sum + Number(o.amount || 0), 0);

    // 上月转化率计算
    const lastMonthTotalCustomers = customers.filter(c => {
      const createdDate = new Date(c.created_at);
      return createdDate <= lastMonthEnd;
    }).length;
    const lastMonthClosedCustomers = customers.filter(c => {
      if (c.status !== '已成交') return false;
      // 使用更新时间估算成交时间
      return true;
    }).length;
    const lastMonthConversionRate = lastMonthTotalCustomers > 0 
      ? Math.round((lastMonthClosedCustomers / lastMonthTotalCustomers) * 100)
      : 0;

    return NextResponse.json({
      // 基础统计
      totalCustomers: customers.length,
      totalLeads: leads.length,
      totalOpportunities: opportunities.length,
      totalTasks: tasks.length,
      todayNewLeads,
      followingCustomers,
      closedCustomers,
      conversionRate,
      pendingTasks,
      totalOpportunityAmount,
      wonAmount,
      weeklyLeads,
      customersByType,
      customersByRegion,
      gradeStats,
      recentActivities,
      recommendedFollowUps,
      // 图表数据
      growthTrendData,
      typeDistributionData,
      regionDistributionData,
      funnelData,
      stageDistributionData,
      // 本月核心指标
      monthNewCustomers,
      monthNewLeads,
      monthOpportunityAmount: Math.round(totalOpportunityAmount / 10000),
      monthWonAmount: Math.round(monthWonAmount / 10000),
      // 上月核心指标（环比）
      lastMonthNewCustomers,
      lastMonthNewLeads,
      lastMonthOpportunityAmount: Math.round(lastMonthOpportunityAmount / 10000),
      lastMonthConversionRate,
    });
  } catch (error) {
    console.error('获取仪表盘统计失败:', error);
    return NextResponse.json({ 
      error: error instanceof Error ? error.message : '获取统计数据失败' 
    }, { status: 500 });
  }
}