'use client';

import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  GrowthTrendChart,
  FunnelChart,
} from '@/components/charts';
import {
  Users,
  Target,
  Briefcase,
  CheckCircle,
  Clock,
  TrendingUp,
  TrendingDown,
  AlertCircle,
  Calendar,
  ArrowRight,
  Loader2,
  DollarSign,
  Percent,
  Star,
  UserPlus,
  FileText,
  Bell,
  ChevronRight,
  Activity,
} from 'lucide-react';

// 数据类型定义
interface GrowthData {
  date: string;
  customers: number;
  leads: number;
}

interface FunnelData {
  stage: string;
  count: number;
  rate: number;
  fill: string;
}

interface DashboardStats {
  totalCustomers: number;
  totalLeads: number;
  totalOpportunities: number;
  totalTasks: number;
  monthNewCustomers: number;
  monthNewLeads: number;
  monthOpportunityAmount: number;
  monthWonAmount: number;
  conversionRate: number;
  // 环比数据
  lastMonthNewCustomers: number;
  lastMonthNewLeads: number;
  lastMonthOpportunityAmount: number;
  lastMonthConversionRate: number;
  // 图表数据
  growthTrendData?: GrowthData[];
  funnelData?: FunnelData[];
  // 推荐跟进
  recommendedFollowUps?: RecommendedFollowUp[];
}

interface RecommendedFollowUp {
  customerId: string;
  customerName: string;
  customerType: string;
  grade: string;
  status: string;
  lastFollowUpTime: string | null;
  nextFollowUpTime: string | null;
  score: number;
  reason: string;
}

interface Task {
  id: string;
  title: string;
  status: string;
  priority: string;
  due_time: string | null;
  create_time: string;
  customer_id?: string;
  customer_name?: string;
}

interface ActivityLog {
  id: string;
  type: string;
  action: string;
  target: string;
  target_id: string;
  user: string;
  time: string;
  details?: string;
}

// 计算环比变化
const calcChange = (current: number, last: number) => {
  if (last === 0) return { value: 0, percent: 0, isUp: current > 0 };
  const diff = current - last;
  const percent = Math.round((diff / last) * 100);
  return { value: diff, percent, isUp: diff >= 0 };
};

// 格式化金额
const formatAmount = (amount: number) => {
  if (amount >= 10000) {
    return `${(amount / 10000).toFixed(1)}万`;
  }
  return amount.toString();
};

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      // 加载统计数据
      const statsRes = await fetch('/api/dashboard/stats');
      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setStats(statsData);
      }

      // 加载今日待办任务
      const tasksRes = await fetch('/api/tasks?status=pending&pageSize=5');
      if (tasksRes.ok) {
        const tasksData = await tasksRes.json();
        setTasks(tasksData.tasks || []);
      }

      // 加载最新动态（模拟数据）
      setActivities(generateMockActivities());
    } catch (error) {
      console.error('加载仪表盘数据失败', error);
    } finally {
      setLoading(false);
    }
  };

  // 模拟活动日志
  const generateMockActivities = (): ActivityLog[] => {
    const now = Date.now();
    return [
      {
        id: 'act_1',
        type: 'customer',
        action: '新增客户',
        target: '深圳市某某家居有限公司',
        target_id: 'cust_001',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 5).toISOString(),
        details: '客户类型：全案设计师，等级：A类',
      },
      {
        id: 'act_2',
        type: 'opportunity',
        action: '创建商机',
        target: '广州某写字楼定制项目',
        target_id: 'opp_001',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 15).toISOString(),
        details: '预计金额：50万，阶段：初步接触',
      },
      {
        id: 'act_3',
        type: 'follow_up',
        action: '完成跟进',
        target: '佛山某建材外贸公司',
        target_id: 'cust_002',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 30).toISOString(),
        details: '跟进方式：电话，客户意向：高',
      },
      {
        id: 'act_4',
        type: 'task',
        action: '完成任务',
        target: '发送产品介绍邮件',
        target_id: 'task_001',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 45).toISOString(),
      },
      {
        id: 'act_5',
        type: 'lead',
        action: '线索转客户',
        target: '东莞某设计工作室',
        target_id: 'lead_001',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 60).toISOString(),
        details: '线索评分：95分，自动转为客户',
      },
      {
        id: 'act_6',
        type: 'email',
        action: '发送邮件',
        target: '产品合作邀请',
        target_id: 'email_001',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 90).toISOString(),
        details: '收件人：周经理，状态：已送达',
      },
      {
        id: 'act_7',
        type: 'ai',
        action: 'AI自动获客',
        target: '发现3条新线索',
        target_id: 'ai_001',
        user: '系统',
        time: new Date(now - 1000 * 60 * 120).toISOString(),
        details: '关键词：全屋定制深圳，匹配度：90%+',
      },
      {
        id: 'act_8',
        type: 'opportunity',
        action: '商机阶段变更',
        target: '惠州某装修公司项目',
        target_id: 'opp_002',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 150).toISOString(),
        details: '从"需求确认"进入"方案报价"',
      },
      {
        id: 'act_9',
        type: 'customer',
        action: '客户等级调整',
        target: '深圳市某某家居有限公司',
        target_id: 'cust_003',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 180).toISOString(),
        details: '从B类升级为A类客户',
      },
      {
        id: 'act_10',
        type: 'task',
        action: '创建跟进任务',
        target: '下周回访重点客户',
        target_id: 'task_002',
        user: '管理员',
        time: new Date(now - 1000 * 60 * 210).toISOString(),
        details: '关联客户：广州某设计公司',
      },
    ];
  };

  // 活动类型图标和颜色
  const activityStyles: Record<string, { icon: React.ReactNode; color: string; bgColor: string }> = {
    customer: { icon: <Users className="h-4 w-4" />, color: '#3b82f6', bgColor: 'bg-blue-500/20' },
    opportunity: { icon: <Briefcase className="h-4 w-4" />, color: '#8b5cf6', bgColor: 'bg-purple-500/20' },
    follow_up: { icon: <FileText className="h-4 w-4" />, color: '#22c55e', bgColor: 'bg-green-500/20' },
    task: { icon: <CheckCircle className="h-4 w-4" />, color: '#f97316', bgColor: 'bg-orange-500/20' },
    lead: { icon: <Target className="h-4 w-4" />, color: '#06b6d4', bgColor: 'bg-cyan-500/20' },
    email: { icon: <Bell className="h-4 w-4" />, color: '#ec4899', bgColor: 'bg-pink-500/20' },
    ai: { icon: <Activity className="h-4 w-4" />, color: '#f59e0b', bgColor: 'bg-amber-500/20' },
  };

  // 时间格式化
  const formatTime = (timeStr: string) => {
    const date = new Date(timeStr);
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / 1000);
    
    if (diff < 60) return '刚刚';
    if (diff < 3600) return `${Math.floor(diff / 60)}分钟前`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}小时前`;
    return `${Math.floor(diff / 86400)}天前`;
  };

  if (loading) {
    return (
      <MainLayout title="仪表盘">
        <div className="flex items-center justify-center h-[400px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  // 环比数据计算
  const customerChange = calcChange(stats?.monthNewCustomers || 0, stats?.lastMonthNewCustomers || 0);
  const leadChange = calcChange(stats?.monthNewLeads || 0, stats?.lastMonthNewLeads || 0);
  const amountChange = calcChange(stats?.monthOpportunityAmount || 0, stats?.lastMonthOpportunityAmount || 0);
  const rateChange = calcChange(stats?.conversionRate || 0, stats?.lastMonthConversionRate || 0);

  return (
    <MainLayout title="仪表盘">
      {/* 顶部4个核心指标卡片 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* 本月新增客户 */}
        <Card className="bg-card border-border hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">本月新增客户</p>
                <p className="text-3xl font-bold text-foreground">{stats?.monthNewCustomers || 0}</p>
                <div className="flex items-center gap-1 mt-2">
                  {customerChange.isUp ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span className={`text-sm ${customerChange.isUp ? 'text-green-500' : 'text-red-500'}`}>
                    {customerChange.percent > 0 ? '+' : ''}{customerChange.percent}% 环比
                  </span>
                </div>
              </div>
              <div className="h-12 w-12 rounded-full bg-primary/20 flex items-center justify-center">
                <UserPlus className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 本月新增线索 */}
        <Card className="bg-card border-border hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">本月新增线索</p>
                <p className="text-3xl font-bold text-foreground">{stats?.monthNewLeads || 0}</p>
                <div className="flex items-center gap-1 mt-2">
                  {leadChange.isUp ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span className={`text-sm ${leadChange.isUp ? 'text-green-500' : 'text-red-500'}`}>
                    {leadChange.percent > 0 ? '+' : ''}{leadChange.percent}% 环比
                  </span>
                </div>
              </div>
              <div className="h-12 w-12 rounded-full bg-cyan-500/20 flex items-center justify-center">
                <Target className="h-6 w-6 text-cyan-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 商机总金额 */}
        <Card className="bg-card border-border hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">商机总金额</p>
                <p className="text-3xl font-bold text-foreground">
                  ¥{formatAmount(stats?.monthOpportunityAmount || 0)}
                </p>
                <div className="flex items-center gap-1 mt-2">
                  {amountChange.isUp ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span className={`text-sm ${amountChange.isUp ? 'text-green-500' : 'text-red-500'}`}>
                    {amountChange.percent > 0 ? '+' : ''}{amountChange.percent}% 环比
                  </span>
                </div>
              </div>
              <div className="h-12 w-12 rounded-full bg-purple-500/20 flex items-center justify-center">
                <DollarSign className="h-6 w-6 text-purple-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* 转化率 */}
        <Card className="bg-card border-border hover:shadow-lg transition-shadow">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">转化率</p>
                <p className="text-3xl font-bold text-foreground">{stats?.conversionRate || 0}%</p>
                <div className="flex items-center gap-1 mt-2">
                  {rateChange.isUp ? (
                    <TrendingUp className="h-4 w-4 text-green-500" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-red-500" />
                  )}
                  <span className={`text-sm ${rateChange.isUp ? 'text-green-500' : 'text-red-500'}`}>
                    {rateChange.percent > 0 ? '+' : ''}{rateChange.percent}% 环比
                  </span>
                </div>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-500/20 flex items-center justify-center">
                <Percent className="h-6 w-6 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 中间区域：左侧客户增长趋势 + 右侧商机漏斗 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        {/* 客户增长趋势图 */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-foreground flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              客户增长趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stats?.growthTrendData && stats.growthTrendData.length > 0 ? (
              <GrowthTrendChart data={stats.growthTrendData} />
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                暂无数据
              </div>
            )}
          </CardContent>
        </Card>

        {/* 商机漏斗图 */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-foreground flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-purple-500" />
              商机转化漏斗
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stats?.funnelData && stats.funnelData.length > 0 ? (
              <FunnelChart data={stats.funnelData} />
            ) : (
              <div className="h-[200px] flex items-center justify-center text-muted-foreground">
                暂无数据
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 下方区域：左侧今日待办 + 右侧推荐跟进 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        {/* 今日待办任务 */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-foreground flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-orange-500" />
                今日待办任务
              </CardTitle>
              <Badge variant="secondary" className="bg-orange-500/20 text-orange-500">
                {tasks.length}项待处理
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {tasks.length > 0 ? (
              <div className="space-y-3">
                {tasks.map((task) => (
                  <div
                    key={task.id}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        task.priority === '高' ? 'bg-red-500' :
                        task.priority === '中' ? 'bg-orange-500' : 'bg-green-500'
                      }`} />
                      <div>
                        <p className="text-sm font-medium text-foreground">{task.title}</p>
                        {task.customer_name && (
                          <p className="text-xs text-muted-foreground">关联客户：{task.customer_name}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {task.due_time && (
                        <span className="text-xs text-muted-foreground">
                          <Clock className="h-3 w-3 inline mr-1" />
                          {new Date(task.due_time).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      )}
                      <Button variant="ghost" size="sm" className="h-8 px-2">
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-[150px] flex items-center justify-center text-muted-foreground">
                <CheckCircle className="h-8 w-8 mr-2 opacity-50" />
                今日无待办任务
              </div>
            )}
          </CardContent>
        </Card>

        {/* 今日推荐跟进 */}
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-foreground flex items-center gap-2">
                <Star className="h-5 w-5 text-amber-500" />
                今日推荐跟进
              </CardTitle>
              <Badge variant="secondary" className="bg-amber-500/20 text-amber-500">
                AI智能推荐
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            {stats?.recommendedFollowUps && stats.recommendedFollowUps.length > 0 ? (
              <div className="space-y-3">
                {stats.recommendedFollowUps.slice(0, 5).map((rec) => (
                  <div
                    key={rec.customerId}
                    className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <Users className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">{rec.customerName}</p>
                        <p className="text-xs text-muted-foreground">{rec.reason}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className={
                        rec.grade === 'A' ? 'border-green-500 text-green-500' :
                        rec.grade === 'B' ? 'border-orange-500 text-orange-500' :
                        rec.grade === 'C' ? 'border-gray-500 text-gray-500' :
                        'border-red-500 text-red-500'
                      }>
                        {rec.grade}类
                      </Badge>
                      <Badge variant="outline" className="border-primary text-primary">
                        {rec.score}分
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="h-[150px] flex items-center justify-center text-muted-foreground">
                <Star className="h-8 w-8 mr-2 opacity-50" />
                暂无推荐跟进客户
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* 底部：最新动态时间线 */}
      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-foreground flex items-center gap-2">
            <Activity className="h-5 w-5 text-cyan-500" />
            最新动态
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative">
            {/* 时间线 */}
            <div className="absolute left-4 top-0 bottom-0 w-0.5 bg-border" />
            
            <div className="space-y-4">
              {activities.map((activity) => {
                const style = activityStyles[activity.type] || activityStyles.customer;
                return (
                  <div key={activity.id} className="relative pl-10">
                    {/* 时间点 */}
                    <div className={`absolute left-2 w-4 h-4 rounded-full ${style.bgColor} flex items-center justify-center`}>
                      <div className={`w-2 h-2 rounded-full`} style={{ backgroundColor: style.color }} />
                    </div>
                    
                    <div className="flex items-start justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${style.bgColor}`}>
                          {style.icon}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">
                            {activity.action}
                            <span className="text-primary ml-1">{activity.target}</span>
                          </p>
                          {activity.details && (
                            <p className="text-xs text-muted-foreground mt-1">{activity.details}</p>
                          )}
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-xs text-muted-foreground">{formatTime(activity.time)}</p>
                        <p className="text-xs text-muted-foreground">{activity.user}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>
    </MainLayout>
  );
}