'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { NotificationBell } from '@/components/ui/notification-bell';
import {
  LayoutDashboard,
  Search,
  Users,
  Mail,
  Target,
  FolderOpen,
  Briefcase,
  Users as TeamIcon,
  BarChart3,
  Settings,
  ChevronDown,
  ChevronRight,
  Menu,
  X,
  LogOut,
  Bell,
  User,
  Activity,
  Lightbulb,
  Globe,
  PieChart,
  Calendar,
  MapPin,
  Video,
  Shield,
  Filter,
  Sparkles,
  Send,
  BookOpen,
} from 'lucide-react';

interface NavItemBase {
  title: string;
  icon: React.ReactNode;
}

interface NavItemWithHref extends NavItemBase {
  href: string;
  children?: never;
}

interface NavItemWithChildren extends NavItemBase {
  href?: string;
  children: NavItemWithHref[];
}

type NavItem = NavItemWithHref | NavItemWithChildren;

const navItems: NavItem[] = [
  {
    title: '仪表盘',
    href: '/dashboard',
    icon: <LayoutDashboard className="h-5 w-5" />,
  },
  {
    title: 'AI获客中心',
    href: '/acquisition',
    icon: <Search className="h-5 w-5" />,
    children: [
      { title: '智能搜索', href: '/acquisition/search', icon: <Search className="h-4 w-4" /> },
      { title: '高级搜客', href: '/acquisition/advanced-search', icon: <Filter className="h-4 w-4" /> },
      { title: '线索发现', href: '/acquisition/lead-discovery', icon: <Sparkles className="h-4 w-4" /> },
      { title: '批量开发', href: '/acquisition/bulk-development', icon: <Send className="h-4 w-4" /> },
      { title: '多渠道获客', href: '/acquisition/channels', icon: <FolderOpen className="h-4 w-4" /> },
      { title: 'AI自动获客', href: '/acquisition/auto', icon: <Target className="h-4 w-4" /> },
      { title: 'AI客户动态', href: '/acquisition/dynamics', icon: <Activity className="h-4 w-4" /> },
      { title: 'AI决策人深挖', href: '/acquisition/decision-maker', icon: <User className="h-4 w-4" /> },
      { title: 'AI拓词建议', href: '/acquisition/keyword-suggest', icon: <Lightbulb className="h-4 w-4" /> },
      { title: 'LBS地图获客', href: '/acquisition/lbs-map', icon: <MapPin className="h-4 w-4" /> },
      { title: 'LinkedIn获客', href: '/acquisition/social-linkedin', icon: <Briefcase className="h-4 w-4" /> },
      { title: 'Facebook获客', href: '/acquisition/social-facebook', icon: <Users className="h-4 w-4" /> },
      { title: 'TikTok获客', href: '/acquisition/social-tiktok', icon: <Video className="h-4 w-4" /> },
      { title: '品牌商标库', href: '/acquisition/trademark-search', icon: <Shield className="h-4 w-4" /> },
      { title: '行业资源库', href: '/resources/industry-library', icon: <BookOpen className="h-4 w-4" /> },
    ],
  },
  {
    title: '客户管理',
    href: '/customers',
    icon: <Users className="h-5 w-5" />,
    children: [
      { title: '客户列表', href: '/customers/list', icon: <Users className="h-4 w-4" /> },
      { title: '公海池', href: '/customers/pool', icon: <FolderOpen className="h-4 w-4" /> },
      { title: '分类看板', href: '/customers/classification-dashboard', icon: <PieChart className="h-4 w-4" /> },
    ],
  },
  {
    title: '营销中心',
    href: '/marketing',
    icon: <Mail className="h-5 w-5" />,
    children: [
      { title: '邮件营销', href: '/marketing/email', icon: <Mail className="h-4 w-4" /> },
      { title: '社媒营销', href: '/marketing/social', icon: <Target className="h-4 w-4" /> },
      { title: 'WhatsApp', href: '/marketing/whatsapp', icon: <Mail className="h-4 w-4" /> },
      { title: '自动化流程', href: '/marketing/automation', icon: <Target className="h-4 w-4" /> },
    ],
  },
  {
    title: '线索池',
    href: '/leads',
    icon: <FolderOpen className="h-5 w-5" />,
  },
  {
    title: '商机管理',
    href: '/opportunities',
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    title: '外贸数据',
    href: '/customs',
    icon: <Globe className="h-5 w-5" />,
    children: [
      { title: '海关数据查询', href: '/customs/search', icon: <Search className="h-4 w-4" /> },
      { title: '展会信息', href: '/customs/exhibitions', icon: <Calendar className="h-4 w-4" /> },
    ],
  },
  {
    title: '团队管理',
    icon: <TeamIcon className="h-5 w-5" />,
    children: [
      { title: '成员管理', href: '/team', icon: <Users className="h-4 w-4" /> },
      { title: '权限矩阵', href: '/team/permissions', icon: <Shield className="h-4 w-4" /> },
    ],
  },
  {
    title: '数据分析',
    href: '/analytics',
    icon: <BarChart3 className="h-5 w-5" />,
    children: [
      { title: '客户分析', href: '/analytics/customers', icon: <Users className="h-4 w-4" /> },
      { title: '销售分析', href: '/analytics/sales', icon: <Target className="h-4 w-4" /> },
      { title: '获客效率', href: '/analytics/acquisition', icon: <Sparkles className="h-4 w-4" /> },
    ],
  },
  {
    title: '系统设置',
    href: '/settings',
    icon: <Settings className="h-5 w-5" />,
    children: [
      { title: '个人设置', href: '/settings/personal', icon: <User className="h-4 w-4" /> },
      { title: 'API密钥', href: '/settings/api-keys', icon: <Shield className="h-4 w-4" /> },
      { title: '团队设置', href: '/settings/team', icon: <Users className="h-4 w-4" /> },
      { title: '系统参数', href: '/settings/params', icon: <Settings className="h-4 w-4" /> },
      { title: '数据管理', href: '/settings/data', icon: <FolderOpen className="h-4 w-4" /> },
    ],
  },
];

export function Sidebar({ mobileOpen = false, onMobileClose }: { mobileOpen?: boolean; onMobileClose?: () => void }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>(['/acquisition', '/customers', '/marketing', '/customs', '/analytics', '/settings', '团队管理']);
  const [showNotifications, setShowNotifications] = useState(false);
  const [pendingTaskCount, setPendingTaskCount] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  // 检测移动端
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  // 获取待完成任务数量
  useEffect(() => {
    fetchPendingTaskCount();
    // 每5分钟刷新一次
    const interval = setInterval(fetchPendingTaskCount, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  const fetchPendingTaskCount = async () => {
    try {
      const session = localStorage.getItem('supabase_session');
      if (!session) return;
      
      const response = await fetch('/api/tasks?status=待完成&pageSize=100', {
        headers: {
          'x-session': session
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setPendingTaskCount(data.total || 0);
      }
    } catch (error) {
      console.error('获取任务数量失败:', error);
    }
  };

  const toggleExpanded = (href: string) => {
    setExpandedItems(prev =>
      prev.includes(href)
        ? prev.filter(item => item !== href)
        : [...prev, href]
    );
  };

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/');
  const isExpanded = (href: string) => expandedItems.includes(href);

  // 路由变化时关闭移动端侧边栏
  useEffect(() => {
    if (isMobile && onMobileClose) {
      onMobileClose();
    }
  }, [pathname, isMobile, onMobileClose]);

  return (
    <>
      {/* 移动端遮罩层 */}
      {isMobile && mobileOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-30 md:hidden"
          onClick={onMobileClose}
        />
      )}
      
      {/* 侧边栏 */}
      <div className={cn(
        "fixed left-0 top-0 z-40 h-screen bg-[#0f1419] border-r border-[#2d3548] transition-all duration-200",
        collapsed && !isMobile ? "w-16" : "w-60",
        isMobile && !mobileOpen ? "-translate-x-full" : "translate-x-0",
        isMobile && mobileOpen ? "w-60" : ""
      )}>
        {/* Logo区域 */}
        <div className="flex items-center justify-between h-14 px-4 border-b border-[#2d3548]">
        {!collapsed && (
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#3b82f6] to-[#1d4ed8] flex items-center justify-center">
              <Target className="h-5 w-5 text-white" />
            </div>
            <span className="text-lg font-semibold text-[#f8fafc]">获客AI</span>
          </div>
        )}
        <div className="flex items-center gap-1">
          {!collapsed && <NotificationBell />}
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8]"
          >
            {collapsed ? <Menu className="h-5 w-5" /> : <X className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* 导航菜单 */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1 px-2">
          {navItems.map((item) => (
            <li key={item.href || item.title}>
              {/* 主菜单项 */}
              <div
                className={cn(
                  "flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors",
                  item.href && isActive(item.href) && !item.children
                    ? "bg-[#1a1f2c] text-[#3b82f6] border-l-3 border-[#3b82f6]"
                    : "text-[#94a3b8] hover:bg-[#1a1f2c] hover:text-[#f8fafc]"
                )}
                onClick={() => {
                  if (item.children) {
                    toggleExpanded(item.href || item.title);
                  }
                }}
              >
                {item.icon}
                {!collapsed && (
                  <>
                    <span className="flex-1 text-sm">{item.title}</span>
                    {item.children && (
                      <span className="text-xs">
                        {isExpanded(item.href || item.title) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                      </span>
                    )}
                  </>
                )}
              </div>

              {/* 子菜单 */}
              {item.children && isExpanded(item.href || item.title) && !collapsed && (
                <ul className="mt-1 ml-4 space-y-1">
                  {item.children.map((child) => (
                    <li key={child.href}>
                      <Link
                        href={child.href}
                        className={cn(
                          "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
                          isActive(child.href)
                            ? "bg-[#1a1f2c] text-[#3b82f6]"
                            : "text-[#94a3b8] hover:bg-[#1a1f2c] hover:text-[#f8fafc]"
                        )}
                      >
                        {child.icon}
                        <span>{child.title}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              )}
            </li>
          ))}
        </ul>
      </nav>

      {/* 底部用户区域 */}
      <div className="border-t border-[#2d3548] p-4">
        {!collapsed ? (
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#1a1f2c] flex items-center justify-center">
                <User className="h-4 w-4 text-[#94a3b8]" />
              </div>
              <div className="text-sm">
                <div className="text-[#f8fafc]">管理员</div>
                <div className="text-xs text-[#64748b]">admin@example.com</div>
              </div>
            </div>
            <div className="flex gap-1">
              <ThemeToggle />
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8] relative"
              >
                <Bell className="h-4 w-4" />
                {pendingTaskCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] flex items-center justify-center bg-[#f97316] text-white text-xs font-bold rounded-full px-1">
                    {pendingTaskCount > 99 ? '99+' : pendingTaskCount}
                  </span>
                )}
              </button>
              <Link
                href="/login"
                className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8]"
              >
                <LogOut className="h-4 w-4" />
              </Link>
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-2 items-center">
            <ThemeToggle />
            <div className="w-8 h-8 rounded-full bg-[#1a1f2c] flex items-center justify-center">
              <User className="h-4 w-4 text-[#94a3b8]" />
            </div>
            <Link
              href="/login"
              className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8]"
            >
              <LogOut className="h-4 w-4" />
            </Link>
          </div>
        )}
      </div>
    </div>
    </>
  );
}