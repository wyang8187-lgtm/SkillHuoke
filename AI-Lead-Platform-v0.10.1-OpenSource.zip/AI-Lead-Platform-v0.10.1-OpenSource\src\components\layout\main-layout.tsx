'use client';

import React, { useState, useEffect } from 'react';
import { Sidebar } from './sidebar';
import { Menu, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { GlobalSearch } from '@/components/ui/global-search';
import { Breadcrumb, type BreadcrumbItem } from '@/components/ui/breadcrumb';

interface MainLayoutProps {
  children: React.ReactNode;
  title?: string;
  breadcrumbs?: BreadcrumbItem[];
}

export function MainLayout({ children, title, breadcrumbs }: MainLayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  // 检测移动端
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768);
      if (window.innerWidth >= 768) {
        setMobileMenuOpen(false);
      }
    };
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  return (
    <div className="min-h-screen bg-[#0f1419]">
      {/* 移动端汉堡菜单按钮 */}
      {isMobile && (
        <header className="fixed top-0 left-0 right-0 z-50 h-14 bg-[#0f1419] border-b border-[#2d3548] flex items-center justify-between px-4">
          <div className="flex items-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-[#f8fafc] hover:bg-[#1a1f2c]"
            >
              <Menu className="h-6 w-6" />
            </Button>
            {title && (
              <h1 className="ml-4 text-lg font-semibold text-[#f8fafc]">{title}</h1>
            )}
          </div>
          <GlobalSearch mobileMode isOpen={false} onClose={() => {}} />
        </header>
      )}
      
      {/* 侧边栏 */}
      <Sidebar 
        mobileOpen={mobileMenuOpen} 
        onMobileClose={() => setMobileMenuOpen(false)} 
      />
      
      {/* 主内容区域 */}
      <main className={cn(
        "min-h-screen transition-all duration-200",
        isMobile ? "ml-0 pt-14" : "ml-60"
      )}>
        {/* 桌面端页面标题栏 */}
        {!isMobile && (
          <header className="sticky top-0 z-30 h-14 bg-[#0f1419] border-b border-[#2d3548] px-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
              {breadcrumbs && breadcrumbs.length > 0 ? (
                <Breadcrumb items={breadcrumbs} />
              ) : (
                <h1 className="text-xl font-semibold text-[#f8fafc]">{title}</h1>
              )}
            </div>
            <GlobalSearch isOpen={false} onClose={() => {}} />
          </header>
        )}
        {/* 内容区域 */}
        <div className={cn(
          "p-6",
          isMobile && "p-4"
        )}>
          {children}
        </div>
      </main>
    </div>
  );
}

// cn函数辅助（如果未导入）
function cn(...classes: (string | boolean | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}