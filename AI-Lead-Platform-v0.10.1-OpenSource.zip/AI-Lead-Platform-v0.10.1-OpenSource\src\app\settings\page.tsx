'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  User, Key, Users, Settings, Database, ArrowRight 
} from 'lucide-react';

export default function SettingsPage() {
  const pathname = usePathname();

  const menuItems = [
    {
      id: 'personal',
      name: '个人设置',
      icon: User,
      path: '/settings/personal',
      description: '个人信息编辑、密码修改、通知偏好设置',
      badge: null
    },
    {
      id: 'api-keys',
      name: 'API密钥管理',
      icon: Key,
      path: '/settings/api-keys',
      description: '配置DeepSeek、OpenAI、SMTP、WhatsApp等API密钥',
      badge: '核心'
    },
    {
      id: 'team',
      name: '团队设置',
      icon: Users,
      path: '/settings/team',
      description: '团队成员管理、角色权限配置、账号启用禁用',
      badge: null
    },
    {
      id: 'params',
      name: '系统参数',
      icon: Settings,
      path: '/settings/params',
      description: '公海规则、查重规则、开发信签名等系统参数',
      badge: null
    },
    {
      id: 'data',
      name: '数据管理',
      icon: Database,
      path: '/settings/data',
      description: '数据备份恢复、清空数据、重置示例数据',
      badge: '危险'
    }
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">系统设置</h1>

      {/* 设置模块入口 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {menuItems.map(item => {
          const isActive = pathname === item.path;
          const Icon = item.icon;
          
          return (
            <Link key={item.id} href={item.path}>
              <Card className={`hover:border-blue-500 transition-colors cursor-pointer ${isActive ? 'border-blue-500 bg-blue-500/5' : ''}`}>
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className={`p-2 rounded-lg ${isActive ? 'bg-blue-500/20' : 'bg-muted/20'}`}>
                      <Icon className={`w-5 h-5 ${isActive ? 'text-blue-500' : 'text-muted-foreground'}`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{item.name}</span>
                        {item.badge && (
                          <Badge variant={item.badge === '危险' ? 'destructive' : 'default'} className="text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </div>
                      <div className="text-sm text-muted-foreground">{item.description}</div>
                    </div>
                    <ArrowRight className={`w-4 h-4 ${isActive ? 'text-blue-500' : 'text-muted-foreground'}`} />
                  </div>
                </CardContent>
              </Card>
            </Link>
          );
        })}
      </div>

      {/* 快捷说明 */}
      <Card className="bg-muted/10">
        <CardContent className="p-4">
          <div className="text-sm text-muted-foreground">
            <p>点击上方卡片进入对应设置页面。</p>
            <p className="mt-1">
              <span className="text-red-500">危险</span>标记的操作需要二次确认，请谨慎执行。
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}