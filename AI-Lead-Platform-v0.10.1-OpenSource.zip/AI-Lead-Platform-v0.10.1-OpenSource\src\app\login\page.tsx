'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { Eye, EyeOff, Loader2, Mail, Lock, ArrowLeft, Sparkles } from 'lucide-react';
import { getSupabaseBrowserClientAsync } from '@/lib/supabase-browser';
import { cn } from '@/lib/utils';
import type { SupabaseClient } from '@supabase/supabase-js';

const APP_NAME = '全屋定制AI获客平台';
const APP_ICON_URL = 'https://coze-coding-project.tos.coze.site/default_app_icon.svg';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [supabase, setSupabase] = useState<SupabaseClient | null>(null);
  const [configLoading, setConfigLoading] = useState(true);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const initSupabase = async () => {
      try {
        const client = await getSupabaseBrowserClientAsync();
        setSupabase(client);
        // 检查是否已登录
        const { data: { session } } = await client.auth.getSession();
        if (session) {
          router.push('/dashboard');
        }
      } catch (err) {
        setError('系统配置加载失败，请刷新页面重试');
        console.error('Supabase init error:', err);
      } finally {
        setConfigLoading(false);
      }
    };
    initSupabase();
  }, [router]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase) {
      setError('系统未准备好，请稍后重试');
      return;
    }
    setLoading(true);
    setError('');

    try {
      const { error: loginError } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (loginError) {
        setError(loginError.message === 'Invalid login credentials' 
          ? '邮箱或密码错误' 
          : loginError.message);
      } else {
        router.push('/dashboard');
      }
    } catch {
      setError('登录失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase) return;
    setLoading(true);
    setError('');

    if (password !== confirmPassword) {
      setError('两次密码输入不一致');
      setLoading(false);
      return;
    }

    if (password.length < 6) {
      setError('密码长度至少6位');
      setLoading(false);
      return;
    }

    try {
      const { error: registerError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (registerError) {
        setError(registerError.message);
      } else {
        setSuccess('注册成功！请查收确认邮件后登录');
        setMode('login');
      }
    } catch {
      setError('注册失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabase) return;
    setLoading(true);
    setError('');

    try {
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: `${window.location.origin}/login?mode=reset`,
      });

      if (resetError) {
        setError(resetError.message);
      } else {
        setSuccess('重置邮件已发送，请查收邮箱');
      }
    } catch {
      setError('发送失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  // 配置加载中
  if (configLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-[#0f1419] via-[#1a1f2c] to-[#0f1419] flex items-center justify-center">
        <div className="flex items-center gap-3 text-[#94a3b8]">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span>正在加载系统配置...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0f1419] via-[#1a1f2c] to-[#0f1419] flex items-center justify-center p-4 md:p-8 relative overflow-hidden">
      {/* 背景动画元素 */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {mounted && (
          <>
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse" />
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-orange-500/10 rounded-full blur-3xl animate-pulse delay-1000" />
          </>
        )}
      </div>

      <div className={cn(
        "w-full max-w-md relative z-10",
        mounted && "animate-in fade-in slide-in-from-bottom-4 duration-500"
      )}>
        {/* Logo和标题 */}
        <div className="flex flex-col items-center mb-8">
          <div className="relative mb-4">
            <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-orange-500 rounded-2xl blur-lg opacity-50" />
            <Image
              src={APP_ICON_URL}
              alt={APP_NAME}
              width={80}
              height={80}
              className="rounded-2xl relative z-10"
              priority
            />
          </div>
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="w-5 h-5 text-orange-500" />
            <h1 className="text-2xl font-bold text-[#f8fafc]">{APP_NAME}</h1>
          </div>
          <p className="text-[#64748b] text-sm">智能获客 · 精准转化</p>
        </div>

        {/* 主卡片 */}
        <div className="bg-[#1a1f2c]/80 backdrop-blur-xl border border-[#2d3548] rounded-2xl p-6 shadow-2xl">
          {/* Tab切换 */}
          <div className="flex gap-2 mb-6">
            <button
              type="button"
              onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
              className={cn(
                'flex-1 py-3 text-sm font-medium rounded-xl transition-all duration-200',
                mode === 'login'
                  ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white shadow-lg shadow-blue-500/25'
                  : 'bg-[#2d3548]/50 text-[#94a3b8] hover:bg-[#2d3548] hover:text-[#f8fafc]'
              )}
            >
              登录
            </button>
            <button
              type="button"
              onClick={() => { setMode('register'); setError(''); setSuccess(''); }}
              className={cn(
                'flex-1 py-3 text-sm font-medium rounded-xl transition-all duration-200',
                mode === 'register'
                  ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white shadow-lg shadow-blue-500/25'
                  : 'bg-[#2d3548]/50 text-[#94a3b8] hover:bg-[#2d3548] hover:text-[#f8fafc]'
              )}
            >
              注册
            </button>
          </div>

          {/* 成功提示 */}
          {success && (
            <div className="mb-4 p-3 bg-green-500/10 border border-green-500/30 rounded-lg text-green-400 text-sm text-center animate-in fade-in slide-in-from-top-2">
              {success}
            </div>
          )}

          {/* 错误提示 */}
          {error && (
            <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm text-center animate-in fade-in slide-in-from-top-2">
              {error}
            </div>
          )}

          {/* 登录表单 */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type="email"
                  placeholder="邮箱地址"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="密码"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="w-full pl-10 pr-10 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#94a3b8]"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => { setMode('forgot'); setError(''); setSuccess(''); }}
                  className="text-sm text-[#3b82f6] hover:text-[#60a5fa] transition-colors"
                >
                  忘记密码？
                </button>
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white font-medium rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '登录'}
              </button>
            </form>
          )}

          {/* 注册表单 */}
          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type="email"
                  placeholder="邮箱地址"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="密码（至少6位）"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full pl-10 pr-10 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#64748b] hover:text-[#94a3b8]"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="确认密码"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white font-medium rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '注册'}
              </button>
            </form>
          )}

          {/* 忘记密码表单 */}
          {mode === 'forgot' && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <button
                type="button"
                onClick={() => { setMode('login'); setError(''); setSuccess(''); }}
                className="flex items-center gap-2 text-[#94a3b8] hover:text-[#f8fafc] transition-colors mb-4"
              >
                <ArrowLeft className="w-4 h-4" />
                返回登录
              </button>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#64748b]" />
                <input
                  type="email"
                  placeholder="输入邮箱地址"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="w-full pl-10 pr-4 py-3 bg-[#0f1419] border border-[#2d3548] rounded-xl text-[#f8fafc] placeholder-[#64748b] focus:border-[#3b82f6] focus:outline-none focus:ring-2 focus:ring-blue-500/20 transition-all"
                />
              </div>
              <p className="text-[#64748b] text-sm">
                输入注册邮箱，我们将发送密码重置链接到您的邮箱。
              </p>
              <button
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white font-medium rounded-xl hover:shadow-lg hover:shadow-blue-500/25 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : '发送重置邮件'}
              </button>
            </form>
          )}
        </div>

        {/* 底部信息 */}
        <div className="mt-6 text-center text-[#64748b] text-xs">
          <p>© 2024 全屋定制AI获客平台 · 面向工厂的专业获客工具</p>
        </div>
      </div>
    </div>
  );
}