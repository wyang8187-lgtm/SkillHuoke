'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle, Eye, EyeOff, Key, Loader2, RefreshCw } from 'lucide-react';

// API密钥配置项
const API_KEYS_CONFIG = [
  {
    id: 'deepseek',
    name: 'DeepSeek API Key',
    description: '用于AI智能搜客、开发信生成等功能',
    placeholder: 'sk-xxxxxxxxxxxxxxxxxxxxxxxx',
    docsUrl: 'https://platform.deepseek.com/api_keys',
    category: 'AI模型'
  },
  {
    id: 'openai',
    name: 'OpenAI API Key',
    description: '备选AI模型，用于智能内容生成',
    placeholder: 'sk-xxxxxxxxxxxxxxxxxxxxxxxx',
    docsUrl: 'https://platform.openai.com/api-keys',
    category: 'AI模型'
  },
  {
    id: 'smtp_host',
    name: 'SMTP 发件服务器',
    description: '邮件发送服务器地址',
    placeholder: 'smtp.example.com',
    docsUrl: '',
    category: '邮件服务'
  },
  {
    id: 'smtp_port',
    name: 'SMTP 端口',
    description: '邮件服务器端口（通常为465或587）',
    placeholder: '465',
    docsUrl: '',
    category: '邮件服务'
  },
  {
    id: 'smtp_user',
    name: 'SMTP 用户名',
    description: '邮件发送账户用户名',
    placeholder: 'user@example.com',
    docsUrl: '',
    category: '邮件服务'
  },
  {
    id: 'smtp_password',
    name: 'SMTP 密码',
    description: '邮件发送账户密码',
    placeholder: '',
    docsUrl: '',
    category: '邮件服务',
    isPassword: true
  },
  {
    id: 'whatsapp',
    name: 'WhatsApp Business API Token',
    description: '用于WhatsApp营销消息发送',
    placeholder: 'EAxxxxxxxxxxxxxxxxxxxx',
    docsUrl: 'https://developers.facebook.com/docs/whatsapp/business-management-api',
    category: '社媒营销'
  },
  {
    id: 'linkedin',
    name: 'LinkedIn API Key',
    description: '用于LinkedIn社媒获客',
    placeholder: '',
    docsUrl: 'https://www.linkedin.com/developers/apps',
    category: '社媒营销'
  }
];

export default function ApiKeysPage() {
  const [keys, setKeys] = useState<Record<string, string>>({});
  const [visibleKeys, setVisibleKeys] = useState<Record<string, boolean>>({});
  const [testingKeys, setTestingKeys] = useState<Record<string, boolean>>({});
  const [saveStatus, setSaveStatus] = useState<Record<string, 'idle' | 'saving' | 'saved' | 'error'>>({});
  const [testStatus, setTestStatus] = useState<Record<string, 'idle' | 'testing' | 'success' | 'failed'>>({});

  // 切换密钥可见性
  const toggleVisibility = (keyId: string) => {
    setVisibleKeys(prev => ({ ...prev, [keyId]: !prev[keyId] }));
  };

  // 更新密钥值
  const updateKey = (keyId: string, value: string) => {
    setKeys(prev => ({ ...prev, [keyId]: value }));
    setSaveStatus(prev => ({ ...prev, [keyId]: 'idle' }));
  };

  // 保存密钥
  const saveKey = async (keyId: string) => {
    setSaveStatus(prev => ({ ...prev, [keyId]: 'saving' }));
    
    try {
      const res = await fetch('/api/settings/api-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyId, value: keys[keyId] })
      });
      
      if (res.ok) {
        setSaveStatus(prev => ({ ...prev, [keyId]: 'saved' }));
      } else {
        setSaveStatus(prev => ({ ...prev, [keyId]: 'error' }));
      }
    } catch {
      setSaveStatus(prev => ({ ...prev, [keyId]: 'error' }));
    }
  };

  // 测试密钥连接
  const testKey = async (keyId: string) => {
    setTestingKeys(prev => ({ ...prev, [keyId]: true }));
    setTestStatus(prev => ({ ...prev, [keyId]: 'testing' }));
    
    try {
      const res = await fetch('/api/settings/api-keys/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keyId, value: keys[keyId] })
      });
      
      const data = await res.json();
      
      if (data.success) {
        setTestStatus(prev => ({ ...prev, [keyId]: 'success' }));
      } else {
        setTestStatus(prev => ({ ...prev, [keyId]: 'failed' }));
      }
    } catch {
      setTestStatus(prev => ({ ...prev, [keyId]: 'failed' }));
    } finally {
      setTestingKeys(prev => ({ ...prev, [keyId]: false }));
    }
  };

  // 按类别分组
  const groupedKeys = API_KEYS_CONFIG.reduce((acc, config) => {
    if (!acc[config.category]) acc[config.category] = [];
    acc[config.category].push(config);
    return acc;
  }, {} as Record<string, typeof API_KEYS_CONFIG>);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <Key className="w-6 h-6" />
          API 密钥管理
        </h1>
        <Button variant="outline" onClick={() => {
          // 刷新所有密钥状态
          Object.keys(groupedKeys).forEach(category => {
            groupedKeys[category].forEach(config => {
              if (keys[config.id]) {
                testKey(config.id);
              }
            });
          });
        }}>
          <RefreshCw className="w-4 h-4 mr-2" />
          一键检测全部
        </Button>
      </div>

      {/* 说明卡片 */}
      <Card className="bg-muted/10 border">
        <CardContent className="p-4">
          <div className="text-sm text-muted-foreground">
            <p className="font-medium mb-2">配置说明：</p>
            <ul className="list-disc list-inside space-y-1">
              <li>API密钥用于启用平台的智能功能（AI搜客、自动开发信、邮件营销等）</li>
              <li>密钥将加密存储在数据库中，确保安全性</li>
              <li>点击"测试连接"可验证密钥是否有效</li>
              <li>未配置的密钥对应功能将使用模拟数据</li>
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* 按类别展示 */}
      {Object.entries(groupedKeys).map(([category, configs]) => (
        <Card key={category}>
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Badge variant="outline">{category}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {configs.map(config => (
              <div key={config.id} className="flex items-start gap-4 p-4 bg-muted/10 rounded-lg">
                <div className="flex-1">
                  <div className="font-medium mb-1">{config.name}</div>
                  <div className="text-sm text-muted-foreground mb-2">{config.description}</div>
                  <div className="relative">
                    <Input
                      type={config.isPassword && !visibleKeys[config.id] ? 'password' : 'text'}
                      placeholder={config.placeholder}
                      value={keys[config.id] || ''}
                      onChange={(e) => updateKey(config.id, e.target.value)}
                      className="pr-10"
                    />
                    {config.isPassword && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="absolute right-0 top-0 h-full px-3"
                        onClick={() => toggleVisibility(config.id)}
                      >
                        {visibleKeys[config.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </Button>
                    )}
                  </div>
                  {config.docsUrl && (
                    <a 
                      href={config.docsUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-xs text-blue-500 hover:underline mt-1 inline-block"
                    >
                      如何获取密钥 →
                    </a>
                  )}
                </div>
                
                {/* 操作按钮 */}
                <div className="flex flex-col gap-2">
                  <Button
                    size="sm"
                    onClick={() => saveKey(config.id)}
                    disabled={!keys[config.id] || saveStatus[config.id] === 'saving'}
                  >
                    {saveStatus[config.id] === 'saving' ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : saveStatus[config.id] === 'saved' ? (
                      <CheckCircle className="w-4 h-4" />
                    ) : saveStatus[config.id] === 'error' ? (
                      <AlertCircle className="w-4 h-4" />
                    ) : (
                      '保存'
                    )}
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => testKey(config.id)}
                    disabled={!keys[config.id] || testingKeys[config.id]}
                  >
                    {testingKeys[config.id] ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : testStatus[config.id] === 'success' ? (
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    ) : testStatus[config.id] === 'failed' ? (
                      <AlertCircle className="w-4 h-4 text-red-500" />
                    ) : (
                      '测试'
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}