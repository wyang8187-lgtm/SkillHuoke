# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进和英文开发动作。

当前版本：`v0.33.0`

## v0.33.0 更新

- 新增 `/email-center` 邮件发送中心。
- 支持 Resend 后端真实发送和未配置时本地草稿降级。
- 内置报价、订单、PI、商业发票、装箱单和出货英文模板。
- 支持最多 3 个 PDF 附件，密钥和附件内容不进入本地备份。
- 数据备份升级为版本 8，包含邮件文本记录并兼容版本 1-7。

Resend 配置：在 `.env` 填写 `RESEND_API_KEY`、`RESEND_FROM_EMAIL` 和 `RESEND_FROM_NAME`，并先在 Resend 验证发件域名。未配置时系统仍可保存本地草稿。

客户与跟进记录目前保存在浏览器本地；更换设备或清理浏览器数据后不会自动同步。

## 核心流程

1. 在 `/lead-wizard` 输入产品、国家、客户类型和数量，保存获客任务。
2. 在 `/lead-tasks` 进入任务执行台，把结果沉淀到候选客户池。
3. 在 `/candidate-leads` 核验并筛选客户，把合适客户加入 CRM。
4. 在 `/crm-customers` 查看客户阶段，并进入客户详情持续跟进。
5. 在客户详情记录联系结果，安排下次行动并复制英文开发文案。

## 预留接口

获客搜索：

```text
POST /api/integrations/lead-search
```

OpenAI：

```text
POST /api/integrations/openai
```

没有配置 API Key 时接口返回演示内容，方便开源项目直接运行。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

点击“演示模式进入工作台”即可查看。

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 环境变量

复制 `.env.example` 为 `.env.local`，按需填写：

```text
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5.4-mini
LEAD_SEARCH_API_KEY=
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

## 开源协议

MIT
