import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.22.0',
  title: 'AI 开发信升级',
  date: '2026-06-27',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.22.0-OpenSource.zip',
  githubRemark: 'v0.22.0：升级 AI 开发信，支持 OpenAI 生成与本地模板自动降级',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  'AI 开发助手支持首次开发信、二次跟进邮件、WhatsApp 和 LinkedIn 私信。',
  '支持专业、简洁、友好三种英文语气，并根据客户资料生成个性化内容。',
  '优先调用后端 OpenAI Responses API，未配置密钥或请求失败时自动使用本地模板。',
  '显示内容来源、降级原因和生成时间，并支持分别复制邮件主题和正文。',
];

export const releaseReviewPages = [
  {
    title: 'CRM 客户池',
    href: '/crm-customers',
    description: '查看客户阶段、评分、优先级和下一步动作，并进入单个客户详情。',
  },
  {
    title: 'AI 开发助手',
    href: '/crm-customers/demo-customer',
    description: '从 CRM 客户池进入真实客户详情后，可选择内容类型和语气生成英文开发内容。',
  },
  {
    title: '客户详情演示',
    href: '/crm-customers/demo-customer',
    description: '需要先从候选客户池加入客户；不存在的客户会显示安全的空状态。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '管理任务沉淀的候选客户，并把适合开发的客户加入 CRM。',
  },
  {
    title: '获客任务记录',
    href: '/lead-tasks',
    description: '查看已保存的获客任务，进入执行台并沉淀候选客户。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和数量，生成获客方案并保存为任务。',
  },
  {
    title: '新手运营引导',
    href: '/onboarding',
    description: '按照获客、核验、开发和 CRM 跟进流程熟悉系统。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '点击“演示模式进入工作台”即可查看当前版本。',
  },
  {
    title: '团队管理',
    href: '/team',
    description: '查看成员、角色和工作量展示。',
  },
  {
    title: '权限矩阵',
    href: '/team/permissions',
    description: '查看老板、管理员、销售和运营的权限差异。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看 CRM 客户、跟进时间线和英文开发动作。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看批量获客任务、候选客户核验和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '先在候选客户池加入一个客户，再进入 CRM 客户池查看详情。',
  '新增一条跟进记录，设置下次跟进时间，并测试复制英文开发文案。',
  '确认版本信息后，将上传包发布到 GitHub 开源仓库。',
];
