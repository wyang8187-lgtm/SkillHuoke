'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  crmCustomerStatusOptions,
  deleteSavedCrmCustomer,
  getCrmCustomerStatusMeta,
  loadSavedCrmCustomers,
  updateSavedCrmCustomer,
  type CrmCustomerStatus,
  type SavedCrmCustomer,
} from '@/lib/lead-wizard';
import { ArrowRight, BriefcaseBusiness, CalendarClock, ExternalLink, Trash2, UsersRound } from 'lucide-react';

export default function CrmCustomersPage() {
  const [customers, setCustomers] = useState<SavedCrmCustomer[]>([]);
  const [statusFilter, setStatusFilter] = useState<CrmCustomerStatus | 'all'>('all');

  useEffect(() => {
    setCustomers(loadSavedCrmCustomers());
  }, []);

  const filteredCustomers = useMemo(
    () => statusFilter === 'all' ? customers : customers.filter((customer) => customer.status === statusFilter),
    [customers, statusFilter]
  );

  const summary = useMemo(() => ({
    total: customers.length,
    newCount: customers.filter((customer) => customer.status === 'new').length,
    contacted: customers.filter((customer) => customer.status === 'contacted').length,
    replied: customers.filter((customer) => customer.status === 'replied').length,
    quoted: customers.filter((customer) => customer.status === 'quoted').length,
  }), [customers]);

  const updateCustomerStatus = (customerId: string, status: CrmCustomerStatus) => {
    setCustomers(updateSavedCrmCustomer(customerId, { status }));
  };

  return (
    <MainLayout title="CRM 客户池">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.21.0</Badge>
            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">客户跟进中心</Badge>
          </div>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">从候选客户进入持续跟进</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                集中查看 CRM 阶段、开发优先级和下一步动作。进入客户详情后，可以记录邮件、WhatsApp、LinkedIn、电话跟进，并直接使用英文开发文案。
              </p>
            </div>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/candidate-leads">
                打开候选客户池
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-5">
          {[
            { label: '全部客户', value: summary.total, tone: 'text-blue-300' },
            { label: '新客户', value: summary.newCount, tone: 'text-sky-300' },
            { label: '已开发', value: summary.contacted, tone: 'text-violet-300' },
            { label: '已回复', value: summary.replied, tone: 'text-emerald-300' },
            { label: '已报价', value: summary.quoted, tone: 'text-amber-300' },
          ].map((item) => (
            <Card key={item.label} className="border-[#2d3548] bg-[#121823]">
              <CardContent className="p-5">
                <p className="text-sm text-[#94a3b8]">{item.label}</p>
                <p className={`mt-2 text-2xl font-semibold ${item.tone}`}>{item.value}</p>
              </CardContent>
            </Card>
          ))}
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
              <UsersRound className="h-5 w-5 text-blue-300" />
              CRM 客户列表
            </CardTitle>
            <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as CrmCustomerStatus | 'all')}>
              <SelectTrigger className="w-full border-[#2d3548] bg-[#0f1419] text-[#f8fafc] sm:w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">全部状态</SelectItem>
                {crmCustomerStatusOptions.map((status) => (
                  <SelectItem key={status.value} value={status.value}>{status.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardHeader>
          <CardContent>
            {filteredCustomers.length === 0 ? (
              <div className="rounded-lg border border-dashed border-[#2d3548] bg-[#0f1419] p-8 text-center">
                <BriefcaseBusiness className="mx-auto h-10 w-10 text-[#64748b]" />
                <h3 className="mt-4 font-medium text-[#f8fafc]">还没有 CRM 客户</h3>
                <p className="mt-2 text-sm text-[#94a3b8]">先从候选客户池选择真实客户并加入 CRM。</p>
                <Button asChild className="mt-5 bg-blue-600 text-white hover:bg-blue-500">
                  <Link href="/candidate-leads">打开候选客户池</Link>
                </Button>
              </div>
            ) : (
              <div className="grid gap-4 xl:grid-cols-2">
                {filteredCustomers.map((customer) => {
                  const status = getCrmCustomerStatusMeta(customer.status);
                  return (
                    <article key={customer.id} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                        <div className="min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <Badge className={`border ${status.className}`}>{status.label}</Badge>
                            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{customer.priority} 级</Badge>
                            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">{customer.score} 分</Badge>
                          </div>
                          <h3 className="mt-3 text-lg font-semibold text-[#f8fafc]">{customer.company}</h3>
                          <p className="mt-1 text-sm text-[#94a3b8]">{customer.country} / {customer.city} · {customer.customerType}</p>
                        </div>
                        <Select value={customer.status} onValueChange={(value) => updateCustomerStatus(customer.id, value as CrmCustomerStatus)}>
                          <SelectTrigger className="h-10 border-[#2d3548] bg-[#121823] text-[#f8fafc] sm:w-32">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {crmCustomerStatusOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="mt-4 rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                        <p className="flex items-center gap-2 text-xs text-[#64748b]">
                          <CalendarClock className="h-4 w-4" />
                          下一步动作
                        </p>
                        <p className="mt-2 line-clamp-2 text-sm leading-6 text-[#cbd5e1]">{customer.nextAction || '进入详情页安排下一次跟进。'}</p>
                      </div>

                      <div className="mt-4 flex flex-wrap gap-2">
                        <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
                          <Link href={`/crm-customers/${encodeURIComponent(customer.id)}`}>
                            查看详情
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Link>
                        </Button>
                        {customer.website ? (
                          <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1]">
                            <a href={customer.website} target="_blank" rel="noreferrer">
                              官网
                              <ExternalLink className="ml-2 h-4 w-4" />
                            </a>
                          </Button>
                        ) : null}
                        <Button
                          type="button"
                          size="icon"
                          variant="outline"
                          title="删除客户"
                          className="ml-auto border-red-500/25 bg-transparent text-red-300 hover:bg-red-500/10"
                          onClick={() => setCustomers(deleteSavedCrmCustomer(customer.id))}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </article>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
