import assert from 'node:assert/strict';
import { parseBackupFile } from '../src/lib/data-backup';

const baseData = {
  leadTasks: [],
  candidateLeads: [],
  crmCustomers: [],
  crmFollowUps: [],
  crmOpportunities: [],
  crmQuotations: [],
};

const v4 = JSON.stringify({
  format: 'skillhuoke-backup',
  version: 4,
  appVersion: 'v0.29.0',
  exportedAt: '2026-06-27T00:00:00.000Z',
  summary: {},
  data: baseData,
});
const parsedV4 = parseBackupFile(v4, new Blob([v4]).size);
assert.equal(parsedV4.version, 5);
assert.deepEqual(parsedV4.data.crmOrders, []);

const order = { id: 'order-1', updatedAt: '2026-06-27T00:00:00.000Z' };
const v5 = JSON.stringify({
  format: 'skillhuoke-backup',
  version: 5,
  appVersion: 'v0.30.0',
  exportedAt: '2026-06-27T00:00:00.000Z',
  summary: {},
  data: { ...baseData, crmOrders: [order] },
});
assert.equal(parseBackupFile(v5, new Blob([v5]).size).data.crmOrders[0].id, 'order-1');

console.log('data-backup-v5 tests passed');
