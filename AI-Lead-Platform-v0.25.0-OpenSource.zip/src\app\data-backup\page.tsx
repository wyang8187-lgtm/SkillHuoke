'use client';

import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  createBackupPayload,
  createBackupPreview,
  createCrmCsv,
  getCurrentBackupSummary,
  getLastBackupTime,
  hasRestorePoint,
  markBackupDownloaded,
  parseBackupFile,
  restoreBackup,
  undoLastRestore,
  type BackupPreview,
  type BackupSummary,
} from '@/lib/data-backup';
import { AlertTriangle, DatabaseBackup, Download, FileCheck2, FileJson, RotateCcw, Upload } from 'lucide-react';

const emptySummary: BackupSummary = { leadTasks: 0, candidateLeads: 0, crmCustomers: 0, crmFollowUps: 0 };

function downloadText(filename: string, content: string, type: string) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

function fileStamp() {
  const now = new Date();
  const pad = (value: number) => String(value).padStart(2, '0');
  return `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}-${pad(now.getHours())}${pad(now.getMinutes())}`;
}

export default function DataBackupPage() {
  const [summary, setSummary] = useState<BackupSummary>(emptySummary);
  const [lastBackup, setLastBackup] = useState('');
  const [preview, setPreview] = useState<BackupPreview>();
  const [restoreAvailable, setRestoreAvailable] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const refresh = () => {
    setSummary(getCurrentBackupSummary());
    setLastBackup(getLastBackupTime());
    setRestoreAvailable(hasRestorePoint());
  };

  useEffect(() => {
    refresh();
  }, []);

  const exportJson = () => {
    try {
      const backup = createBackupPayload();
      downloadText(`SkillHuoke-Backup-${fileStamp()}.json`, JSON.stringify(backup, null, 2), 'application/json;charset=utf-8');
      markBackupDownloaded(backup.exportedAt);
      setMessage('完整 JSON 备份已下载。');
      setError('');
      refresh();
    } catch {
      setError('备份下载失败，请重试。');
    }
  };

  const exportCsv = () => {
    try {
      downloadText(`SkillHuoke-CRM-${fileStamp()}.csv`, createCrmCsv(), 'text/csv;charset=utf-8');
      setMessage('CRM 客户 CSV 已下载。');
      setError('');
    } catch {
      setError('CSV 导出失败，请重试。');
    }
  };

  const selectBackup = async (file?: File) => {
    setPreview(undefined);
    setMessage('');
    setError('');
    if (!file) return;
    try {
      const backup = parseBackupFile(await file.text(), file.size);
      setPreview(createBackupPreview(backup));
    } catch (parseError) {
      setError(parseError instanceof Error ? parseError.message : '备份文件预检失败。');
    }
  };

  const applyRestore = (mode: 'merge' | 'overwrite') => {
    if (!preview) return;
    const text = mode === 'overwrite'
      ? '覆盖恢复会替换当前四类业务数据，确认继续吗？'
      : '确认把备份数据合并到当前浏览器吗？';
    if (!window.confirm(text)) return;
    try {
      const nextSummary = restoreBackup(preview.backup, mode);
      setSummary(nextSummary);
      setRestoreAvailable(true);
      setPreview(undefined);
      setMessage(mode === 'overwrite' ? '覆盖恢复完成，已自动保存恢复点。' : '合并导入完成，已自动保存恢复点。');
      setError('');
    } catch {
      setError('导入失败，当前数据没有被确认更新。');
    }
  };

  const undo = () => {
    if (!window.confirm('确认撤销最近一次导入并恢复原数据吗？')) return;
    try {
      setSummary(undoLastRestore());
      setRestoreAvailable(false);
      setMessage('最近一次导入已撤销。');
      setError('');
    } catch (undoError) {
      setError(undoError instanceof Error ? undoError.message : '撤销失败。');
    }
  };

  return (
    <MainLayout title="数据备份">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="flex flex-wrap gap-2">
                <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.24.0</Badge>
                <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">仅备份业务数据</Badge>
              </div>
              <h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">保护你的客户和跟进记录</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">备份不会包含 API Key、密码、登录会话、环境变量或浏览器 Cookie。</p>
            </div>
            <div className="text-sm text-[#94a3b8]">最近备份：{lastBackup ? new Date(lastBackup).toLocaleString('zh-CN') : '尚未备份'}</div>
          </div>
        </section>

        <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {[
            ['获客任务', summary.leadTasks],
            ['候选客户', summary.candidateLeads],
            ['CRM 客户', summary.crmCustomers],
            ['跟进记录', summary.crmFollowUps],
          ].map(([label, value]) => (
            <Card key={label} className="border-[#2d3548] bg-[#121823]"><CardContent className="p-5"><p className="text-sm text-[#94a3b8]">{label}</p><p className="mt-2 text-2xl font-semibold text-blue-300">{value}</p></CardContent></Card>
          ))}
        </section>

        {message ? <div className="rounded-lg border border-emerald-500/25 bg-emerald-500/10 p-4 text-sm text-emerald-200">{message}</div> : null}
        {error ? <div className="rounded-lg border border-red-500/25 bg-red-500/10 p-4 text-sm text-red-200">{error}</div> : null}

        <section className="grid gap-6 lg:grid-cols-2">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader><CardTitle className="flex items-center gap-2 text-[#f8fafc]"><DatabaseBackup className="h-5 w-5 text-blue-300" />导出备份</CardTitle></CardHeader>
            <CardContent className="space-y-3">
              <Button type="button" onClick={exportJson} className="w-full justify-start bg-blue-600 text-white hover:bg-blue-500"><FileJson className="mr-2 h-4 w-4" />下载完整 JSON 备份</Button>
              <Button type="button" onClick={exportCsv} variant="outline" className="w-full justify-start border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"><Download className="mr-2 h-4 w-4" />下载 CRM 客户 CSV</Button>
              <p className="text-xs leading-5 text-[#64748b]">JSON 用于恢复系统数据；CSV 用于在 Excel 中查看和整理 CRM 客户。</p>
            </CardContent>
          </Card>

          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader><CardTitle className="flex items-center gap-2 text-[#f8fafc]"><Upload className="h-5 w-5 text-violet-300" />导入备份</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <Input type="file" accept=".json,application/json" onChange={(event) => selectBackup(event.target.files?.[0])} className="border-[#2d3548] bg-[#0f1419] text-[#cbd5e1]" />
              <p className="text-xs leading-5 text-[#64748b]">选择文件后只做预检，不会立即修改数据。最大文件 10 MB。</p>
              {restoreAvailable ? (
                <Button type="button" variant="outline" className="w-full border-amber-500/25 bg-amber-500/10 text-amber-200" onClick={undo}><RotateCcw className="mr-2 h-4 w-4" />撤销最近一次导入</Button>
              ) : null}
            </CardContent>
          </Card>
        </section>

        {preview ? (
          <Card className="border-violet-500/25 bg-[#121823]">
            <CardHeader><CardTitle className="flex items-center gap-2 text-[#f8fafc]"><FileCheck2 className="h-5 w-5 text-violet-300" />导入预检结果</CardTitle></CardHeader>
            <CardContent className="space-y-5">
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
                {[
                  ['获客任务', preview.imported.leadTasks, preview.duplicateIds.leadTasks],
                  ['候选客户', preview.imported.candidateLeads, preview.duplicateIds.candidateLeads],
                  ['CRM 客户', preview.imported.crmCustomers, preview.duplicateIds.crmCustomers],
                  ['跟进记录', preview.imported.crmFollowUps, preview.duplicateIds.crmFollowUps],
                ].map(([label, total, duplicates]) => (
                  <div key={label} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4"><p className="text-sm text-[#94a3b8]">{label}</p><p className="mt-2 text-lg font-semibold text-[#f8fafc]">{total} 条</p><p className="mt-1 text-xs text-amber-300">重复 ID：{duplicates}</p></div>
                ))}
              </div>
              <div className="rounded-lg border border-amber-500/25 bg-amber-500/10 p-4 text-sm text-amber-100"><AlertTriangle className="mr-2 inline h-4 w-4" />来源版本：{preview.backup.appVersion}，导出时间：{preview.backup.exportedAt ? new Date(preview.backup.exportedAt).toLocaleString('zh-CN') : '未知'}</div>
              <div className="flex flex-wrap gap-3">
                <Button type="button" onClick={() => applyRestore('merge')} className="bg-blue-600 text-white hover:bg-blue-500">合并导入</Button>
                <Button type="button" onClick={() => applyRestore('overwrite')} variant="outline" className="border-red-500/25 bg-red-500/10 text-red-200">覆盖恢复</Button>
              </div>
            </CardContent>
          </Card>
        ) : null}
      </div>
    </MainLayout>
  );
}
