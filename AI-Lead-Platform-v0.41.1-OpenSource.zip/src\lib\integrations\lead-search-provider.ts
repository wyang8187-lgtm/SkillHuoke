export type LeadSearchProvider = 'auto' | 'mock' | 'google' | 'serpapi' | 'bing';

export interface LeadSearchInput {
  product: string;
  country: string;
  customerType: string;
  quantity?: number;
  provider?: LeadSearchProvider;
  query?: string;
}

export interface LeadSearchCandidate {
  companyName: string;
  website?: string;
  country: string;
  city?: string;
  customerType: string;
  sourceUrl?: string;
  emailStatus: 'found' | 'not_found' | 'needs_verification';
  phoneStatus: 'found' | 'not_found' | 'needs_verification';
  whatsappStatus: 'found' | 'not_found' | 'needs_verification';
  linkedinStatus: 'found' | 'not_found' | 'needs_verification';
  matchScore: number;
  priority: 'A' | 'B' | 'C' | 'D';
  confidence: number;
  riskSignals: string[];
  nextAction: string;
}

export interface SearchAttempt {
  provider: Exclude<LeadSearchProvider, 'auto' | 'mock'>;
  query: string;
  status: 'success' | 'empty' | 'failed';
  rawCount: number;
  usableCount: number;
  reason?: string;
}

export interface LeadSearchBatchSummary {
  targetQuantity: number;
  queryCount: number;
  providerCount: number;
  attemptCount: number;
  rawCount: number;
  usableCount: number;
  dedupedCount: number;
  returnedCount: number;
  reachedTarget: boolean;
  partial: boolean;
}

export interface LeadSearchResult {
  provider: LeadSearchProvider;
  query: string;
  candidates: LeadSearchCandidate[];
  warnings: string[];
  searchQueries?: string[];
  attempts?: SearchAttempt[];
  filteredCount?: number;
  batchSummary?: LeadSearchBatchSummary;
}

interface SearchProviderOptions {
  env?: NodeJS.ProcessEnv | Record<string, string | undefined>;
  fetcher?: typeof fetch;
  timeoutMs?: number;
}

interface RawSearchResult {
  title: string;
  url: string;
  snippet: string;
  provider: Exclude<LeadSearchProvider, 'auto' | 'mock'>;
}

type SourceType = 'official' | 'contact_page' | 'directory' | 'social' | 'marketplace' | 'job' | 'document' | 'noise';

interface ClassifiedResult extends RawSearchResult {
  domain: string;
  sourceType: SourceType;
  score: number;
  riskSignals: string[];
  evidenceSignals: string[];
}

function envValue(env: NodeJS.ProcessEnv | Record<string, string | undefined>, key: string) {
  return env[key]?.trim() || '';
}

function uniqueValues(values: string[]) {
  const seen = new Set<string>();
  return values
    .map((value) => value.replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .filter((value) => {
      const key = value.toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

function splitTerms(value: string) {
  return value
    .split(/[,+，、/|]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function splitCustomerTypes(customerType: string) {
  const terms = splitTerms(customerType);
  return terms.length ? terms : [customerType.trim()].filter(Boolean);
}

function splitProductTerms(product: string) {
  const terms = splitTerms(product);
  return terms.length ? terms : [product.trim()].filter(Boolean);
}

function countryCities(country: string) {
  const normalized = country.toLowerCase();
  if (normalized.includes('australia') || country.includes('澳')) {
    return ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide', 'Gold Coast', 'Canberra'];
  }
  if (normalized.includes('united states') || normalized.includes('usa') || country.includes('美国')) {
    return ['Los Angeles', 'New York', 'Houston', 'Dallas', 'Miami', 'Chicago', 'Seattle'];
  }
  return [];
}

export function buildSearchQueries(input: LeadSearchInput) {
  const country = input.country.trim();
  const products = splitProductTerms(input.product);
  const customerTypes = splitCustomerTypes(input.customerType);
  const cities = countryCities(country);
  const targetQuantity = Math.min(Math.max(input.quantity || 10, 1), 50);
  const maxQueries = targetQuantity >= 40 ? 36 : targetQuantity >= 25 ? 24 : 12;
  const primaryProduct = products[0] || input.product.trim();
  const primaryType = customerTypes[0] || input.customerType.trim();
  const typeGroup = customerTypes.join(' OR ') || input.customerType.trim();
  const base = `${country} ${primaryProduct} ${primaryType}`;
  const queries: string[] = [
    input.query || '',
    `${base} official website contact email phone`,
    `${base} company "contact us"`,
    `${country} (${typeGroup}) ${primaryProduct} supplier website`,
    `${base} projects showroom about team`,
    `${base} LinkedIn company`,
    `${base} WhatsApp phone email`,
  ];

  for (const city of cities) {
    for (const type of customerTypes.slice(0, 4)) {
      queries.push(`${city} ${primaryProduct} ${type} contact`);
      queries.push(`${city} ${primaryProduct} ${type} company website`);
    }
  }

  for (const type of customerTypes) {
    for (const product of products) {
      queries.push(`${country} ${product} ${type} official website`);
      queries.push(`${country} ${product} ${type} contact email phone`);
      queries.push(`${country} ${product} ${type} projects showroom`);
      queries.push(`${country} ${product} ${type} LinkedIn company`);
    }
  }

  return uniqueValues(queries).slice(0, maxQueries);
}

function configuredProviders(env: NodeJS.ProcessEnv | Record<string, string | undefined>) {
  return {
    serpapi: Boolean(envValue(env, 'SERPAPI_KEY') || envValue(env, 'SERPAPI_API_KEY')),
    bing: Boolean(envValue(env, 'BING_SEARCH_API_KEY')),
    google: Boolean(envValue(env, 'GOOGLE_SEARCH_API_KEY') && envValue(env, 'GOOGLE_SEARCH_CX')),
  };
}

function providerOrder(provider: LeadSearchProvider, env: NodeJS.ProcessEnv | Record<string, string | undefined>) {
  const configured = configuredProviders(env);
  if (provider === 'mock') return [];
  if (provider !== 'auto') return configured[provider] ? [provider] : [];
  return (['serpapi', 'bing', 'google'] as const).filter((item) => configured[item]);
}

function extractDomain(url: string) {
  try {
    const parsed = new URL(url);
    return parsed.hostname.replace(/^www\./, '').toLowerCase();
  } catch {
    return '';
  }
}

function cleanCompanyName(title: string, domain: string) {
  const cleaned = title
    .replace(/\s*[-|–—].*$/, '')
    .replace(/\b(Home|Homepage|Contact|Contact Us|About|About Us|Official Website)\b/gi, '')
    .trim();
  if (cleaned.length >= 3) return cleaned;
  return domain.split('.')[0]?.replace(/[-_]/g, ' ') || 'Unknown Company';
}

function classifySource(result: RawSearchResult): SourceType {
  const url = result.url.toLowerCase();
  const text = `${result.title} ${result.snippet}`.toLowerCase();
  if (url.endsWith('.pdf') || text.includes(' pdf ')) return 'document';
  if (/(jobs|career|careers|recruit|hiring|seek\.com|indeed\.com|glassdoor)/.test(url + text)) return 'job';
  if (/(wikipedia|pinterest|reddit|forum|blogspot|wordpress\.com)/.test(url)) return 'noise';
  if (/(facebook\.com|instagram\.com|tiktok\.com|linkedin\.com|youtube\.com)/.test(url)) return 'social';
  if (/(yellowpages|yelp\.|truelocal|hotfrog|directory|find-open|cylex|dnb\.com)/.test(url)) return 'directory';
  if (/(houzz|archipro|build\.com\.au|homeimprovementpages|hipages)/.test(url)) return 'marketplace';
  if (/(contact|contact-us|about|about-us|team|showroom|projects|gallery)/.test(url)) return 'contact_page';
  return 'official';
}

function scoreClassifiedResult(result: RawSearchResult, input: LeadSearchInput, index: number): ClassifiedResult {
  const domain = extractDomain(result.url);
  const sourceType = classifySource(result);
  const text = `${result.title} ${result.snippet} ${result.url}`.toLowerCase();
  const productTokens = input.product.toLowerCase().split(/\s+/).filter((token) => token.length > 3);
  const typeTokens = input.customerType.toLowerCase().split(/\s+|\+/).filter((token) => token.length > 3);
  const evidenceSignals: string[] = [];
  const riskSignals: string[] = [];
  let score = 74 - Math.min(index, 6) * 2;

  if (sourceType === 'official') {
    score += 14;
    evidenceSignals.push('official_domain');
  }
  if (sourceType === 'contact_page') {
    score += 18;
    evidenceSignals.push('contact_or_about_page');
  }
  if (sourceType === 'marketplace') {
    score += 4;
    evidenceSignals.push('industry_marketplace_source');
    riskSignals.push('marketplace_needs_official_site_check');
  }
  if (sourceType === 'directory') {
    score -= 10;
    riskSignals.push('directory_result_needs_official_site');
  }
  if (sourceType === 'social') {
    score -= 12;
    riskSignals.push('social_page_needs_company_verification');
  }
  if (sourceType === 'job') {
    score -= 45;
    riskSignals.push('job_page_noise');
  }
  if (sourceType === 'document') {
    score -= 32;
    riskSignals.push('document_result_noise');
  }
  if (sourceType === 'noise') {
    score -= 45;
    riskSignals.push('noise_result');
  }
  if (productTokens.some((token) => text.includes(token))) {
    score += 8;
    evidenceSignals.push('product_match');
  }
  if (typeTokens.some((token) => text.includes(token))) {
    score += 8;
    evidenceSignals.push('customer_type_match');
  }
  if (/(contact|email|phone|tel|call|showroom)/.test(text)) {
    score += 6;
    evidenceSignals.push('contact_evidence');
  }
  if (/linkedin/.test(text)) {
    score += 3;
    evidenceSignals.push('linkedin_evidence');
  }
  if (/whatsapp/.test(text)) {
    score += 4;
    evidenceSignals.push('whatsapp_evidence');
  }
  if (!domain) {
    score -= 8;
    riskSignals.push('invalid_url');
  }

  return {
    ...result,
    domain,
    sourceType,
    score: Math.max(20, Math.min(96, score)),
    riskSignals,
    evidenceSignals,
  };
}

function priorityFromScore(score: number): LeadSearchCandidate['priority'] {
  if (score >= 84) return 'A';
  if (score >= 72) return 'B';
  if (score >= 58) return 'C';
  return 'D';
}

function sourceTypeLabel(type: SourceType) {
  const labels: Record<SourceType, string> = {
    official: '官网',
    contact_page: '联系/关于页面',
    directory: '目录页',
    social: '社媒页',
    marketplace: '行业平台',
    job: '招聘页',
    document: '文档页',
    noise: '噪音页',
  };
  return labels[type];
}

function buildNextAction(priority: LeadSearchCandidate['priority'], result: ClassifiedResult) {
  if (priority === 'A') return '优先核验官网 Contact / About 页面，补全邮箱、电话和 LinkedIn 后进入 CRM 开发。';
  if (priority === 'B') return '先核验官网和业务匹配度，再选择英文开发信或 LinkedIn 人员搜索。';
  if (priority === 'C') return '补充官网证据、联系人和联系方式后再决定是否开发。';
  return `暂缓开发：当前结果更像${sourceTypeLabel(result.sourceType)}或证据不足。`;
}

function toCandidate(result: ClassifiedResult, input: LeadSearchInput, index: number): LeadSearchCandidate {
  const score = result.score;
  const text = `${result.title} ${result.snippet} ${result.url}`.toLowerCase();
  const priority = priorityFromScore(score);
  const customerTypes = splitCustomerTypes(input.customerType);
  const riskSignals = ['needs_public_source_verification', ...result.riskSignals];
  if (result.evidenceSignals.length) riskSignals.push(`evidence:${result.evidenceSignals.join(',')}`);
  riskSignals.push(`source_type:${result.sourceType}`);

  return {
    companyName: cleanCompanyName(result.title, result.domain),
    website: result.domain ? `https://${result.domain}` : result.url,
    country: input.country,
    city: undefined,
    customerType: customerTypes[index % Math.max(customerTypes.length, 1)] || input.customerType,
    sourceUrl: result.url,
    emailStatus: /email|mailto:/.test(text) ? 'found' : 'needs_verification',
    phoneStatus: /phone|tel:|call|\+\d/.test(text) ? 'found' : 'needs_verification',
    whatsappStatus: /whatsapp|wa\.me/.test(text) ? 'found' : 'needs_verification',
    linkedinStatus: /linkedin/.test(text) ? 'found' : 'needs_verification',
    matchScore: score,
    priority,
    confidence: Math.max(35, Math.min(94, score - result.riskSignals.length * 4 + result.evidenceSignals.length * 2)),
    riskSignals,
    nextAction: buildNextAction(priority, result),
  };
}

function dedupeCandidates(candidates: LeadSearchCandidate[]) {
  const seen = new Set<string>();
  const output: LeadSearchCandidate[] = [];
  for (const candidate of candidates.sort((a, b) => b.matchScore - a.matchScore)) {
    const key = candidate.website ? extractDomain(candidate.website) : candidate.companyName.toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    output.push(candidate);
  }
  return output;
}

function createMockCandidates(input: LeadSearchInput, query: string): LeadSearchCandidate[] {
  const quantity = Math.min(Math.max(input.quantity || 5, 1), 50);
  const customerTypes = splitCustomerTypes(input.customerType);

  return Array.from({ length: quantity }, (_, index) => {
    const type = customerTypes[index % Math.max(customerTypes.length, 1)] || input.customerType;
    const score = Math.max(62, 88 - Math.floor(index / 2) * 3);
    return {
      companyName: `${input.country} ${type} Lead ${index + 1}`,
      website: `https://example-${index + 1}.com`,
      country: input.country,
      city: input.country.toLowerCase().includes('australia') || input.country.includes('澳') ? 'Sydney' : undefined,
      customerType: type,
      sourceUrl: `https://www.google.com/search?q=${encodeURIComponent(query)}`,
      emailStatus: 'needs_verification',
      phoneStatus: 'needs_verification',
      whatsappStatus: 'needs_verification',
      linkedinStatus: 'needs_verification',
      matchScore: score,
      priority: priorityFromScore(score),
      confidence: score - 10,
      riskSignals: ['mock_data', 'needs_real_search_api_or_more_keywords'],
      nextAction: '演示候选客户：请先配置 SerpAPI、Bing 或 Google，再运行真实搜索核验。',
    };
  });
}

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(new Error(`request timed out after ${timeoutMs}ms`)), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => {
    if (timer) clearTimeout(timer);
  });
}

async function fetchJson(fetcher: typeof fetch, url: string, init: RequestInit | undefined, timeoutMs: number) {
  const response = await withTimeout(fetcher(url, init), timeoutMs);
  const text = await response.text();
  if (!response.ok) {
    throw new Error(`HTTP ${response.status}: ${text.slice(0, 120)}`);
  }
  return text ? JSON.parse(text) : {};
}

async function searchSerpApi(query: string, env: NodeJS.ProcessEnv | Record<string, string | undefined>, fetcher: typeof fetch, timeoutMs: number): Promise<RawSearchResult[]> {
  const url = new URL('https://serpapi.com/search.json');
  url.searchParams.set('api_key', envValue(env, 'SERPAPI_KEY') || envValue(env, 'SERPAPI_API_KEY'));
  url.searchParams.set('engine', 'google');
  url.searchParams.set('q', query);
  url.searchParams.set('num', '10');
  const data = await fetchJson(fetcher, url.toString(), undefined, timeoutMs);
  const items = Array.isArray(data.organic_results) ? data.organic_results : [];
  return items.map((item: Record<string, unknown>) => ({
    provider: 'serpapi' as const,
    title: String(item.title || ''),
    url: String(item.link || ''),
    snippet: String(item.snippet || ''),
  })).filter((item: RawSearchResult) => item.title && item.url);
}

async function searchBing(query: string, env: NodeJS.ProcessEnv | Record<string, string | undefined>, fetcher: typeof fetch, timeoutMs: number): Promise<RawSearchResult[]> {
  const endpoint = envValue(env, 'BING_SEARCH_ENDPOINT') || 'https://api.bing.microsoft.com/v7.0/search';
  const url = new URL(endpoint);
  url.searchParams.set('q', query);
  url.searchParams.set('count', '10');
  const data = await fetchJson(fetcher, url.toString(), {
    headers: { 'Ocp-Apim-Subscription-Key': envValue(env, 'BING_SEARCH_API_KEY') },
  }, timeoutMs);
  const items = Array.isArray(data.webPages?.value) ? data.webPages.value : [];
  return items.map((item: Record<string, unknown>) => ({
    provider: 'bing' as const,
    title: String(item.name || ''),
    url: String(item.url || ''),
    snippet: String(item.snippet || ''),
  })).filter((item: RawSearchResult) => item.title && item.url);
}

async function searchGoogle(query: string, env: NodeJS.ProcessEnv | Record<string, string | undefined>, fetcher: typeof fetch, timeoutMs: number): Promise<RawSearchResult[]> {
  const url = new URL('https://www.googleapis.com/customsearch/v1');
  url.searchParams.set('key', envValue(env, 'GOOGLE_SEARCH_API_KEY'));
  url.searchParams.set('cx', envValue(env, 'GOOGLE_SEARCH_CX'));
  url.searchParams.set('q', query);
  url.searchParams.set('num', '10');
  const data = await fetchJson(fetcher, url.toString(), undefined, timeoutMs);
  const items = Array.isArray(data.items) ? data.items : [];
  return items.map((item: Record<string, unknown>) => ({
    provider: 'google' as const,
    title: String(item.title || ''),
    url: String(item.link || ''),
    snippet: String(item.snippet || ''),
  })).filter((item: RawSearchResult) => item.title && item.url);
}

async function runProvider(
  provider: Exclude<LeadSearchProvider, 'auto' | 'mock'>,
  query: string,
  env: NodeJS.ProcessEnv | Record<string, string | undefined>,
  fetcher: typeof fetch,
  timeoutMs: number
) {
  if (provider === 'serpapi') return searchSerpApi(query, env, fetcher, timeoutMs);
  if (provider === 'bing') return searchBing(query, env, fetcher, timeoutMs);
  return searchGoogle(query, env, fetcher, timeoutMs);
}

function buildBatchSummary(
  targetQuantity: number,
  searchQueries: string[],
  order: Array<Exclude<LeadSearchProvider, 'auto' | 'mock'>>,
  attempts: SearchAttempt[],
  rawCount: number,
  usableCount: number,
  dedupedCount: number,
  returnedCount: number
): LeadSearchBatchSummary {
  return {
    targetQuantity,
    queryCount: searchQueries.length,
    providerCount: order.length,
    attemptCount: attempts.length,
    rawCount,
    usableCount,
    dedupedCount,
    returnedCount,
    reachedTarget: returnedCount >= targetQuantity,
    partial: returnedCount > 0 && returnedCount < targetQuantity,
  };
}

export async function searchLeadCandidates(
  input: LeadSearchInput,
  options: SearchProviderOptions = {}
): Promise<LeadSearchResult> {
  const env = options.env || process.env;
  const fetcher = options.fetcher || fetch;
  const timeoutMs = options.timeoutMs ?? 8000;
  const requestedProvider = input.provider || 'auto';
  const searchQueries = buildSearchQueries(input);
  const primaryQuery = searchQueries[0] || `${input.country} ${input.product} ${input.customerType}`;
  const warnings: string[] = [];
  const attempts: SearchAttempt[] = [];
  const order = providerOrder(requestedProvider, env);
  const targetQuantity = Math.min(Math.max(input.quantity || 10, 1), 50);
  let filteredCount = 0;
  let rawCount = 0;
  let usableCount = 0;
  let dedupedCount = 0;
  let bestProvider: LeadSearchProvider = 'mock';
  let bestQuery = primaryQuery;
  let collected: LeadSearchCandidate[] = [];

  if (requestedProvider !== 'auto' && requestedProvider !== 'mock' && order.length === 0) {
    warnings.push(`${requestedProvider} 未配置，无法运行指定搜索源。`);
  }

  if (order.length === 0) {
    warnings.push('未配置真实搜索源，当前使用演示候选客户。请先在接口配置向导中接入 SerpAPI、Bing 或 Google。');
    const candidates = createMockCandidates(input, primaryQuery);
    return {
      provider: 'mock',
      query: primaryQuery,
      candidates,
      warnings,
      searchQueries,
      attempts,
      filteredCount: 0,
      batchSummary: buildBatchSummary(targetQuantity, searchQueries, order, attempts, 0, candidates.length, 0, candidates.length),
    };
  }

  for (const provider of order) {
    for (const query of searchQueries) {
      try {
        const rawResults = await runProvider(provider, query, env, fetcher, timeoutMs);
        rawCount += rawResults.length;
        const classified = rawResults.map((result, index) => scoreClassifiedResult(result, input, index));
        const usable = classified
          .filter((result) => priorityFromScore(result.score) !== 'D')
          .map((result, index) => toCandidate(result, input, index));
        usableCount += usable.length;
        filteredCount += Math.max(0, rawResults.length - usable.length);
        attempts.push({ provider, query, status: usable.length ? 'success' : 'empty', rawCount: rawResults.length, usableCount: usable.length });

        if (usable.length) {
          bestProvider = provider;
          bestQuery = query;
          const before = collected.length;
          collected = dedupeCandidates([...collected, ...usable]).slice(0, targetQuantity);
          dedupedCount += Math.max(0, before + usable.length - collected.length);
          if (collected.length >= targetQuantity) break;
        }
      } catch (error) {
        const reason = error instanceof Error ? error.message : '未知错误';
        attempts.push({ provider, query, status: 'failed', rawCount: 0, usableCount: 0, reason });
      }
    }
    if (collected.length >= targetQuantity) break;
  }

  const failedAttempts = attempts.filter((attempt) => attempt.status === 'failed');
  const emptyAttempts = attempts.filter((attempt) => attempt.status === 'empty');
  if (failedAttempts.length) warnings.push(`有 ${failedAttempts.length} 次搜索源请求失败，系统已自动换关键词或换搜索源继续尝试。`);
  if (emptyAttempts.length) warnings.push(`有 ${emptyAttempts.length} 次搜索返回为空或只有低质量结果，系统已继续扩展关键词。`);
  if (filteredCount) warnings.push(`已过滤 ${filteredCount} 条招聘页、文档页、目录噪音或低证据结果。`);
  if (dedupedCount) warnings.push(`已按官网域名去重 ${dedupedCount} 条重复候选。`);

  if (collected.length > 0) {
    if (collected.length < targetQuantity) {
      warnings.push(`本次目标 ${targetQuantity} 个，已保留 ${collected.length} 个可核验候选客户。系统没有丢弃部分结果，建议继续补充搜索源或扩大关键词。`);
    } else {
      warnings.push(`本次已达到目标数量 ${targetQuantity} 个候选客户。`);
    }
    warnings.push(`已尝试 ${attempts.length} 组“搜索源 + 关键词”，共读取 ${rawCount} 条搜索结果。`);
    return {
      provider: bestProvider,
      query: bestQuery,
      candidates: collected,
      warnings,
      searchQueries,
      attempts,
      filteredCount,
      batchSummary: buildBatchSummary(targetQuantity, searchQueries, order, attempts, rawCount, usableCount, dedupedCount, collected.length),
    };
  }

  warnings.push('所有真实搜索源和扩展关键词都未返回可用结果，已降级为演示候选客户。建议检查 API Key、代理网络或换更具体的产品/国家/客户类型。');
  const candidates = createMockCandidates(input, primaryQuery);
  return {
    provider: 'mock',
    query: primaryQuery,
    candidates,
    warnings,
    searchQueries,
    attempts,
    filteredCount,
    batchSummary: buildBatchSummary(targetQuantity, searchQueries, order, attempts, rawCount, candidates.length, dedupedCount, candidates.length),
  };
}
