import assert from 'node:assert/strict';
import { buildSearchQueries, searchLeadCandidates } from '../src/lib/integrations/lead-search-provider';

const input = {
  product: 'custom cabinets',
  country: 'Australia',
  customerType: 'Builder + Kitchen Company',
  quantity: 3,
};

function serpResult(index: number, query: string) {
  return {
    title: `Australia Cabinet Company ${index} Contact`,
    link: `https://cabinet-company-${index}.example.com/contact`,
    snippet: `${query} custom cabinetry projects. Contact by phone and email.`,
  };
}

async function main() {
  const queries = buildSearchQueries({ ...input, query: 'manual query' });
  assert.equal(queries[0], 'manual query');
  assert.ok(queries.some((query) => query.includes('official website')));
  assert.ok(queries.some((query) => query.includes('WhatsApp')));

  const bulkQueries = buildSearchQueries({
    product: 'custom cabinets, wardrobes, wood doors',
    country: 'Australia',
    customerType: 'Builder + Designer + Kitchen Company + Importer',
    quantity: 50,
  });
  assert.ok(bulkQueries.length > queries.length);
  assert.ok(bulkQueries.some((query) => query.includes('Sydney')));
  assert.ok(bulkQueries.some((query) => query.includes('Designer')));

  const calls: string[] = [];
  const serpapi = await searchLeadCandidates(input, {
    env: { SERPAPI_KEY: 'serp-secret' },
    fetcher: async (url) => {
      calls.push(String(url));
      if (calls.length === 1) {
        return new Response(JSON.stringify({
          organic_results: [
            {
              title: 'Kitchen Installer Jobs Australia',
              link: 'https://jobs.example.com/kitchen-installer',
              snippet: 'Hiring kitchen installers and cabinet makers.',
            },
          ],
        }), { status: 200 });
      }
      return new Response(JSON.stringify({
        organic_results: [
          {
            title: 'Sydney Custom Kitchens Contact',
            link: 'https://sydneycustomkitchens.example.com/contact',
            snippet: 'Kitchen company in Sydney. Contact our showroom by phone and email for custom cabinetry projects.',
          },
          {
            title: 'Houzz Sydney Custom Kitchens',
            link: 'https://www.houzz.com.au/pro/sydneycustomkitchens',
            snippet: 'Custom cabinetry and kitchen renovation profile.',
          },
        ],
      }), { status: 200 });
    },
  });
  assert.equal(serpapi.provider, 'serpapi');
  assert.ok(calls.length > 1);
  assert.ok(serpapi.attempts && serpapi.attempts.length > 1);
  assert.equal(serpapi.candidates[0].priority, 'A');
  assert.equal(serpapi.candidates[0].emailStatus, 'found');
  assert.ok(serpapi.batchSummary);
  assert.equal(serpapi.batchSummary?.targetQuantity, 3);

  const bulk = await searchLeadCandidates({
    product: 'custom cabinets, wardrobes, wood doors',
    country: 'Australia',
    customerType: 'Builder + Designer + Kitchen Company + Importer',
    quantity: 50,
  }, {
    env: { SERPAPI_KEY: 'serp-secret' },
    fetcher: async (url) => {
      const q = new URL(String(url)).searchParams.get('q') || '';
      const seed = Math.abs(q.split('').reduce((sum, char) => sum + char.charCodeAt(0), 0));
      const start = seed % 1000;
      return new Response(JSON.stringify({
        organic_results: Array.from({ length: 10 }, (_, index) => serpResult(start + index, q)),
      }), { status: 200 });
    },
    timeoutMs: 1000,
  });
  assert.equal(bulk.candidates.length, 50);
  assert.equal(bulk.batchSummary?.targetQuantity, 50);
  assert.equal(bulk.batchSummary?.reachedTarget, true);
  assert.ok((bulk.attempts?.length || 0) >= 5);

  const timeoutFallback = await searchLeadCandidates(input, {
    env: { SERPAPI_KEY: 'slow', BING_SEARCH_API_KEY: 'bing-secret' },
    timeoutMs: 5,
    fetcher: async (url) => {
      if (String(url).includes('serpapi.com')) {
        await new Promise((resolve) => setTimeout(resolve, 20));
        return new Response('{}', { status: 200 });
      }
      return new Response(JSON.stringify({
        webPages: {
          value: [
            {
              name: 'Melbourne Joinery Group About',
              url: 'https://melbournejoinery.example.com/about',
              snippet: 'Builder supplier and joinery company for residential custom cabinet projects. Phone and email available.',
            },
          ],
        },
      }), { status: 200 });
    },
  });
  assert.ok(timeoutFallback.attempts?.some((attempt) => attempt.status === 'failed'));
  assert.ok(timeoutFallback.candidates.length > 0);
  assert.match(timeoutFallback.warnings.join('\n'), /请求失败/);

  const mock = await searchLeadCandidates(input, {
    env: {},
    fetcher: async () => {
      throw new Error('fetch should not run');
    },
  });
  assert.equal(mock.provider, 'mock');
  assert.match(mock.warnings.join('\n'), /未配置真实搜索源/);
  assert.ok(mock.candidates.length > 0);
  assert.ok(mock.candidates.every((candidate) => candidate.priority !== 'D'));

  console.log('lead-search-provider tests passed');
}

main();
