import {
  loadSavedCandidateLeads,
  loadSavedCrmCustomers,
  loadSavedCrmFollowUps,
  loadSavedLeadTasks,
  saveCandidateLeads,
  saveCrmCustomers,
  saveCrmFollowUps,
  saveLeadTasks,
  type SavedCandidateLead,
  type SavedCrmCustomer,
  type SavedCrmFollowUp,
  type SavedLeadTask,
} from './lead-wizard';
import { loadSavedCrmOpportunities, saveCrmOpportunities, type SavedCrmOpportunity } from './crm-opportunities';
import { loadSavedCrmQuotations, saveCrmQuotations, type SavedCrmQuotation } from './crm-quotations';
import { loadCompanyProfile, saveCompanyProfile, type CompanyProfile } from './company-profile';
import { loadSavedCrmOrders, saveCrmOrders, type SavedCrmOrder } from './crm-orders';
import { loadSavedTradeDocuments, saveTradeDocuments, type SavedTradeDocument } from './trade-documents';
import { loadSavedShipments, saveShipments, type SavedShipment } from './shipments';
import {loadSavedEmailRecords,saveEmailRecords,type SavedEmailRecord} from './email-records';

export const BACKUP_FORMAT = 'skillhuoke-backup';
export const BACKUP_VERSION = 8;
export const LAST_BACKUP_STORAGE_KEY = 'skillhuoke_last_backup_v024';
export const RESTORE_POINT_STORAGE_KEY = 'skillhuoke_restore_point_v024';
export const MAX_BACKUP_FILE_SIZE = 10 * 1024 * 1024;

export interface BackupData {
  leadTasks: SavedLeadTask[];
  candidateLeads: SavedCandidateLead[];
  crmCustomers: SavedCrmCustomer[];
  crmFollowUps: SavedCrmFollowUp[];
  crmOpportunities: SavedCrmOpportunity[];
  crmQuotations: SavedCrmQuotation[];
  crmOrders: SavedCrmOrder[];
  tradeDocuments: SavedTradeDocument[];
  shipments: SavedShipment[];
  emailRecords:SavedEmailRecord[];
}

export interface BackupSummary {
  leadTasks: number;
  candidateLeads: number;
  crmCustomers: number;
  crmFollowUps: number;
  crmOpportunities: number;
  crmQuotations: number;
  crmOrders: number;
  tradeDocuments: number;
  shipments: number;
  emailRecords:number;
}

export interface SkillHuokeBackup {
  format: typeof BACKUP_FORMAT;
  version: typeof BACKUP_VERSION;
  appVersion: string;
  exportedAt: string;
  summary: BackupSummary;
  data: BackupData;
  companyProfile?: CompanyProfile;
}

export interface BackupPreview {
  backup: SkillHuokeBackup;
  current: BackupSummary;
  imported: BackupSummary;
  duplicateIds: BackupSummary;
}

export type BackupRestoreMode = 'merge' | 'overwrite';

function summarize(data: BackupData): BackupSummary {
  return {
    leadTasks: data.leadTasks.length,
    candidateLeads: data.candidateLeads.length,
    crmCustomers: data.crmCustomers.length,
    crmFollowUps: data.crmFollowUps.length,
    crmOpportunities: data.crmOpportunities.length,
    crmQuotations: data.crmQuotations.length,
    crmOrders: data.crmOrders.length,
    tradeDocuments: data.tradeDocuments.length,
    shipments: data.shipments.length,
    emailRecords:data.emailRecords.length,
  };
}

export function loadCurrentBackupData(): BackupData {
  return {
    leadTasks: loadSavedLeadTasks(),
    candidateLeads: loadSavedCandidateLeads(),
    crmCustomers: loadSavedCrmCustomers(),
    crmFollowUps: loadSavedCrmFollowUps(),
    crmOpportunities: loadSavedCrmOpportunities(),
    crmQuotations: loadSavedCrmQuotations(),
    crmOrders: loadSavedCrmOrders(),
    tradeDocuments: loadSavedTradeDocuments(),
    shipments: loadSavedShipments(),
    emailRecords:loadSavedEmailRecords(),
  };
}

export function getCurrentBackupSummary() {
  return summarize(loadCurrentBackupData());
}

export function createBackupPayload(appVersion = 'v0.35.0'): SkillHuokeBackup {
  const data = loadCurrentBackupData();
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    appVersion,
    exportedAt: new Date().toISOString(),
    summary: summarize(data),
    data,
    companyProfile: loadCompanyProfile(),
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

export function parseBackupFile(text: string, fileSize: number): SkillHuokeBackup {
  if (fileSize > MAX_BACKUP_FILE_SIZE) throw new Error('备份文件不能超过 10 MB。');

  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error('文件不是有效的 JSON 备份。');
  }

  if (!isRecord(parsed) || parsed.format !== BACKUP_FORMAT || ![1,2,3,4,5,6,7,BACKUP_VERSION].includes(Number(parsed.version))) {
    throw new Error('备份格式或版本不受支持。');
  }
  if (!isRecord(parsed.data)) throw new Error('备份缺少 data 数据。');

  const data = parsed.data;
  if (!Array.isArray(data.crmOpportunities) && parsed.version === 1) data.crmOpportunities = [];
  if (!Array.isArray(data.crmQuotations) && Number(parsed.version) < 3) data.crmQuotations = [];
  if (!Array.isArray(data.crmOrders) && Number(parsed.version) < 5) data.crmOrders = [];
  if (!Array.isArray(data.tradeDocuments) && Number(parsed.version) < 6) data.tradeDocuments = [];
  if (!Array.isArray(data.shipments) && Number(parsed.version) < 7) data.shipments = [];
  if(!Array.isArray(data.emailRecords)&&Number(parsed.version)<8)data.emailRecords=[];
  const keys: Array<keyof BackupData> = ['leadTasks','candidateLeads','crmCustomers','crmFollowUps','crmOpportunities','crmQuotations','crmOrders','tradeDocuments','shipments','emailRecords'];
  for (const key of keys) {
    if (!Array.isArray(data[key])) throw new Error(`备份中的 ${key} 不是有效数组。`);
  }

  const normalizedData = data as unknown as BackupData;
  return {
    format: BACKUP_FORMAT,
    version: BACKUP_VERSION,
    appVersion: typeof parsed.appVersion === 'string' ? parsed.appVersion : 'unknown',
    exportedAt: typeof parsed.exportedAt === 'string' ? parsed.exportedAt : '',
    summary: summarize(normalizedData),
    data: normalizedData,
    companyProfile: isRecord(parsed.companyProfile) ? parsed.companyProfile as unknown as CompanyProfile : undefined,
  };
}

function countDuplicates<T extends { id: string }>(current: T[], imported: T[]) {
  const ids = new Set(current.map((item) => item.id));
  return imported.filter((item) => ids.has(item.id)).length;
}

export function createBackupPreview(backup: SkillHuokeBackup): BackupPreview {
  const currentData = loadCurrentBackupData();
  return {
    backup,
    current: summarize(currentData),
    imported: summarize(backup.data),
    duplicateIds: {
      leadTasks: countDuplicates(currentData.leadTasks, backup.data.leadTasks),
      candidateLeads: countDuplicates(currentData.candidateLeads, backup.data.candidateLeads),
      crmCustomers: countDuplicates(currentData.crmCustomers, backup.data.crmCustomers),
      crmFollowUps: countDuplicates(currentData.crmFollowUps, backup.data.crmFollowUps),
      crmOpportunities: countDuplicates(currentData.crmOpportunities, backup.data.crmOpportunities),
      crmQuotations: countDuplicates(currentData.crmQuotations, backup.data.crmQuotations),
      crmOrders: countDuplicates(currentData.crmOrders, backup.data.crmOrders),
      tradeDocuments: countDuplicates(currentData.tradeDocuments, backup.data.tradeDocuments),
      shipments: countDuplicates(currentData.shipments, backup.data.shipments),
      emailRecords:countDuplicates(currentData.emailRecords,backup.data.emailRecords),
    },
  };
}

function mergeById<T extends { id: string; updatedAt?: string }>(current: T[], imported: T[]) {
  const result = new Map(current.map((item) => [item.id, item]));
  imported.forEach((item) => {
    const existing = result.get(item.id);
    if (!existing) {
      result.set(item.id, item);
      return;
    }
    const currentTime = existing.updatedAt ? Date.parse(existing.updatedAt) : Number.NaN;
    const importedTime = item.updatedAt ? Date.parse(item.updatedAt) : Number.NaN;
    if (!Number.isNaN(importedTime) && (Number.isNaN(currentTime) || importedTime > currentTime)) {
      result.set(item.id, item);
    }
  });
  return Array.from(result.values());
}

function saveBackupData(data: BackupData) {
  saveLeadTasks(data.leadTasks);
  saveCandidateLeads(data.candidateLeads);
  saveCrmCustomers(data.crmCustomers);
  saveCrmFollowUps(data.crmFollowUps);
  saveCrmOpportunities(data.crmOpportunities);
  saveCrmQuotations(data.crmQuotations);
  saveCrmOrders(data.crmOrders);
  saveTradeDocuments(data.tradeDocuments);
  saveShipments(data.shipments);
  saveEmailRecords(data.emailRecords);
}

export function saveRestorePoint() {
  if (typeof window === 'undefined') return;
  const restorePoint = createBackupPayload('restore-point');
  window.localStorage.setItem(RESTORE_POINT_STORAGE_KEY, JSON.stringify(restorePoint));
}

export function restoreBackup(backup: SkillHuokeBackup, mode: BackupRestoreMode) {
  saveRestorePoint();
  if (mode === 'overwrite') {
    saveBackupData(backup.data);
    if (backup.companyProfile) saveCompanyProfile(backup.companyProfile);
  } else {
    const current = loadCurrentBackupData();
    saveBackupData({
      leadTasks: mergeById(current.leadTasks, backup.data.leadTasks),
      candidateLeads: mergeById(current.candidateLeads, backup.data.candidateLeads),
      crmCustomers: mergeById(current.crmCustomers, backup.data.crmCustomers),
      crmFollowUps: mergeById(current.crmFollowUps, backup.data.crmFollowUps),
      crmOpportunities: mergeById(current.crmOpportunities, backup.data.crmOpportunities),
      crmQuotations: mergeById(current.crmQuotations, backup.data.crmQuotations),
      crmOrders: mergeById(current.crmOrders, backup.data.crmOrders),
      tradeDocuments: mergeById(current.tradeDocuments, backup.data.tradeDocuments),
      shipments: mergeById(current.shipments, backup.data.shipments),
      emailRecords:mergeById(current.emailRecords,backup.data.emailRecords),
    });
  }
  return getCurrentBackupSummary();
}

export function hasRestorePoint() {
  return typeof window !== 'undefined' && Boolean(window.localStorage.getItem(RESTORE_POINT_STORAGE_KEY));
}

export function undoLastRestore() {
  if (typeof window === 'undefined') throw new Error('当前环境不能恢复数据。');
  const raw = window.localStorage.getItem(RESTORE_POINT_STORAGE_KEY);
  if (!raw) throw new Error('没有可用的恢复点。');
  const backup = parseBackupFile(raw, new Blob([raw]).size);
  saveBackupData(backup.data);
  if (backup.companyProfile) saveCompanyProfile(backup.companyProfile);
  window.localStorage.removeItem(RESTORE_POINT_STORAGE_KEY);
  return getCurrentBackupSummary();
}

function csvCell(value: unknown) {
  const text = String(value ?? '').replaceAll('"', '""');
  return `"${text}"`;
}

export function createCrmCsv(customers = loadSavedCrmCustomers()) {
  const headers = ['公司名称', '官网', '国家', '城市', '客户类型', '联系方式状态', '评分', '优先级', 'CRM 阶段', '客户备注', '下一步动作', '下次跟进时间', '来源任务', '创建时间', '更新时间'];
  const rows = customers.map((customer) => [
    customer.company,
    customer.website,
    customer.country,
    customer.city,
    customer.customerType,
    customer.contactStatus,
    customer.score,
    customer.priority,
    customer.status,
    customer.note,
    customer.nextAction,
    customer.nextFollowUpAt || '',
    customer.sourceTaskTitle,
    customer.createdAt,
    customer.updatedAt,
  ].map(csvCell).join(','));
  return `\uFEFF${headers.map(csvCell).join(',')}\r\n${rows.join('\r\n')}`;
}

export function markBackupDownloaded(exportedAt: string) {
  if (typeof window !== 'undefined') window.localStorage.setItem(LAST_BACKUP_STORAGE_KEY, exportedAt);
}

export function getLastBackupTime() {
  return typeof window === 'undefined' ? '' : window.localStorage.getItem(LAST_BACKUP_STORAGE_KEY) || '';
}
