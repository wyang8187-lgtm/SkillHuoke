# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进、报价、订单、单据、出货、邮件发送和接口配置诊断。

当前版本：`v0.35.0`

## v0.35.0 更新

- `/settings/api-keys` 升级为接口配置向导。
- 每个接口服务提供中文配置步骤、官方入口、缺失字段和可复制 `.env` 片段。
- 新增“复制全部 `.env` 模板”，方便一次性准备 OpenAI、DeepSeek、Google、SerpAPI、Bing、Resend 和 Supabase 配置。
- 修复接口诊断中心和版本体验中心的中文显示。
- 继续保持安全规则：网页不输入、不保存、不展示完整 API Key。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

进入后点击“演示模式进入工作台”。

## 接口配置方式

1. 打开 `http://127.0.0.1:5000/settings/api-keys`。
2. 点击“复制全部 .env 模板”，或复制单个服务的 `.env` 片段。
3. 在项目根目录创建或编辑 `.env` 文件。
4. 把真实 API Key 填到对应变量后面。
5. 保存 `.env` 后重启后端服务。
6. 回到接口配置向导，点击“刷新配置”和“测试连接”。

重要说明：不要把真实 API Key 提交到 GitHub。上传开源包时只保留 `.env.example`，不要上传 `.env` 或 `.env.local`。

## 主要页面

- 登录页：`/login`
- 版本体验中心：`/release`
- 接口配置向导：`/settings/api-keys`
- 获客任务向导：`/lead-wizard`
- 候选客户池：`/candidate-leads`
- CRM 客户池：`/crm-customers`
- 邮件中心：`/email-center`

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 开源协议

MIT
