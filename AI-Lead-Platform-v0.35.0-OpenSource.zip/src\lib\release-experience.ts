import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.35.0',
  title: '接口配置向导与中文体验修复',
  date: '2026-06-30',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.35.0-OpenSource.zip',
  githubRemark: 'v0.35.0：新增接口配置向导、一键复制 .env 模板，并修复接口诊断中心中文显示',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '接口诊断中心升级为接口配置向导，非程序员也能按步骤完成接入。',
  '每个服务新增官方入口、配置步骤、缺失字段说明和可复制 .env 片段。',
  '新增“复制全部 .env 模板”，方便一次性准备 OpenAI、DeepSeek、搜索、邮件和 Supabase 配置。',
  '修复接口诊断数据、页面和版本中心的中文显示，让系统设置区更适合真实交付演示。',
];

export const releaseReviewPages = [
  {
    title: '接口配置向导',
    href: '/settings/api-keys',
    description: '复制 .env 模板，查看每个接口配置步骤、缺失字段、代理状态和连接测试结果。',
  },
  {
    title: '版本体验中心',
    href: '/release',
    description: '查看本次版本更新、上传包名称、GitHub 备注和重点检查页面。',
  },
  {
    title: '邮件中心',
    href: '/email-center',
    description: '验证 Resend 未配置时可保存本地草稿，配置后可走后端真实发送。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和数量，生成获客任务并进入任务执行台。',
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    description: '管理任务沉淀的候选客户，并把适合开发的客户加入 CRM。',
  },
  {
    title: 'CRM 客户池',
    href: '/crm-customers',
    description: '查看客户阶段、评分、优先级、联系方式和下一步动作。',
  },
  {
    title: '数据备份',
    href: '/data-backup',
    description: '导出或恢复本地 CRM、报价、订单、单据、出货和邮件记录。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '点击“演示模式进入工作台”即可查看当前版本。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看 CRM 客户、跟进时间线和英文开发动作。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '查看批量获客任务、候选客户核验和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '进入接口配置向导，确认页面中文正常显示。',
  '点击“复制全部 .env 模板”，确认能复制完整接口变量模板。',
  '打开任意服务卡片，查看官方入口、配置步骤和本服务 .env 片段。',
  '点击“刷新配置”和“测试连接”，确认能看到中文测试结果和下一步建议。',
];
