'use client';

import Link from 'next/link';
import { useMemo, useState } from 'react';
import { ArrowRight, CheckCircle2, Clipboard, KeyRound, Search, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiQuickFields, buildQuickEnvSnippet, type ApiQuickValues } from '@/lib/api-key-quick-entry';

export function ApiKeyQuickEntry() {
  const [values, setValues] = useState<ApiQuickValues>({});
  const [copied, setCopied] = useState(false);
  const [notice, setNotice] = useState('');

  const envSnippet = useMemo(() => buildQuickEnvSnippet(values), [values]);

  async function copySnippet() {
    if (!envSnippet) {
      setNotice('请先至少填写一个 API Key 或 CX。');
      return;
    }

    try {
      await navigator.clipboard.writeText(envSnippet);
      setCopied(true);
      setNotice('已复制 .env 配置片段。请粘贴到项目根目录 .env 文件，保存后重启后端。');
      setTimeout(() => setCopied(false), 1800);
    } catch {
      setNotice('复制失败，请手动选中下方配置片段复制。');
    }
  }

  return (
    <Card className="border-blue-500/25 bg-gradient-to-br from-blue-500/10 via-[#121823] to-emerald-500/10">
      <CardHeader className="space-y-3">
        <div className="flex flex-col gap-3 xl:flex-row xl:items-start xl:justify-between">
          <div>
            <div className="flex items-center gap-2 text-sm text-blue-300">
              <KeyRound className="h-4 w-4" />
              v0.39.0 API 快速接入
            </div>
            <CardTitle className="mt-3 text-xl text-[#f8fafc]">先填接口，再跑真实获客</CardTitle>
            <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
              把常用接口放到工作台前面。这里会帮你生成 `.env` 配置片段，但不会保存完整密钥到浏览器、备份文件或开源上传包。
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={copySnippet} className="bg-blue-600 text-white hover:bg-blue-500">
              {copied ? <CheckCircle2 className="mr-2 h-4 w-4" /> : <Clipboard className="mr-2 h-4 w-4" />}
              复制 .env 配置
            </Button>
            <Button asChild variant="outline">
              <Link href="/settings/api-keys">
                <ShieldCheck className="mr-2 h-4 w-4" />
                检测接口状态
              </Link>
            </Button>
            <Button asChild variant="outline">
              <Link href="/lead-tasks">
                <Search className="mr-2 h-4 w-4" />
                开始真实获客
              </Link>
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {notice ? (
          <div className="rounded-md border border-blue-500/25 bg-blue-500/10 p-3 text-sm text-blue-100">{notice}</div>
        ) : null}

        <div className="grid gap-3 lg:grid-cols-2">
          {apiQuickFields.map((field) => (
            <label key={field.name} className="rounded-md border border-[#2d3548] bg-[#0f1419] p-3">
              <span className="text-sm font-medium text-[#f8fafc]">{field.label}</span>
              <input
                className="mt-2 w-full rounded-md border border-[#334155] bg-[#05070c] px-3 py-2 text-sm text-[#e2e8f0] outline-none transition focus:border-blue-400"
                type={field.secret ? 'password' : 'text'}
                value={values[field.name] || ''}
                onChange={(event) => setValues((current) => ({ ...current, [field.name]: event.target.value }))}
                placeholder={field.placeholder}
                autoComplete="off"
              />
              <span className="mt-2 block text-xs leading-5 text-[#94a3b8]">{field.helper}</span>
            </label>
          ))}
        </div>

        <div className="rounded-md border border-[#2d3548] bg-[#05070c] p-3">
          <div className="mb-2 flex items-center justify-between gap-3">
            <span className="text-sm font-medium text-[#f8fafc]">将生成的配置粘贴到项目根目录 `.env`</span>
            <span className="text-xs text-[#94a3b8]">保存后需要重启后端</span>
          </div>
          <pre className="min-h-16 overflow-x-auto whitespace-pre-wrap text-xs leading-5 text-emerald-200">
            {envSnippet || '填写上方接口后，这里会自动生成 .env 配置片段。'}
          </pre>
        </div>

        <div className="flex items-start gap-2 rounded-md border border-amber-500/25 bg-amber-500/10 p-3 text-sm leading-6 text-amber-100">
          <ArrowRight className="mt-1 h-4 w-4 shrink-0" />
          <p>流程：填写 Key → 复制 `.env` 配置 → 粘贴保存 → 重新运行 `npm start` → 回到“检测接口状态”。</p>
        </div>
      </CardContent>
    </Card>
  );
}
