'use client';

import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { ThemeToggle } from '@/components/ui/theme-toggle';
import { NotificationBell } from '@/components/ui/notification-bell';
import { demoWorkspace, getWorkspaceModeLabel } from '@/lib/workspace';
import { getCrmReminderSummary, loadSavedCrmCustomers } from '@/lib/lead-wizard';
import {
  Activity,
  BarChart3,
  Bell,
  BookOpen,
  Briefcase,
  BriefcaseBusiness,
  Building2,
  Calendar,
  ChevronDown,
  ChevronRight,
  ClipboardList,
  CircleDollarSign,
  Filter,
  FolderOpen,
  Files,
  Globe,
  LayoutDashboard,
  Lightbulb,
  LogOut,
  Mail,
  MapPin,
  Menu,
  PieChart,
  PackageCheck,
  Search,
  Send,
  Ship,
  Settings,
  Shield,
  Sparkles,
  Target,
  User,
  Users,
  Users as TeamIcon,
  Video,
  X,
} from 'lucide-react';

interface NavItemBase {
  title: string;
  icon: React.ReactNode;
}

interface NavItemWithHref extends NavItemBase {
  href: string;
  children?: never;
}

interface NavItemWithChildren extends NavItemBase {
  href?: string;
  children: NavItemWithHref[];
}

type NavItem = NavItemWithHref | NavItemWithChildren;

function hasNavChildren(item: NavItem): item is NavItemWithChildren {
  return 'children' in item;
}

const navItems: NavItem[] = [
  {
    title: '仪表盘',
    href: '/dashboard',
    icon: <LayoutDashboard className="h-5 w-5" />,
  },
  {
    title: '版本体验',
    href: '/release',
    icon: <Sparkles className="h-5 w-5" />,
  },
  {
    title: '新手引导',
    href: '/onboarding',
    icon: <Target className="h-5 w-5" />,
  },
  {
    title: '获客向导',
    href: '/lead-wizard',
    icon: <Lightbulb className="h-5 w-5" />,
  },
  {
    title: '任务记录',
    href: '/lead-tasks',
    icon: <ClipboardList className="h-5 w-5" />,
  },
  {
    title: '候选客户池',
    href: '/candidate-leads',
    icon: <Building2 className="h-5 w-5" />,
  },
  {
    title: 'CRM 客户池',
    href: '/crm-customers',
    icon: <BriefcaseBusiness className="h-5 w-5" />,
  },
  {
    title: '今日跟进',
    href: '/crm-follow-ups',
    icon: <Calendar className="h-5 w-5" />,
  },
  {
    title: '数据备份',
    href: '/data-backup',
    icon: <FolderOpen className="h-5 w-5" />,
  },
  {
    title: 'CRM 分析',
    href: '/crm-analytics',
    icon: <BarChart3 className="h-5 w-5" />,
  },
  {
    title: '销售机会',
    href: '/crm-opportunities',
    icon: <BriefcaseBusiness className="h-5 w-5" />,
  },
  {
    title: '正式报价',
    href: '/crm-quotations',
    icon: <CircleDollarSign className="h-5 w-5" />,
  },
  {
    title: '订单管理',
    href: '/crm-orders',
    icon: <PackageCheck className="h-5 w-5" />,
  },
  {
    title: '外贸单据',
    href: '/trade-documents',
    icon: <Files className="h-5 w-5" />,
  },
  {
    title: '海运出货',
    href: '/shipments',
    icon: <Ship className="h-5 w-5" />,
  },
  {
    title: '邮件中心',
    href: '/email-center',
    icon: <Mail className="h-5 w-5" />,
  },
  {
    title: 'AI获客中心',
    href: '/acquisition',
    icon: <Search className="h-5 w-5" />,
    children: [
      { title: '智能搜索', href: '/acquisition/search', icon: <Search className="h-4 w-4" /> },
      { title: '高级搜客', href: '/acquisition/advanced-search', icon: <Filter className="h-4 w-4" /> },
      { title: '线索发现', href: '/acquisition/lead-discovery', icon: <Sparkles className="h-4 w-4" /> },
      { title: '批量开发', href: '/acquisition/bulk-development', icon: <Send className="h-4 w-4" /> },
      { title: '多渠道获客', href: '/acquisition/channels', icon: <FolderOpen className="h-4 w-4" /> },
      { title: 'AI自动获客', href: '/acquisition/auto', icon: <Target className="h-4 w-4" /> },
      { title: '客户动态', href: '/acquisition/dynamics', icon: <Activity className="h-4 w-4" /> },
      { title: '决策人深挖', href: '/acquisition/decision-maker', icon: <User className="h-4 w-4" /> },
      { title: '关键词建议', href: '/acquisition/keyword-suggest', icon: <Lightbulb className="h-4 w-4" /> },
      { title: 'LBS地图获客', href: '/acquisition/lbs-map', icon: <MapPin className="h-4 w-4" /> },
      { title: 'LinkedIn获客', href: '/acquisition/social-linkedin', icon: <Briefcase className="h-4 w-4" /> },
      { title: 'Facebook获客', href: '/acquisition/social-facebook', icon: <Users className="h-4 w-4" /> },
      { title: 'TikTok获客', href: '/acquisition/social-tiktok', icon: <Video className="h-4 w-4" /> },
      { title: '品牌商标库', href: '/acquisition/trademark-search', icon: <Shield className="h-4 w-4" /> },
      { title: '行业资源库', href: '/resources/industry-library', icon: <BookOpen className="h-4 w-4" /> },
    ],
  },
  {
    title: '客户管理',
    href: '/customers',
    icon: <Users className="h-5 w-5" />,
    children: [
      { title: '客户列表', href: '/customers/list', icon: <Users className="h-4 w-4" /> },
      { title: '公海池', href: '/customers/pool', icon: <FolderOpen className="h-4 w-4" /> },
      { title: '分类看板', href: '/customers/classification-dashboard', icon: <PieChart className="h-4 w-4" /> },
    ],
  },
  {
    title: '营销中心',
    href: '/marketing',
    icon: <Mail className="h-5 w-5" />,
    children: [
      { title: '邮件营销', href: '/marketing/email', icon: <Mail className="h-4 w-4" /> },
      { title: '社媒营销', href: '/marketing/social', icon: <Target className="h-4 w-4" /> },
      { title: 'WhatsApp', href: '/marketing/whatsapp', icon: <Mail className="h-4 w-4" /> },
      { title: '自动化流程', href: '/marketing/automation', icon: <Target className="h-4 w-4" /> },
    ],
  },
  {
    title: '线索池',
    href: '/leads',
    icon: <FolderOpen className="h-5 w-5" />,
  },
  {
    title: '商机管理',
    href: '/opportunities',
    icon: <Briefcase className="h-5 w-5" />,
  },
  {
    title: '外贸数据',
    href: '/customs',
    icon: <Globe className="h-5 w-5" />,
    children: [
      { title: '海关数据查询', href: '/customs/search', icon: <Search className="h-4 w-4" /> },
      { title: '展会信息', href: '/customs/exhibitions', icon: <Calendar className="h-4 w-4" /> },
    ],
  },
  {
    title: '团队管理',
    icon: <TeamIcon className="h-5 w-5" />,
    children: [
      { title: '成员管理', href: '/team', icon: <Users className="h-4 w-4" /> },
      { title: '权限矩阵', href: '/team/permissions', icon: <Shield className="h-4 w-4" /> },
    ],
  },
  {
    title: '数据分析',
    href: '/analytics',
    icon: <BarChart3 className="h-5 w-5" />,
    children: [
      { title: '客户分析', href: '/analytics/customers', icon: <Users className="h-4 w-4" /> },
      { title: '销售分析', href: '/analytics/sales', icon: <Target className="h-4 w-4" /> },
      { title: '获客效率', href: '/analytics/acquisition', icon: <Sparkles className="h-4 w-4" /> },
    ],
  },
  {
    title: '系统设置',
    href: '/settings',
    icon: <Settings className="h-5 w-5" />,
    children: [
      { title: '个人设置', href: '/settings/personal', icon: <User className="h-4 w-4" /> },
      { title: '公司与报价', href: '/settings/company-profile', icon: <Building2 className="h-4 w-4" /> },
      { title: 'API密钥', href: '/settings/api-keys', icon: <Shield className="h-4 w-4" /> },
      { title: '团队设置', href: '/settings/team', icon: <Users className="h-4 w-4" /> },
      { title: '系统参数', href: '/settings/params', icon: <Settings className="h-4 w-4" /> },
      { title: '数据管理', href: '/settings/data', icon: <FolderOpen className="h-4 w-4" /> },
    ],
  },
];

const hiddenNavHrefs = new Set([
  '/crm-analytics',
  '/acquisition/dynamics',
  '/acquisition/decision-maker',
  '/acquisition/keyword-suggest',
  '/acquisition/lbs-map',
  '/acquisition/social-linkedin',
  '/acquisition/social-facebook',
  '/acquisition/social-tiktok',
  '/acquisition/trademark-search',
  '/resources/industry-library',
  '/analytics/customers',
  '/analytics/sales',
]);

function visibleNavItems(items: NavItem[]): NavItem[] {
  const output: NavItem[] = [];
  for (const item of items) {
    if (item.href && hiddenNavHrefs.has(item.href)) continue;
    if (hasNavChildren(item)) {
      const children = visibleNavItems(item.children) as NavItemWithHref[];
      output.push({ ...item, children });
    } else {
      output.push(item);
    }
  }
  return output;
}

export function Sidebar({ mobileOpen = false, onMobileClose }: { mobileOpen?: boolean; onMobileClose?: () => void }) {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);
  const [expandedItems, setExpandedItems] = useState<string[]>([
    '/acquisition',
    '/customers',
    '/marketing',
    '/customs',
    '/analytics',
    '/settings',
    '团队管理',
  ]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [pendingTaskCount, setPendingTaskCount] = useState(0);
  const [crmDueCount, setCrmDueCount] = useState(0);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 768);
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  useEffect(() => {
    fetchPendingTaskCount();
    const interval = setInterval(fetchPendingTaskCount, 5 * 60 * 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const refreshCrmDueCount = () => {
      setCrmDueCount(getCrmReminderSummary(loadSavedCrmCustomers()).due);
    };
    refreshCrmDueCount();
    window.addEventListener('storage', refreshCrmDueCount);
    return () => window.removeEventListener('storage', refreshCrmDueCount);
  }, [pathname]);

  useEffect(() => {
    if (isMobile && onMobileClose) {
      onMobileClose();
    }
  }, [pathname, isMobile, onMobileClose]);

  const fetchPendingTaskCount = async () => {
    try {
      const session = localStorage.getItem('supabase_session');
      if (!session) return;

      const response = await fetch('/api/tasks?status=pending&pageSize=100', {
        headers: { 'x-session': session },
      });

      if (response.ok) {
        const data = await response.json();
        setPendingTaskCount(data.total || 0);
      }
    } catch (error) {
      console.error('获取待办任务数量失败:', error);
    }
  };

  const toggleExpanded = (key: string) => {
    setExpandedItems((prev) =>
      prev.includes(key) ? prev.filter((item) => item !== key) : [...prev, key]
    );
  };

  const isActive = (href: string) => pathname === href || pathname.startsWith(`${href}/`);
  const isExpanded = (key: string) => expandedItems.includes(key);

  return (
    <>
      {isMobile && mobileOpen && (
        <div className="fixed inset-0 bg-black/50 z-30 md:hidden" onClick={onMobileClose} />
      )}

      <aside
        className={cn(
          'fixed left-0 top-0 z-40 h-screen bg-[#0f1419] border-r border-[#2d3548] transition-all duration-200',
          collapsed && !isMobile ? 'w-16' : 'w-60',
          isMobile && !mobileOpen ? '-translate-x-full' : 'translate-x-0',
          isMobile && mobileOpen ? 'w-60' : ''
        )}
      >
        <div className="flex items-center justify-between h-14 px-4 border-b border-[#2d3548]">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#3b82f6] to-[#1d4ed8] flex items-center justify-center">
                <Target className="h-5 w-5 text-white" />
              </div>
              <span className="text-lg font-semibold text-[#f8fafc]">获客AI</span>
            </div>
          )}
          <div className="flex items-center gap-1">
            {!collapsed && <NotificationBell />}
            <button
              onClick={() => setCollapsed(!collapsed)}
              className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8]"
              title={collapsed ? '展开菜单' : '收起菜单'}
            >
              {collapsed ? <Menu className="h-5 w-5" /> : <X className="h-5 w-5" />}
            </button>
          </div>
        </div>

        <nav className="h-[calc(100vh-8.5rem)] overflow-y-auto py-4">
          {!collapsed && (
            <div className="mx-3 mb-4 rounded-lg border border-[#2d3548] bg-[#1a1f2c]/70 p-3">
              <div className="text-xs text-[#64748b] mb-1">当前工作空间</div>
              <div className="text-sm font-medium text-[#f8fafc] truncate">{demoWorkspace.name}</div>
              <div className="mt-2 flex items-center justify-between text-xs">
                <span className="text-blue-300">{demoWorkspace.plan}</span>
                <span className="rounded-full bg-amber-500/15 px-2 py-0.5 text-amber-300">
                  {getWorkspaceModeLabel(demoWorkspace.mode)}
                </span>
              </div>
            </div>
          )}
          <ul className="space-y-1 px-2">
            {visibleNavItems(navItems).map((item) => {
              const key = item.href || item.title;
              const hasChildren = hasNavChildren(item);
              const parentActive = item.href
                ? isActive(item.href)
                : hasChildren && item.children.some((child) => isActive(child.href));

              return (
                <li key={key}>
                  {hasChildren ? (
                    <button
                      type="button"
                      className={cn(
                        'w-full flex items-center gap-3 px-3 py-2.5 rounded-md cursor-pointer transition-colors',
                        parentActive
                          ? 'bg-[#1a1f2c] text-[#3b82f6]'
                          : 'text-[#94a3b8] hover:bg-[#1a1f2c] hover:text-[#f8fafc]'
                      )}
                      onClick={() => toggleExpanded(key)}
                    >
                      {item.icon}
                      {!collapsed && (
                        <>
                          <span className="flex-1 text-left text-sm">{item.title}</span>
                          {isExpanded(key) ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                        </>
                      )}
                    </button>
                  ) : (
                    <Link
                      href={item.href}
                      className={cn(
                        'flex items-center gap-3 px-3 py-2.5 rounded-md transition-colors',
                        isActive(item.href)
                          ? 'bg-[#1a1f2c] text-[#3b82f6]'
                          : 'text-[#94a3b8] hover:bg-[#1a1f2c] hover:text-[#f8fafc]'
                      )}
                    >
                      {item.icon}
                      {!collapsed && <span className="flex-1 text-sm">{item.title}</span>}
                      {!collapsed && item.href === '/crm-follow-ups' && crmDueCount > 0 && (
                        <span className="min-w-5 rounded-full bg-amber-500/20 px-1.5 py-0.5 text-center text-xs font-semibold text-amber-300">
                          {crmDueCount > 99 ? '99+' : crmDueCount}
                        </span>
                      )}
                    </Link>
                  )}

                  {hasChildren && isExpanded(key) && !collapsed && (
                    <ul className="mt-1 ml-4 space-y-1">
                      {item.children.map((child) => (
                        <li key={child.href}>
                          <Link
                            href={child.href}
                            className={cn(
                              'flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors',
                              isActive(child.href)
                                ? 'bg-[#1a1f2c] text-[#3b82f6]'
                                : 'text-[#94a3b8] hover:bg-[#1a1f2c] hover:text-[#f8fafc]'
                            )}
                          >
                            {child.icon}
                            <span>{child.title}</span>
                          </Link>
                        </li>
                      ))}
                    </ul>
                  )}
                </li>
              );
            })}
          </ul>
        </nav>

        <div className="border-t border-[#2d3548] p-4">
          {!collapsed ? (
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 min-w-0">
                <div className="w-8 h-8 rounded-full bg-[#1a1f2c] flex items-center justify-center shrink-0">
                  <User className="h-4 w-4 text-[#94a3b8]" />
                </div>
                <div className="text-sm min-w-0">
                  <div className="text-[#f8fafc] truncate">演示管理员</div>
                  <div className="text-xs text-[#64748b] truncate">{demoWorkspace.ownerRole}</div>
                </div>
              </div>
              <div className="flex gap-1">
                <ThemeToggle />
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8] relative"
                  title="通知"
                >
                  <Bell className="h-4 w-4" />
                  {pendingTaskCount > 0 && (
                    <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] flex items-center justify-center bg-[#f97316] text-white text-xs font-bold rounded-full px-1">
                      {pendingTaskCount > 99 ? '99+' : pendingTaskCount}
                    </span>
                  )}
                </button>
                <Link href="/login" className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8]" title="退出">
                  <LogOut className="h-4 w-4" />
                </Link>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-2 items-center">
              <ThemeToggle />
              <div className="w-8 h-8 rounded-full bg-[#1a1f2c] flex items-center justify-center">
                <User className="h-4 w-4 text-[#94a3b8]" />
              </div>
              <Link href="/login" className="p-1.5 rounded-md hover:bg-[#1a1f2c] text-[#94a3b8]" title="退出">
                <LogOut className="h-4 w-4" />
              </Link>
            </div>
          )}
        </div>
      </aside>
    </>
  );
}
