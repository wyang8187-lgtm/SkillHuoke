export type IntegrationId =
  | 'openai'
  | 'deepseek'
  | 'google-search'
  | 'serpapi'
  | 'bing-search'
  | 'resend'
  | 'supabase';

export type IntegrationCategory = 'AI 模型' | '搜索服务' | '邮件服务' | '数据库';

export interface IntegrationEnvField {
  name: string;
  label: string;
  required: boolean;
  secret: boolean;
  aliases?: string[];
  defaultValue?: string;
}

export interface IntegrationDefinition {
  id: IntegrationId;
  name: string;
  category: IntegrationCategory;
  description: string;
  docsUrl: string;
  fields: IntegrationEnvField[];
  setupGuide: string;
  setupSteps: string[];
  testable: boolean;
}

export interface IntegrationStatusField {
  name: string;
  label: string;
  required: boolean;
  configured: boolean;
  secret: boolean;
  value: string;
}

export interface IntegrationStatus {
  id: IntegrationId;
  name: string;
  category: IntegrationCategory;
  description: string;
  docsUrl: string;
  configured: boolean;
  missingEnv: string[];
  fields: IntegrationStatusField[];
  setupGuide: string;
  setupSteps: string[];
  envTemplate: string;
  testable: boolean;
  mode: string;
}

export interface ProxySummaryItem {
  name: string;
  configured: boolean;
  value: string;
}

export interface ProxySummary {
  hasProxy: boolean;
  preferredSource: string;
  items: ProxySummaryItem[];
  note: string;
}

export const INTEGRATIONS: IntegrationDefinition[] = [
  {
    id: 'openai',
    name: 'OpenAI',
    category: 'AI 模型',
    description: '用于 AI 开发信、客户判断、英文内容生成和后续智能分析。',
    docsUrl: 'https://platform.openai.com/api-keys',
    setupGuide: '适合需要高质量英文开发信和客户分析的场景。填写 Key 后重启后端，再点击测试连接。',
    setupSteps: [
      '打开 OpenAI Platform，进入 API Keys 页面。',
      '创建新的 API Key，并只复制一次。',
      '把 Key 填到项目根目录 .env 的 OPENAI_API_KEY 后面。',
      '保存 .env 后重启后端服务，再回到本页点击“刷新配置”和“测试连接”。',
    ],
    testable: true,
    fields: [
      { name: 'OPENAI_API_KEY', label: 'OpenAI API Key', required: true, secret: true },
      { name: 'OPENAI_BASE_URL', label: 'Base URL', required: false, secret: false, defaultValue: 'https://api.openai.com/v1' },
      { name: 'OPENAI_MODEL', label: '模型名称', required: false, secret: false },
    ],
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    category: 'AI 模型',
    description: '可作为 AI 文案和判断模型的备用服务，适合控制成本。',
    docsUrl: 'https://platform.deepseek.com/api_keys',
    setupGuide: '适合做备用 AI 模型。默认模型可先使用 deepseek-chat。',
    setupSteps: [
      '打开 DeepSeek 平台，进入 API Keys 页面。',
      '创建 API Key 并复制。',
      '把 Key 填到 .env 的 DEEPSEEK_API_KEY 后面。',
      '保存 .env 后重启后端，再点击测试连接。',
    ],
    testable: true,
    fields: [
      { name: 'DEEPSEEK_API_KEY', label: 'DeepSeek API Key', required: true, secret: true },
      { name: 'DEEPSEEK_BASE_URL', label: 'Base URL', required: false, secret: false, defaultValue: 'https://api.deepseek.com/v1' },
      { name: 'DEEPSEEK_MODEL', label: '模型名称', required: false, secret: false, defaultValue: 'deepseek-chat' },
    ],
  },
  {
    id: 'google-search',
    name: 'Google Custom Search',
    category: '搜索服务',
    description: '用于通过 Google 自定义搜索发现公开客户线索和官网信息。',
    docsUrl: 'https://programmablesearchengine.google.com/',
    setupGuide: '需要同时有 API Key 和搜索引擎 CX，缺一不可。',
    setupSteps: [
      '在 Google Cloud 启用 Custom Search API。',
      '创建 API Key，并把 API 限制选择为 Custom Search API。',
      '在 Programmable Search Engine 创建搜索引擎，复制搜索引擎 ID 作为 CX。',
      '把 GOOGLE_SEARCH_API_KEY 和 GOOGLE_SEARCH_CX 填入 .env。',
      '保存 .env 后重启后端，再点击测试连接。',
    ],
    testable: true,
    fields: [
      { name: 'GOOGLE_SEARCH_API_KEY', label: 'Google API Key', required: true, secret: true },
      { name: 'GOOGLE_SEARCH_CX', label: '搜索引擎 CX', required: true, secret: true },
    ],
  },
  {
    id: 'serpapi',
    name: 'SerpAPI',
    category: '搜索服务',
    description: '推荐作为默认搜索源，适合海外搜索结果采集和降级处理。',
    docsUrl: 'https://serpapi.com/manage-api-key',
    setupGuide: '如果你不想处理 Google Cloud 的复杂配置，可以优先接 SerpAPI。',
    setupSteps: [
      '注册并登录 SerpAPI。',
      '进入 API Key 页面复制 Key。',
      '把 Key 填到 .env 的 SERPAPI_KEY 后面。',
      '保存 .env 后重启后端，再点击测试连接。',
    ],
    testable: true,
    fields: [
      { name: 'SERPAPI_KEY', label: 'SerpAPI Key', required: true, secret: true, aliases: ['SERPAPI_API_KEY'] },
    ],
  },
  {
    id: 'bing-search',
    name: 'Bing Search',
    category: '搜索服务',
    description: '作为搜索降级来源，适合补充 Google 或 SerpAPI。',
    docsUrl: 'https://www.microsoft.com/bing/apis/bing-web-search-api',
    setupGuide: '适合作为备用搜索源。Endpoint 通常可以保持默认。',
    setupSteps: [
      '在 Microsoft Azure 或 Bing API 页面创建 Bing Web Search 资源。',
      '复制订阅 Key。',
      '把 Key 填到 .env 的 BING_SEARCH_API_KEY 后面。',
      'Endpoint 默认使用 Bing Web Search v7，通常不用修改。',
      '保存 .env 后重启后端，再点击测试连接。',
    ],
    testable: true,
    fields: [
      { name: 'BING_SEARCH_API_KEY', label: 'Bing Search Key', required: true, secret: true },
      { name: 'BING_SEARCH_ENDPOINT', label: 'Endpoint', required: false, secret: false, defaultValue: 'https://api.bing.microsoft.com/v7.0/search' },
    ],
  },
  {
    id: 'resend',
    name: 'Resend',
    category: '邮件服务',
    description: '用于报价、订单、单据和物流邮件的真实发送。',
    docsUrl: 'https://resend.com/api-keys',
    setupGuide: '真实发送前需要在 Resend 验证发件域名，否则建议继续使用本地草稿模式。',
    setupSteps: [
      '注册并登录 Resend。',
      '先完成发件域名验证。',
      '创建 API Key 并复制。',
      '把 RESEND_API_KEY 和 RESEND_FROM_EMAIL 填入 .env。',
      '保存 .env 后重启后端，再点击测试连接。',
    ],
    testable: true,
    fields: [
      { name: 'RESEND_API_KEY', label: 'Resend API Key', required: true, secret: true },
      { name: 'RESEND_FROM_EMAIL', label: '发件邮箱', required: true, secret: false },
      { name: 'RESEND_FROM_NAME', label: '发件名称', required: false, secret: false, defaultValue: 'SkillHuoke Export' },
      { name: 'RESEND_REPLY_TO', label: '回复邮箱', required: false, secret: false },
    ],
  },
  {
    id: 'supabase',
    name: 'Supabase',
    category: '数据库',
    description: '用于后续 SaaS 数据库、账号、团队和业务数据持久化。',
    docsUrl: 'https://supabase.com/dashboard',
    setupGuide: '当前仍支持本地演示数据。接 Supabase 后，后续可以逐步升级成真正多用户 SaaS。',
    setupSteps: [
      '打开 Supabase Dashboard，创建或进入项目。',
      '在 Project Settings 的 API 页面复制 Project URL 和 anon public key。',
      '把 COZE_SUPABASE_URL 和 COZE_SUPABASE_ANON_KEY 填入 .env。',
      '如需要后端管理能力，再填写 COZE_SUPABASE_SERVICE_ROLE_KEY。',
      '保存 .env 后重启后端，再点击测试连接。',
    ],
    testable: true,
    fields: [
      { name: 'COZE_SUPABASE_URL', label: '项目 URL', required: true, secret: false },
      { name: 'COZE_SUPABASE_ANON_KEY', label: 'Anon Key', required: true, secret: true },
      { name: 'COZE_SUPABASE_SERVICE_ROLE_KEY', label: 'Service Role Key', required: false, secret: true },
    ],
  },
];

export function maskSecret(value: string | undefined) {
  const trimmed = value?.trim() || '';
  if (!trimmed) return '';
  return `••••${trimmed.slice(-4)}`;
}

function getEnvValue(env: NodeJS.ProcessEnv | Record<string, string | undefined>, field: IntegrationEnvField) {
  const names = [field.name, ...(field.aliases || [])];
  for (const name of names) {
    const value = env[name]?.trim();
    if (value) return { value, sourceName: field.name };
  }
  return { value: field.defaultValue || '', sourceName: field.name };
}

export function buildEnvTemplate(definition: IntegrationDefinition) {
  return definition.fields
    .map((field) => `${field.name}=${field.defaultValue || ''}`)
    .join('\n');
}

export function buildFullEnvTemplate() {
  return INTEGRATIONS.map((definition) => `# ${definition.name}\n${buildEnvTemplate(definition)}`).join('\n\n');
}

export function buildIntegrationStatuses(env: NodeJS.ProcessEnv | Record<string, string | undefined> = process.env): IntegrationStatus[] {
  return INTEGRATIONS.map((definition) => {
    const fields = definition.fields.map((field) => {
      const { value } = getEnvValue(env, field);
      const configured = Boolean(value);
      return {
        name: field.name,
        label: field.label,
        required: field.required,
        configured,
        secret: field.secret,
        value: field.secret ? maskSecret(value) : value,
      };
    });
    const missingEnv = fields
      .filter((field) => field.required && !field.configured)
      .map((field) => field.name);

    return {
      id: definition.id,
      name: definition.name,
      category: definition.category,
      description: definition.description,
      docsUrl: definition.docsUrl,
      configured: missingEnv.length === 0,
      missingEnv,
      fields,
      setupGuide: definition.setupGuide,
      setupSteps: definition.setupSteps,
      envTemplate: buildEnvTemplate(definition),
      testable: definition.testable,
      mode: missingEnv.length === 0 ? '已具备真实连接测试条件' : '配置不完整，将继续使用演示或降级能力',
    };
  });
}

export function getIntegrationById(id: string) {
  return INTEGRATIONS.find((integration) => integration.id === id);
}

export function getRawEnvValue(id: IntegrationId, name: string, env: NodeJS.ProcessEnv = process.env) {
  const definition = getIntegrationById(id);
  const field = definition?.fields.find((item) => item.name === name);
  if (!field) return '';
  return getEnvValue(env, field).value;
}

function safeProxyValue(value: string | undefined) {
  const trimmed = value?.trim();
  if (!trimmed) return '';
  try {
    const url = new URL(trimmed);
    const host = url.port ? `${url.hostname}:${url.port}` : url.hostname;
    return `${url.protocol}//${host}`;
  } catch {
    return trimmed.replace(/\/\/.*@/, '//***@');
  }
}

export function summarizeProxyConfig(env: NodeJS.ProcessEnv | Record<string, string | undefined> = process.env): ProxySummary {
  const names = ['SKILLHUOKE_PROXY', 'HTTPS_PROXY', 'HTTP_PROXY', 'ALL_PROXY'];
  const items = names.map((name) => {
    const value = env[name];
    return {
      name,
      configured: Boolean(value?.trim()),
      value: safeProxyValue(value),
    };
  });
  const first = items.find((item) => item.configured);
  return {
    hasProxy: Boolean(first),
    preferredSource: first?.name || '未检测到代理变量',
    items,
    note: first
      ? '后端检测到代理环境变量。页面只显示主机摘要，不显示账号或密码。'
      : '未检测到代理环境变量。如果本机无法访问海外 API，可配置系统代理或 SKILLHUOKE_PROXY 后重启后端。',
  };
}
