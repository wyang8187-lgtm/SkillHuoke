export interface ApiQuickField {
  name: string;
  label: string;
  placeholder: string;
  helper: string;
  secret: boolean;
}

export type ApiQuickValues = Record<string, string>;

export const apiQuickFields: ApiQuickField[] = [
  {
    name: 'OPENAI_API_KEY',
    label: 'OpenAI API Key',
    placeholder: 'sk-...',
    helper: '用于 AI 开发信、客户分析和智能生成。',
    secret: true,
  },
  {
    name: 'DEEPSEEK_API_KEY',
    label: 'DeepSeek API Key',
    placeholder: 'sk-...',
    helper: '可作为 OpenAI 的低成本 AI 文案和分析接口。',
    secret: true,
  },
  {
    name: 'DEEPSEEK_BASE_URL',
    label: 'DeepSeek Base URL',
    placeholder: 'https://api.deepseek.com/v1',
    helper: '通常保持默认地址即可，除非你使用代理网关。',
    secret: false,
  },
  {
    name: 'DEEPSEEK_MODEL',
    label: 'DeepSeek Model',
    placeholder: 'deepseek-chat',
    helper: '推荐先用 deepseek-chat，后续可按需要切换模型。',
    secret: false,
  },
  {
    name: 'SERPAPI_KEY',
    label: 'SerpAPI Key',
    placeholder: '复制 SerpAPI 后台的 Key',
    helper: '推荐优先接入，配置简单，适合真实搜索获客。',
    secret: true,
  },
  {
    name: 'GOOGLE_SEARCH_API_KEY',
    label: 'Google Search API Key',
    placeholder: 'Google Cloud Custom Search API Key',
    helper: '用于 Google Custom Search，需要和 CX 一起配置。',
    secret: true,
  },
  {
    name: 'GOOGLE_SEARCH_CX',
    label: 'Google CX',
    placeholder: 'Programmable Search Engine CX',
    helper: 'Google 自定义搜索引擎 ID，不是 API Key。',
    secret: false,
  },
  {
    name: 'BING_SEARCH_API_KEY',
    label: 'Bing Search API Key',
    placeholder: 'Azure / Bing Web Search Key',
    helper: '作为搜索降级来源，SerpAPI 或 Google 失败时可继续搜索。',
    secret: true,
  },
];

export function buildQuickEnvSnippet(values: ApiQuickValues) {
  return apiQuickFields
    .map((field) => {
      const value = values[field.name]?.trim();
      return value ? `${field.name}=${value}` : '';
    })
    .filter(Boolean)
    .join('\n');
}
