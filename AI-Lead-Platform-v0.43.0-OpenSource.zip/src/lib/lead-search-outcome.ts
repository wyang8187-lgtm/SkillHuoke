export type LeadSearchOutcome = {
  status: 'failed' | 'partial' | 'completed';
  label: '执行失败' | '部分完成' | '执行完成';
};

export function getLeadSearchOutcome(targetQuantity: number, returnedCount: number): LeadSearchOutcome {
  if (returnedCount <= 0) return { status: 'failed', label: '执行失败' };
  if (returnedCount < targetQuantity) return { status: 'partial', label: '部分完成' };
  return { status: 'completed', label: '执行完成' };
}
