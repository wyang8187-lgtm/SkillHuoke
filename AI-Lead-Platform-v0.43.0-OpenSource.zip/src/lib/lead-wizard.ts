import type {
  LeadSearchCandidate,
  LeadSearchResult,
  ProviderDiagnostic,
} from './integrations/lead-search-provider';
import { getLeadSearchOutcome } from './lead-search-outcome';

export interface LeadWizardInput {
  product: string;
  country: string;
  customerType: string;
  quantity: number;
}

export interface LeadWizardOutput {
  keywords: string[];
  channels: string[];
  verificationRules: string[];
  outreachActions: string[];
  priorityLogic: string[];
}

export type LeadTaskStatus = 'draft' | 'pending' | 'running' | 'completed';

export interface SavedLeadTask {
  id: string;
  title: string;
  status: LeadTaskStatus;
  input: LeadWizardInput;
  output: LeadWizardOutput;
  createdAt: string;
  updatedAt: string;
  runSnapshot?: LeadTaskRunSnapshot;
}

export interface LeadTaskRunSnapshot {
  status: 'pending' | 'running' | 'enriching' | 'partial' | 'failed' | 'completed';
  targetCount: number;
  foundCount: number;
  enrichedCount: number;
  progressPercent: number;
  currentStep: string;
  successAttempts: number;
  failedAttempts: number;
  emptyAttempts: number;
  providerDiagnostics: ProviderDiagnostic[];
  lastRunAt: string;
  lastError?: string;
}

export interface LeadTaskExecutionStep {
  id: string;
  title: string;
  status: 'completed' | 'running' | 'pending';
  detail: string;
}

export interface LeadTaskRunLog {
  time: string;
  level: 'info' | 'success' | 'warning';
  message: string;
}

export interface LeadTaskCandidate {
  id: string;
  company: string;
  website: string;
  country: string;
  city: string;
  customerType: string;
  contactStatus: string;
  email?: string;
  phone?: string;
  whatsapp?: string;
  linkedin?: string;
  contactSource?: string;
  contactConfidence?: number;
  score: number;
  priority: 'A' | 'B' | 'C';
  recommendation: string;
}

export type CandidateLeadStatus = 'priority' | 'verify' | 'paused' | 'joined';

export interface SavedCandidateLead extends LeadTaskCandidate {
  sourceTaskId: string;
  sourceTaskTitle: string;
  status: CandidateLeadStatus;
  createdAt: string;
  updatedAt: string;
}

export type CrmCustomerStatus = 'new' | 'contacted' | 'replied' | 'quoted' | 'paused';
export type CrmVerificationStatus = 'pending' | 'partial' | 'verified';
export type CrmCustomerSourceType = 'candidate' | 'manual' | 'import';

export interface SavedCrmCustomer {
  id: string;
  candidateId: string;
  company: string;
  website: string;
  country: string;
  city: string;
  customerType: string;
  contactStatus: string;
  score: number;
  priority: 'A' | 'B' | 'C';
  sourceTaskId: string;
  sourceTaskTitle: string;
  status: CrmCustomerStatus;
  note: string;
  nextAction: string;
  nextFollowUpAt?: string;
  contactName?: string;
  contactTitle?: string;
  email?: string;
  phone?: string;
  whatsapp?: string;
  linkedin?: string;
  verificationStatus?: CrmVerificationStatus;
  sourceType?: CrmCustomerSourceType;
  createdAt: string;
  updatedAt: string;
}

export type CrmFollowUpChannel = 'email' | 'whatsapp' | 'linkedin' | 'phone' | 'note';
export type CrmReminderBucket = 'overdue' | 'today' | 'upcoming' | 'unscheduled';

export interface SavedCrmFollowUp {
  id: string;
  customerId: string;
  channel: CrmFollowUpChannel;
  content: string;
  contactedAt: string;
  createdAt: string;
}

export interface CustomerOutreachCopy {
  emailSubject: string;
  emailBody: string;
  whatsappMessage: string;
}

export interface LeadTaskExecutionPreview {
  steps: LeadTaskExecutionStep[];
  logs: LeadTaskRunLog[];
  candidates: LeadTaskCandidate[];
}

export const LEAD_TASKS_STORAGE_KEY = 'skillhuoke_lead_tasks_v017';
export const CANDIDATE_LEADS_STORAGE_KEY = 'skillhuoke_candidate_leads_v019';
export const CRM_CUSTOMERS_STORAGE_KEY = 'skillhuoke_crm_customers_v020';
export const CRM_FOLLOW_UPS_STORAGE_KEY = 'skillhuoke_crm_follow_ups_v021';

export const leadTaskStatusOptions: Array<{ value: LeadTaskStatus; label: string; className: string }> = [
  { value: 'draft', label: '草稿', className: 'bg-slate-500/15 text-slate-300 border-slate-500/25' },
  { value: 'pending', label: '待执行', className: 'bg-amber-500/15 text-amber-300 border-amber-500/25' },
  { value: 'running', label: '执行中', className: 'bg-blue-500/15 text-blue-300 border-blue-500/25' },
  { value: 'completed', label: '已完成', className: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25' },
];

export const candidateLeadStatusOptions: Array<{ value: CandidateLeadStatus; label: string; className: string }> = [
  { value: 'priority', label: '优先开发', className: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25' },
  { value: 'verify', label: '需要核验', className: 'bg-amber-500/15 text-amber-300 border-amber-500/25' },
  { value: 'paused', label: '暂缓开发', className: 'bg-slate-500/15 text-slate-300 border-slate-500/25' },
  { value: 'joined', label: '已加入客户池', className: 'bg-blue-500/15 text-blue-300 border-blue-500/25' },
];

export const crmCustomerStatusOptions: Array<{ value: CrmCustomerStatus; label: string; className: string }> = [
  { value: 'new', label: '新客户', className: 'bg-blue-500/15 text-blue-300 border-blue-500/25' },
  { value: 'contacted', label: '已开发', className: 'bg-violet-500/15 text-violet-300 border-violet-500/25' },
  { value: 'replied', label: '已回复', className: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25' },
  { value: 'quoted', label: '已报价', className: 'bg-amber-500/15 text-amber-300 border-amber-500/25' },
  { value: 'paused', label: '暂缓', className: 'bg-slate-500/15 text-slate-300 border-slate-500/25' },
];

export const crmFollowUpChannelOptions: Array<{ value: CrmFollowUpChannel; label: string }> = [
  { value: 'email', label: '邮件' },
  { value: 'whatsapp', label: 'WhatsApp' },
  { value: 'linkedin', label: 'LinkedIn' },
  { value: 'phone', label: '电话' },
  { value: 'note', label: '内部备注' },
];

export const defaultLeadWizardInput: LeadWizardInput = {
  product: '全屋定制、橱柜、衣柜、木门、家具出口',
  country: 'Australia',
  customerType: 'Builder + Designer + Kitchen Company + Importer',
  quantity: 50,
};

function cleanValue(value: string, fallback: string) {
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : fallback;
}

function normalizeProductForSearch(product: string) {
  return product
    .replace(/、/g, ' ')
    .replace(/，/g, ' ')
    .replace(/,/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function generateLeadWizardOutput(input: LeadWizardInput): LeadWizardOutput {
  const product = cleanValue(input.product, defaultLeadWizardInput.product);
  const country = cleanValue(input.country, defaultLeadWizardInput.country);
  const customerType = cleanValue(input.customerType, defaultLeadWizardInput.customerType);
  const searchProduct = normalizeProductForSearch(product);
  const quantity = Math.max(1, Math.min(500, Number.isFinite(input.quantity) ? input.quantity : defaultLeadWizardInput.quantity));

  const keywords = [
    `${country} ${searchProduct} ${customerType} contact email`,
    `${country} ${searchProduct} company LinkedIn`,
    `site:.${country.toLowerCase().includes('australia') ? 'au' : 'com'} ${searchProduct} contact`,
    `${country} ${searchProduct} importer supplier WhatsApp`,
    `${country} kitchen company builder designer joinery contact`,
    `${country} custom cabinets wardrobe door furniture manufacturer`,
  ];

  const channels = [
    `Google / Bing 搜索：先找官网和 Contact 页面，目标 ${quantity} 个候选结果。`,
    'LinkedIn：搜索公司页和 Owner / Procurement / Project / Design / Sourcing 联系人。',
    '官网表单：当邮箱或 WhatsApp 不完整时，优先通过 Contact 表单核验。',
    '行业目录：只作为辅助来源，必须回到官网或 LinkedIn 二次核验。',
  ];

  const verificationRules = [
    '官网域名、公司名和目标国家必须匹配，目录页和聚合页降低优先级。',
    '邮箱优先选择官网公开邮箱，个人邮箱需要 LinkedIn 或官网团队页佐证。',
    'WhatsApp / 电话需要带国家区号，并和官网、Google Business 或社媒页面一致。',
    'LinkedIn 公司页、项目案例、产品类型与目标客户类型越匹配，评分越高。',
    '没有官网、没有联系人、只有社媒帖子或只有目录页的结果先标记为待核验。',
  ];

  const outreachActions = [
    'A 级：官网、邮箱/电话、LinkedIn、业务匹配都完整，直接生成英文开发信。',
    'B 级：公司真实但联系人不完整，先用 LinkedIn 搜索 Owner / Procurement / Design 联系人。',
    'C 级：联系方式缺失，先通过官网表单或公开电话核验，再进入 CRM。',
    'D 级：目录页、广告页、招聘页、无关社媒帖子，过滤或暂缓开发。',
  ];

  const priorityLogic = [
    `优先收集 ${Math.ceil(quantity * 0.4)} 个 A/B 级客户进入 CRM。`,
    `保留 ${Math.ceil(quantity * 0.3)} 个 C 级客户做补全核验。`,
    '每个客户至少记录来源链接、官网、国家、客户类型、联系方式状态和下一步动作。',
    '开发前先确认客户类型，再选择首次开发、二次跟进或报价邀请模板。',
  ];

  return {
    keywords,
    channels,
    verificationRules,
    outreachActions,
    priorityLogic,
  };
}

function isBrowser() {
  return typeof window !== 'undefined';
}

function getNowText() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

export function buildLeadTaskRunSnapshot(
  result: LeadSearchResult,
  lastRunAt = getNowText()
): LeadTaskRunSnapshot {
  const summary = result.batchSummary;
  const targetCount = summary?.targetQuantity || 0;
  const foundCount = summary?.returnedCount || result.candidates.length;
  const enrichedCount = summary?.enrichedCount || 0;
  const outcome = getLeadSearchOutcome(targetCount, foundCount);
  const providerDiagnostics = result.providerDiagnostics || [];
  const errors = providerDiagnostics
    .filter((diagnostic) => diagnostic.reason)
    .map((diagnostic) => {
      const name =
        diagnostic.provider === 'serpapi'
          ? 'SerpAPI'
          : diagnostic.provider === 'google'
            ? 'Google'
            : 'Bing';
      return `${name}：${diagnostic.reason}`;
    });
  return {
    status: outcome.status,
    targetCount,
    foundCount,
    enrichedCount,
    progressPercent: targetCount > 0
      ? Math.min(100, Math.round((foundCount / targetCount) * 100))
      : 0,
    currentStep:
      outcome.status === 'failed'
        ? '真实搜索失败，请根据诊断修复后重试'
        : outcome.status === 'partial'
          ? '已保留部分真实客户，等待继续补全'
          : '已达到目标客户数量',
    successAttempts: result.attempts?.filter((attempt) => attempt.status === 'success').length || 0,
    failedAttempts: result.attempts?.filter((attempt) => attempt.status === 'failed').length || 0,
    emptyAttempts: result.attempts?.filter((attempt) => attempt.status === 'empty').length || 0,
    providerDiagnostics,
    lastRunAt,
    lastError: errors.length ? errors.join('；') : undefined,
  };
}

function createTaskId() {
  return `lead-task-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

export function getLeadTaskStatusMeta(status: LeadTaskStatus) {
  return leadTaskStatusOptions.find((item) => item.value === status) ?? leadTaskStatusOptions[0];
}

export function getCandidateLeadStatusMeta(status: CandidateLeadStatus) {
  return candidateLeadStatusOptions.find((item) => item.value === status) ?? candidateLeadStatusOptions[1];
}

export function getCrmCustomerStatusMeta(status: CrmCustomerStatus) {
  return crmCustomerStatusOptions.find((item) => item.value === status) ?? crmCustomerStatusOptions[0];
}

function describeContactStatus(candidate: LeadSearchCandidate) {
  const labels = [
    candidate.emailStatus === 'found' ? '邮箱已发现' : '邮箱待核验',
    candidate.phoneStatus === 'found' ? '电话已发现' : '电话待核验',
    candidate.whatsappStatus === 'found' ? 'WhatsApp已发现' : 'WhatsApp待核验',
    candidate.linkedinStatus === 'found' ? 'LinkedIn已发现' : 'LinkedIn待核验',
  ];
  return labels.join(' / ');
}

function normalizeTaskPriority(priority: LeadSearchCandidate['priority']): LeadTaskCandidate['priority'] {
  return priority === 'A' || priority === 'B' ? priority : 'C';
}

export function mapSearchCandidatesToTaskCandidates(
  taskId: string,
  candidates: LeadSearchCandidate[]
): LeadTaskCandidate[] {
  return candidates
    .filter((candidate) => candidate.priority !== 'D')
    .map((candidate, index): LeadTaskCandidate => ({
      id: `${taskId}-real-${index + 1}`,
      company: candidate.companyName,
      website: candidate.website || candidate.sourceUrl || '',
      country: candidate.country,
      city: candidate.city || '待核验',
      customerType: candidate.customerType || '待确认',
      contactStatus: describeContactStatus(candidate),
      email: candidate.email,
      phone: candidate.phone,
      whatsapp: candidate.whatsapp,
      linkedin: candidate.linkedin,
      contactSource:
        candidate.contactSources?.email ||
        candidate.contactSources?.phone ||
        candidate.contactSources?.whatsapp ||
        candidate.contactSources?.linkedin ||
        candidate.sourceUrl,
      contactConfidence: candidate.contactConfidence,
      score: candidate.matchScore,
      priority: normalizeTaskPriority(candidate.priority),
      recommendation: [
        candidate.nextAction,
        candidate.sourceUrl ? `来源：${candidate.sourceUrl}` : '',
        candidate.riskSignals.length ? `风险提示：${candidate.riskSignals.join('、')}` : '',
      ].filter(Boolean).join(' '),
    }));
}

export function loadSavedLeadTasks(): SavedLeadTask[] {
  if (!isBrowser()) return [];

  try {
    const raw = window.localStorage.getItem(LEAD_TASKS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedLeadTask[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function findSavedLeadTask(taskId: string) {
  return loadSavedLeadTasks().find((task) => task.id === taskId) ?? null;
}

export function saveLeadTasks(tasks: SavedLeadTask[]) {
  if (!isBrowser()) return;
  window.localStorage.setItem(LEAD_TASKS_STORAGE_KEY, JSON.stringify(tasks));
}

export function createSavedLeadTask(input: LeadWizardInput, output: LeadWizardOutput): SavedLeadTask {
  const now = getNowText();
  const title = `${input.country || '目标市场'} - ${input.customerType || '客户类型'} - ${input.quantity || 0} 个`;

  return {
    id: createTaskId(),
    title,
    status: 'pending',
    input,
    output,
    createdAt: now,
    updatedAt: now,
  };
}

export function addSavedLeadTask(task: SavedLeadTask) {
  const tasks = loadSavedLeadTasks();
  const nextTasks = [task, ...tasks];
  saveLeadTasks(nextTasks);
  return nextTasks;
}

export function updateSavedLeadTaskStatus(taskId: string, status: LeadTaskStatus) {
  const tasks = loadSavedLeadTasks();
  const now = getNowText();
  const nextTasks = tasks.map((task) => (task.id === taskId ? { ...task, status, updatedAt: now } : task));
  saveLeadTasks(nextTasks);
  return nextTasks;
}

export function updateSavedLeadTaskRunSnapshot(
  taskId: string,
  runSnapshot: LeadTaskRunSnapshot
) {
  const tasks = loadSavedLeadTasks();
  const nextTasks = tasks.map((task) =>
    task.id === taskId
      ? { ...task, runSnapshot, updatedAt: runSnapshot.lastRunAt }
      : task
  );
  saveLeadTasks(nextTasks);
  return nextTasks;
}

export function deleteSavedLeadTask(taskId: string) {
  const tasks = loadSavedLeadTasks();
  const nextTasks = tasks.filter((task) => task.id !== taskId);
  saveLeadTasks(nextTasks);
  return nextTasks;
}

export function buildLeadTaskExportText(task: SavedLeadTask) {
  return [
    `获客任务：${task.title}`,
    `状态：${getLeadTaskStatusMeta(task.status).label}`,
    `创建时间：${task.createdAt}`,
    '',
    '【任务输入】',
    `产品：${task.input.product}`,
    `国家：${task.input.country}`,
    `客户类型：${task.input.customerType}`,
    `目标数量：${task.input.quantity}`,
    '',
    '【搜索关键词】',
    ...task.output.keywords.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【推荐渠道】',
    ...task.output.channels.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【核验规则】',
    ...task.output.verificationRules.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【开发动作】',
    ...task.output.outreachActions.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【优先级逻辑】',
    ...task.output.priorityLogic.map((item, index) => `${index + 1}. ${item}`),
  ].join('\n');
}

export function downloadLeadTaskText(task: SavedLeadTask) {
  if (!isBrowser()) return;

  const blob = new Blob([buildLeadTaskExportText(task)], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${task.title.replace(/[\\/:*?"<>|]/g, '-')}.txt`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function loadSavedCandidateLeads(): SavedCandidateLead[] {
  if (!isBrowser()) return [];

  try {
    const raw = window.localStorage.getItem(CANDIDATE_LEADS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedCandidateLead[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveCandidateLeads(candidates: SavedCandidateLead[]) {
  if (!isBrowser()) return;
  window.localStorage.setItem(CANDIDATE_LEADS_STORAGE_KEY, JSON.stringify(candidates));
}

export function seedCandidateLeadsFromTask(task: SavedLeadTask, candidates: LeadTaskCandidate[]) {
  const existing = loadSavedCandidateLeads();
  const now = getNowText();
  const incoming = candidates.map((candidate): SavedCandidateLead => ({
    ...candidate,
    sourceTaskId: task.id,
    sourceTaskTitle: task.title,
    status: candidate.priority === 'A' ? 'priority' : candidate.priority === 'B' ? 'verify' : 'paused',
    createdAt: now,
    updatedAt: now,
  }));

  const byId = new Map<string, SavedCandidateLead>();
  [...incoming, ...existing].forEach((candidate) => {
    byId.set(candidate.id, candidate);
  });

  const nextCandidates = Array.from(byId.values());
  saveCandidateLeads(nextCandidates);
  return nextCandidates;
}

export type CandidateSourceType = 'real_search' | 'mock' | 'manual_import' | 'unknown';

export function getCandidateSourceMeta(candidate: SavedCandidateLead) {
  const text = `${candidate.sourceTaskTitle} ${candidate.recommendation}`.toLowerCase();
  const urlMatch = candidate.recommendation.match(/https?:\/\/[^\s，。)]+/);
  if (text.includes('mock') || text.includes('演示')) {
    return { type: 'mock' as CandidateSourceType, label: '演示降级', url: urlMatch?.[0] || '' };
  }
  if (text.includes('real search') || text.includes('真实搜索') || urlMatch) {
    return { type: 'real_search' as CandidateSourceType, label: '真实搜索', url: urlMatch?.[0] || '' };
  }
  if (text.includes('import') || text.includes('导入') || text.includes('manual')) {
    return { type: 'manual_import' as CandidateSourceType, label: '手动/导入', url: urlMatch?.[0] || '' };
  }
  return { type: 'unknown' as CandidateSourceType, label: '未标记来源', url: urlMatch?.[0] || '' };
}

export function buildCandidateVerificationChecklist(candidate: SavedCandidateLead) {
  const contact = candidate.contactStatus.toLowerCase();
  return [
    { key: 'website', label: '官网', done: Boolean(candidate.website) },
    { key: 'email', label: '邮箱', done: contact.includes('邮箱已发现') || contact.includes('email found') },
    { key: 'phone', label: '电话', done: contact.includes('电话已发现') || contact.includes('phone found') },
    { key: 'whatsapp', label: 'WhatsApp', done: contact.includes('whatsapp已发现') || contact.includes('whatsapp found') },
    { key: 'linkedin', label: 'LinkedIn', done: contact.includes('linkedin已发现') || contact.includes('linkedin found') },
  ];
}

export function updateCandidateStatuses(
  candidates: SavedCandidateLead[],
  candidateIds: string[],
  status: CandidateLeadStatus,
  updatedAt = getNowText()
) {
  const selectedIds = new Set(candidateIds);
  return candidates.map((candidate) =>
    selectedIds.has(candidate.id) ? { ...candidate, status, updatedAt } : candidate
  );
}

export function updateSavedCandidateLeadStatus(candidateId: string, status: CandidateLeadStatus) {
  const candidates = loadSavedCandidateLeads();
  const now = getNowText();
  const nextCandidates = candidates.map((candidate) =>
    candidate.id === candidateId ? { ...candidate, status, updatedAt: now } : candidate
  );
  saveCandidateLeads(nextCandidates);
  return nextCandidates;
}

export function updateSavedCandidateLeadStatuses(candidateIds: string[], status: CandidateLeadStatus) {
  const nextCandidates = updateCandidateStatuses(loadSavedCandidateLeads(), candidateIds, status);
  saveCandidateLeads(nextCandidates);
  return nextCandidates;
}

export function deleteSavedCandidateLead(candidateId: string) {
  const candidates = loadSavedCandidateLeads();
  const nextCandidates = candidates.filter((candidate) => candidate.id !== candidateId);
  saveCandidateLeads(nextCandidates);
  return nextCandidates;
}

export function loadSavedCrmCustomers(): SavedCrmCustomer[] {
  if (!isBrowser()) return [];

  try {
    const raw = window.localStorage.getItem(CRM_CUSTOMERS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedCrmCustomer[];
    if (!Array.isArray(parsed)) return [];
    return parsed.map((customer) => ({
      ...customer,
      note: customer.note || '',
      nextAction: customer.nextAction || '',
      contactName: customer.contactName || '',
      contactTitle: customer.contactTitle || '',
      email: customer.email || '',
      phone: customer.phone || '',
      whatsapp: customer.whatsapp || '',
      linkedin: customer.linkedin || '',
      verificationStatus: customer.verificationStatus || 'pending',
      sourceType: customer.sourceType || 'candidate',
      createdAt: customer.createdAt || getNowText(),
      updatedAt: customer.updatedAt || customer.createdAt || getNowText(),
    }));
  } catch {
    return [];
  }
}

export function saveCrmCustomers(customers: SavedCrmCustomer[]) {
  if (!isBrowser()) return;
  window.localStorage.setItem(CRM_CUSTOMERS_STORAGE_KEY, JSON.stringify(customers));
}

export function convertCandidateToCrmCustomer(candidate: SavedCandidateLead) {
  const existing = loadSavedCrmCustomers();
  const now = getNowText();
  const alreadyExists = existing.find((customer) => customer.candidateId === candidate.id);

  if (alreadyExists) {
    return existing;
  }

  const nextAction =
    candidate.priority === 'A'
      ? '发送首次英文开发信，并同步 LinkedIn 触达。'
      : candidate.priority === 'B'
        ? '先补充联系人，再发送 LinkedIn 开场白。'
        : '先核验联系方式，再决定是否开发。';

  const customer: SavedCrmCustomer = {
    id: `crm-${candidate.id}`,
    candidateId: candidate.id,
    company: candidate.company,
    website: candidate.website,
    country: candidate.country,
    city: candidate.city,
    customerType: candidate.customerType,
    contactStatus: candidate.contactStatus,
    score: candidate.score,
    priority: candidate.priority,
    sourceTaskId: candidate.sourceTaskId,
    sourceTaskTitle: candidate.sourceTaskTitle,
    status: 'new',
    note: candidate.recommendation,
    nextAction,
    email: candidate.email,
    phone: candidate.phone,
    whatsapp: candidate.whatsapp,
    linkedin: candidate.linkedin,
    verificationStatus: 'pending',
    sourceType: 'candidate',
    createdAt: now,
    updatedAt: now,
  };

  const nextCustomers = [customer, ...existing];
  saveCrmCustomers(nextCustomers);
  updateSavedCandidateLeadStatus(candidate.id, 'joined');
  return nextCustomers;
}

export function updateSavedCrmCustomer(
  customerId: string,
  patch: Partial<Pick<SavedCrmCustomer, 'status' | 'note' | 'nextAction' | 'nextFollowUpAt'>>
) {
  const customers = loadSavedCrmCustomers();
  const now = getNowText();
  const nextCustomers = customers.map((customer) =>
    customer.id === customerId ? { ...customer, ...patch, updatedAt: now } : customer
  );
  saveCrmCustomers(nextCustomers);
  return nextCustomers;
}

export function createManualCrmCustomer(
  input: Omit<SavedCrmCustomer, 'id' | 'candidateId' | 'sourceTaskId' | 'sourceTaskTitle' | 'createdAt' | 'updatedAt'>
) {
  const now = getNowText();
  const id = `crm-manual-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const customer: SavedCrmCustomer = {
    ...input,
    id,
    candidateId: `manual-${id}`,
    sourceTaskId: 'manual-entry',
    sourceTaskTitle: '手动录入',
    sourceType: 'manual',
    createdAt: now,
    updatedAt: now,
  };
  const nextCustomers = [customer, ...loadSavedCrmCustomers()];
  saveCrmCustomers(nextCustomers);
  return customer;
}

export function updateFullSavedCrmCustomer(customerId: string, input: Partial<SavedCrmCustomer>) {
  const now = getNowText();
  const customers = loadSavedCrmCustomers();
  const nextCustomers = customers.map((customer) =>
    customer.id === customerId
      ? { ...customer, ...input, id: customer.id, createdAt: customer.createdAt, updatedAt: now }
      : customer
  );
  saveCrmCustomers(nextCustomers);
  return nextCustomers.find((customer) => customer.id === customerId);
}

export function deleteSavedCrmCustomer(customerId: string) {
  const customers = loadSavedCrmCustomers();
  const nextCustomers = customers.filter((customer) => customer.id !== customerId);
  saveCrmCustomers(nextCustomers);
  saveCrmFollowUps(loadSavedCrmFollowUps().filter((followUp) => followUp.customerId !== customerId));
  return nextCustomers;
}

export function getSavedCrmCustomer(customerId: string) {
  return loadSavedCrmCustomers().find((customer) => customer.id === customerId);
}

export function loadSavedCrmFollowUps(): SavedCrmFollowUp[] {
  if (!isBrowser()) return [];

  try {
    const raw = window.localStorage.getItem(CRM_FOLLOW_UPS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedCrmFollowUp[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveCrmFollowUps(followUps: SavedCrmFollowUp[]) {
  if (!isBrowser()) return;
  window.localStorage.setItem(CRM_FOLLOW_UPS_STORAGE_KEY, JSON.stringify(followUps));
}

export function addSavedCrmFollowUp(
  customerId: string,
  input: Pick<SavedCrmFollowUp, 'channel' | 'content' | 'contactedAt'>
) {
  const content = input.content.trim();
  if (!content) return loadSavedCrmFollowUps();

  const now = getNowText();
  const followUp: SavedCrmFollowUp = {
    id: `follow-up-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    customerId,
    channel: input.channel,
    content,
    contactedAt: input.contactedAt || now,
    createdAt: now,
  };
  const nextFollowUps = [followUp, ...loadSavedCrmFollowUps()];
  saveCrmFollowUps(nextFollowUps);

  const customer = getSavedCrmCustomer(customerId);
  if (customer) {
    const shouldMarkContacted = customer.status === 'new' && input.channel !== 'note';
    updateSavedCrmCustomer(customerId, {
      status: shouldMarkContacted ? 'contacted' : customer.status,
    });
  }

  return nextFollowUps;
}

export function deleteSavedCrmFollowUp(followUpId: string) {
  const nextFollowUps = loadSavedCrmFollowUps().filter((followUp) => followUp.id !== followUpId);
  saveCrmFollowUps(nextFollowUps);
  return nextFollowUps;
}

function getOutreachProduct(customer: SavedCrmCustomer) {
  const source = `${customer.sourceTaskTitle} ${customer.note}`.toLowerCase();
  if (source.includes('door')) return 'custom interior doors';
  if (source.includes('furniture')) return 'custom furniture';
  if (source.includes('wardrobe')) return 'custom wardrobes';
  return 'custom cabinetry, wardrobes, interior doors, and furniture';
}

export function generateCustomerOutreachCopy(customer: SavedCrmCustomer): CustomerOutreachCopy {
  const company = customer.company || 'your team';
  const customerType = customer.customerType || 'building and design company';
  const country = customer.country || 'your market';
  const product = getOutreachProduct(customer);

  return {
    emailSubject: `Custom cabinetry solutions for ${company}`,
    emailBody: `Hi ${company} team,

I came across your company while researching ${customerType.toLowerCase()} businesses in ${country}. We manufacture ${product} for residential and commercial projects, with support for drawings, material selection, production, and export delivery.

I would be glad to share our catalogue and learn more about the projects or product categories you are currently sourcing. Would a short introduction be useful?

Best regards,
SkillHuoke Export Team`,
    whatsappMessage: `Hi ${company} team, I found your company while researching ${customerType.toLowerCase()} businesses in ${country}. We manufacture ${product} for export projects. May I send you a short catalogue and introduction?`,
  };
}

export function getCrmReminderBucket(
  customer: SavedCrmCustomer,
  now = new Date()
): CrmReminderBucket {
  if (!customer.nextFollowUpAt) return 'unscheduled';
  const scheduled = new Date(customer.nextFollowUpAt);
  if (Number.isNaN(scheduled.getTime())) return 'unscheduled';
  if (customer.status === 'paused') return 'unscheduled';

  const startOfToday = new Date(now);
  startOfToday.setHours(0, 0, 0, 0);
  const endOfToday = new Date(now);
  endOfToday.setHours(23, 59, 59, 999);

  if (scheduled < startOfToday) return 'overdue';
  if (scheduled <= endOfToday) return 'today';
  return 'upcoming';
}

export function getCrmReminderSummary(customers: SavedCrmCustomer[], now = new Date()) {
  const summary: Record<CrmReminderBucket, number> = {
    overdue: 0,
    today: 0,
    upcoming: 0,
    unscheduled: 0,
  };
  customers.forEach((customer) => {
    summary[getCrmReminderBucket(customer, now)] += 1;
  });
  return { ...summary, due: summary.overdue + summary.today };
}

export function rescheduleSavedCrmCustomer(customerId: string, days: number, now = new Date()) {
  const customer = getSavedCrmCustomer(customerId);
  if (!customer) return loadSavedCrmCustomers();
  const existingDate = customer.nextFollowUpAt ? new Date(customer.nextFollowUpAt) : now;
  const base = Number.isNaN(existingDate.getTime()) ? new Date(now) : existingDate;
  if (base < now) {
    base.setTime(now.getTime());
  }
  base.setDate(base.getDate() + days);
  return updateSavedCrmCustomer(customerId, { nextFollowUpAt: toLocalDateTimeValue(base) });
}

function toLocalDateTimeValue(date: Date) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60_000).toISOString().slice(0, 16);
}

export function completeScheduledCrmFollowUp(customerId: string) {
  const customer = getSavedCrmCustomer(customerId);
  if (!customer) return loadSavedCrmCustomers();
  addSavedCrmFollowUp(customerId, {
    channel: 'note',
    content: '已完成计划跟进，等待安排下一步。',
    contactedAt: new Date().toISOString(),
  });
  return updateSavedCrmCustomer(customerId, { nextFollowUpAt: '' });
}

export function generateLeadTaskExecutionPreview(task: SavedLeadTask): LeadTaskExecutionPreview {
  const country = task.input.country || 'Australia';
  const customerType = task.input.customerType || 'Kitchen Company';
  const product = task.input.product || 'custom cabinets';
  const keywordCount = task.output.keywords.length;
  const targetCount = Math.max(1, task.input.quantity);
  const discoveredCount = Math.max(6, Math.round(targetCount * 0.62));
  const filteredCount = Math.max(2, Math.round(discoveredCount * 0.28));
  const candidateCount = Math.max(4, discoveredCount - filteredCount);

  const steps: LeadTaskExecutionStep[] = [
    {
      id: 'keywords',
      title: '生成搜索关键词',
      status: 'completed',
      detail: `已生成 ${keywordCount} 组关键词，覆盖官网、LinkedIn、Importer、Builder 和 Contact 页面。`,
    },
    {
      id: 'search',
      title: '搜索官网与公开页面',
      status: task.status === 'draft' || task.status === 'pending' ? 'running' : 'completed',
      detail: `模拟搜索 ${country} 市场，发现 ${discoveredCount} 条公开结果。`,
    },
    {
      id: 'parse',
      title: '解析 Contact / About 页面',
      status: task.status === 'completed' ? 'completed' : 'running',
      detail: '提取公开邮箱、电话、WhatsApp、LinkedIn 和公司介绍线索。',
    },
    {
      id: 'verify',
      title: '真实性评分与风险过滤',
      status: task.status === 'completed' ? 'completed' : 'pending',
      detail: `过滤 ${filteredCount} 条目录页、招聘页、社媒噪音或信息缺失结果。`,
    },
    {
      id: 'deposit',
      title: '沉淀候选客户',
      status: task.status === 'completed' ? 'completed' : 'pending',
      detail: `预计沉淀 ${candidateCount} 个 A/B/C 级候选客户，等待加入客户池。`,
    },
  ];

  const logs: LeadTaskRunLog[] = [
    { time: '00:00', level: 'info', message: `任务启动：${task.title}` },
    { time: '00:03', level: 'success', message: `关键词生成完成：${keywordCount} 组搜索指令。` },
    { time: '00:07', level: 'info', message: `开始搜索 ${country} 市场公开页面。` },
    { time: '00:13', level: 'success', message: `发现 ${discoveredCount} 条公开结果，准备解析官网页面。` },
    { time: '00:18', level: 'warning', message: `过滤 ${filteredCount} 条低质量结果：目录页、招聘页或无联系方式页面。` },
    { time: '00:24', level: 'success', message: `生成 ${candidateCount} 个候选客户预览。` },
  ];

  const productLabel = product.split(/[、,，\s]+/).filter(Boolean)[0] ?? 'Custom';
  const candidates: LeadTaskCandidate[] = [
    {
      id: `${task.id}-candidate-1`,
      company: `${country} Premier Kitchens`,
      website: 'https://example-kitchens.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Sydney' : 'Los Angeles',
      customerType: 'Kitchen Company',
      contactStatus: '官网邮箱 + LinkedIn 已发现',
      score: 88,
      priority: 'A',
      recommendation: '优先开发，适合发送首次英文开发信。',
    },
    {
      id: `${task.id}-candidate-2`,
      company: `${productLabel} Design Studio`,
      website: 'https://example-design-studio.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Melbourne' : 'New York',
      customerType: 'Designer',
      contactStatus: '官网表单 + 电话已发现',
      score: 81,
      priority: 'A',
      recommendation: '先通过官网表单核验联系人，再进入 CRM。',
    },
    {
      id: `${task.id}-candidate-3`,
      company: `${country} Builder Supply Group`,
      website: 'https://example-builder-supply.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Brisbane' : 'Seattle',
      customerType: customerType.includes('Builder') ? 'Builder' : 'Importer',
      contactStatus: 'LinkedIn 公司页已发现，邮箱待补全',
      score: 73,
      priority: 'B',
      recommendation: '先搜索采购或项目负责人，再发送 LinkedIn 开场白。',
    },
    {
      id: `${task.id}-candidate-4`,
      company: `${country} Home Joinery Imports`,
      website: 'https://example-joinery-imports.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Perth' : 'Chicago',
      customerType: 'Importer',
      contactStatus: '电话已发现，WhatsApp 待核验',
      score: 66,
      priority: 'C',
      recommendation: '联系方式不完整，先核验官网电话和 WhatsApp 再开发。',
    },
  ];

  return { steps, logs, candidates };
}
