export interface ContactEvidence {
  value: string;
  sourceUrl: string;
  confidence: number;
}

export interface LeadContactDetails {
  emails: ContactEvidence[];
  phones: ContactEvidence[];
  whatsapp: ContactEvidence[];
  linkedin: ContactEvidence[];
}

export interface LeadWebsiteEnrichment {
  email?: string;
  phone?: string;
  whatsapp?: string;
  linkedin?: string;
  contactSources: Partial<Record<'email' | 'phone' | 'whatsapp' | 'linkedin', string>>;
  contactConfidence: number;
  status: 'complete' | 'partial' | 'not_found' | 'failed';
  warnings: string[];
  pagesVisited: number;
}

interface EnrichmentOptions {
  fetcher?: typeof fetch;
  timeoutMs?: number;
  maxPages?: number;
}

const PLACEHOLDER_EMAILS = /^(example|test|sample|yourname|name)@|@(example|test)\.(com|org|net)$/i;

function decodeHtml(value: string) {
  return value
    .replace(/&amp;/gi, '&')
    .replace(/&#64;|&commat;/gi, '@')
    .replace(/&#43;|&plus;/gi, '+')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'");
}

function uniqueEvidence(items: ContactEvidence[]) {
  const seen = new Set<string>();
  return items.filter((item) => {
    const key = item.value.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function normalizePhone(value: string) {
  const decoded = decodeURIComponent(value).trim().replace(/^tel:/i, '');
  const hasPlus = decoded.startsWith('+');
  const digits = decoded.replace(/\D/g, '');
  if (digits.length < 8 || digits.length > 15) return '';
  return `${hasPlus ? '+' : ''}${digits}`;
}

function normalizeWhatsapp(value: string) {
  const decoded = decodeURIComponent(value);
  const match = decoded.match(/(?:wa\.me\/|phone=)(\+?\d{8,15})/i);
  if (!match) return '';
  const digits = match[1].replace(/\D/g, '');
  return digits ? `+${digits}` : '';
}

function pushEvidence(
  list: ContactEvidence[],
  value: string,
  sourceUrl: string,
  confidence: number
) {
  if (value) list.push({ value, sourceUrl, confidence });
}

export function extractPublicContacts(html: string, sourceUrl: string): LeadContactDetails {
  const decoded = decodeHtml(html);
  const details: LeadContactDetails = { emails: [], phones: [], whatsapp: [], linkedin: [] };

  for (const match of decoded.matchAll(/mailto:([^"'?&\s>]+)/gi)) {
    const email = decodeURIComponent(match[1]).trim().toLowerCase();
    if (!PLACEHOLDER_EMAILS.test(email) && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      pushEvidence(details.emails, email, sourceUrl, 95);
    }
  }
  for (const match of decoded.matchAll(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi)) {
    const email = match[0].toLowerCase();
    if (!PLACEHOLDER_EMAILS.test(email)) pushEvidence(details.emails, email, sourceUrl, 82);
  }
  for (const match of decoded.matchAll(/tel:([^"'>]+)/gi)) {
    pushEvidence(details.phones, normalizePhone(match[1]), sourceUrl, 92);
  }
  for (const match of decoded.matchAll(/https?:\/\/(?:api\.)?whatsapp\.com\/[^"'\s<]+|https?:\/\/wa\.me\/[^"'\s<]+/gi)) {
    pushEvidence(details.whatsapp, normalizeWhatsapp(match[0]), sourceUrl, 96);
  }
  for (const match of decoded.matchAll(/https?:\/\/(?:www\.)?linkedin\.com\/company\/[^"'\s<?#]+\/?/gi)) {
    pushEvidence(details.linkedin, match[0], sourceUrl, 94);
  }

  return {
    emails: uniqueEvidence(details.emails),
    phones: uniqueEvidence(details.phones),
    whatsapp: uniqueEvidence(details.whatsapp),
    linkedin: uniqueEvidence(details.linkedin),
  };
}

function mergeContacts(target: LeadContactDetails, incoming: LeadContactDetails) {
  target.emails = uniqueEvidence([...target.emails, ...incoming.emails]);
  target.phones = uniqueEvidence([...target.phones, ...incoming.phones]);
  target.whatsapp = uniqueEvidence([...target.whatsapp, ...incoming.whatsapp]);
  target.linkedin = uniqueEvidence([...target.linkedin, ...incoming.linkedin]);
}

function contactLinks(html: string, pageUrl: string, origin: string) {
  const links: string[] = [];
  for (const match of decodeHtml(html).matchAll(/href=["']([^"'#]+)["']/gi)) {
    try {
      const url = new URL(match[1], pageUrl);
      if (url.origin !== origin) continue;
      if (!/(contact|about|team|showroom|location)/i.test(`${url.pathname} ${match[0]}`)) continue;
      links.push(url.href);
    } catch {
      // Ignore malformed links found in third-party HTML.
    }
  }
  return [...new Set(links)];
}

async function fetchHtml(url: string, fetcher: typeof fetch, timeoutMs: number) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetcher(url, {
      signal: controller.signal,
      headers: { 'user-agent': 'SkillHuoke/0.42 public-contact-enrichment' },
    });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const contentType = response.headers.get('content-type') || '';
    if (contentType && !contentType.includes('text/html')) throw new Error('页面不是 HTML');
    return await response.text();
  } finally {
    clearTimeout(timer);
  }
}

export async function enrichLeadWebsite(
  website: string,
  options: EnrichmentOptions = {}
): Promise<LeadWebsiteEnrichment> {
  const fetcher = options.fetcher || fetch;
  const timeoutMs = Math.max(options.timeoutMs || 5000, 100);
  const maxPages = Math.min(Math.max(options.maxPages || 3, 1), 3);
  const root = new URL(website);
  const queue = [new URL('/', root).href];
  const visited = new Set<string>();
  const warnings: string[] = [];
  const contacts: LeadContactDetails = { emails: [], phones: [], whatsapp: [], linkedin: [] };

  while (queue.length && visited.size < maxPages) {
    const url = queue.shift()!;
    if (visited.has(url)) continue;
    visited.add(url);
    try {
      const html = await fetchHtml(url, fetcher, timeoutMs);
      mergeContacts(contacts, extractPublicContacts(html, url));
      for (const link of contactLinks(html, url, root.origin)) {
        if (!visited.has(link) && !queue.includes(link)) queue.push(link);
      }
    } catch (error) {
      warnings.push(`${url}: ${error instanceof Error ? error.message : '访问失败'}`);
    }
  }

  const email = contacts.emails[0];
  const phone = contacts.phones[0];
  const whatsapp = contacts.whatsapp[0];
  const linkedin = contacts.linkedin[0];
  const foundCount = [email, phone, whatsapp, linkedin].filter(Boolean).length;
  const confidenceValues = [email, phone, whatsapp, linkedin]
    .filter((item): item is ContactEvidence => Boolean(item))
    .map((item) => item.confidence);
  const contactConfidence = confidenceValues.length
    ? Math.round(confidenceValues.reduce((sum, value) => sum + value, 0) / confidenceValues.length)
    : 0;
  const status: LeadWebsiteEnrichment['status'] =
    foundCount >= 3 && !warnings.length
      ? 'complete'
      : foundCount > 0
        ? 'partial'
        : warnings.length === visited.size
          ? 'failed'
          : 'not_found';

  return {
    email: email?.value,
    phone: phone?.value,
    whatsapp: whatsapp?.value,
    linkedin: linkedin?.value,
    contactSources: {
      email: email?.sourceUrl,
      phone: phone?.sourceUrl,
      whatsapp: whatsapp?.sourceUrl,
      linkedin: linkedin?.sourceUrl,
    },
    contactConfidence,
    status,
    warnings,
    pagesVisited: visited.size,
  };
}
