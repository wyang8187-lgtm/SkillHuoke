import { NextResponse } from 'next/server';
import { buildFullEnvTemplate, buildIntegrationStatuses, summarizeProxyConfig } from '@/lib/integration-diagnostics';

export async function GET() {
  return NextResponse.json({
    services: buildIntegrationStatuses(),
    proxy: summarizeProxyConfig(),
    envTemplate: buildFullEnvTemplate(),
    envFile: '.env',
    message: '接口状态只读取服务器环境变量，完整密钥不会返回前端。',
  });
}
