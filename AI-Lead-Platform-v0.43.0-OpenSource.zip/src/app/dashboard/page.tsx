'use client';

import React, { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FunnelChart, GrowthTrendChart } from '@/components/charts';
import { ApiKeyQuickEntry } from '@/components/integrations/api-key-quick-entry';
import {
  Activity,
  ArrowRight,
  Briefcase,
  CheckCircle,
  Clock,
  FileText,
  Loader2,
  Percent,
  Sparkles,
  Star,
  Target,
  TrendingDown,
  TrendingUp,
  UserPlus,
  Users,
} from 'lucide-react';
import { getApiStatusLabel, getQuotaPercent, getWorkspaceModeLabel, type WorkspaceInfo } from '@/lib/workspace';

interface GrowthData {
  date: string;
  customers: number;
  leads: number;
}

interface FunnelData {
  stage: string;
  count: number;
  rate: number;
  fill: string;
}

interface RecommendedFollowUp {
  customerId: string;
  customerName: string;
  customerType: string;
  grade: string;
  status: string;
  score: number;
  reason: string;
  suggestedAction?: string;
}

interface DashboardStats {
  workspaceId?: string;
  workspace?: WorkspaceInfo;
  totalCustomers: number;
  totalLeads: number;
  totalOpportunities: number;
  totalTasks: number;
  monthNewCustomers: number;
  monthNewLeads: number;
  monthOpportunityAmount: number;
  conversionRate: number;
  lastMonthNewCustomers: number;
  lastMonthNewLeads: number;
  lastMonthOpportunityAmount: number;
  lastMonthConversionRate: number;
  growthTrendData?: GrowthData[];
  funnelData?: FunnelData[];
  recommendedFollowUps?: RecommendedFollowUp[];
}

interface Task {
  id: string;
  title: string;
  status: string;
  priority: '高' | '中' | '低' | string;
  due_time: string | null;
  customer_name?: string;
}

interface ActivityLog {
  id: string;
  type: 'customer' | 'opportunity' | 'follow_up' | 'task' | 'lead' | 'email' | 'ai';
  action: string;
  target: string;
  user: string;
  time: string;
  details?: string;
}

const demoTasks: Task[] = [
  {
    id: 'task-1',
    title: '核验 Sydney Custom Kitchens 官网邮箱和联系人',
    status: 'pending',
    priority: '高',
    due_time: new Date(Date.now() + 1000 * 60 * 45).toISOString(),
    customer_name: 'Sydney Custom Kitchens',
  },
  {
    id: 'task-2',
    title: '给 Melbourne Builder Group 发送首次开发信',
    status: 'pending',
    priority: '中',
    due_time: new Date(Date.now() + 1000 * 60 * 120).toISOString(),
    customer_name: 'Melbourne Builder Group',
  },
  {
    id: 'task-3',
    title: '补全 Brisbane Interior Studio 的 LinkedIn 联系人',
    status: 'pending',
    priority: '中',
    due_time: null,
    customer_name: 'Brisbane Interior Studio',
  },
];

const activityStyles: Record<ActivityLog['type'], { icon: React.ReactNode; bgColor: string; color: string }> = {
  customer: { icon: <Users className="h-4 w-4" />, bgColor: 'bg-blue-500/20', color: 'text-blue-500' },
  opportunity: { icon: <Briefcase className="h-4 w-4" />, bgColor: 'bg-purple-500/20', color: 'text-purple-500' },
  follow_up: { icon: <FileText className="h-4 w-4" />, bgColor: 'bg-green-500/20', color: 'text-green-500' },
  task: { icon: <CheckCircle className="h-4 w-4" />, bgColor: 'bg-orange-500/20', color: 'text-orange-500' },
  lead: { icon: <Target className="h-4 w-4" />, bgColor: 'bg-cyan-500/20', color: 'text-cyan-500' },
  email: { icon: <FileText className="h-4 w-4" />, bgColor: 'bg-pink-500/20', color: 'text-pink-500' },
  ai: { icon: <Activity className="h-4 w-4" />, bgColor: 'bg-amber-500/20', color: 'text-amber-500' },
};

function calcChange(current: number, last: number) {
  if (last === 0) return { percent: current > 0 ? 100 : 0, isUp: current >= 0 };
  const diff = current - last;
  return { percent: Math.round((diff / last) * 100), isUp: diff >= 0 };
}

function formatAmount(amount: number) {
  if (amount >= 10000) return `${(amount / 10000).toFixed(1)}万`;
  return `${amount}万`;
}

function formatTime(timeStr: string) {
  const diff = Math.floor((Date.now() - new Date(timeStr).getTime()) / 1000);
  if (diff < 60) return '刚刚';
  if (diff < 3600) return `${Math.floor(diff / 60)}分钟前`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}小时前`;
  return `${Math.floor(diff / 86400)}天前`;
}

function generateActivities(): ActivityLog[] {
  const now = Date.now();
  return [
    {
      id: 'act-1',
      type: 'ai',
      action: 'AI自动获客发现新线索',
      target: '澳洲厨房公司候选客户 12 个',
      user: '系统',
      time: new Date(now - 1000 * 60 * 8).toISOString(),
      details: '关键词：custom kitchen cabinet supplier Australia，已过滤目录页和低质量结果。',
    },
    {
      id: 'act-2',
      type: 'customer',
      action: '新增客户',
      target: 'Sydney Custom Kitchens',
      user: '演示管理员',
      time: new Date(now - 1000 * 60 * 18).toISOString(),
      details: '客户类型：Kitchen Company，真实性评分：92分，建议优先开发。',
    },
    {
      id: 'act-3',
      type: 'follow_up',
      action: '生成跟进建议',
      target: 'Melbourne Builder Group',
      user: 'AI助手',
      time: new Date(now - 1000 * 60 * 36).toISOString(),
      details: '建议先通过官网表单确认采购负责人，再发送橱柜和木门项目合作邮件。',
    },
    {
      id: 'act-4',
      type: 'email',
      action: '生成英文开发信',
      target: '全屋定制出口合作模板',
      user: 'AI助手',
      time: new Date(now - 1000 * 60 * 75).toISOString(),
      details: '模板用途：首次开发，客户类型：Builder / Designer / Importer。',
    },
    {
      id: 'act-5',
      type: 'task',
      action: '创建核验任务',
      target: '补全 3 个客户的 LinkedIn 联系人',
      user: '演示管理员',
      time: new Date(now - 1000 * 60 * 120).toISOString(),
    },
  ];
}

function MetricCard({
  title,
  value,
  change,
  icon,
  tone,
}: {
  title: string;
  value: string | number;
  change: { percent: number; isUp: boolean };
  icon: React.ReactNode;
  tone: string;
}) {
  return (
    <Card className="bg-card border-border hover:shadow-lg transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-muted-foreground mb-1">{title}</p>
            <p className="text-3xl font-bold text-foreground">{value}</p>
            <div className="flex items-center gap-1 mt-2">
              {change.isUp ? <TrendingUp className="h-4 w-4 text-green-500" /> : <TrendingDown className="h-4 w-4 text-red-500" />}
              <span className={`text-sm ${change.isUp ? 'text-green-500' : 'text-red-500'}`}>
                {change.percent > 0 ? '+' : ''}{change.percent}% 环比
              </span>
            </div>
          </div>
          <div className={`h-12 w-12 rounded-full ${tone} flex items-center justify-center`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setLoading(true);
    try {
      const session = localStorage.getItem('supabase_session') || 'demo-session';
      const statsRes = await fetch('/api/dashboard/stats', {
        headers: { 'x-session': session },
      });

      if (statsRes.ok) {
        setStats(await statsRes.json());
      }

      const tasksRes = await fetch('/api/tasks?status=pending&pageSize=5', {
        headers: { 'x-session': session },
      });

      if (tasksRes.ok) {
        const tasksData = await tasksRes.json();
        setTasks(tasksData.tasks?.length ? tasksData.tasks : demoTasks);
      } else {
        setTasks(demoTasks);
      }

      setActivities(generateActivities());
    } catch (error) {
      console.error('加载仪表盘数据失败:', error);
      setTasks(demoTasks);
      setActivities(generateActivities());
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <MainLayout title="仪表盘">
        <div className="flex items-center justify-center h-[420px]">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </MainLayout>
    );
  }

  const customerChange = calcChange(stats?.monthNewCustomers || 0, stats?.lastMonthNewCustomers || 0);
  const leadChange = calcChange(stats?.monthNewLeads || 0, stats?.lastMonthNewLeads || 0);
  const amountChange = calcChange(stats?.monthOpportunityAmount || 0, stats?.lastMonthOpportunityAmount || 0);
  const rateChange = calcChange(stats?.conversionRate || 0, stats?.lastMonthConversionRate || 0);

  return (
    <MainLayout title="仪表盘">
      <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-3 py-1 text-sm text-primary mb-3">
            <Sparkles className="h-4 w-4" />
            V0.12 SaaS 底座版
          </div>
          <h1 className="text-2xl font-semibold text-foreground">外贸 AI 获客工作台</h1>
          <p className="text-sm text-muted-foreground mt-1">
            从搜索、核验、评分到开发信和 CRM 跟进，把客户开发流程集中到一个页面里。
          </p>
        </div>
        <Button className="gap-2">
          开始新的获客任务
          <ArrowRight className="h-4 w-4" />
        </Button>
      </div>

      <div className="mb-6">
        <ApiKeyQuickEntry />
      </div>

      {stats?.workspace && (
        <Card className="mb-6 border-blue-500/20 bg-gradient-to-r from-blue-500/10 via-card to-amber-500/10">
          <CardContent className="p-5">
            <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1.2fr_1fr_1fr_1fr]">
              <div>
                <div className="text-xs text-muted-foreground mb-1">当前工作空间</div>
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="text-lg font-semibold text-foreground">{stats.workspace.name}</h2>
                  <Badge className="bg-amber-500/20 text-amber-500">
                    {getWorkspaceModeLabel(stats.workspace.mode)}
                  </Badge>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{stats.workspace.dataScope}</p>
              </div>

              <div className="rounded-lg border border-border bg-background/40 p-3">
                <div className="text-xs text-muted-foreground">当前套餐</div>
                <div className="mt-1 text-base font-semibold text-foreground">{stats.workspace.plan}</div>
                <div className="mt-1 text-xs text-muted-foreground">{stats.workspace.ownerRole}</div>
              </div>

              <div className="rounded-lg border border-border bg-background/40 p-3">
                <div className="text-xs text-muted-foreground">本月搜索额度</div>
                <div className="mt-1 text-base font-semibold text-foreground">
                  {stats.workspace.quota.searchesUsed}/{stats.workspace.quota.searchesLimit}
                </div>
                <div className="mt-2 h-2 rounded-full bg-muted overflow-hidden">
                  <div
                    className="h-full rounded-full bg-blue-500"
                    style={{ width: `${getQuotaPercent(stats.workspace.quota.searchesUsed, stats.workspace.quota.searchesLimit)}%` }}
                  />
                </div>
              </div>

              <div className="rounded-lg border border-border bg-background/40 p-3">
                <div className="text-xs text-muted-foreground">API 与数据隔离</div>
                <div className="mt-1 text-sm text-foreground">OpenAI：{getApiStatusLabel(stats.workspace.apiStatus.openai)}</div>
                <div className="text-sm text-foreground">搜索源：{getApiStatusLabel(stats.workspace.apiStatus.leadSearch)}</div>
                <div className="mt-1 text-xs text-muted-foreground">{stats.workspace.isolationStatus}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <MetricCard
          title="本月新增客户"
          value={stats?.monthNewCustomers || 0}
          change={customerChange}
          tone="bg-primary/20"
          icon={<UserPlus className="h-6 w-6 text-primary" />}
        />
        <MetricCard
          title="本月新增线索"
          value={stats?.monthNewLeads || 0}
          change={leadChange}
          tone="bg-cyan-500/20"
          icon={<Target className="h-6 w-6 text-cyan-500" />}
        />
        <MetricCard
          title="商机预计金额"
          value={`¥${formatAmount(stats?.monthOpportunityAmount || 0)}`}
          change={amountChange}
          tone="bg-purple-500/20"
          icon={<Briefcase className="h-6 w-6 text-purple-500" />}
        />
        <MetricCard
          title="线索转化率"
          value={`${stats?.conversionRate || 0}%`}
          change={rateChange}
          tone="bg-green-500/20"
          icon={<Percent className="h-6 w-6 text-green-500" />}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-foreground flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              客户增长趋势
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stats?.growthTrendData?.length ? (
              <GrowthTrendChart data={stats.growthTrendData} />
            ) : (
              <div className="h-[220px] flex items-center justify-center text-muted-foreground">暂无增长数据</div>
            )}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-foreground flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-purple-500" />
              商机转化漏斗
            </CardTitle>
          </CardHeader>
          <CardContent>
            {stats?.funnelData?.length ? (
              <FunnelChart data={stats.funnelData} />
            ) : (
              <div className="h-[220px] flex items-center justify-center text-muted-foreground">暂无漏斗数据</div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-foreground flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-orange-500" />
                今日待办任务
              </CardTitle>
              <Badge variant="secondary" className="bg-orange-500/20 text-orange-500">
                {tasks.length} 项待处理
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {tasks.map((task) => (
                <div key={task.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-2 h-2 rounded-full shrink-0 ${
                        task.priority === '高' ? 'bg-red-500' : task.priority === '中' ? 'bg-orange-500' : 'bg-green-500'
                      }`}
                    />
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">{task.title}</p>
                      {task.customer_name && (
                        <p className="text-xs text-muted-foreground truncate">关联客户：{task.customer_name}</p>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {task.due_time && (
                      <span className="text-xs text-muted-foreground">
                        <Clock className="h-3 w-3 inline mr-1" />
                        {new Date(task.due_time).toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    )}
                    <Button variant="ghost" size="sm" className="h-8 px-2">
                      <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-foreground flex items-center gap-2">
                <Star className="h-5 w-5 text-amber-500" />
                今日推荐跟进
              </CardTitle>
              <Badge variant="secondary" className="bg-amber-500/20 text-amber-500">
                AI 推荐
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {(stats?.recommendedFollowUps || []).map((rec) => (
                <div key={rec.customerId} className="p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors">
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div>
                      <p className="text-sm font-semibold text-foreground">{rec.customerName}</p>
                      <p className="text-xs text-muted-foreground">{rec.customerType} · {rec.status}</p>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <Badge className="bg-primary/20 text-primary">{rec.grade}类</Badge>
                      <span className="text-sm font-semibold text-foreground">{rec.score}分</span>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{rec.reason}</p>
                  {rec.suggestedAction && (
                    <p className="text-xs text-primary mt-2">建议动作：{rec.suggestedAction}</p>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-card border-border">
        <CardHeader className="pb-2">
          <CardTitle className="text-foreground flex items-center gap-2">
            <Activity className="h-5 w-5 text-primary" />
            最近获客动态
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {activities.map((activity) => {
              const style = activityStyles[activity.type];
              return (
                <div key={activity.id} className="flex items-start gap-3">
                  <div className={`w-9 h-9 rounded-full ${style.bgColor} ${style.color} flex items-center justify-center shrink-0`}>
                    {style.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4">
                      <div>
                        <p className="text-sm font-medium text-foreground">{activity.action}</p>
                        <p className="text-sm text-muted-foreground">{activity.target}</p>
                      </div>
                      <span className="text-xs text-muted-foreground shrink-0">{formatTime(activity.time)}</span>
                    </div>
                    {activity.details && <p className="text-xs text-muted-foreground mt-1">{activity.details}</p>}
                    <p className="text-xs text-muted-foreground mt-1">操作人：{activity.user}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </MainLayout>
  );
}
