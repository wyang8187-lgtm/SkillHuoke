'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  buildLeadTaskRunSnapshot,
  downloadLeadTaskText,
  findSavedLeadTask,
  loadSavedLeadTasks,
  mapSearchCandidatesToTaskCandidates,
  seedCandidateLeadsFromTask,
  updateSavedLeadTaskRunSnapshot,
  updateSavedLeadTaskStatus,
  type LeadTaskCandidate,
  type SavedLeadTask,
} from '@/lib/lead-wizard';
import type { LeadSearchResult } from '@/lib/integrations/lead-search-provider';
import {
  AlertTriangle,
  ArrowLeft,
  Database,
  Download,
  ExternalLink,
  Loader2,
  Search,
  Settings,
} from 'lucide-react';

const providerName: Record<string, string> = {
  serpapi: 'SerpAPI',
  bing: 'Bing',
  google: 'Google',
  mock: '演示数据',
  auto: '自动选择',
};

function contactText(value?: string) {
  return value || '未找到';
}

export default function LeadTaskRunnerPage() {
  const params = useParams<{ id: string }>();
  const [task, setTask] = useState<SavedLeadTask | null>(null);
  const [searchResult, setSearchResult] = useState<LeadSearchResult | null>(null);
  const [candidates, setCandidates] = useState<LeadTaskCandidate[]>([]);
  const [searching, setSearching] = useState(false);
  const [message, setMessage] = useState('');
  const [recentTasks, setRecentTasks] = useState<SavedLeadTask[]>([]);

  useEffect(() => {
    setTask(findSavedLeadTask(params.id));
    setRecentTasks(loadSavedLeadTasks());
  }, [params.id]);

  const saveSnapshot = (nextTask: SavedLeadTask, result: LeadSearchResult) => {
    const runSnapshot = buildLeadTaskRunSnapshot(result);
    const updated = updateSavedLeadTaskRunSnapshot(nextTask.id, runSnapshot);
    setTask(updated.find((item) => item.id === nextTask.id) ?? nextTask);
  };

  const runRealSearch = async () => {
    if (!task) return;
    setSearching(true);
    setMessage('');
    setSearchResult(null);
    setCandidates([]);

    const runningSnapshot = {
      status: 'running' as const,
      targetCount: task.input.quantity,
      foundCount: 0,
      enrichedCount: 0,
      progressPercent: 0,
      currentStep: '正在调用真实搜索源',
      successAttempts: 0,
      failedAttempts: 0,
      emptyAttempts: 0,
      providerDiagnostics: [],
      lastRunAt: new Date().toLocaleString('zh-CN', { hour12: false }),
    };
    updateSavedLeadTaskStatus(task.id, 'running');
    updateSavedLeadTaskRunSnapshot(task.id, runningSnapshot);
    setTask({ ...task, status: 'running', runSnapshot: runningSnapshot });
    setRecentTasks(loadSavedLeadTasks());

    try {
      const response = await fetch('/api/integrations/lead-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          product: task.input.product,
          country: task.input.country,
          customerType: task.input.customerType,
          quantity: task.input.quantity,
          provider: 'auto',
        }),
      });
      const payload = await response.json();
      if (!response.ok || !payload.success) {
        throw new Error(payload.error || '真实搜索运行失败。');
      }

      const result = payload.data as LeadSearchResult;
      const mapped = mapSearchCandidatesToTaskCandidates(task.id, result.candidates);
      setSearchResult(result);
      setCandidates(mapped);
      saveSnapshot(task, result);

      if (mapped.length > 0) {
        updateSavedLeadTaskStatus(task.id, 'completed');
      }
      setRecentTasks(loadSavedLeadTasks());
    } catch (error) {
      const reason = error instanceof Error ? error.message : '真实搜索运行失败。';
      const failedSnapshot = {
        status: 'failed' as const,
        targetCount: task.input.quantity,
        foundCount: 0,
        enrichedCount: 0,
        progressPercent: 0,
        currentStep: '搜索请求失败',
        successAttempts: 0,
        failedAttempts: 1,
        emptyAttempts: 0,
        providerDiagnostics: [],
        lastRunAt: new Date().toLocaleString('zh-CN', { hour12: false }),
        lastError: reason,
      };
      const updated = updateSavedLeadTaskRunSnapshot(task.id, failedSnapshot);
      setTask(updated.find((item) => item.id === task.id) ?? task);
      setRecentTasks(loadSavedLeadTasks());
      setMessage(reason);
    } finally {
      setSearching(false);
    }
  };

  const addCandidates = (items: LeadTaskCandidate[]) => {
    if (!task || !items.length) return;
    seedCandidateLeadsFromTask(task, items);
    setMessage(`已将 ${items.length} 个客户加入候选池。`);
  };

  if (!task) {
    return (
      <MainLayout title="获客执行台">
        <div className="border border-dashed border-[#2d3548] bg-[#121823] p-8 text-center">
          <p className="text-[#cbd5e1]">没有找到这条本地任务。</p>
          <Button asChild className="mt-4 bg-blue-600 text-white hover:bg-blue-500">
            <Link href="/lead-tasks">返回任务记录</Link>
          </Button>
        </div>
      </MainLayout>
    );
  }

  const foundCount =
    searchResult?.batchSummary?.returnedCount ?? task.runSnapshot?.foundCount ?? 0;
  const enrichedCount =
    searchResult?.batchSummary?.enrichedCount ?? task.runSnapshot?.enrichedCount ?? 0;
  const diagnostics = searchResult?.providerDiagnostics || task.runSnapshot?.providerDiagnostics || [];
  const failureText =
    message ||
    diagnostics
      .filter((item) => item.reason)
      .map((item) => `${providerName[item.provider]}：${item.reason}`)
      .join('；');

  return (
    <MainLayout title="获客执行台">
      <div className="space-y-4">
        <section className="border border-[#2d3548] bg-[#121823] p-4">
          <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.43.0</Badge>
                <Badge className="border-slate-500/25 bg-slate-500/15 text-slate-300">
                  目标 {task.input.quantity} 个
                </Badge>
              </div>
              <h2 className="mt-2 truncate text-lg font-semibold text-[#f8fafc]">{task.title}</h2>
              <p className="mt-1 text-sm text-[#94a3b8]">
                {task.input.product} · {task.input.country} · {task.input.customerType}
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                <Link href="/lead-tasks"><ArrowLeft className="mr-2 h-4 w-4" />返回</Link>
              </Button>
              <Button onClick={runRealSearch} disabled={searching} className="bg-blue-600 text-white hover:bg-blue-500">
                {searching ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                {searching ? '正在搜索' : '运行真实搜索'}
              </Button>
              <Button
                variant="outline"
                disabled={!candidates.length}
                onClick={() => addCandidates(candidates)}
                className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]"
              >
                <Database className="mr-2 h-4 w-4" />全部加入候选池
              </Button>
              <Button
                variant="outline"
                onClick={() => downloadLeadTaskText(task)}
                className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]"
              >
                <Download className="mr-2 h-4 w-4" />导出
              </Button>
            </div>
          </div>

          <div className="mt-4 grid gap-3 border-t border-[#2d3548] pt-4 sm:grid-cols-4">
            <div><p className="text-xs text-[#64748b]">目标</p><p className="mt-1 font-semibold text-[#f8fafc]">{task.input.quantity}</p></div>
            <div><p className="text-xs text-[#64748b]">已找到</p><p className="mt-1 font-semibold text-[#f8fafc]">{foundCount}</p></div>
            <div><p className="text-xs text-[#64748b]">官网补全</p><p className="mt-1 font-semibold text-[#f8fafc]">{enrichedCount}</p></div>
            <div><p className="text-xs text-[#64748b]">进度</p><p className="mt-1 font-semibold text-[#f8fafc]">{task.runSnapshot?.progressPercent || 0}%</p></div>
          </div>
        </section>

        {failureText ? (
          <section className="flex flex-col gap-3 border border-red-500/25 bg-red-500/10 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex gap-3">
              <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-300" />
              <div>
                <p className="font-medium text-red-200">搜索失败原因</p>
                <p className="mt-1 text-sm leading-6 text-red-100">{failureText}</p>
              </div>
            </div>
            <Button asChild variant="outline" className="border-red-500/25 bg-transparent text-red-100 hover:bg-red-500/10">
              <Link href="/settings/api-keys"><Settings className="mr-2 h-4 w-4" />前往 API 设置</Link>
            </Button>
          </section>
        ) : null}

        {diagnostics.length ? (
          <section className="grid gap-2 md:grid-cols-3">
            {diagnostics.map((item) => (
              <div key={item.provider} className="border border-[#2d3548] bg-[#121823] p-3">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-medium text-[#f8fafc]">{providerName[item.provider]}</p>
                  <Badge className={item.status === 'failed' ? 'bg-red-500/15 text-red-300' : 'bg-emerald-500/15 text-emerald-300'}>
                    {item.status === 'failed' ? '失败' : item.status === 'success' ? '正常' : '部分完成'}
                  </Badge>
                </div>
                <p className="mt-2 text-xs text-[#94a3b8]">
                  成功 {item.successAttempts} · 失败 {item.failedAttempts} · 可用结果 {item.usableCount}
                </p>
                {item.suggestion ? <p className="mt-2 text-xs leading-5 text-[#cbd5e1]">{item.suggestion}</p> : null}
              </div>
            ))}
          </section>
        ) : null}

        <section className="overflow-hidden border border-[#2d3548] bg-[#121823]">
          <div className="flex flex-col gap-3 border-b border-[#2d3548] p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="font-semibold text-[#f8fafc]">客户搜索结果</h3>
              <p className="mt-1 text-sm text-[#94a3b8]">搜索到的客户会直接显示在这里。</p>
            </div>
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{candidates.length} 个客户</Badge>
          </div>

          {candidates.length ? (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[1180px] text-left text-sm">
                <thead className="bg-[#0f1419] text-xs text-[#94a3b8]">
                  <tr>
                    {['公司名称', '国家/类型', '邮箱', '电话', 'WhatsApp', 'LinkedIn', '评分', '公开来源', '操作'].map((label) => (
                      <th key={label} className="px-4 py-3 font-medium">{label}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#2d3548]">
                  {candidates.map((candidate) => (
                    <tr key={candidate.id} className="text-[#cbd5e1] hover:bg-[#171d29]">
                      <td className="px-4 py-3">
                        <p className="font-medium text-[#f8fafc]">{candidate.company}</p>
                        <a href={candidate.website} target="_blank" rel="noreferrer" className="mt-1 block max-w-56 truncate text-xs text-blue-300">
                          {candidate.website}
                        </a>
                      </td>
                      <td className="px-4 py-3"><p>{candidate.country}</p><p className="mt-1 text-xs text-[#94a3b8]">{candidate.customerType}</p></td>
                      <td className="max-w-52 break-all px-4 py-3">{contactText(candidate.email)}</td>
                      <td className="px-4 py-3">{contactText(candidate.phone)}</td>
                      <td className="px-4 py-3">{contactText(candidate.whatsapp)}</td>
                      <td className="px-4 py-3">
                        {candidate.linkedin ? <a href={candidate.linkedin} target="_blank" rel="noreferrer" className="text-blue-300">打开 LinkedIn</a> : '未找到'}
                      </td>
                      <td className="px-4 py-3"><Badge className="bg-emerald-500/15 text-emerald-300">{candidate.priority} · {candidate.score}</Badge></td>
                      <td className="px-4 py-3">
                        {candidate.contactSource ? <a href={candidate.contactSource} target="_blank" rel="noreferrer" className="inline-flex items-center text-blue-300">查看来源<ExternalLink className="ml-1 h-3 w-3" /></a> : '无'}
                      </td>
                      <td className="px-4 py-3">
                        <Button size="sm" variant="outline" onClick={() => addCandidates([candidate])} className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                          加入候选池
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="p-10 text-center">
              <Search className="mx-auto h-9 w-9 text-[#64748b]" />
              <p className="mt-3 font-medium text-[#f8fafc]">暂无客户结果</p>
              <p className="mt-1 text-sm text-[#94a3b8]">点击“运行真实搜索”，结果会直接出现在本页。</p>
            </div>
          )}
        </section>

        <section className="border border-[#2d3548] bg-[#121823]">
          <div className="flex items-center justify-between gap-3 border-b border-[#2d3548] p-4">
            <div>
              <h3 className="font-semibold text-[#f8fafc]">任务列表</h3>
              <p className="mt-1 text-sm text-[#94a3b8]">直接切换其他任务，不需要返回上一页。</p>
            </div>
            <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
              <Link href="/lead-wizard">新建任务</Link>
            </Button>
          </div>
          <div className="divide-y divide-[#2d3548]">
            {recentTasks.map((item) => {
              const snapshot = item.runSnapshot;
              return (
                <div key={item.id} className="flex flex-col gap-3 p-4 lg:flex-row lg:items-center lg:justify-between">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge className={item.id === task.id ? 'bg-blue-500/15 text-blue-300' : 'bg-slate-500/15 text-slate-300'}>
                        {item.id === task.id ? '当前任务' : snapshot?.status === 'failed' ? '执行失败' : snapshot?.status === 'partial' ? '部分完成' : snapshot?.status === 'completed' ? '已完成' : '等待执行'}
                      </Badge>
                      <span className="text-xs text-[#64748b]">{snapshot?.lastRunAt || item.createdAt}</span>
                    </div>
                    <p className="mt-2 truncate font-medium text-[#f8fafc]">{item.title}</p>
                    <p className="mt-1 text-sm text-[#94a3b8]">
                      进度 {snapshot?.foundCount || 0}/{snapshot?.targetCount || item.input.quantity} · 官网补全 {snapshot?.enrichedCount || 0} · {snapshot?.progressPercent || 0}%
                    </p>
                    {snapshot?.lastError ? <p className="mt-1 text-sm text-red-300">{snapshot.lastError}</p> : null}
                  </div>
                  <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                    <Link href={`/lead-tasks/${item.id}`}>{item.id === task.id ? '当前执行台' : '切换任务'}</Link>
                  </Button>
                </div>
              );
            })}
          </div>
        </section>
      </div>
    </MainLayout>
  );
}
