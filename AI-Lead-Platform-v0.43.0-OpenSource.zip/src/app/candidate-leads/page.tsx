'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  buildCandidateVerificationChecklist,
  candidateLeadStatusOptions,
  convertCandidateToCrmCustomer,
  deleteSavedCandidateLead,
  getCandidateLeadStatusMeta,
  getCandidateSourceMeta,
  loadSavedCandidateLeads,
  updateSavedCandidateLeadStatus,
  updateSavedCandidateLeadStatuses,
  type CandidateLeadStatus,
  type CandidateSourceType,
  type SavedCandidateLead,
} from '@/lib/lead-wizard';
import { ArrowRight, Building2, CheckCircle2, Filter, ListChecks, Search, Trash2, UsersRound } from 'lucide-react';

type PriorityFilter = 'all' | 'A' | 'B' | 'C';
type SourceFilter = 'all' | CandidateSourceType;

const sourceOptions: Array<{ value: SourceFilter; label: string }> = [
  { value: 'all', label: '全部来源' },
  { value: 'real_search', label: '真实搜索' },
  { value: 'mock', label: '演示降级' },
  { value: 'manual_import', label: '手动/导入' },
  { value: 'unknown', label: '未标记来源' },
];

export default function CandidateLeadsPage() {
  const [candidates, setCandidates] = useState<SavedCandidateLead[]>([]);
  const [priorityFilter, setPriorityFilter] = useState<PriorityFilter>('all');
  const [statusFilter, setStatusFilter] = useState<CandidateLeadStatus | 'all'>('all');
  const [sourceFilter, setSourceFilter] = useState<SourceFilter>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  useEffect(() => {
    setCandidates(loadSavedCandidateLeads());
  }, []);

  const filteredCandidates = useMemo(() => {
    return candidates.filter((candidate) => {
      const source = getCandidateSourceMeta(candidate);
      const matchesPriority = priorityFilter === 'all' || candidate.priority === priorityFilter;
      const matchesStatus = statusFilter === 'all' || candidate.status === statusFilter;
      const matchesSource = sourceFilter === 'all' || source.type === sourceFilter;
      return matchesPriority && matchesStatus && matchesSource;
    });
  }, [candidates, priorityFilter, statusFilter, sourceFilter]);

  const visibleIds = filteredCandidates.map((candidate) => candidate.id);
  const allVisibleSelected = visibleIds.length > 0 && visibleIds.every((id) => selectedIds.includes(id));

  const summary = useMemo(() => {
    return {
      total: candidates.length,
      a: candidates.filter((candidate) => candidate.priority === 'A').length,
      b: candidates.filter((candidate) => candidate.priority === 'B').length,
      c: candidates.filter((candidate) => candidate.priority === 'C').length,
      joined: candidates.filter((candidate) => candidate.status === 'joined').length,
      real: candidates.filter((candidate) => getCandidateSourceMeta(candidate).type === 'real_search').length,
    };
  }, [candidates]);

  const refreshCandidates = () => setCandidates(loadSavedCandidateLeads());

  const toggleSelected = (candidateId: string) => {
    setSelectedIds((current) =>
      current.includes(candidateId) ? current.filter((id) => id !== candidateId) : [...current, candidateId]
    );
  };

  const toggleAllVisible = () => {
    setSelectedIds((current) => {
      if (allVisibleSelected) return current.filter((id) => !visibleIds.includes(id));
      return Array.from(new Set([...current, ...visibleIds]));
    });
  };

  const handleStatusChange = (candidateId: string, status: CandidateLeadStatus) => {
    setCandidates(updateSavedCandidateLeadStatus(candidateId, status));
  };

  const handleBatchStatus = (status: CandidateLeadStatus) => {
    if (selectedIds.length === 0) return;
    setCandidates(updateSavedCandidateLeadStatuses(selectedIds, status));
  };

  const handleJoinCustomerPool = (candidateId: string) => {
    const candidate = candidates.find((item) => item.id === candidateId);
    if (candidate) convertCandidateToCrmCustomer(candidate);
    setCandidates(updateSavedCandidateLeadStatus(candidateId, 'joined'));
  };

  const handleBatchJoin = () => {
    selectedIds
      .map((id) => candidates.find((candidate) => candidate.id === id))
      .filter((candidate): candidate is SavedCandidateLead => Boolean(candidate))
      .forEach((candidate) => convertCandidateToCrmCustomer(candidate));
    setCandidates(updateSavedCandidateLeadStatuses(selectedIds, 'joined'));
  };

  const handleDelete = (candidateId: string) => {
    setCandidates(deleteSavedCandidateLead(candidateId));
    setSelectedIds((current) => current.filter((id) => id !== candidateId));
  };

  return (
    <MainLayout title="候选客户池">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.38.0</Badge>
            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">筛选工作台</Badge>
          </div>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">候选客户筛选与核验</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                这里用于处理真实搜索和任务沉淀出来的候选客户。你可以按等级、状态、来源筛选，批量标记核验状态，并把合适客户加入 CRM。
              </p>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
                <Link href="/lead-tasks">打开任务记录<ArrowRight className="ml-2 h-4 w-4" /></Link>
              </Button>
              <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                <Link href="/crm-customers">打开 CRM 客户池</Link>
              </Button>
            </div>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-6">
          {[
            { label: '全部候选', value: summary.total, tone: 'text-blue-300' },
            { label: '真实搜索', value: summary.real, tone: 'text-emerald-300' },
            { label: 'A 级', value: summary.a, tone: 'text-emerald-300' },
            { label: 'B 级', value: summary.b, tone: 'text-amber-300' },
            { label: 'C 级', value: summary.c, tone: 'text-slate-300' },
            { label: '已加入 CRM', value: summary.joined, tone: 'text-violet-300' },
          ].map((item) => (
            <Card key={item.label} className="border-[#2d3548] bg-[#121823]">
              <CardContent className="p-5">
                <p className="text-sm text-[#94a3b8]">{item.label}</p>
                <p className={`mt-2 text-2xl font-semibold ${item.tone}`}>{item.value}</p>
              </CardContent>
            </Card>
          ))}
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader className="space-y-4">
            <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <UsersRound className="h-5 w-5 text-blue-300" />
                候选客户列表
              </CardTitle>
              <div className="flex flex-col gap-3 sm:flex-row sm:flex-wrap">
                <Select value={priorityFilter} onValueChange={(value) => setPriorityFilter(value as PriorityFilter)}>
                  <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc] sm:w-36">
                    <Filter className="mr-2 h-4 w-4" />
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部等级</SelectItem>
                    <SelectItem value="A">A 级</SelectItem>
                    <SelectItem value="B">B 级</SelectItem>
                    <SelectItem value="C">C 级</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as CandidateLeadStatus | 'all')}>
                  <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc] sm:w-44"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    {candidateLeadStatusOptions.map((status) => (
                      <SelectItem key={status.value} value={status.value}>{status.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={sourceFilter} onValueChange={(value) => setSourceFilter(value as SourceFilter)}>
                  <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc] sm:w-44"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {sourceOptions.map((option) => (
                      <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
              <Button type="button" size="sm" variant="outline" onClick={toggleAllVisible}>
                {allVisibleSelected ? '取消选择当前结果' : '选择当前结果'}
              </Button>
              <span className="text-sm text-[#94a3b8]">已选择 {selectedIds.length} 个</span>
              <Button type="button" size="sm" className="bg-emerald-600 text-white hover:bg-emerald-500" disabled={!selectedIds.length} onClick={() => handleBatchStatus('priority')}>批量优先开发</Button>
              <Button type="button" size="sm" className="bg-amber-600 text-white hover:bg-amber-500" disabled={!selectedIds.length} onClick={() => handleBatchStatus('verify')}>批量需要核验</Button>
              <Button type="button" size="sm" variant="outline" disabled={!selectedIds.length} onClick={() => handleBatchStatus('paused')}>批量暂缓</Button>
              <Button type="button" size="sm" className="bg-violet-600 text-white hover:bg-violet-500" disabled={!selectedIds.length} onClick={handleBatchJoin}>批量加入 CRM</Button>
              <Button type="button" size="sm" variant="outline" onClick={refreshCandidates}>刷新</Button>
            </div>
          </CardHeader>
          <CardContent>
            {filteredCandidates.length === 0 ? (
              <div className="rounded-lg border border-dashed border-[#2d3548] bg-[#0f1419] p-8 text-center">
                <Building2 className="mx-auto h-10 w-10 text-[#64748b]" />
                <h3 className="mt-4 font-medium text-[#f8fafc]">还没有候选客户</h3>
                <p className="mt-2 text-sm text-[#94a3b8]">先从获客任务执行台运行真实搜索，再点击“沉淀到候选池”。</p>
                <Button asChild className="mt-5 bg-blue-600 text-white hover:bg-blue-500">
                  <Link href="/lead-tasks">打开任务记录</Link>
                </Button>
              </div>
            ) : (
              <div className="grid gap-4 xl:grid-cols-2">
                {filteredCandidates.map((candidate) => {
                  const status = getCandidateLeadStatusMeta(candidate.status);
                  const source = getCandidateSourceMeta(candidate);
                  const checklist = buildCandidateVerificationChecklist(candidate);
                  const selected = selectedIds.includes(candidate.id);
                  return (
                    <div key={candidate.id} className={`rounded-lg border bg-[#0f1419] p-4 ${selected ? 'border-blue-500/60' : 'border-[#2d3548]'}`}>
                      <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <button type="button" onClick={() => toggleSelected(candidate.id)} className={`rounded border px-2 py-1 text-xs ${selected ? 'border-blue-400 bg-blue-500/15 text-blue-200' : 'border-[#2d3548] text-[#94a3b8]'}`}>
                              {selected ? '已选择' : '选择'}
                            </button>
                            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{candidate.priority} 级</Badge>
                            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">{candidate.score} 分</Badge>
                            <Badge className={`border ${status.className}`}>{status.label}</Badge>
                            <Badge className="border-violet-500/25 bg-violet-500/15 text-violet-300">{source.label}</Badge>
                          </div>
                          <h3 className="mt-3 text-lg font-semibold text-[#f8fafc]">{candidate.company}</h3>
                          <p className="mt-1 break-all text-sm text-blue-300">{candidate.website}</p>
                          {source.url ? <p className="mt-1 break-all text-xs text-[#64748b]">来源链接：{source.url}</p> : null}
                        </div>
                        <div className="flex flex-col gap-2 sm:flex-row lg:flex-col">
                          <Select value={candidate.status} onValueChange={(value) => handleStatusChange(candidate.id, value as CandidateLeadStatus)}>
                            <SelectTrigger className="h-10 border-[#2d3548] bg-[#121823] text-[#f8fafc] sm:w-36"><SelectValue /></SelectTrigger>
                            <SelectContent>
                              {candidateLeadStatusOptions.map((option) => (
                                <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <Button type="button" className="h-10 bg-emerald-600 text-white hover:bg-emerald-500" onClick={() => handleJoinCustomerPool(candidate.id)}>
                            <CheckCircle2 className="mr-2 h-4 w-4" />
                            加入 CRM
                          </Button>
                          <Button type="button" variant="outline" className="h-10 border-red-500/25 bg-transparent text-red-300 hover:bg-red-500/10" onClick={() => handleDelete(candidate.id)}>
                            <Trash2 className="mr-2 h-4 w-4" />
                            删除
                          </Button>
                        </div>
                      </div>

                      <div className="mt-4 grid gap-3 md:grid-cols-2">
                        <p className="text-sm text-[#94a3b8]">国家 / 城市：{candidate.country} / {candidate.city}</p>
                        <p className="text-sm text-[#94a3b8]">客户类型：{candidate.customerType}</p>
                        <p className="text-sm text-[#94a3b8]">联系方式：{candidate.contactStatus}</p>
                        <p className="text-sm text-[#94a3b8]">来源任务：{candidate.sourceTaskTitle}</p>
                      </div>

                      <div className="mt-4 rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                        <div className="mb-2 flex items-center gap-2 text-xs text-[#64748b]"><ListChecks className="h-4 w-4" />核验清单</div>
                        <div className="flex flex-wrap gap-2">
                          {checklist.map((item) => (
                            <Badge key={item.key} className={item.done ? 'border-emerald-500/25 bg-emerald-500/15 text-emerald-300' : 'border-amber-500/25 bg-amber-500/15 text-amber-300'}>
                              {item.done ? '已具备' : '待补全'}：{item.label}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="mt-4 rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                        <p className="text-xs text-[#64748b]">推荐动作</p>
                        <p className="mt-1 text-sm leading-6 text-[#cbd5e1]">{candidate.recommendation}</p>
                      </div>
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                          <Link href="/crm-customers">打开 CRM 客户池</Link>
                        </Button>
                        <Button asChild variant="outline" className="border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                          <Link href="/marketing/email">
                            <Search className="mr-2 h-4 w-4" />
                            生成开发动作
                          </Link>
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayout>
  );
}
