# v0.42.0 Real Lead Enrichment Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Improve real bulk lead discovery and enrich each official website result with public email, phone, WhatsApp, and LinkedIn evidence.

**Architecture:** Keep provider discovery in `lead-search-provider.ts`, but place website crawling and contact extraction in a focused `lead-contact-enricher.ts` module. The search service returns partial real results when providers or websites fail, and the existing acquisition UI displays concrete contacts plus batch diagnostics.

**Tech Stack:** Next.js 16, React 19, TypeScript, Node built-in test runner, native `fetch`, pnpm.

---

### Task 1: Contact extraction

**Files:**
- Create: `src/lib/integrations/lead-contact-enricher.ts`
- Create: `tests/lead-contact-enricher.test.ts`

- [ ] **Step 1: Write failing extraction tests**

Add tests that pass representative HTML containing `mailto:`, `tel:`, `wa.me`, `api.whatsapp.com`, and `linkedin.com/company/` links to `extractPublicContacts()`. Assert normalized concrete values, source URL, confidence, and deduplication.

- [ ] **Step 2: Verify the tests fail**

Run: `corepack pnpm exec tsx --test tests/lead-contact-enricher.test.ts`

Expected: FAIL because `lead-contact-enricher.ts` does not exist.

- [ ] **Step 3: Implement the parser**

Create typed `ContactEvidence`, `LeadContactDetails`, and `extractPublicContacts(html, sourceUrl)` exports. Decode common HTML entities, inspect link attributes and visible text, reject placeholder emails, normalize phone numbers, and retain the public source URL for every value.

- [ ] **Step 4: Verify the parser tests pass**

Run: `corepack pnpm exec tsx --test tests/lead-contact-enricher.test.ts`

Expected: all extraction tests PASS.

### Task 2: Bounded website enrichment

**Files:**
- Modify: `src/lib/integrations/lead-contact-enricher.ts`
- Modify: `tests/lead-contact-enricher.test.ts`

- [ ] **Step 1: Write failing crawler tests**

Use an injected fetcher to simulate a homepage and a Contact page. Assert that `enrichLeadWebsite()` stays on the same domain, visits no more than three pages, follows contact/about/team links, preserves partial contacts after one page fails, and reports timeout or access warnings without throwing.

- [ ] **Step 2: Verify the crawler tests fail**

Run: `corepack pnpm exec tsx --test tests/lead-contact-enricher.test.ts`

Expected: FAIL because `enrichLeadWebsite()` is missing.

- [ ] **Step 3: Implement bounded enrichment**

Add `enrichLeadWebsite(website, options)` with an injected fetcher, per-request timeout, maximum page count, same-domain checks, prioritized contact links, contact merging, confidence calculation, and statuses `complete`, `partial`, `not_found`, or `failed`.

- [ ] **Step 4: Verify crawler tests pass**

Run: `corepack pnpm exec tsx --test tests/lead-contact-enricher.test.ts`

Expected: all enrichment tests PASS.

### Task 3: Search integration and real-result fallback

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Modify: `tests/lead-search-provider.test.ts`
- Modify: `src/app/api/integrations/lead-search/route.ts`

- [ ] **Step 1: Write failing integration tests**

Extend candidate expectations with concrete contact fields, evidence, enrichment status, and warnings. Add tests proving that provider failures preserve previous candidates, empty real searches do not inject mock companies, and only a bounded number of official websites are enriched concurrently.

- [ ] **Step 2: Verify integration tests fail**

Run: `corepack pnpm exec tsx --test tests/lead-search-provider.test.ts`

Expected: FAIL because the candidate contact and enrichment fields are absent.

- [ ] **Step 3: Integrate enrichment**

Extend `LeadSearchCandidate` and batch summary types. Enrich deduplicated official candidates with a small worker pool, merge concrete contact values and evidence, calculate contact counters, and return an explicit shortfall reason. Preserve mock behavior only when `provider: "mock"` is intentionally selected.

- [ ] **Step 4: Repair API messages**

Replace the mojibake validation and failure messages in `src/app/api/integrations/lead-search/route.ts` with readable Chinese.

- [ ] **Step 5: Verify search tests pass**

Run: `corepack pnpm exec tsx --test tests/lead-search-provider.test.ts tests/lead-contact-enricher.test.ts`

Expected: all tests PASS.

### Task 4: Acquisition result presentation

**Files:**
- Modify: `src/app/acquisition/page.tsx`
- Modify: relevant candidate mapping module discovered from existing imports
- Modify: relevant candidate mapping tests

- [ ] **Step 1: Write failing mapping tests**

Assert that concrete email, phone, WhatsApp, LinkedIn, source evidence, and enrichment statuses survive conversion from API candidates into the local candidate pool.

- [ ] **Step 2: Verify mapping tests fail**

Run the exact existing candidate mapping test command after locating the owning test file.

Expected: FAIL because concrete enrichment fields are not mapped.

- [ ] **Step 3: Update result UI and mapping**

Display separate discovery and enrichment statistics, concrete contact values with source links, and a readable shortfall explanation. Keep the existing acquisition page and candidate-pool action; do not add new navigation.

- [ ] **Step 4: Verify mapping tests pass**

Run the same candidate mapping tests.

Expected: all tests PASS.

### Task 5: Version, documentation, verification, and package

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/data-backup.ts`
- Modify: `src/lib/release-experience.ts`

- [ ] **Step 1: Update release metadata**

Set version `0.42.0`, document the two-stage real lead workflow, update release-center copy, and keep all secret values out of tracked files.

- [ ] **Step 2: Run full verification**

Run:

```powershell
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
corepack pnpm exec tsx --test tests/lead-contact-enricher.test.ts tests/lead-search-provider.test.ts tests/lead-task-search-mapping.test.ts tests/candidate-workbench.test.ts tests/integration-diagnostics.test.ts
```

Expected: all commands exit successfully.

- [ ] **Step 3: Verify key pages**

Confirm HTTP 200 and browser rendering for `/login`, `/dashboard`, `/acquisition`, `/lead-tasks`, `/candidate-leads`, and `/release`.

- [ ] **Step 4: Build the open-source ZIP**

Create `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.42.0-OpenSource.zip`, excluding `.env`, `.env.local`, `node_modules`, `.next`, `.git`, logs, and `tsconfig.tsbuildinfo`. Inspect archive entries before delivery.

- [ ] **Step 5: Prepare release note**

Use: `v0.42.0：升级真实批量获客和官网联系方式补全，支持多搜索源降级、公开邮箱电话 WhatsApp LinkedIn 提取及来源核验。`
