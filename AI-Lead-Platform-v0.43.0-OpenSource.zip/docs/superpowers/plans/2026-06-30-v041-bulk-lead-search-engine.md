# V0.41.0 Bulk Lead Search Engine Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make real lead search behave like a batch acquisition engine that can pursue up to 50 candidates through expanded keywords, bounded attempts, partial-result preservation, and deduplication.

**Architecture:** Keep `/api/integrations/lead-search` stable and upgrade the provider module. The provider will generate a larger keyword plan based on products, customer types, country/cities, and contact intent; run configured providers with per-request timeouts; dedupe by domain; and return batch summary evidence even when not enough leads are found.

**Tech Stack:** Next.js 16 Route Handlers, TypeScript, native fetch, AbortController, Node assert tests.

---

### Task 1: Expand Batch Keyword Planning

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Test: `tests/lead-search-provider.test.ts`

- [ ] Add city and customer-type query expansion.
- [ ] Generate more queries when `quantity` is high.
- [ ] Keep manual query first.

### Task 2: Batch Attempts And Partial Results

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Test: `tests/lead-search-provider.test.ts`

- [ ] Increase target cap from 20 to 50.
- [ ] Add per-request timeout and record timeout as failed attempt.
- [ ] Continue with remaining queries/providers after a timeout.
- [ ] Return partial candidates instead of throwing away progress.

### Task 3: Batch Summary Evidence

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Test: `tests/lead-search-provider.test.ts`

- [ ] Add `batchSummary` to response with target, query count, attempts, raw count, usable count, dedupe count, returned count, and whether target was reached.
- [ ] Add Chinese warnings explaining partial completion and next actions.

### Task 4: Version And Docs

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/release-experience.ts`
- Modify: `src/lib/data-backup.ts`

- [ ] Update release to `v0.41.0`.
- [ ] Document that batch search is the current priority.

### Task 5: Verify And Package

**Commands:**
- `corepack pnpm exec tsx tests/lead-search-provider.test.ts`
- `corepack pnpm exec tsx tests/lead-task-search-mapping.test.ts`
- `corepack pnpm run ts-check`
- `corepack pnpm run lint:build`
- `corepack pnpm run build`

- [ ] Verify `/dashboard`, `/lead-tasks`, `/candidate-leads`, `/settings/api-keys`, `/release`, and `/login`.
- [ ] Package `AI-Lead-Platform-v0.41.0-OpenSource.zip` without local `.env`.
