# V0.40.0 Search Quality And Fallback Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Improve real lead search quality by expanding search keywords, trying multiple queries before mock fallback, classifying noisy results, and returning clear search attempt evidence.

**Architecture:** Keep the public `/api/integrations/lead-search` route stable. Upgrade `lead-search-provider` so provider fallback runs across query variants, records attempts, filters noise more carefully, dedupes by domain, and only uses mock data after every configured provider/query combination fails.

**Tech Stack:** Next.js 16 Route Handlers, TypeScript, native fetch, Node assert tests.

---

### Task 1: Search Strategy Expansion

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Test: `tests/lead-search-provider.test.ts`

- [ ] Add `buildSearchQueries(input)` that returns 4-6 distinct query variants.
- [ ] Include product, country, customer type, contact intent, official website intent, and source-specific terms.
- [ ] Ensure a user-supplied query is tried first.

### Task 2: Multi Query Provider Fallback

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Test: `tests/lead-search-provider.test.ts`

- [ ] For each configured provider, try multiple query variants before moving to the next provider.
- [ ] Stop when enough A/B/C candidates have been found.
- [ ] Record attempts with provider, query, status, raw count, usable count, and failure reason.

### Task 3: Better Noise And Evidence Scoring

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Test: `tests/lead-search-provider.test.ts`

- [ ] Classify result source as official website, contact page, directory, social, marketplace, job page, document, or noise.
- [ ] Penalize job pages, PDFs, generic directories, and irrelevant social posts.
- [ ] Reward official domains, contact/about/project pages, business keywords, and contact evidence.
- [ ] Add Chinese warning summaries that explain filtering and fallback behavior.

### Task 4: Release Metadata And Docs

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/release-experience.ts`
- Modify: `src/lib/data-backup.ts`

- [ ] Update version to `v0.40.0`.
- [ ] Document search quality and fallback improvements.

### Task 5: Verify And Package

**Commands:**
- `corepack pnpm exec tsx tests/lead-search-provider.test.ts`
- `corepack pnpm exec tsx tests/lead-task-search-mapping.test.ts`
- `corepack pnpm run ts-check`
- `corepack pnpm run lint:build`
- `corepack pnpm run build`

- [ ] Verify `/dashboard`, `/lead-tasks`, `/candidate-leads`, `/settings/api-keys`, `/release`, and `/login`.
- [ ] Package `AI-Lead-Platform-v0.40.0-OpenSource.zip` without local secrets.
