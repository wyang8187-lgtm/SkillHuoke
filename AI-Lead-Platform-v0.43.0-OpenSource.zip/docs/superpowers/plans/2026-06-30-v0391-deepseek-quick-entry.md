# V0.39.1 DeepSeek Quick Entry Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add DeepSeek to the front-facing API quick entry so users can configure it beside OpenAI and search providers.

**Architecture:** Reuse the existing quick entry helper and component. Add DeepSeek fields to generated `.env` snippets, keep secrets temporary in component state, and leave real provider reading on the server-side `.env`.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, clipboard API, Node assert tests.

---

### Task 1: Add DeepSeek Fields

**Files:**
- Modify: `src/lib/api-key-quick-entry.ts`
- Modify: `tests/api-key-quick-entry.test.ts`

- [ ] Add `DEEPSEEK_API_KEY`, `DEEPSEEK_BASE_URL`, and `DEEPSEEK_MODEL` quick fields.
- [ ] Default base URL placeholder should be `https://api.deepseek.com/v1`.
- [ ] Default model placeholder should be `deepseek-chat`.
- [ ] Test that DeepSeek values appear in generated `.env` snippets.

### Task 2: Update Release And Docs

**Files:**
- Modify: `package.json`
- Modify: `README.md`
- Modify: `.env.example`
- Modify: `src/lib/release-experience.ts`
- Modify: `src/lib/data-backup.ts`

- [ ] Bump version to `v0.39.1`.
- [ ] Document DeepSeek quick entry as an OpenAI alternative.
- [ ] Keep `.env.example` secret-free.

### Task 3: Verify And Package

**Commands:**
- `corepack pnpm exec tsx tests/api-key-quick-entry.test.ts`
- `corepack pnpm run ts-check`
- `corepack pnpm run lint:build`
- `corepack pnpm run build`

- [ ] Verify `/dashboard`, `/settings/api-keys`, `/release`, and `/login` return HTTP 200.
- [ ] Package `AI-Lead-Platform-v0.39.1-OpenSource.zip`, excluding local secrets and build output.
