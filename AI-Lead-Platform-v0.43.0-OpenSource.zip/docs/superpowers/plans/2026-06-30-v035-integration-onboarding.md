# v0.35.0 Integration Onboarding Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Upgrade the integration diagnostics center into a Chinese onboarding guide with copyable `.env` snippets and no secret leakage.

**Architecture:** Keep integration definitions in `src/lib/integration-diagnostics.ts`, adding setup steps and template generation. The existing status API returns sanitized guide data. The `/settings/api-keys` client page renders the guide, copy buttons, diagnostics, proxy status, and test results. Release metadata and docs move to v0.35.0.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, Node assert tests, localStorage, browser clipboard API.

---

### Task 1: Test Integration Guide Data

**Files:**
- Modify: `tests/integration-diagnostics.test.ts`

- [ ] Add assertions that OpenAI has setup steps, an `.env` snippet, and no full secret in status JSON.
- [ ] Add assertions that the full template includes all seven service groups.
- [ ] Run `corepack pnpm exec tsx tests/integration-diagnostics.test.ts` and verify it fails before implementation.

### Task 2: Implement Guide Data

**Files:**
- Replace: `src/lib/integration-diagnostics.ts`

- [ ] Rewrite Chinese labels and descriptions as valid readable Chinese.
- [ ] Add `setupSteps` and `envTemplate` to integration definitions and status output.
- [ ] Add `buildFullEnvTemplate()` for the page-level copy button.
- [ ] Run `corepack pnpm exec tsx tests/integration-diagnostics.test.ts` and verify it passes.

### Task 3: Rebuild Diagnostics Page

**Files:**
- Replace: `src/app/settings/api-keys/page.tsx`

- [ ] Render normal Chinese text.
- [ ] Add global copy-all button and per-service copy button.
- [ ] Render setup steps, env snippets, config fields, test results, and proxy diagnostics.
- [ ] Keep no key input, no save button, no full secret display.

### Task 4: Release and Documentation

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/release-experience.ts`
- Modify: `src/lib/data-backup.ts`

- [ ] Set version to `0.35.0`.
- [ ] Update current release metadata, highlights, review pages, checklist, package name, and GitHub remark.
- [ ] Update README with v0.35.0 setup guide.
- [ ] Set default backup app version to `v0.35.0`.

### Task 5: Verification and Package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.35.0-OpenSource.zip`

- [ ] Run diagnostics tests and integration runner tests.
- [ ] Run `corepack pnpm run ts-check`.
- [ ] Run `corepack pnpm run lint:build`.
- [ ] Run `corepack pnpm run build`.
- [ ] Verify `/login`, `/settings/api-keys`, `/api/integrations/status`, and `/release` return HTTP 200.
- [ ] Create ZIP excluding `node_modules`, `.next`, `.git`, `.env`, `.env.local`, logs, and `tsconfig.tsbuildinfo`.
- [ ] Final response includes upload package link, login URL, key pages, GitHub remark, updates, and verification.

## Self-Review

- Spec coverage: Covers Chinese repair, setup steps, `.env` snippets, copy all, per-service copy, safe status API, release metadata, docs, verification, and ZIP package.
- Placeholder scan: No TBD or open-ended implementation placeholders remain.
- Type consistency: Uses `setupSteps`, `envTemplate`, `buildFullEnvTemplate`, version `v0.35.0`, and package `AI-Lead-Platform-v0.35.0-OpenSource.zip` consistently.
