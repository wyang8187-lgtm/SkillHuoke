# v0.43.0 Compact Task Console Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the oversized task runner with a compact operation bar and an immediately visible customer results table.

**Architecture:** Keep the existing search API, task persistence, diagnostics, and candidate mapping. Refactor only the task detail presentation so actions, progress, errors, and result rows share one page without workflow-step or log panels.

**Tech Stack:** Next.js 16, React 19, TypeScript, existing UI components and lucide icons, tsx tests, pnpm.

---

### Task 1: Result table mapping

**Files:**
- Modify: `src/lib/lead-wizard.ts`
- Modify: `tests/lead-task-search-mapping.test.ts`

- [ ] Add failing assertions for concrete contacts, public source, score, and priority.
- [ ] Ensure the mapped task candidate retains every field needed by the table.
- [ ] Run mapping tests and confirm they pass.

### Task 2: Compact task runner

**Files:**
- Modify: `src/app/lead-tasks/[id]/page.tsx`

- [ ] Replace the large header and repeated statistics with one compact operation band.
- [ ] Keep real-search, candidate-pool, export, API settings, and back actions.
- [ ] Remove rendered workflow steps and run logs.
- [ ] Render progress and diagnostics immediately below the operation band.
- [ ] Render a responsive customer results table below diagnostics.
- [ ] Add website, LinkedIn, and source links plus contact values.
- [ ] Show a useful empty state when no real results exist.

### Task 3: Verification guard

**Files:**
- Create: `tests/compact-task-console.test.ts`

- [ ] Assert that the task console source no longer renders “执行步骤” or “运行日志”.
- [ ] Assert that customer-table headings and failure-diagnostic text exist.
- [ ] Run the test and confirm it passes.

### Task 4: Release and package

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/data-backup.ts`
- Modify: `src/lib/release-experience.ts`

- [ ] Upgrade metadata to `v0.43.0`.
- [ ] Run type checking, focused lint, production build, and related tests.
- [ ] Verify task list, task detail, API settings, and release pages.
- [ ] Create `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.43.0-OpenSource.zip`.
- [ ] Confirm the ZIP excludes secrets, dependencies, build files, logs, and Git data.
