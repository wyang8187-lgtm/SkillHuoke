# v0.42.1 Search Failure Diagnostics Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Explain real-search failures in readable Chinese, stop repeating terminal provider errors, and reflect failed or partial searches accurately in the task runner.

**Architecture:** Add a pure error-classification and provider-summary layer to the existing search provider. Return structured diagnostics through the existing API and render them in the task runner without exposing secrets.

**Tech Stack:** Next.js 16, React 19, TypeScript, native fetch, tsx tests, pnpm.

---

### Task 1: Provider error classification

**Files:**
- Modify: `src/lib/integrations/lead-search-provider.ts`
- Modify: `tests/lead-search-provider.test.ts`

- [ ] Add failing tests for HTTP 401, 403, 429, timeout, and network errors.
- [ ] Run `corepack pnpm exec tsx tests/lead-search-provider.test.ts` and confirm failure.
- [ ] Add typed `providerDiagnostics`, Chinese error labels, and action suggestions.
- [ ] Stop a provider after terminal authentication, permission, or quota errors.
- [ ] Re-run the test and confirm it passes.

### Task 2: Accurate task outcome

**Files:**
- Modify: `src/app/lead-tasks/[id]/page.tsx`
- Create: `src/lib/lead-search-outcome.ts`
- Create: `tests/lead-search-outcome.test.ts`

- [ ] Add failing tests for failed, partial, and completed search outcomes.
- [ ] Implement a pure outcome helper based on target and returned counts.
- [ ] Update the task runner so zero results remain failed instead of completed.
- [ ] Re-run the outcome tests.

### Task 3: Diagnostic UI

**Files:**
- Modify: `src/app/lead-tasks/[id]/page.tsx`

- [ ] Render one diagnostic card per configured provider.
- [ ] Show Chinese reason, HTTP/error category, request counts, result counts, and action suggestion.
- [ ] Add a link to `/settings/api-keys`.
- [ ] Avoid displaying raw response bodies or secret values.

### Task 4: Release and verification

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/data-backup.ts`
- Modify: `src/lib/release-experience.ts`

- [ ] Upgrade release metadata to `v0.42.1`.
- [ ] Run type checking, focused lint, production build, and all related tests.
- [ ] Verify `/login`, `/dashboard`, `/lead-tasks`, `/settings/api-keys`, and `/release`.
- [ ] Create `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.42.1-OpenSource.zip`.
- [ ] Confirm the archive excludes `.env`, `.next`, `node_modules`, `.git`, logs, and `tsconfig.tsbuildinfo`.
