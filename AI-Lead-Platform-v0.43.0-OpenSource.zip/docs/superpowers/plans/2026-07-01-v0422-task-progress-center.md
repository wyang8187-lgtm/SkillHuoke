# v0.42.2 Task Progress Center Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Persist and display reliable task progress, partial-result counts, and provider failure reasons in the task list and task runner.

**Architecture:** Extend the existing local `SavedLeadTask` model with an optional run snapshot so old tasks remain compatible. Use pure helpers to calculate task outcome and progress, then persist the final search summary and provider diagnostics after every run.

**Tech Stack:** Next.js 16, React 19, TypeScript, browser localStorage, tsx tests, pnpm.

---

### Task 1: Task progress model

**Files:**
- Modify: `src/lib/lead-wizard.ts`
- Modify: `src/lib/lead-search-outcome.ts`
- Create: `tests/lead-task-progress.test.ts`

- [ ] Add failing tests for 0/40, 10/40, and 40/40 progress snapshots.
- [ ] Add task run status, counts, percentage, diagnostics, step, and last-run time types.
- [ ] Add a pure builder that converts a search result into a persisted task snapshot.
- [ ] Add a storage update helper that preserves older task fields.
- [ ] Run the progress tests and confirm they pass.

### Task 2: Persist execution results

**Files:**
- Modify: `src/app/lead-tasks/[id]/page.tsx`
- Modify: `src/lib/lead-wizard.ts`

- [ ] Write `running` progress when the user starts a real search.
- [ ] Persist actual found, enriched, attempt, failure, and provider diagnostic counts after the API responds.
- [ ] Persist failed, partial, or completed outcome without discarding partial candidates.
- [ ] Display a prominent final outcome panel at the top of the task runner.

### Task 3: Task list progress UI

**Files:**
- Modify: `src/app/lead-tasks/page.tsx`

- [ ] Add target/found/enriched counters to every task card.
- [ ] Add a stable progress bar and percentage.
- [ ] Add current step, last-run time, and readable provider failure summary.
- [ ] Add detail, rerun, and API settings actions.
- [ ] Keep old tasks without a run snapshot readable.

### Task 4: Release and verification

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/data-backup.ts`
- Modify: `src/lib/release-experience.ts`

- [ ] Upgrade release metadata to `v0.42.2`.
- [ ] Run type checking, focused lint, production build, and related tests.
- [ ] Verify `/login`, `/lead-tasks`, one task detail page when available, `/settings/api-keys`, and `/release`.
- [ ] Create `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.42.2-OpenSource.zip`.
- [ ] Confirm the archive excludes secrets, dependencies, build output, logs, and Git data.
