# v0.38.0 Candidate Workbench Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Upgrade the candidate lead pool into a practical screening workbench with source display, verification checklist, filters, selection, and batch actions.

**Architecture:** Add pure helper functions to `src/lib/lead-wizard.ts` for candidate source detection, verification checklist, and batch status updates. Replace `/candidate-leads` with a clean Chinese client page that uses existing localStorage data and helper functions. CRM conversion stays on the existing local CRM flow.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, localStorage, Node assert tests.

---

### Task 1: Candidate Helper Tests

**Files:**
- Create: `tests/candidate-workbench.test.ts`

- [ ] Test source type detection from recommendation/source task.
- [ ] Test verification checklist from contact status.
- [ ] Test batch status updates return updated candidates without losing others.

### Task 2: Candidate Helper Implementation

**Files:**
- Modify: `src/lib/lead-wizard.ts`

- [ ] Add `getCandidateSourceMeta`.
- [ ] Add `buildCandidateVerificationChecklist`.
- [ ] Add `updateSavedCandidateLeadStatuses`.
- [ ] Keep existing single-candidate helpers compatible.

### Task 3: Candidate Workbench UI

**Files:**
- Replace: `src/app/candidate-leads/page.tsx`

- [ ] Render clean Chinese UI.
- [ ] Add filters for priority, status, source type, and CRM joined state.
- [ ] Add row selection and select all visible candidates.
- [ ] Add batch mark priority, verify, paused, and batch join CRM.
- [ ] Show source type, source link, contact checklist, recommendation, and task source.

### Task 4: Release and Docs

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/release-experience.ts`
- Modify: `src/lib/data-backup.ts`

- [ ] Set version to `0.38.0`.
- [ ] Update release metadata, highlights, review pages, package name, and GitHub remark.
- [ ] Document candidate screening flow.

### Task 5: Verification and Package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.38.0-OpenSource.zip`

- [ ] Run candidate, task-search, lead-search, and integration tests.
- [ ] Run TypeScript, ESLint, and build.
- [ ] Verify `/candidate-leads`, `/lead-tasks`, `/settings/api-keys`, `/release`, `/login`.
- [ ] Package while excluding dependencies, build output, `.env`, logs, and git data.

## Self-Review

- Scope is focused on candidate screening and batch actions.
- No placeholders remain.
- Version and package names are consistent.
