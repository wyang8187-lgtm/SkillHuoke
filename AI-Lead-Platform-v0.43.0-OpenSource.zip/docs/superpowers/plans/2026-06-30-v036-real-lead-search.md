# v0.36.0 Real Lead Search Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make `/api/integrations/lead-search` use configured real search providers before falling back to mock data.

**Architecture:** Keep the API route stable and move provider selection, request construction, parsing, ranking, and fallback behavior into `src/lib/integrations/lead-search-provider.ts`. The provider tries SerpAPI, Bing, then Google for `auto`, maps search results into candidate leads, filters noisy URLs, and returns Chinese warnings when it falls back.

**Tech Stack:** Next.js 16 route handlers, TypeScript, native fetch, Node assert tests.

---

### Task 1: Provider Tests

**Files:**
- Create: `tests/lead-search-provider.test.ts`

- [ ] Test that `auto` prefers SerpAPI when configured.
- [ ] Test that SerpAPI failure falls back to Bing.
- [ ] Test that no provider configured falls back to mock with Chinese warning.
- [ ] Test that candidates include source links, scores, priorities, and no D-level noise.

### Task 2: Real Provider Implementation

**Files:**
- Replace: `src/lib/integrations/lead-search-provider.ts`

- [ ] Add injectable env and fetcher options for tests while keeping the public API compatible.
- [ ] Build fixed URLs for SerpAPI, Bing, and Google only.
- [ ] Parse result shapes from all three providers.
- [ ] Filter social posts, directories, jobs, PDFs, and low-quality pages into warnings or lower scores.
- [ ] Return A/B/C candidates and fallback to mock with Chinese warnings if real providers fail.

### Task 3: Route and Docs

**Files:**
- Modify: `src/app/api/integrations/lead-search/route.ts`
- Modify: `package.json`
- Modify: `README.md`
- Modify: `src/lib/release-experience.ts`
- Modify: `src/lib/data-backup.ts`

- [ ] Keep request contract the same.
- [ ] Update version to `0.36.0`.
- [ ] Update README and release metadata.
- [ ] Set upload package and GitHub remark.

### Task 4: Verification and Package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.36.0-OpenSource.zip`

- [ ] Run provider tests and existing integration tests.
- [ ] Run TypeScript, ESLint, and build.
- [ ] Verify `/api/integrations/lead-search`, `/settings/api-keys`, `/release`, and `/login`.
- [ ] Package while excluding dependencies, build output, `.env`, logs, and git data.

## Self-Review

- Scope is focused on backend search provider selection and candidate mapping.
- No placeholders remain.
- Version, package, route, and provider names are consistent.
