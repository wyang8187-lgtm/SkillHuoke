# v0.37.0 Task Real Search Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Connect the lead task runner page to the real lead search API so users can run a task, inspect the provider/warnings, and deposit results into the candidate pool.

**Architecture:** Add a small browser-safe mapper in `src/lib/lead-wizard.ts` that converts backend `LeadSearchCandidate` objects into existing `LeadTaskCandidate` objects. Rebuild `/lead-tasks/[id]` with normal Chinese text, a real-search action, result summary, warnings, and candidate deposit using the existing local candidate pool storage.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, localStorage, native fetch, Node assert tests.

---

### Task 1: Mapper Test

**Files:**
- Create: `tests/lead-task-search-mapping.test.ts`

- [ ] Test that backend search candidates become existing task candidates.
- [ ] Test that D priority is downgraded or excluded from deposit output.
- [ ] Test that contact status and recommendation are readable Chinese.

### Task 2: Mapper Implementation

**Files:**
- Modify: `src/lib/lead-wizard.ts`

- [ ] Add `mapSearchCandidatesToTaskCandidates`.
- [ ] Keep existing local preview behavior compatible.
- [ ] Fix the most visible Chinese labels used by the task runner.

### Task 3: Real Search Task Runner UI

**Files:**
- Replace: `src/app/lead-tasks/[id]/page.tsx`

- [ ] Add “运行真实搜索” button.
- [ ] Call `/api/integrations/lead-search` with task input.
- [ ] Show provider, query, warnings, loading and error states.
- [ ] Use real search results for candidate preview and candidate-pool deposit.
- [ ] Keep manual status buttons and export link.

### Task 4: Release and Docs

**Files:**
- Modify: `package.json`
- Modify: `.env.example`
- Modify: `README.md`
- Modify: `src/lib/release-experience.ts`
- Modify: `src/lib/data-backup.ts`

- [ ] Set version to `0.37.0`.
- [ ] Update release highlights, review pages, package name, and GitHub remark.
- [ ] Document task runner real search flow.

### Task 5: Verification and Package

**Files:**
- Create: `C:\Users\w2775\Documents\找客\AI-Lead-Platform-v0.37.0-OpenSource.zip`

- [ ] Run mapper, lead search, integration diagnostics, and integration runner tests.
- [ ] Run TypeScript, ESLint, and build.
- [ ] Verify `/lead-tasks`, `/settings/api-keys`, `/release`, `/login`, and search API.
- [ ] Package while excluding dependencies, build output, `.env`, logs, and git data.

## Self-Review

- Scope is focused on task runner using the existing real search API and candidate pool.
- No placeholders remain.
- Version and package names are consistent.
