# V0.39.0 Front API Entry Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Add a front-facing API quick entry so non-technical users can paste common API keys near the main workflow and copy a ready `.env` snippet.

**Architecture:** Keep real API secrets server-side in `.env`. Add a reusable client component that accepts temporary key input, generates a copyable `.env` snippet, links to diagnostics, and never stores secrets in localStorage or package files.

**Tech Stack:** Next.js 16 App Router, React 19, TypeScript, local component state, clipboard API, Node assert tests.

---

### Task 1: Add Quick Entry Data Helper

**Files:**
- Create: `src/lib/api-key-quick-entry.ts`
- Test: `tests/api-key-quick-entry.test.ts`

- [ ] Create a small definition list for `OPENAI_API_KEY`, `SERPAPI_KEY`, `GOOGLE_SEARCH_API_KEY`, `GOOGLE_SEARCH_CX`, and `BING_SEARCH_API_KEY`.
- [ ] Add `buildQuickEnvSnippet(values)` that returns only non-empty fields as `KEY=value` lines.
- [ ] Test that empty values are skipped and generated snippets do not include placeholder text.

### Task 2: Add Reusable Front API Component

**Files:**
- Create: `src/components/integrations/api-key-quick-entry.tsx`

- [ ] Render five password/text inputs with Chinese labels.
- [ ] Add buttons for “复制 .env 配置”, “去检测接口”, and “开始真实获客”.
- [ ] Do not write API keys to localStorage, server routes, logs, or backups.
- [ ] Show a short security note explaining that the final key still needs to be saved into local `.env`.

### Task 3: Put Entry On Dashboard And API Page

**Files:**
- Modify: `src/app/dashboard/page.tsx`
- Modify: `src/app/settings/api-keys/page.tsx`

- [ ] Import the reusable component.
- [ ] Place it after the dashboard hero so users see it before metrics.
- [ ] Place it near the top of `/settings/api-keys`, before the full diagnostics cards.

### Task 4: Release Metadata And Docs

**Files:**
- Modify: `src/lib/release-experience.ts`
- Modify: `README.md`
- Modify: `.env.example`
- Modify: `package.json`

- [ ] Update current release to `v0.39.0`.
- [ ] Document the new front API quick entry.
- [ ] Keep `.env.example` as examples only, without real secrets.

### Task 5: Verify And Package

**Commands:**
- `corepack pnpm exec tsx tests/api-key-quick-entry.test.ts`
- `corepack pnpm exec tsx tests/candidate-workbench.test.ts`
- `corepack pnpm run ts-check`
- `corepack pnpm run lint:build`
- `corepack pnpm run build`

- [ ] Verify `/dashboard`, `/settings/api-keys`, `/candidate-leads`, `/release`, and `/login` return HTTP 200.
- [ ] Package `AI-Lead-Platform-v0.39.0-OpenSource.zip`, excluding `node_modules`, `.next`, `.git`, `.env`, logs, and build cache.
