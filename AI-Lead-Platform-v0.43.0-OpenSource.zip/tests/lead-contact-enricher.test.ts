import assert from 'node:assert/strict';
import {
  enrichLeadWebsite,
  extractPublicContacts,
} from '../src/lib/integrations/lead-contact-enricher';

async function main() {
  const extracted = extractPublicContacts(`
    <main>
      <a href="mailto:sales@acmekitchens.com.au">Email sales@acmekitchens.com.au</a>
      <a href="tel:+61 2 9123 4567">Call us</a>
      <a href="https://wa.me/61412345678">WhatsApp</a>
      <a href="https://www.linkedin.com/company/example-kitchens/">LinkedIn</a>
      <a href="mailto:info@acmekitchens.com.au">info@acmekitchens.com.au</a>
      <a href="mailto:sales@acmekitchens.com.au">Duplicate</a>
    </main>
  `, 'https://example.com/contact');

  assert.deepEqual(extracted.emails.map((item) => item.value), [
    'sales@acmekitchens.com.au',
    'info@acmekitchens.com.au',
  ]);
  assert.equal(extracted.phones[0]?.value, '+61291234567');
  assert.equal(extracted.whatsapp[0]?.value, '+61412345678');
  assert.equal(
    extracted.linkedin[0]?.value,
    'https://www.linkedin.com/company/example-kitchens/'
  );
  assert.ok(extracted.emails.every((item) => item.sourceUrl === 'https://example.com/contact'));

  const requested: string[] = [];
  const enriched = await enrichLeadWebsite('https://example.com', {
    timeoutMs: 100,
    maxPages: 3,
    fetcher: async (input) => {
      const url = String(input);
      requested.push(url);
      if (url === 'https://example.com/') {
        return new Response(`
          <a href="/contact">Contact</a>
          <a href="https://other.example.net/contact">External</a>
          <a href="mailto:hello@acmekitchens.com.au">Email</a>
        `, { status: 200, headers: { 'content-type': 'text/html' } });
      }
      if (url === 'https://example.com/contact') {
        return new Response(`
          <a href="tel:+61 3 9000 0000">Phone</a>
          <a href="https://api.whatsapp.com/send?phone=61400111222">WhatsApp</a>
          <a href="https://linkedin.com/company/example">LinkedIn</a>
        `, { status: 200, headers: { 'content-type': 'text/html' } });
      }
      throw new Error('unexpected request');
    },
  });

  assert.deepEqual(requested, ['https://example.com/', 'https://example.com/contact']);
  assert.equal(enriched.status, 'complete');
  assert.equal(enriched.email, 'hello@acmekitchens.com.au');
  assert.equal(enriched.phone, '+61390000000');
  assert.equal(enriched.whatsapp, '+61400111222');
  assert.equal(enriched.linkedin, 'https://linkedin.com/company/example');
  assert.ok(enriched.contactConfidence >= 80);

  const partial = await enrichLeadWebsite('https://partial.example.com', {
    timeoutMs: 100,
    maxPages: 2,
    fetcher: async (input) => {
      const url = String(input);
      if (url === 'https://partial.example.com/') {
        return new Response(`
          <a href="/about">About</a>
          <a href="mailto:team@partial.example.com">Email</a>
        `, { status: 200, headers: { 'content-type': 'text/html' } });
      }
      throw new Error('blocked');
    },
  });

  assert.equal(partial.status, 'partial');
  assert.equal(partial.email, 'team@partial.example.com');
  assert.match(partial.warnings.join('\n'), /blocked/);

  console.log('lead-contact-enricher tests passed');
}

main();
