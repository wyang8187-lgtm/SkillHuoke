import assert from 'node:assert/strict';
import {
  buildCandidateVerificationChecklist,
  getCandidateSourceMeta,
  updateCandidateStatuses,
  type SavedCandidateLead,
} from '../src/lib/lead-wizard';

const base: SavedCandidateLead = {
  id: 'candidate-1',
  company: 'Sydney Custom Kitchens',
  website: 'https://sydneycustomkitchens.example.com',
  country: 'Australia',
  city: 'Sydney',
  customerType: 'Kitchen Company',
  contactStatus: '邮箱已发现 / 电话待核验 / WhatsApp待核验 / LinkedIn已发现',
  score: 88,
  priority: 'A',
  recommendation: '优先开发。来源：https://search.example.com/result-1 风险提示：needs_public_source_verification',
  sourceTaskId: 'task-1',
  sourceTaskTitle: 'Australia cabinets real search task',
  status: 'verify',
  createdAt: '2026-06-30',
  updatedAt: '2026-06-30',
};

const source = getCandidateSourceMeta(base);
assert.equal(source.type, 'real_search');
assert.equal(source.label, '真实搜索');
assert.equal(source.url, 'https://search.example.com/result-1');

const checklist = buildCandidateVerificationChecklist(base);
assert.equal(checklist.find((item) => item.key === 'email')?.done, true);
assert.equal(checklist.find((item) => item.key === 'phone')?.done, false);
assert.equal(checklist.find((item) => item.key === 'linkedin')?.done, true);
assert.match(checklist.find((item) => item.key === 'whatsapp')?.label || '', /WhatsApp/);

const updated = updateCandidateStatuses(
  [
    base,
    { ...base, id: 'candidate-2', status: 'paused' },
    { ...base, id: 'candidate-3', status: 'joined' },
  ],
  ['candidate-1', 'candidate-2'],
  'priority',
  'now'
);
assert.equal(updated.find((item) => item.id === 'candidate-1')?.status, 'priority');
assert.equal(updated.find((item) => item.id === 'candidate-2')?.status, 'priority');
assert.equal(updated.find((item) => item.id === 'candidate-3')?.status, 'joined');
assert.equal(updated.find((item) => item.id === 'candidate-1')?.updatedAt, 'now');

console.log('candidate-workbench tests passed');
