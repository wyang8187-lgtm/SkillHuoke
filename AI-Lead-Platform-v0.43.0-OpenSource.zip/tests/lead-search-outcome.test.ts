import assert from 'node:assert/strict';
import { getLeadSearchOutcome } from '../src/lib/lead-search-outcome';

assert.deepEqual(getLeadSearchOutcome(40, 0), {
  status: 'failed',
  label: '执行失败',
});
assert.deepEqual(getLeadSearchOutcome(40, 12), {
  status: 'partial',
  label: '部分完成',
});
assert.deepEqual(getLeadSearchOutcome(40, 40), {
  status: 'completed',
  label: '执行完成',
});
assert.deepEqual(getLeadSearchOutcome(40, 48), {
  status: 'completed',
  label: '执行完成',
});

console.log('lead-search-outcome tests passed');
