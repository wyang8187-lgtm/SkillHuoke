import assert from 'node:assert/strict';
import { buildQuickEnvSnippet } from '../src/lib/api-key-quick-entry';

const snippet = buildQuickEnvSnippet({
  OPENAI_API_KEY: ' sk-test ',
  DEEPSEEK_API_KEY: 'deepseek-key',
  DEEPSEEK_BASE_URL: 'https://api.deepseek.com/v1',
  DEEPSEEK_MODEL: 'deepseek-chat',
  SERPAPI_KEY: '',
  GOOGLE_SEARCH_API_KEY: 'google-key',
  GOOGLE_SEARCH_CX: 'cx-123',
});

assert.equal(snippet.includes('OPENAI_API_KEY=sk-test'), true);
assert.equal(snippet.includes('DEEPSEEK_API_KEY=deepseek-key'), true);
assert.equal(snippet.includes('DEEPSEEK_BASE_URL=https://api.deepseek.com/v1'), true);
assert.equal(snippet.includes('DEEPSEEK_MODEL=deepseek-chat'), true);
assert.equal(snippet.includes('GOOGLE_SEARCH_API_KEY=google-key'), true);
assert.equal(snippet.includes('GOOGLE_SEARCH_CX=cx-123'), true);
assert.equal(snippet.includes('SERPAPI_KEY='), false);
assert.equal(snippet.includes('复制'), false);

const emptySnippet = buildQuickEnvSnippet({});
assert.equal(emptySnippet, '');

console.log('api-key-quick-entry tests passed');
