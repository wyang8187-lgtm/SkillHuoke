import assert from 'node:assert/strict';
import { buildLeadTaskRunSnapshot } from '../src/lib/lead-wizard';
import type { LeadSearchResult } from '../src/lib/integrations/lead-search-provider';

function result(returnedCount: number): LeadSearchResult {
  return {
    provider: 'serpapi',
    query: 'Australia custom cabinetry builder',
    candidates: [],
    warnings: [],
    attempts: [],
    batchSummary: {
      targetQuantity: 40,
      queryCount: 12,
      providerCount: 2,
      attemptCount: 3,
      rawCount: returnedCount,
      usableCount: returnedCount,
      dedupedCount: 0,
      returnedCount,
      reachedTarget: returnedCount >= 40,
      partial: returnedCount > 0 && returnedCount < 40,
      enrichedCount: Math.min(returnedCount, 7),
      emailCount: 4,
      phoneCount: 5,
      whatsappCount: 2,
      linkedinCount: 3,
      enrichmentFailureCount: 1,
    },
    providerDiagnostics: [{
      provider: 'serpapi',
      status: returnedCount ? 'partial' : 'failed',
      successAttempts: returnedCount ? 1 : 0,
      failedAttempts: 1,
      emptyAttempts: 0,
      rawCount: returnedCount,
      usableCount: returnedCount,
      errorCode: 'invalid_key',
      reason: 'API 密钥无效',
      suggestion: '请更换密钥。',
    }],
  };
}

const failed = buildLeadTaskRunSnapshot(result(0), '2026-07-01 10:00:00');
assert.equal(failed.status, 'failed');
assert.equal(failed.progressPercent, 0);
assert.equal(failed.lastError, 'SerpAPI：API 密钥无效');

const partial = buildLeadTaskRunSnapshot(result(10), '2026-07-01 10:05:00');
assert.equal(partial.status, 'partial');
assert.equal(partial.progressPercent, 25);
assert.equal(partial.foundCount, 10);
assert.equal(partial.enrichedCount, 7);
assert.equal(partial.currentStep, '已保留部分真实客户，等待继续补全');

const completed = buildLeadTaskRunSnapshot(result(40), '2026-07-01 10:10:00');
assert.equal(completed.status, 'completed');
assert.equal(completed.progressPercent, 100);
assert.equal(completed.lastError, 'SerpAPI：API 密钥无效');

console.log('lead-task-progress tests passed');
