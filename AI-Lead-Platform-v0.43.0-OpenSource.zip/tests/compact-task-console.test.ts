import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { resolve } from 'node:path';

const source = readFileSync(
  resolve(process.cwd(), 'src/app/lead-tasks/[id]/page.tsx'),
  'utf8'
);

assert.doesNotMatch(source, />执行步骤</);
assert.doesNotMatch(source, />运行日志</);
assert.match(source, /客户搜索结果/);
assert.match(source, /公司名称/);
assert.match(source, /WhatsApp/);
assert.match(source, /搜索失败原因/);
assert.match(source, /前往 API 设置/);
assert.match(source, /任务列表/);
assert.match(source, /切换任务/);

console.log('compact-task-console tests passed');
