import assert from 'node:assert/strict';
import { mapSearchCandidatesToTaskCandidates } from '../src/lib/lead-wizard';
import type { LeadSearchCandidate } from '../src/lib/integrations/lead-search-provider';

const candidates: LeadSearchCandidate[] = [
  {
    companyName: 'Sydney Custom Kitchens',
    website: 'https://sydneycustomkitchens.example.com',
    country: 'Australia',
    city: 'Sydney',
    customerType: 'Kitchen Company',
    sourceUrl: 'https://search.example.com/result-1',
    emailStatus: 'found',
    phoneStatus: 'needs_verification',
    whatsappStatus: 'needs_verification',
    linkedinStatus: 'found',
    email: 'sales@sydneycustomkitchens.com.au',
    phone: '+61290000000',
    whatsapp: '+61400123456',
    linkedin: 'https://linkedin.com/company/sydney-custom-kitchens',
    contactSources: {
      email: 'https://sydneycustomkitchens.example.com/contact',
    },
    contactConfidence: 93,
    enrichmentStatus: 'complete',
    matchScore: 89,
    priority: 'A',
    confidence: 82,
    riskSignals: ['needs_public_source_verification'],
    nextAction: '优先核验官网和联系人。',
  },
  {
    companyName: 'Noise Directory',
    website: 'https://directory.example.com',
    country: 'Australia',
    customerType: 'Directory',
    emailStatus: 'not_found',
    phoneStatus: 'not_found',
    whatsappStatus: 'not_found',
    linkedinStatus: 'not_found',
    matchScore: 41,
    priority: 'D',
    confidence: 30,
    riskSignals: ['noise_result'],
    nextAction: '暂缓。',
  },
];

const mapped = mapSearchCandidatesToTaskCandidates('task-1', candidates);
assert.equal(mapped.length, 1);
assert.equal(mapped[0].id, 'task-1-real-1');
assert.equal(mapped[0].company, 'Sydney Custom Kitchens');
assert.equal(mapped[0].website, 'https://sydneycustomkitchens.example.com');
assert.equal(mapped[0].score, 89);
assert.equal(mapped[0].priority, 'A');
assert.equal(mapped[0].email, 'sales@sydneycustomkitchens.com.au');
assert.equal(mapped[0].phone, '+61290000000');
assert.equal(mapped[0].whatsapp, '+61400123456');
assert.equal(mapped[0].contactConfidence, 93);
assert.match(mapped[0].contactStatus, /邮箱已发现/);
assert.match(mapped[0].contactStatus, /LinkedIn已发现/);
assert.match(mapped[0].recommendation, /来源/);
assert.match(mapped[0].recommendation, /优先核验官网/);

console.log('lead-task-search-mapping tests passed');
