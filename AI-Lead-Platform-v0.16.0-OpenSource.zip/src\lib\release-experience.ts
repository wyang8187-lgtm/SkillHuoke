import { demoWorkspace } from './workspace';

export const currentRelease = {
  version: 'v0.16.0',
  title: '可填写获客任务向导表单',
  date: '2026-06-26',
  localUrl: 'http://127.0.0.1:5000',
  loginUrl: 'http://127.0.0.1:5000/login',
  packageName: 'AI-Lead-Platform-v0.16.0-OpenSource.zip',
  githubRemark: 'v0.16.0：新增可填写获客任务向导表单',
  workspaceName: demoWorkspace.name,
};

export const releaseHighlights = [
  '新增可填写获客任务向导，输入产品、国家、客户类型和数量即可生成执行方案。',
  '自动生成搜索关键词、推荐渠道、核验规则、开发动作建议和优先级逻辑。',
  '新手引导页的“开始获客任务”已连接到获客向导。',
  '版本体验中心继续保留登录方式、重点查看页面、上传包和 GitHub 备注。',
];

export const releaseReviewPages = [
  {
    title: '版本体验中心',
    href: '/release',
    description: '先看这里，确认当前版本、登录方式、演示身份、上传包和 GitHub 备注。',
  },
  {
    title: '获客任务向导',
    href: '/lead-wizard',
    description: '输入产品、国家、客户类型和数量，生成关键词、渠道、核验规则和开发动作。',
  },
  {
    title: '新手运营引导',
    href: '/onboarding',
    description: '查看外贸老板第一次使用系统时的 6 步运营流程和获客任务向导预览。',
  },
  {
    title: '登录页',
    href: '/login',
    description: '查看演示模式入口和四种角色说明。',
  },
  {
    title: '团队管理',
    href: '/team',
    description: '检查 v0.13.0 新增的成员、角色和工作量展示。',
  },
  {
    title: '权限矩阵',
    href: '/team/permissions',
    description: '检查老板、管理员、销售、运营的权限差异。',
  },
  {
    title: '团队设置',
    href: '/settings/team',
    description: '检查 SaaS 团队设置入口和后续接入清单。',
  },
];

export const demoRoleAccounts = [
  {
    role: '老板',
    email: 'owner@skillhuoke.demo',
    password: 'demo123456',
    focus: '看公司全局、团队权限、客户数据和 SaaS 设置。',
  },
  {
    role: '管理员',
    email: 'admin@skillhuoke.demo',
    password: 'demo123456',
    focus: '看团队运营、客户分配、任务监督和基础配置。',
  },
  {
    role: '销售',
    email: 'sales@skillhuoke.demo',
    password: 'demo123456',
    focus: '看自己负责的客户、CRM 跟进和开发信流程。',
  },
  {
    role: '运营',
    email: 'operator@skillhuoke.demo',
    password: 'demo123456',
    focus: '看批量获客任务、线索核验、模板和导出准备。',
  },
];

export const releaseChecklist = [
  '打开登录页，点击“演示模式进入工作台”。',
  '进入版本体验中心，按页面列出的入口逐个查看。',
  '确认本次版本功能、GitHub 备注和上传包名称。',
  '上传压缩包到开源仓库，并使用版本备注作为提交说明。',
];
