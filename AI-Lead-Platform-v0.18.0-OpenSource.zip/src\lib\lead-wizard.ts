export interface LeadWizardInput {
  product: string;
  country: string;
  customerType: string;
  quantity: number;
}

export interface LeadWizardOutput {
  keywords: string[];
  channels: string[];
  verificationRules: string[];
  outreachActions: string[];
  priorityLogic: string[];
}

export type LeadTaskStatus = 'draft' | 'pending' | 'running' | 'completed';

export interface SavedLeadTask {
  id: string;
  title: string;
  status: LeadTaskStatus;
  input: LeadWizardInput;
  output: LeadWizardOutput;
  createdAt: string;
  updatedAt: string;
}

export interface LeadTaskExecutionStep {
  id: string;
  title: string;
  status: 'completed' | 'running' | 'pending';
  detail: string;
}

export interface LeadTaskRunLog {
  time: string;
  level: 'info' | 'success' | 'warning';
  message: string;
}

export interface LeadTaskCandidate {
  id: string;
  company: string;
  website: string;
  country: string;
  city: string;
  customerType: string;
  contactStatus: string;
  score: number;
  priority: 'A' | 'B' | 'C';
  recommendation: string;
}

export interface LeadTaskExecutionPreview {
  steps: LeadTaskExecutionStep[];
  logs: LeadTaskRunLog[];
  candidates: LeadTaskCandidate[];
}

export const LEAD_TASKS_STORAGE_KEY = 'skillhuoke_lead_tasks_v017';

export const leadTaskStatusOptions: Array<{ value: LeadTaskStatus; label: string; className: string }> = [
  { value: 'draft', label: '草稿', className: 'bg-slate-500/15 text-slate-300 border-slate-500/25' },
  { value: 'pending', label: '待执行', className: 'bg-amber-500/15 text-amber-300 border-amber-500/25' },
  { value: 'running', label: '执行中', className: 'bg-blue-500/15 text-blue-300 border-blue-500/25' },
  { value: 'completed', label: '已完成', className: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/25' },
];

export const defaultLeadWizardInput: LeadWizardInput = {
  product: '全屋定制、橱柜、衣柜、木门、家具出口',
  country: 'Australia',
  customerType: 'Builder + Designer + Kitchen Company + Importer',
  quantity: 50,
};

function cleanValue(value: string, fallback: string) {
  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : fallback;
}

function normalizeProductForSearch(product: string) {
  return product
    .replace(/、/g, ' ')
    .replace(/，/g, ' ')
    .replace(/,/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

export function generateLeadWizardOutput(input: LeadWizardInput): LeadWizardOutput {
  const product = cleanValue(input.product, defaultLeadWizardInput.product);
  const country = cleanValue(input.country, defaultLeadWizardInput.country);
  const customerType = cleanValue(input.customerType, defaultLeadWizardInput.customerType);
  const searchProduct = normalizeProductForSearch(product);
  const quantity = Math.max(1, Math.min(500, Number.isFinite(input.quantity) ? input.quantity : defaultLeadWizardInput.quantity));

  const keywords = [
    `${country} ${searchProduct} ${customerType} contact email`,
    `${country} ${searchProduct} company LinkedIn`,
    `site:.${country.toLowerCase().includes('australia') ? 'au' : 'com'} ${searchProduct} contact`,
    `${country} ${searchProduct} importer supplier WhatsApp`,
    `${country} kitchen company builder designer joinery contact`,
    `${country} custom cabinets wardrobe door furniture manufacturer`,
  ];

  const channels = [
    `Google / Bing 搜索：先找官网和 Contact 页面，目标 ${quantity} 个候选结果。`,
    'LinkedIn：搜索公司页和 Owner / Procurement / Project / Design / Sourcing 联系人。',
    '官网表单：当邮箱或 WhatsApp 不完整时，优先通过 Contact 表单核验。',
    '行业目录：只作为辅助来源，必须回到官网或 LinkedIn 二次核验。',
  ];

  const verificationRules = [
    '官网域名、公司名和目标国家必须匹配，目录页和聚合页降低优先级。',
    '邮箱优先选择官网公开邮箱，个人邮箱需要 LinkedIn 或官网团队页佐证。',
    'WhatsApp / 电话需要带国家区号，并和官网、Google Business 或社媒页面一致。',
    'LinkedIn 公司页、项目案例、产品类型与目标客户类型越匹配，评分越高。',
    '没有官网、没有联系人、只有社媒帖子或只有目录页的结果先标记为待核验。',
  ];

  const outreachActions = [
    'A 级：官网、邮箱/电话、LinkedIn、业务匹配都完整，直接生成英文开发信。',
    'B 级：公司真实但联系人不完整，先用 LinkedIn 搜索 Owner / Procurement / Design 联系人。',
    'C 级：联系方式缺失，先通过官网表单或公开电话核验，再进入 CRM。',
    'D 级：目录页、广告页、招聘页、无关社媒帖子，过滤或暂缓开发。',
  ];

  const priorityLogic = [
    `优先收集 ${Math.ceil(quantity * 0.4)} 个 A/B 级客户进入 CRM。`,
    `保留 ${Math.ceil(quantity * 0.3)} 个 C 级客户做补全核验。`,
    '每个客户至少记录来源链接、官网、国家、客户类型、联系方式状态和下一步动作。',
    '开发前先确认客户类型，再选择首次开发、二次跟进或报价邀请模板。',
  ];

  return {
    keywords,
    channels,
    verificationRules,
    outreachActions,
    priorityLogic,
  };
}

function isBrowser() {
  return typeof window !== 'undefined';
}

function getNowText() {
  return new Date().toLocaleString('zh-CN', { hour12: false });
}

function createTaskId() {
  return `lead-task-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`;
}

export function getLeadTaskStatusMeta(status: LeadTaskStatus) {
  return leadTaskStatusOptions.find((item) => item.value === status) ?? leadTaskStatusOptions[0];
}

export function loadSavedLeadTasks(): SavedLeadTask[] {
  if (!isBrowser()) return [];

  try {
    const raw = window.localStorage.getItem(LEAD_TASKS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as SavedLeadTask[];
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function findSavedLeadTask(taskId: string) {
  return loadSavedLeadTasks().find((task) => task.id === taskId) ?? null;
}

export function saveLeadTasks(tasks: SavedLeadTask[]) {
  if (!isBrowser()) return;
  window.localStorage.setItem(LEAD_TASKS_STORAGE_KEY, JSON.stringify(tasks));
}

export function createSavedLeadTask(input: LeadWizardInput, output: LeadWizardOutput): SavedLeadTask {
  const now = getNowText();
  const title = `${input.country || '目标市场'} - ${input.customerType || '客户类型'} - ${input.quantity || 0} 个`;

  return {
    id: createTaskId(),
    title,
    status: 'pending',
    input,
    output,
    createdAt: now,
    updatedAt: now,
  };
}

export function addSavedLeadTask(task: SavedLeadTask) {
  const tasks = loadSavedLeadTasks();
  const nextTasks = [task, ...tasks];
  saveLeadTasks(nextTasks);
  return nextTasks;
}

export function updateSavedLeadTaskStatus(taskId: string, status: LeadTaskStatus) {
  const tasks = loadSavedLeadTasks();
  const now = getNowText();
  const nextTasks = tasks.map((task) => (task.id === taskId ? { ...task, status, updatedAt: now } : task));
  saveLeadTasks(nextTasks);
  return nextTasks;
}

export function deleteSavedLeadTask(taskId: string) {
  const tasks = loadSavedLeadTasks();
  const nextTasks = tasks.filter((task) => task.id !== taskId);
  saveLeadTasks(nextTasks);
  return nextTasks;
}

export function buildLeadTaskExportText(task: SavedLeadTask) {
  return [
    `获客任务：${task.title}`,
    `状态：${getLeadTaskStatusMeta(task.status).label}`,
    `创建时间：${task.createdAt}`,
    '',
    '【任务输入】',
    `产品：${task.input.product}`,
    `国家：${task.input.country}`,
    `客户类型：${task.input.customerType}`,
    `目标数量：${task.input.quantity}`,
    '',
    '【搜索关键词】',
    ...task.output.keywords.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【推荐渠道】',
    ...task.output.channels.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【核验规则】',
    ...task.output.verificationRules.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【开发动作】',
    ...task.output.outreachActions.map((item, index) => `${index + 1}. ${item}`),
    '',
    '【优先级逻辑】',
    ...task.output.priorityLogic.map((item, index) => `${index + 1}. ${item}`),
  ].join('\n');
}

export function downloadLeadTaskText(task: SavedLeadTask) {
  if (!isBrowser()) return;

  const blob = new Blob([buildLeadTaskExportText(task)], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `${task.title.replace(/[\\/:*?"<>|]/g, '-')}.txt`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

export function generateLeadTaskExecutionPreview(task: SavedLeadTask): LeadTaskExecutionPreview {
  const country = task.input.country || 'Australia';
  const customerType = task.input.customerType || 'Kitchen Company';
  const product = task.input.product || 'custom cabinets';
  const keywordCount = task.output.keywords.length;
  const targetCount = Math.max(1, task.input.quantity);
  const discoveredCount = Math.max(6, Math.round(targetCount * 0.62));
  const filteredCount = Math.max(2, Math.round(discoveredCount * 0.28));
  const candidateCount = Math.max(4, discoveredCount - filteredCount);

  const steps: LeadTaskExecutionStep[] = [
    {
      id: 'keywords',
      title: '生成搜索关键词',
      status: 'completed',
      detail: `已生成 ${keywordCount} 组关键词，覆盖官网、LinkedIn、Importer、Builder 和 Contact 页面。`,
    },
    {
      id: 'search',
      title: '搜索官网与公开页面',
      status: task.status === 'draft' || task.status === 'pending' ? 'running' : 'completed',
      detail: `模拟搜索 ${country} 市场，发现 ${discoveredCount} 条公开结果。`,
    },
    {
      id: 'parse',
      title: '解析 Contact / About 页面',
      status: task.status === 'completed' ? 'completed' : 'running',
      detail: '提取公开邮箱、电话、WhatsApp、LinkedIn 和公司介绍线索。',
    },
    {
      id: 'verify',
      title: '真实性评分与风险过滤',
      status: task.status === 'completed' ? 'completed' : 'pending',
      detail: `过滤 ${filteredCount} 条目录页、招聘页、社媒噪音或信息缺失结果。`,
    },
    {
      id: 'deposit',
      title: '沉淀候选客户',
      status: task.status === 'completed' ? 'completed' : 'pending',
      detail: `预计沉淀 ${candidateCount} 个 A/B/C 级候选客户，等待加入客户池。`,
    },
  ];

  const logs: LeadTaskRunLog[] = [
    { time: '00:00', level: 'info', message: `任务启动：${task.title}` },
    { time: '00:03', level: 'success', message: `关键词生成完成：${keywordCount} 组搜索指令。` },
    { time: '00:07', level: 'info', message: `开始搜索 ${country} 市场公开页面。` },
    { time: '00:13', level: 'success', message: `发现 ${discoveredCount} 条公开结果，准备解析官网页面。` },
    { time: '00:18', level: 'warning', message: `过滤 ${filteredCount} 条低质量结果：目录页、招聘页或无联系方式页面。` },
    { time: '00:24', level: 'success', message: `生成 ${candidateCount} 个候选客户预览。` },
  ];

  const productLabel = product.split(/[、,，\s]+/).filter(Boolean)[0] ?? 'Custom';
  const candidates: LeadTaskCandidate[] = [
    {
      id: `${task.id}-candidate-1`,
      company: `${country} Premier Kitchens`,
      website: 'https://example-kitchens.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Sydney' : 'Los Angeles',
      customerType: 'Kitchen Company',
      contactStatus: '官网邮箱 + LinkedIn 已发现',
      score: 88,
      priority: 'A',
      recommendation: '优先开发，适合发送首次英文开发信。',
    },
    {
      id: `${task.id}-candidate-2`,
      company: `${productLabel} Design Studio`,
      website: 'https://example-design-studio.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Melbourne' : 'New York',
      customerType: 'Designer',
      contactStatus: '官网表单 + 电话已发现',
      score: 81,
      priority: 'A',
      recommendation: '先通过官网表单核验联系人，再进入 CRM。',
    },
    {
      id: `${task.id}-candidate-3`,
      company: `${country} Builder Supply Group`,
      website: 'https://example-builder-supply.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Brisbane' : 'Seattle',
      customerType: customerType.includes('Builder') ? 'Builder' : 'Importer',
      contactStatus: 'LinkedIn 公司页已发现，邮箱待补全',
      score: 73,
      priority: 'B',
      recommendation: '先搜索采购或项目负责人，再发送 LinkedIn 开场白。',
    },
    {
      id: `${task.id}-candidate-4`,
      company: `${country} Home Joinery Imports`,
      website: 'https://example-joinery-imports.com',
      country,
      city: country.toLowerCase().includes('australia') ? 'Perth' : 'Chicago',
      customerType: 'Importer',
      contactStatus: '电话已发现，WhatsApp 待核验',
      score: 66,
      priority: 'C',
      recommendation: '联系方式不完整，先核验官网电话和 WhatsApp 再开发。',
    },
  ];

  return { steps, logs, candidates };
}
