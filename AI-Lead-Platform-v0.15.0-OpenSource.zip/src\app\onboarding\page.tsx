import Link from 'next/link';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { onboardingChecklist, onboardingWorkflow, leadWizardPreview } from '@/lib/onboarding-workflow';
import {
  ArrowRight,
  CheckCircle2,
  ClipboardCheck,
  Compass,
  FileSpreadsheet,
  ListChecks,
  Search,
  Sparkles,
  Target,
} from 'lucide-react';

export default function OnboardingPage() {
  return (
    <MainLayout title="新手运营引导">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">v0.15.0</Badge>
            <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">新手运营引导中心</Badge>
          </div>
          <div className="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <h2 className="text-2xl font-semibold text-[#f8fafc]">第一次打开系统，就按这 6 步跑</h2>
              <p className="mt-2 max-w-3xl text-sm leading-6 text-[#94a3b8]">
                这页给外贸老板和运营团队看：先配置基础能力，再创建获客任务，沉淀候选客户，核验真实性，生成开发动作，最后进入 CRM 跟进和导出。
              </p>
            </div>
            <Button asChild className="bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/acquisition/search">
                开始获客任务
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </section>

        <section className="grid gap-4 md:grid-cols-3">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="flex items-center gap-4 p-5">
              <Compass className="h-9 w-9 text-blue-300" />
              <div>
                <p className="text-sm text-[#94a3b8]">运营步骤</p>
                <p className="mt-1 text-2xl font-semibold text-[#f8fafc]">{onboardingWorkflow.length} 步</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="flex items-center gap-4 p-5">
              <Search className="h-9 w-9 text-emerald-300" />
              <div>
                <p className="text-sm text-[#94a3b8]">示例搜索关键词</p>
                <p className="mt-1 text-2xl font-semibold text-[#f8fafc]">{leadWizardPreview.generatedKeywords.length} 组</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardContent className="flex items-center gap-4 p-5">
              <ClipboardCheck className="h-9 w-9 text-amber-300" />
              <div>
                <p className="text-sm text-[#94a3b8]">检查清单</p>
                <p className="mt-1 text-2xl font-semibold text-[#f8fafc]">{onboardingChecklist.length} 项</p>
              </div>
            </CardContent>
          </Card>
        </section>

        <Card className="border-[#2d3548] bg-[#121823]">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
              <ListChecks className="h-5 w-5 text-blue-300" />
              外贸获客运营流程
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 lg:grid-cols-2">
              {onboardingWorkflow.map((item) => (
                <div key={item.step} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg border border-blue-500/25 bg-blue-500/15 text-sm font-semibold text-blue-300">
                        {item.step}
                      </div>
                      <div>
                        <h3 className="font-medium text-[#f8fafc]">{item.title}</h3>
                        <p className="mt-1 text-xs text-[#64748b]">负责人：{item.owner}</p>
                      </div>
                    </div>
                    <Button asChild variant="outline" className="h-9 border-[#2d3548] bg-transparent text-[#cbd5e1] hover:bg-[#1a1f2c]">
                      <Link href={item.href}>
                        {item.action}
                      </Link>
                    </Button>
                  </div>
                  <p className="mt-4 text-sm leading-6 text-[#94a3b8]">{item.description}</p>
                  <div className="mt-3 rounded-lg border border-[#2d3548] bg-[#121823] p-3">
                    <p className="text-xs text-[#64748b]">系统产出</p>
                    <p className="mt-1 text-sm leading-6 text-[#cbd5e1]">{item.output}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <section className="grid gap-4 xl:grid-cols-[1fr_360px]">
          <Card className="border-[#2d3548] bg-[#121823]">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                <Sparkles className="h-5 w-5 text-emerald-300" />
                轻量获客任务向导预览
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                  <p className="text-xs text-[#64748b]">产品</p>
                  <p className="mt-1 text-sm leading-6 text-[#f8fafc]">{leadWizardPreview.product}</p>
                </div>
                <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                  <p className="text-xs text-[#64748b]">目标国家</p>
                  <p className="mt-1 text-sm text-[#f8fafc]">{leadWizardPreview.country}</p>
                </div>
                <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                  <p className="text-xs text-[#64748b]">客户类型</p>
                  <p className="mt-1 text-sm leading-6 text-[#f8fafc]">{leadWizardPreview.customerType}</p>
                </div>
                <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                  <p className="text-xs text-[#64748b]">目标数量</p>
                  <p className="mt-1 text-sm text-[#f8fafc]">{leadWizardPreview.quantity} 个候选客户</p>
                </div>
              </div>

              <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                <div className="mb-3 flex items-center gap-2">
                  <Target className="h-4 w-4 text-blue-300" />
                  <h3 className="font-medium text-[#f8fafc]">系统自动生成的搜索关键词</h3>
                </div>
                <div className="grid gap-2 md:grid-cols-2">
                  {leadWizardPreview.generatedKeywords.map((keyword) => (
                    <div key={keyword} className="rounded-md border border-[#2d3548] bg-[#121823] px-3 py-2 text-sm text-[#cbd5e1]">
                      {keyword}
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid gap-3 md:grid-cols-2">
                <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                  <p className="mb-3 text-sm font-medium text-[#f8fafc]">推荐渠道</p>
                  <div className="flex flex-wrap gap-2">
                    {leadWizardPreview.recommendedChannels.map((channel) => (
                      <Badge key={channel} className="border-blue-500/25 bg-blue-500/15 text-blue-300">
                        {channel}
                      </Badge>
                    ))}
                  </div>
                </div>
                <div className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                  <p className="mb-3 text-sm font-medium text-[#f8fafc]">下一步动作</p>
                  <div className="space-y-2">
                    {leadWizardPreview.nextActions.map((action) => (
                      <div key={action} className="flex gap-2 text-sm leading-6 text-[#94a3b8]">
                        <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-300" />
                        {action}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                  <FileSpreadsheet className="h-5 w-5 text-violet-300" />
                  新手检查清单
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {onboardingChecklist.map((item, index) => (
                  <div key={item} className="flex gap-3 rounded-lg border border-[#2d3548] bg-[#0f1419] p-3">
                    <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-emerald-500/15 text-xs font-semibold text-emerald-300">
                      {index + 1}
                    </div>
                    <p className="text-sm leading-6 text-[#cbd5e1]">{item}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardContent className="space-y-3 p-4">
                <p className="font-medium text-[#f8fafc]">下一版可以继续做什么？</p>
                <p className="text-sm leading-6 text-[#94a3b8]">
                  v0.16 可以把这里的向导升级成真正可填写表单：输入产品、国家、客户类型和数量后，生成任务并进入候选客户池。
                </p>
                <Button asChild className="w-full bg-blue-600 text-white hover:bg-blue-500">
                  <Link href="/acquisition/search">
                    进入智能搜索
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </div>
    </MainLayout>
  );
}
