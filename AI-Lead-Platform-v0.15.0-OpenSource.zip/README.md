# AI智能获客平台

AI智能获客平台是一个面向外贸企业的开源 SaaS 原型，目标是把客户搜索、线索核验、联系方式补全、英文开发信生成和 CRM 跟进集中到一个工作台里。

当前版本：`v0.15.0`

## 核心模块

- 仪表盘：展示客户、线索、商机、待办、转化率和 AI 推荐跟进。
- 版本体验：展示当前版本、登录方式、重点检查页面、演示账号和上传备注。
- 新手引导：展示外贸老板第一次使用系统的配置、获客、核验、开发和 CRM 跟进流程。
- AI获客中心：预留智能搜索、高级搜客、线索发现、批量开发、多渠道获客等入口。
- 社媒线索：预留 LinkedIn、Facebook、TikTok 公开线索入口。
- 客户管理：客户列表、公海池、客户分类看板。
- 营销中心：邮件营销、WhatsApp、社媒营销和自动化流程。
- 数据分析：客户分析、销售分析和获客效率分析。
- 团队权限：团队成员、角色矩阵、数据范围和 SaaS 权限说明。
- 系统设置：API Key、团队、系统参数、额度和数据隔离。

## v0.15 更新

- 新增新手运营引导中心 `/onboarding`，把外贸获客 SaaS 的使用路径整理成 6 步流程。
- 增加轻量获客任务向导预览，展示产品、国家、客户类型、数量如何生成关键词和推荐渠道。
- 版本体验中心同步更新为 v0.15.0，并将新手引导列为重点查看页面。
- 侧边栏新增“新手引导”入口，方便非技术用户第一次进入系统就知道怎么操作。

## v0.14 更新

- 新增版本体验中心 `/release`，集中展示当前版本、登录地址、重点查看页面、上传包名称和 GitHub 备注。
- 登录页增加老板、管理员、销售、运营四种演示身份说明，方便非技术用户理解 SaaS 权限视角。
- 侧边栏新增“版本体验”入口，部署后可以直接检查本次升级效果。
- 增加 v0.14.0 设计文档和实施计划，方便开源项目继续迭代。

## v0.13 更新

- 新增统一团队权限数据层，集中维护老板、管理员、销售、运营四类角色。
- 重写团队管理页，展示成员列表、邀请预览、工作量、客户数和角色说明。
- 重写权限矩阵页，展示客户数据、获客任务、营销跟进、数据导出、团队设置、套餐安全等权限。
- 重写团队设置页，形成 SaaS 团队设置入口，连接成员管理和权限矩阵。
- 修复工作空间信息乱码，并将团队人数额度更新到 v0.13 演示状态。

## v0.12 更新

- 增加 SaaS 工作空间模型，预留 `workspaceId` 作为后续多租户数据隔离基础。
- 顶部栏和侧边栏显示当前工作空间、套餐和演示/正式模式。
- 仪表盘增加 SaaS 状态卡，展示当前公司、搜索额度、API 配置状态和数据隔离说明。
- 系统设置页升级为 SaaS 控制台雏形，包含公司工作空间、当前套餐、使用额度、API 状态和数据隔离卡片。
- 保留演示模式和 Supabase 正式登录接口，后续可接入真实账号、团队成员和权限系统。

## v0.11 更新

- 修复登录页、侧边栏、仪表盘首屏中文乱码。
- 优化演示模式入口，没有 Supabase 配置也能进入工作台查看效果。
- 重写仪表盘演示数据，让推荐理由、跟进建议和最近动态更贴近外贸获客场景。
- 修复网页标题和 README 乱码。
- 保留 Supabase 正式账号登录接口，后续配置数据库后可以继续接入正式登录。

## 预留获客 API

```text
POST /api/integrations/lead-search
```

请求示例：

```json
{
  "product": "custom cabinets",
  "country": "Australia",
  "customerType": "Builder + Designer",
  "quantity": 20,
  "provider": "auto",
  "query": "Australia custom cabinets builder contact"
}
```

当前默认使用 mock provider，方便开源项目直接运行。后续接入 Google、SerpAPI、Bing 或其他数据服务时，可以替换 `src/lib/integrations/lead-search-provider.ts` 中的实现。

## 预留 OpenAI API

```text
POST /api/integrations/openai
```

请求示例：

```json
{
  "task": "write_email",
  "prompt": "Write a short English outreach email for an Australian kitchen company.",
  "context": {
    "product": "custom cabinets",
    "customerType": "Kitchen Company"
  }
}
```

没有配置 `OPENAI_API_KEY` 时接口会返回 mock 内容；配置后可以在 `src/lib/integrations/openai-provider.ts` 中接入真实 OpenAI SDK 或 HTTP API。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://localhost:5000
```

## 检查代码

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 环境变量

复制 `.env.example` 为 `.env.local`，按需填写：

```text
OPENAI_API_KEY=
LEAD_SEARCH_API_KEY=
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```
