# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进和英文开发动作。

当前版本：`v0.21.0`

## v0.21.0 更新

- 新增 CRM 客户详情页 `/crm-customers/[id]`。
- 支持邮件、WhatsApp、LinkedIn、电话和内部备注跟进时间线。
- 支持设置 CRM 阶段、下一步动作和下次跟进时间。
- 为每个客户生成纯英文开发信和 WhatsApp 开场白，支持一键复制。
- 修复 CRM 客户池和版本体验中心的中文乱码。

客户与跟进记录目前保存在浏览器本地；更换设备或清理浏览器数据后不会自动同步。

## 核心流程

1. 在 `/lead-wizard` 输入产品、国家、客户类型和数量，保存获客任务。
2. 在 `/lead-tasks` 进入任务执行台，把结果沉淀到候选客户池。
3. 在 `/candidate-leads` 核验并筛选客户，把合适客户加入 CRM。
4. 在 `/crm-customers` 查看客户阶段，并进入客户详情持续跟进。
5. 在客户详情记录联系结果，安排下次行动并复制英文开发文案。

## 预留接口

获客搜索：

```text
POST /api/integrations/lead-search
```

OpenAI：

```text
POST /api/integrations/openai
```

没有配置 API Key 时接口返回演示内容，方便开源项目直接运行。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

点击“演示模式进入工作台”即可查看。

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 环境变量

复制 `.env.example` 为 `.env.local`，按需填写：

```text
OPENAI_API_KEY=
LEAD_SEARCH_API_KEY=
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

## 开源协议

MIT
