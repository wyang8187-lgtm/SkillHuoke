'use client';

import Link from 'next/link';
import { useParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { MainLayout } from '@/components/layout';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  addSavedCrmFollowUp,
  crmCustomerStatusOptions,
  crmFollowUpChannelOptions,
  deleteSavedCrmFollowUp,
  generateCustomerOutreachCopy,
  getCrmCustomerStatusMeta,
  getSavedCrmCustomer,
  loadSavedCrmFollowUps,
  updateSavedCrmCustomer,
  type CrmCustomerStatus,
  type CrmFollowUpChannel,
  type SavedCrmCustomer,
  type SavedCrmFollowUp,
} from '@/lib/lead-wizard';
import {
  ArrowLeft,
  Building2,
  CalendarClock,
  Check,
  Clipboard,
  ExternalLink,
  Mail,
  MessageCircle,
  Phone,
  Send,
  Trash2,
} from 'lucide-react';

const channelIcons = {
  email: Mail,
  whatsapp: MessageCircle,
  linkedin: Send,
  phone: Phone,
  note: Clipboard,
};

function toLocalDateTimeInput(date = new Date()) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60_000).toISOString().slice(0, 16);
}

export default function CrmCustomerDetailPage() {
  const params = useParams<{ id: string }>();
  const customerId = decodeURIComponent(params.id);
  const [customer, setCustomer] = useState<SavedCrmCustomer>();
  const [followUps, setFollowUps] = useState<SavedCrmFollowUp[]>([]);
  const [channel, setChannel] = useState<CrmFollowUpChannel>('email');
  const [content, setContent] = useState('');
  const [contactedAt, setContactedAt] = useState(() => toLocalDateTimeInput());
  const [error, setError] = useState('');
  const [copied, setCopied] = useState('');

  const refresh = () => {
    setCustomer(getSavedCrmCustomer(customerId));
    setFollowUps(loadSavedCrmFollowUps().filter((item) => item.customerId === customerId));
  };

  useEffect(() => {
    refresh();
    // customerId is the only external value used by refresh.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerId]);

  const outreach = useMemo(
    () => (customer ? generateCustomerOutreachCopy(customer) : undefined),
    [customer]
  );

  const updateCustomer = (
    patch: Partial<Pick<SavedCrmCustomer, 'status' | 'note' | 'nextAction' | 'nextFollowUpAt'>>
  ) => {
    updateSavedCrmCustomer(customerId, patch);
    refresh();
  };

  const addFollowUp = () => {
    if (!content.trim()) {
      setError('请填写本次跟进内容。');
      return;
    }
    addSavedCrmFollowUp(customerId, {
      channel,
      content,
      contactedAt: new Date(contactedAt).toISOString(),
    });
    setContent('');
    setContactedAt(toLocalDateTimeInput());
    setError('');
    refresh();
  };

  const copyText = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      window.setTimeout(() => setCopied(''), 1800);
    } catch {
      setError('复制失败，请手动选择文字复制。');
    }
  };

  if (!customer) {
    return (
      <MainLayout title="客户详情">
        <Card className="border-[#2d3548] bg-[#121823]">
          <CardContent className="p-10 text-center">
            <Building2 className="mx-auto h-10 w-10 text-[#64748b]" />
            <h2 className="mt-4 text-xl font-semibold text-[#f8fafc]">没有找到这个客户</h2>
            <p className="mt-2 text-sm text-[#94a3b8]">客户可能已被删除，或者当前浏览器还没有保存该客户。</p>
            <Button asChild className="mt-6 bg-blue-600 text-white hover:bg-blue-500">
              <Link href="/crm-customers">返回 CRM 客户池</Link>
            </Button>
          </CardContent>
        </Card>
      </MainLayout>
    );
  }

  const status = getCrmCustomerStatusMeta(customer.status);

  return (
    <MainLayout title="客户跟进中心">
      <div className="space-y-6">
        <section className="rounded-lg border border-[#2d3548] bg-[#121823] p-6">
          <Link href="/crm-customers" className="inline-flex items-center text-sm text-blue-300 hover:text-blue-200">
            <ArrowLeft className="mr-2 h-4 w-4" />
            返回 CRM 客户池
          </Link>
          <div className="mt-5 flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <Badge className={`border ${status.className}`}>{status.label}</Badge>
                <Badge className="border-blue-500/25 bg-blue-500/15 text-blue-300">{customer.priority} 级客户</Badge>
                <Badge className="border-emerald-500/25 bg-emerald-500/15 text-emerald-300">{customer.score} 分</Badge>
              </div>
              <h2 className="mt-3 text-2xl font-semibold text-[#f8fafc]">{customer.company}</h2>
              <p className="mt-2 text-sm text-[#94a3b8]">{customer.country} / {customer.city} · {customer.customerType}</p>
            </div>
            {customer.website ? (
              <Button asChild variant="outline" className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]">
                <a href={customer.website} target="_blank" rel="noreferrer">
                  打开公司官网
                  <ExternalLink className="ml-2 h-4 w-4" />
                </a>
              </Button>
            ) : null}
          </div>
        </section>

        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.35fr)_minmax(340px,0.65fr)]">
          <div className="space-y-6">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="text-[#f8fafc]">客户资料</CardTitle>
              </CardHeader>
              <CardContent className="grid gap-4 sm:grid-cols-2">
                {[
                  ['官网', customer.website || '待补全'],
                  ['联系方式', customer.contactStatus || '待核验'],
                  ['客户类型', customer.customerType],
                  ['来源任务', customer.sourceTaskTitle],
                ].map(([label, value]) => (
                  <div key={label} className="rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                    <p className="text-xs text-[#64748b]">{label}</p>
                    <p className="mt-2 break-words text-sm text-[#cbd5e1]">{value}</p>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="text-[#f8fafc]">新增跟进记录</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 sm:grid-cols-2">
                  <Select value={channel} onValueChange={(value) => setChannel(value as CrmFollowUpChannel)}>
                    <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {crmFollowUpChannelOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Input
                    type="datetime-local"
                    value={contactedAt}
                    onChange={(event) => setContactedAt(event.target.value)}
                    className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                  />
                </div>
                <Textarea
                  value={content}
                  onChange={(event) => setContent(event.target.value)}
                  placeholder="例如：已通过 WhatsApp 发送产品目录，对方希望下周查看报价。"
                  className="min-h-28 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                />
                {error ? <p className="text-sm text-red-300">{error}</p> : null}
                <Button type="button" onClick={addFollowUp} className="bg-blue-600 text-white hover:bg-blue-500">
                  <Send className="mr-2 h-4 w-4" />
                  保存跟进记录
                </Button>
              </CardContent>
            </Card>

            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="text-[#f8fafc]">跟进时间线</CardTitle>
              </CardHeader>
              <CardContent>
                {followUps.length === 0 ? (
                  <p className="rounded-lg border border-dashed border-[#2d3548] bg-[#0f1419] p-6 text-center text-sm text-[#94a3b8]">
                    还没有跟进记录。完成首次联系后，把结果记录在这里。
                  </p>
                ) : (
                  <div className="space-y-3">
                    {followUps.map((item) => {
                      const Icon = channelIcons[item.channel];
                      const channelLabel = crmFollowUpChannelOptions.find((option) => option.value === item.channel)?.label;
                      return (
                        <div key={item.id} className="flex gap-3 rounded-lg border border-[#2d3548] bg-[#0f1419] p-4">
                          <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-blue-500/15 text-blue-300">
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <p className="text-sm font-medium text-[#f8fafc]">{channelLabel}</p>
                              <p className="text-xs text-[#64748b]">{new Date(item.contactedAt).toLocaleString('zh-CN')}</p>
                            </div>
                            <p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-[#cbd5e1]">{item.content}</p>
                          </div>
                          <Button
                            type="button"
                            size="icon"
                            variant="ghost"
                            className="shrink-0 text-[#64748b] hover:text-red-300"
                            title="删除记录"
                            onClick={() => {
                              setFollowUps(deleteSavedCrmFollowUp(item.id).filter((entry) => entry.customerId === customerId));
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      );
                    })}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="border-[#2d3548] bg-[#121823]">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                  <CalendarClock className="h-5 w-5 text-amber-300" />
                  跟进安排
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="mb-2 block text-sm text-[#cbd5e1]">CRM 阶段</label>
                  <Select value={customer.status} onValueChange={(value) => updateCustomer({ status: value as CrmCustomerStatus })}>
                    <SelectTrigger className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {crmCustomerStatusOptions.map((option) => (
                        <SelectItem key={option.value} value={option.value}>{option.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="mb-2 block text-sm text-[#cbd5e1]">下次跟进时间</label>
                  <Input
                    type="datetime-local"
                    value={customer.nextFollowUpAt || ''}
                    onChange={(event) => updateCustomer({ nextFollowUpAt: event.target.value })}
                    className="border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                  />
                </div>
                <div>
                  <label className="mb-2 block text-sm text-[#cbd5e1]">下一步动作</label>
                  <Textarea
                    value={customer.nextAction}
                    onChange={(event) => updateCustomer({ nextAction: event.target.value })}
                    className="min-h-24 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                  />
                </div>
                <div>
                  <label className="mb-2 block text-sm text-[#cbd5e1]">客户备注</label>
                  <Textarea
                    value={customer.note}
                    onChange={(event) => updateCustomer({ note: event.target.value })}
                    className="min-h-24 border-[#2d3548] bg-[#0f1419] text-[#f8fafc]"
                  />
                </div>
              </CardContent>
            </Card>

            {outreach ? (
              <>
                <Card className="border-[#2d3548] bg-[#121823]">
                  <CardHeader className="flex-row items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                      <Mail className="h-5 w-5 text-blue-300" />
                      英文开发信
                    </CardTitle>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="border-[#2d3548] bg-[#0f1419] text-[#cbd5e1]"
                      onClick={() => copyText('email', `Subject: ${outreach.emailSubject}\n\n${outreach.emailBody}`)}
                    >
                      {copied === 'email' ? <Check className="mr-2 h-4 w-4" /> : <Clipboard className="mr-2 h-4 w-4" />}
                      {copied === 'email' ? '已复制' : '复制'}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm font-medium text-blue-300">Subject: {outreach.emailSubject}</p>
                    <p className="mt-4 whitespace-pre-wrap text-sm leading-6 text-[#cbd5e1]">{outreach.emailBody}</p>
                  </CardContent>
                </Card>

                <Card className="border-[#2d3548] bg-[#121823]">
                  <CardHeader className="flex-row items-center justify-between">
                    <CardTitle className="flex items-center gap-2 text-[#f8fafc]">
                      <MessageCircle className="h-5 w-5 text-emerald-300" />
                      WhatsApp 开场白
                    </CardTitle>
                    <Button
                      type="button"
                      size="sm"
                      variant="outline"
                      className="border-[#2d3548] bg-[#0f1419] text-[#cbd5e1]"
                      onClick={() => copyText('whatsapp', outreach.whatsappMessage)}
                    >
                      {copied === 'whatsapp' ? <Check className="mr-2 h-4 w-4" /> : <Clipboard className="mr-2 h-4 w-4" />}
                      {copied === 'whatsapp' ? '已复制' : '复制'}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm leading-6 text-[#cbd5e1]">{outreach.whatsappMessage}</p>
                  </CardContent>
                </Card>
              </>
            ) : null}
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
