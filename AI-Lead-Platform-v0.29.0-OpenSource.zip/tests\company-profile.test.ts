import assert from 'node:assert/strict';
import {
  createDefaultCompanyProfile,
  normalizeCompanyProfile,
  validateCompanyProfile,
} from '../src/lib/company-profile';

const defaults = createDefaultCompanyProfile();

assert.equal(defaults.companyNameEn, 'SkillHuoke Export');
assert.equal(defaults.defaultCurrency, 'USD');
assert.equal(defaults.defaultValidityDays, 30);
assert.equal(defaults.showBankDetails, false);

const normalized = normalizeCompanyProfile({
  ...defaults,
  companyNameEn: '  M.Y. Design  ',
  website: 'mydesign.example.com/',
  defaultValidityDays: 999,
});

assert.equal(normalized.companyNameEn, 'M.Y. Design');
assert.equal(normalized.website, 'https://mydesign.example.com');
assert.equal(normalized.defaultValidityDays, 365);

assert.deepEqual(validateCompanyProfile({ ...defaults, companyNameEn: '' }), ['请填写英文公司名称。']);
assert.deepEqual(
  validateCompanyProfile({ ...defaults, showBankDetails: true, bankAccountNumber: '' }),
  ['启用银行信息后，请填写银行账号。'],
);

console.log('company-profile tests passed');
