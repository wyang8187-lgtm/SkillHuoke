import type { OpportunityCurrency } from './crm-opportunities';
import type { QuotationLanguage, TradeTerm } from './crm-quotations';

export const COMPANY_PROFILE_STORAGE_KEY = 'skillhuoke_company_profile_v029';
export const MAX_LOGO_FILE_SIZE = 1024 * 1024;

export interface CompanyProfile {
  companyNameZh: string;
  companyNameEn: string;
  addressZh: string;
  addressEn: string;
  phone: string;
  email: string;
  website: string;
  logoDataUrl: string;
  bankName: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankSwift: string;
  bankAddress: string;
  showBankDetails: boolean;
  defaultCurrency: OpportunityCurrency;
  defaultTradeTerm: TradeTerm;
  defaultPaymentTerms: string;
  defaultDeliveryTime: string;
  defaultValidityDays: number;
  defaultLanguage: QuotationLanguage;
  updatedAt: string;
}

export function createDefaultCompanyProfile(): CompanyProfile {
  return {
    companyNameZh: 'SkillHuoke 外贸获客',
    companyNameEn: 'SkillHuoke Export',
    addressZh: '',
    addressEn: '',
    phone: '',
    email: '',
    website: '',
    logoDataUrl: '',
    bankName: '',
    bankAccountName: '',
    bankAccountNumber: '',
    bankSwift: '',
    bankAddress: '',
    showBankDetails: false,
    defaultCurrency: 'USD',
    defaultTradeTerm: 'FOB',
    defaultPaymentTerms: '30% deposit, 70% before shipment',
    defaultDeliveryTime: '30-45 days',
    defaultValidityDays: 30,
    defaultLanguage: 'en',
    updatedAt: '',
  };
}

function cleanWebsite(value: string) {
  const trimmed = value.trim().replace(/\/+$/, '');
  if (!trimmed) return '';
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

export function normalizeCompanyProfile(value: Partial<CompanyProfile>): CompanyProfile {
  const defaults = createDefaultCompanyProfile();
  const profile = { ...defaults, ...value };
  const validity = Number(profile.defaultValidityDays);
  return {
    ...profile,
    companyNameZh: profile.companyNameZh.trim(),
    companyNameEn: profile.companyNameEn.trim(),
    addressZh: profile.addressZh.trim(),
    addressEn: profile.addressEn.trim(),
    phone: profile.phone.trim(),
    email: profile.email.trim(),
    website: cleanWebsite(profile.website),
    bankName: profile.bankName.trim(),
    bankAccountName: profile.bankAccountName.trim(),
    bankAccountNumber: profile.bankAccountNumber.trim(),
    bankSwift: profile.bankSwift.trim().toUpperCase(),
    bankAddress: profile.bankAddress.trim(),
    defaultPaymentTerms: profile.defaultPaymentTerms.trim(),
    defaultDeliveryTime: profile.defaultDeliveryTime.trim(),
    defaultValidityDays: Math.min(365, Math.max(1, Number.isFinite(validity) ? Math.round(validity) : 30)),
  };
}

export function validateCompanyProfile(value: CompanyProfile) {
  const errors: string[] = [];
  if (!value.companyNameEn.trim()) errors.push('请填写英文公司名称。');
  if (value.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.email)) errors.push('公司邮箱格式不正确。');
  if (value.showBankDetails && !value.bankAccountNumber.trim()) errors.push('启用银行信息后，请填写银行账号。');
  return errors;
}

export function loadCompanyProfile(): CompanyProfile {
  if (typeof window === 'undefined') return createDefaultCompanyProfile();
  try {
    const raw = window.localStorage.getItem(COMPANY_PROFILE_STORAGE_KEY);
    return raw ? normalizeCompanyProfile(JSON.parse(raw) as Partial<CompanyProfile>) : createDefaultCompanyProfile();
  } catch {
    return createDefaultCompanyProfile();
  }
}

export function saveCompanyProfile(value: CompanyProfile) {
  const profile = normalizeCompanyProfile({ ...value, updatedAt: new Date().toISOString() });
  if (typeof window !== 'undefined') window.localStorage.setItem(COMPANY_PROFILE_STORAGE_KEY, JSON.stringify(profile));
  return profile;
}

export function resetCompanyProfile() {
  const profile = createDefaultCompanyProfile();
  if (typeof window !== 'undefined') window.localStorage.removeItem(COMPANY_PROFILE_STORAGE_KEY);
  return profile;
}

export async function resizeCompanyLogo(file: File): Promise<string> {
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type)) throw new Error('仅支持 PNG、JPEG 或 WebP 图片。');
  if (file.size > MAX_LOGO_FILE_SIZE) throw new Error('Logo 文件不能超过 1 MB。');

  const source = URL.createObjectURL(file);
  try {
    const image = new Image();
    await new Promise<void>((resolve, reject) => {
      image.onload = () => resolve();
      image.onerror = () => reject(new Error('无法读取 Logo 图片。'));
      image.src = source;
    });
    const scale = Math.min(1, 600 / Math.max(image.naturalWidth, image.naturalHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
    canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
    const context = canvas.getContext('2d');
    if (!context) throw new Error('浏览器无法处理 Logo 图片。');
    context.drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/webp', 0.86);
  } finally {
    URL.revokeObjectURL(source);
  }
}
