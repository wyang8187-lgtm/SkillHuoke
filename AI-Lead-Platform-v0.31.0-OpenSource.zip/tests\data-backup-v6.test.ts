import assert from 'node:assert/strict';
import { parseBackupFile } from '../src/lib/data-backup';
const base={leadTasks:[],candidateLeads:[],crmCustomers:[],crmFollowUps:[],crmOpportunities:[],crmQuotations:[],crmOrders:[]};
const v5=JSON.stringify({format:'skillhuoke-backup',version:5,appVersion:'v0.30.0',exportedAt:'2026-06-27T00:00:00.000Z',summary:{},data:base});
const old=parseBackupFile(v5,new Blob([v5]).size);
assert.equal(old.version,6);assert.deepEqual(old.data.tradeDocuments,[]);
const v6=JSON.stringify({format:'skillhuoke-backup',version:6,appVersion:'v0.31.0',exportedAt:'2026-06-27T00:00:00.000Z',summary:{},data:{...base,tradeDocuments:[{id:'doc-1',updatedAt:'2026-06-27T00:00:00.000Z'}]}});
assert.equal(parseBackupFile(v6,new Blob([v6]).size).data.tradeDocuments[0].id,'doc-1');
console.log('data-backup-v6 tests passed');
