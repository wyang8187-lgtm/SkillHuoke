# AI 智能获客平台

面向外贸企业的开源 SaaS 原型，覆盖获客任务、候选客户筛选、CRM 跟进和英文开发动作。

当前版本：`v0.23.0`

## v0.23.0 更新

- 新增 `/crm-follow-ups` 今日跟进工作队列。
- 自动分类逾期、今天、未来和未安排客户。
- 支持按 CRM 阶段和 A/B/C 优先级筛选。
- 支持快速延期到明天、三天后、下周或自定义时间。
- 完成跟进后写入内部记录并清空本次提醒。

客户与跟进记录目前保存在浏览器本地；更换设备或清理浏览器数据后不会自动同步。

## 核心流程

1. 在 `/lead-wizard` 输入产品、国家、客户类型和数量，保存获客任务。
2. 在 `/lead-tasks` 进入任务执行台，把结果沉淀到候选客户池。
3. 在 `/candidate-leads` 核验并筛选客户，把合适客户加入 CRM。
4. 在 `/crm-customers` 查看客户阶段，并进入客户详情持续跟进。
5. 在客户详情记录联系结果，安排下次行动并复制英文开发文案。

## 预留接口

获客搜索：

```text
POST /api/integrations/lead-search
```

OpenAI：

```text
POST /api/integrations/openai
```

没有配置 API Key 时接口返回演示内容，方便开源项目直接运行。

## 快速开始

```bash
corepack pnpm install --frozen-lockfile
corepack pnpm run dev
```

打开：

```text
http://127.0.0.1:5000/login
```

点击“演示模式进入工作台”即可查看。

## 代码检查

```bash
corepack pnpm run ts-check
corepack pnpm run lint:build
corepack pnpm run build
```

## 环境变量

复制 `.env.example` 为 `.env.local`，按需填写：

```text
OPENAI_API_KEY=
OPENAI_MODEL=gpt-5.4-mini
LEAD_SEARCH_API_KEY=
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
```

## 开源协议

MIT
