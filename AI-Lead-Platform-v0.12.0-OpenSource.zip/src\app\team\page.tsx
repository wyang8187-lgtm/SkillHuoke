'use client';

import React, { useState, useEffect } from 'react';
import { MainLayout } from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Users as TeamIcon,
  User,
  UserPlus,
  Mail,
  Settings,
  Shield,
  Eye,
  Edit,
  Trash2,
  Search,
  TrendingUp,
  Target,
  CheckCircle,
  Clock,
} from 'lucide-react';
import { initData, getData, STORAGE_KEYS } from '@/lib/mock-data';
import type { TeamMember, Customer, Task, Opportunity } from '@/types';

// 成员业绩卡片
function MemberPerformanceCard({ member, customers, tasks, opportunities }: {
  member: TeamMember;
  customers: Customer[];
  tasks: Task[];
  opportunities: Opportunity[];
}) {
  const memberCustomers = customers.filter(c => c.ownerId === member.id);
  const memberTasks = tasks.filter(t => t.userId === member.id);
  const memberOpportunities = opportunities.filter(o => o.ownerId === member.id);
  const wonOpportunities = memberOpportunities.filter(o => o.stage === '成交');
  const wonAmount = wonOpportunities.reduce((sum, o) => sum + o.amount, 0);

  return (
    <Card className="stat-card">
      <CardContent className="p-6">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 rounded-full bg-[#1a1f2c] border border-[#2d3548] flex items-center justify-center">
            <User className="h-6 w-6 text-[#94a3b8]" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-[#f8fafc] font-medium">{member.name}</h3>
              <Badge className={member.role === '管理员' ? 'status-badge-A' : 'status-badge-C'}>
                {member.role}
              </Badge>
              <Badge className={member.status === '在职' ? 'status-badge-A' : 'status-badge-D'}>
                {member.status}
              </Badge>
            </div>
            <p className="text-sm text-[#94a3b8]">{member.email}</p>
            
            <div className="grid grid-cols-4 gap-4 mt-4">
              <div className="text-center">
                <p className="text-xs text-[#94a3b8]">负责客户</p>
                <p className="text-lg font-bold text-[#f8fafc]">{memberCustomers.length}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#94a3b8]">成交商机</p>
                <p className="text-lg font-bold text-[#22c55e]">{wonOpportunities.length}</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#94a3b8]">成交金额</p>
                <p className="text-lg font-bold text-[#f97316]">{(wonAmount / 10000).toFixed(1)}万</p>
              </div>
              <div className="text-center">
                <p className="text-xs text-[#94a3b8]">待处理任务</p>
                <p className="text-lg font-bold text-[#3b82f6]">
                  {memberTasks.filter(t => t.status === '待完成').length}
                </p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function TeamPage() {
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [selectedRole, setSelectedRole] = useState<string>('');
  const [viewMode, setViewMode] = useState<'list' | 'performance'>('list');

  useEffect(() => {
    initData();
    setMembers(getData<TeamMember>(STORAGE_KEYS.teamMembers));
    setCustomers(getData<Customer>(STORAGE_KEYS.customers));
    setTasks(getData<Task>(STORAGE_KEYS.tasks));
    setOpportunities(getData<Opportunity>(STORAGE_KEYS.opportunities));
  }, []);

  const filteredMembers = members.filter(m => {
    if (searchKeyword && !m.name.includes(searchKeyword) && !m.email.includes(searchKeyword)) return false;
    if (selectedRole && m.role !== selectedRole) return false;
    return true;
  });

  const roleColors: Record<string, string> = {
    '管理员': '#22c55e',
    '销售经理': '#3b82f6',
    '销售员': '#f97316',
    '运营': '#8b5cf6',
  };

  // 团队总业绩
  const totalWon = opportunities.filter(o => o.stage === '成交').reduce((sum, o) => sum + o.amount, 0);
  const totalPipeline = opportunities.filter(o => o.stage !== '成交' && o.stage !== '输单').reduce((sum, o) => sum + o.amount, 0);

  return (
    <MainLayout title="团队管理">
      {/* 统计卡片 */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <TeamIcon className="h-6 w-6 text-[#3b82f6]" />
          <div>
            <p className="text-xs text-[#94a3b8]">团队成员</p>
            <p className="text-xl font-bold text-[#f8fafc]">{members.filter(m => m.status === '在职').length}</p>
          </div>
        </div>
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <TrendingUp className="h-6 w-6 text-[#22c55e]" />
          <div>
            <p className="text-xs text-[#94a3b8]">团队成交额</p>
            <p className="text-xl font-bold text-[#22c55e]">{(totalWon / 10000).toFixed(1)} 万</p>
          </div>
        </div>
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <Target className="h-6 w-6 text-[#f97316]" />
          <div>
            <p className="text-xs text-[#94a3b8]">管道金额</p>
            <p className="text-xl font-bold text-[#f97316]">{(totalPipeline / 10000).toFixed(1)} 万</p>
          </div>
        </div>
        <div className="p-4 bg-[#1a1f2c] rounded-lg border border-[#2d3548] flex items-center gap-3">
          <CheckCircle className="h-6 w-6 text-[#8b5cf6]" />
          <div>
            <p className="text-xs text-[#94a3b8]">人均客户数</p>
            <p className="text-xl font-bold text-[#8b5cf6]">
              {Math.round(customers.length / members.filter(m => m.status === '在职').length)}
            </p>
          </div>
        </div>
      </div>

      {/* 操作栏 */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex gap-2">
          <Button
            onClick={() => setViewMode('list')}
            className={viewMode === 'list' 
              ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
              : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
            }
          >
            <TeamIcon className="h-4 w-4 mr-2" />
            成员列表
          </Button>
          <Button
            onClick={() => setViewMode('performance')}
            className={viewMode === 'performance' 
              ? 'bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8] text-white' 
              : 'bg-[#1a1f2c] text-[#94a3b8] border border-[#2d3548]'
            }
          >
            <TrendingUp className="h-4 w-4 mr-2" />
            业绩看板
          </Button>
        </div>
        <Button className="bg-gradient-to-r from-[#3b82f6] to-[#1d4ed8]">
          <UserPlus className="h-4 w-4 mr-2" />
          添加成员
        </Button>
      </div>

      {/* 成员列表视图 */}
      {viewMode === 'list' && (
        <div className="flex flex-col md:flex-row gap-4 mb-4">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[#64748b]" />
            <Input
              placeholder="搜索成员..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              className="pl-12 h-12 bg-[#1a1f2c] border-[#2d3548] text-[#f8fafc]"
            />
          </div>
          <Button variant="outline" className="h-12 border-[#2d3548] text-[#94a3b8]">
            <Shield className="h-4 w-4 mr-2" />
            权限设置
          </Button>
        </div>
      )}

      {/* 列表视图 */}
      {viewMode === 'list' && (
        <Card className="stat-card">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="bg-[#1a1f2c] border-[#2d3548]">
                  <TableHead className="text-[#94a3b8]">成员</TableHead>
                  <TableHead className="text-[#94a3b8]">邮箱</TableHead>
                  <TableHead className="text-[#94a3b8]">角色</TableHead>
                  <TableHead className="text-[#94a3b8]">状态</TableHead>
                  <TableHead className="text-[#94a3b8]">负责客户</TableHead>
                  <TableHead className="text-[#94a3b8]">入职时间</TableHead>
                  <TableHead className="text-[#94a3b8]">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMembers.map((member) => (
                  <TableRow key={member.id} className="border-[#2d3548] hover:bg-[#1a1f2c]">
                    <TableCell className="text-[#f8fafc]">
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-[#1a1f2c] border border-[#2d3548] flex items-center justify-center">
                          <User className="h-4 w-4 text-[#94a3b8]" />
                        </div>
                        {member.name}
                      </div>
                    </TableCell>
                    <TableCell className="text-[#94a3b8]">{member.email}</TableCell>
                    <TableCell>
                      <Badge 
                        style={{
                          backgroundColor: `${roleColors[member.role]}20`,
                          color: roleColors[member.role],
                          border: `1px solid ${roleColors[member.role]}30`
                        }}
                      >
                        {member.role}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={member.status === '在职' ? 'status-badge-A' : 'status-badge-D'}>
                        {member.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-[#f8fafc]">
                      {customers.filter(c => c.ownerId === member.id).length}
                    </TableCell>
                    <TableCell className="text-[#64748b] text-xs">{member.createTime}</TableCell>
                    <TableCell>
                      <div className="flex gap-1">
                        <Button size="sm" variant="ghost" className="h-8 px-2 text-[#3b82f6]">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 px-2 text-[#94a3b8]">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="ghost" className="h-8 px-2 text-[#ef4444]">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}

      {/* 业绩看板视图 */}
      {viewMode === 'performance' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredMembers.filter(m => m.status === '在职').map((member) => (
            <MemberPerformanceCard 
              key={member.id}
              member={member}
              customers={customers}
              tasks={tasks}
              opportunities={opportunities}
            />
          ))}
        </div>
      )}
    </MainLayout>
  );
}