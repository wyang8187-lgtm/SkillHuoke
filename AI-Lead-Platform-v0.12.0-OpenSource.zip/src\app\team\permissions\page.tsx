'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Users,
  Shield,
  Eye,
  UserPlus,
  Edit,
  Ban,
  CheckCircle,
  Search,
  MoreHorizontal,
  Mail,
  Phone,
  Calendar,
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface TeamMember {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  role_name: string;
  status: string;
  avatar?: string;
  created_at: string;
  last_login?: string;
  customer_count: number;
  team: string;
}

interface RoleConfig {
  id: string;
  name: string;
  description: string;
  color: string;
  level: number;
}

interface Permission {
  id: string;
  name: string;
  category: string;
}

interface PermissionMatrix {
  admin: string[];
  team_leader: string[];
  sales: string[];
}

interface DataScope {
  role: string;
  scope: string;
  description: string;
  icon: string;
}

export default function TeamManagementPage() {
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [roles, setRoles] = useState<RoleConfig[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [permissionMatrix, setPermissionMatrix] = useState<PermissionMatrix | null>(null);
  const [dataScopes, setDataScopes] = useState<DataScope[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('sales');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      
      // 加载团队成员
      const membersRes = await fetch('/api/team/members');
      const membersData = await membersRes.json();
      if (membersData.success) {
        setMembers(membersData.data);
      }

      // 加载权限配置
      const permRes = await fetch('/api/team/permissions');
      const permData = await permRes.json();
      if (permData.success) {
        setRoles(permData.data.roles);
        setPermissions(permData.data.permissions);
        setPermissionMatrix(permData.data.permissionMatrix);
        setDataScopes(permData.data.dataScopes);
      }
    } catch (error) {
      console.error('加载失败:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInvite = async () => {
    if (!inviteEmail) return;
    
    try {
      const res = await fetch('/api/team/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'invite',
          email: inviteEmail,
          role: inviteRole,
        }),
      });
      
      const data = await res.json();
      if (data.success) {
        alert(`邀请邮件已发送至 ${inviteEmail}`);
        setInviteDialogOpen(false);
        setInviteEmail('');
        setInviteRole('sales');
      }
    } catch (error) {
      console.error('邀请失败:', error);
    }
  };

  const handleUpdateRole = async (memberId: string, newRole: string) => {
    try {
      const res = await fetch('/api/team/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update_role',
          member_id: memberId,
          role: newRole,
        }),
      });
      
      const data = await res.json();
      if (data.success) {
        alert('角色已更新');
        loadData();
      }
    } catch (error) {
      console.error('更新失败:', error);
    }
  };

  const handleUpdateStatus = async (memberId: string, newStatus: string) => {
    try {
      const res = await fetch('/api/team/members', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'update_status',
          member_id: memberId,
          status: newStatus,
        }),
      });
      
      const data = await res.json();
      if (data.success) {
        alert(newStatus === 'active' ? '账号已启用' : '账号已禁用');
        loadData();
      }
    } catch (error) {
      console.error('更新失败:', error);
    }
  };

  const filteredMembers = members.filter(member => {
    const matchesSearch = member.name.includes(searchTerm) || 
                          member.email.includes(searchTerm) ||
                          member.phone.includes(searchTerm);
    const matchesRole = filterRole === 'all' || member.role === filterRole;
    const matchesStatus = filterStatus === 'all' || member.status === filterStatus;
    return matchesSearch && matchesRole && matchesStatus;
  });

  const getRoleColor = (roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    return role?.color || '#6b7280';
  };

  const getRoleBadge = (roleId: string) => {
    const role = roles.find(r => r.id === roleId);
    return role?.name || roleId;
  };

  const categories = [...new Set(permissions.map(p => p.category))];

  return (
    <div className="p-6 space-y-6">
      {/* 页面标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[var(--text-primary)]">团队权限管理</h1>
          <p className="text-[var(--text-secondary)] mt-1">管理团队成员、角色权限和数据范围</p>
        </div>
        <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
          <DialogTrigger asChild>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <UserPlus className="w-4 h-4 mr-2" />
              邀请成员
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>邀请团队成员</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div>
                <label className="text-sm font-medium">邮箱地址</label>
                <Input
                  placeholder="输入成员邮箱"
                  value={inviteEmail}
                  onChange={(e) => setInviteEmail(e.target.value)}
                  className="mt-1"
                />
              </div>
              <div>
                <label className="text-sm font-medium">角色</label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map(role => (
                      <SelectItem key={role.id} value={role.id}>
                        <div className="flex items-center gap-2">
                          <div 
                            className="w-2 h-2 rounded-full" 
                            style={{ backgroundColor: role.color }}
                          />
                          {role.name}
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <Button 
                className="w-full bg-blue-600 hover:bg-blue-700"
                onClick={handleInvite}
              >
                发送邀请邮件
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="members">
        <TabsList className="bg-[var(--bg-card)]">
          <TabsTrigger value="members">
            <Users className="w-4 h-4 mr-2" />
            成员管理
          </TabsTrigger>
          <TabsTrigger value="permissions">
            <Shield className="w-4 h-4 mr-2" />
            权限矩阵
          </TabsTrigger>
          <TabsTrigger value="scopes">
            <Eye className="w-4 h-4 mr-2" />
            数据范围
          </TabsTrigger>
        </TabsList>

        {/* 成员管理 */}
        <TabsContent value="members" className="mt-4">
          <Card className="bg-[var(--bg-card)] border-[var(--border-color)]">
            <CardHeader>
              <div className="flex items-center gap-4">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--text-muted)]" />
                  <Input
                    placeholder="搜索成员姓名/邮箱/手机号"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9"
                  />
                </div>
                <Select value={filterRole} onValueChange={setFilterRole}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="角色筛选" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部角色</SelectItem>
                    {roles.map(role => (
                      <SelectItem key={role.id} value={role.id}>
                        {role.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-32">
                    <SelectValue placeholder="状态筛选" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部状态</SelectItem>
                    <SelectItem value="active">已启用</SelectItem>
                    <SelectItem value="disabled">已禁用</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow className="border-[var(--border-color)]">
                    <TableHead className="text-[var(--text-secondary)]">成员</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">联系方式</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">角色</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">团队</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">客户数</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">状态</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">最后登录</TableHead>
                    <TableHead className="text-[var(--text-secondary)]">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredMembers.map(member => (
                    <TableRow key={member.id} className="border-[var(--border-color)]">
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center text-white font-medium">
                            {member.name.charAt(0)}
                          </div>
                          <div>
                            <div className="font-medium text-[var(--text-primary)]">{member.name}</div>
                            <div className="text-sm text-[var(--text-muted)]">
                              <Calendar className="w-3 h-3 inline mr-1" />
                              {member.created_at}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="space-y-1">
                          <div className="flex items-center gap-1 text-sm text-[var(--text-secondary)]">
                            <Mail className="w-3 h-3" />
                            {member.email}
                          </div>
                          <div className="flex items-center gap-1 text-sm text-[var(--text-secondary)]">
                            <Phone className="w-3 h-3" />
                            {member.phone}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge 
                          style={{ backgroundColor: getRoleColor(member.role), color: 'white' }}
                          className="text-white"
                        >
                          {getRoleBadge(member.role)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[var(--text-secondary)]">
                        {member.team}
                      </TableCell>
                      <TableCell className="text-[var(--text-secondary)]">
                        {member.customer_count} 个
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={member.status === 'active' ? 'default' : 'secondary'}
                          className={cn(
                            member.status === 'active' 
                              ? 'bg-green-500/20 text-green-400' 
                              : 'bg-gray-500/20 text-gray-400'
                          )}
                        >
                          {member.status === 'active' ? '已启用' : '已禁用'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-[var(--text-muted)]">
                        {member.last_login || '-'}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 px-2">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>修改角色</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-4 pt-4">
                                <div className="text-sm text-[var(--text-secondary)]">
                                  成员: {member.name} ({member.email})
                                </div>
                                <div>
                                  <label className="text-sm font-medium">新角色</label>
                                  <Select 
                                    defaultValue={member.role}
                                    onValueChange={(newRole) => handleUpdateRole(member.id, newRole)}
                                  >
                                    <SelectTrigger className="mt-1">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      {roles.map(role => (
                                        <SelectItem key={role.id} value={role.id}>
                                          <div className="flex items-center gap-2">
                                            <div 
                                              className="w-2 h-2 rounded-full" 
                                              style={{ backgroundColor: role.color }}
                                            />
                                            {role.name} - {role.description}
                                          </div>
                                        </SelectItem>
                                      ))}
                                    </SelectContent>
                                  </Select>
                                </div>
                              </div>
                            </DialogContent>
                          </Dialog>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-8 px-2"
                            onClick={() => handleUpdateStatus(
                              member.id, 
                              member.status === 'active' ? 'disabled' : 'active'
                            )}
                          >
                            {member.status === 'active' ? (
                              <Ban className="w-4 h-4 text-red-400" />
                            ) : (
                              <CheckCircle className="w-4 h-4 text-green-400" />
                            )}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 权限矩阵 */}
        <TabsContent value="permissions" className="mt-4">
          <Card className="bg-[var(--bg-card)] border-[var(--border-color)]">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">功能权限矩阵</CardTitle>
              <p className="text-sm text-[var(--text-secondary)]">
                查看各角色拥有的功能权限
              </p>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* 角色标识 */}
                <div className="flex items-center gap-6 mb-4">
                  {roles.map(role => (
                    <div key={role.id} className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: role.color }}
                      />
                      <span className="text-[var(--text-secondary)]">{role.name}</span>
                    </div>
                  ))}
                </div>

                {/* 按类别分组展示权限 */}
                {categories.map(category => (
                  <div key={category} className="border-t border-[var(--border-color)] pt-4">
                    <div className="text-sm font-medium text-[var(--text-secondary)] mb-3">
                      {category}
                    </div>
                    <Table>
                      <TableHeader>
                        <TableRow className="border-[var(--border-color)]">
                          <TableHead className="text-[var(--text-secondary)] w-48">权限项</TableHead>
                          {roles.map(role => (
                            <TableHead key={role.id} className="text-center text-[var(--text-secondary)]">
                              <div 
                                className="w-3 h-3 rounded-full mx-auto mb-1" 
                                style={{ backgroundColor: role.color }}
                              />
                            </TableHead>
                          ))}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {permissions
                          .filter(p => p.category === category)
                          .map(permission => (
                            <TableRow key={permission.id} className="border-[var(--border-color)]">
                              <TableCell className="text-[var(--text-primary)]">
                                {permission.name}
                              </TableCell>
                              {roles.map(role => {
                                const rolePermissions = permissionMatrix?.[role.id as keyof PermissionMatrix];
                                return (
                                  <TableCell key={role.id} className="text-center">
                                    {rolePermissions?.includes(permission.id) ? (
                                      <CheckCircle className="w-5 h-5 text-green-400 mx-auto" />
                                    ) : (
                                      <div className="w-5 h-5 rounded-full bg-gray-500/20 mx-auto" />
                                    )}
                                  </TableCell>
                                );
                              })}
                            </TableRow>
                          ))}
                      </TableBody>
                    </Table>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* 数据范围 */}
        <TabsContent value="scopes" className="mt-4">
          <Card className="bg-[var(--bg-card)] border-[var(--border-color)]">
            <CardHeader>
              <CardTitle className="text-[var(--text-primary)]">数据范围控制</CardTitle>
              <p className="text-sm text-[var(--text-secondary)]">
                不同角色可查看的数据范围
              </p>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                {dataScopes.map(scope => {
                  const role = roles.find(r => r.id === scope.role);
                  return (
                    <Card 
                      key={scope.role}
                      className="bg-[var(--bg-secondary)] border-[var(--border-color)]"
                    >
                      <CardContent className="pt-6">
                        <div className="text-center space-y-4">
                          <div className="text-4xl">{scope.icon}</div>
                          <Badge 
                            style={{ backgroundColor: role?.color, color: 'white' }}
                            className="text-white"
                          >
                            {role?.name}
                          </Badge>
                          <div className="text-lg font-medium text-[var(--text-primary)]">
                            {scope.description}
                          </div>
                          <div className="text-sm text-[var(--text-muted)]">
                            {scope.scope === 'all' && '可查看所有客户、线索、商机数据'}
                            {scope.scope === 'team' && '可查看所属团队的所有数据'}
                            {scope.scope === 'self' && '仅可查看自己创建和负责的数据'}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}