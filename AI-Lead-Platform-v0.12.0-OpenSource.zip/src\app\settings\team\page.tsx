'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { 
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow 
} from '@/components/ui/table';
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger 
} from '@/components/ui/dialog';
import { 
  Users, UserPlus, Edit, Trash2, Shield, Mail, Phone, Loader2 
} from 'lucide-react';

// 模拟团队成员数据
const mockMembers = [
  { id: '1', name: '张三', email: 'zhangsan@example.com', phone: '13800138000', role: '管理员', status: '活跃', customers: 25 },
  { id: '2', name: '李四', email: 'lisi@example.com', phone: '13900139000', role: '销售主管', status: '活跃', customers: 15 },
  { id: '3', name: '王五', email: 'wangwu@example.com', phone: '13700137000', role: '销售', status: '活跃', customers: 8 },
  { id: '4', name: '赵六', email: 'zhaoliu@example.com', phone: '13600136000', role: '销售', status: '禁用', customers: 0 },
];

// 角色定义
const roles = [
  { id: 'admin', name: '管理员', desc: '全部权限，可管理团队成员和系统设置' },
  { id: 'manager', name: '销售主管', desc: '可查看团队数据、分配客户、管理商机' },
  { id: 'sales', name: '销售', desc: '仅可查看和跟进自己的客户和商机' },
];

export default function TeamSettingsPage() {
  const [members, setMembers] = useState(mockMembers);
  const [inviteDialogOpen, setInviteDialogOpen] = useState(false);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editingMember, setEditingMember] = useState<any>(null);

  // 新成员表单
  const [newMember, setNewMember] = useState({
    name: '',
    email: '',
    phone: '',
    role: 'sales'
  });

  // 邀请成员
  const handleInvite = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setMembers([...members, {
        id: String(members.length + 1),
        ...newMember,
        status: '待激活',
        customers: 0
      }]);
      setNewMember({ name: '', email: '', phone: '', role: 'sales' });
      setInviteDialogOpen(false);
    } finally {
      setLoading(false);
    }
  };

  // 编辑成员
  const handleEdit = (member: any) => {
    setEditingMember(member);
    setEditDialogOpen(true);
  };

  // 保存编辑
  const handleSaveEdit = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 500));
      setMembers(members.map(m => m.id === editingMember.id ? editingMember : m));
      setEditDialogOpen(false);
    } finally {
      setLoading(false);
    }
  };

  // 禁用/启用成员
  const toggleStatus = async (memberId: string) => {
    setMembers(members.map(m => 
      m.id === memberId ? { ...m, status: m.status === '活跃' ? '禁用' : '活跃' } : m
    ));
  };

  // 删除成员
  const handleDelete = async (memberId: string) => {
    if (confirm('确定要删除该成员吗？')) {
      setMembers(members.filter(m => m.id !== memberId));
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold flex items-center gap-2">
        <Users className="w-6 h-6" />
        团队设置
      </h1>

      {/* 成员列表 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              团队成员
            </span>
            <Dialog open={inviteDialogOpen} onOpenChange={setInviteDialogOpen}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <UserPlus className="w-4 h-4 mr-2" />
                  邀请成员
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>邀请团队成员</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <label className="text-sm font-medium">姓名</label>
                    <Input
                      value={newMember.name}
                      onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                      placeholder="请输入姓名"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">邮箱</label>
                    <Input
                      type="email"
                      value={newMember.email}
                      onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
                      placeholder="请输入邮箱"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">手机号</label>
                    <Input
                      value={newMember.phone}
                      onChange={(e) => setNewMember({ ...newMember, phone: e.target.value })}
                      placeholder="请输入手机号"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">角色</label>
                    <select
                      className="w-full h-10 rounded-md border bg-background px-3"
                      value={newMember.role}
                      onChange={(e) => setNewMember({ ...newMember, role: e.target.value })}
                    >
                      {roles.map(role => (
                        <option key={role.id} value={role.id}>{role.name}</option>
                      ))}
                    </select>
                  </div>
                  <Button onClick={handleInvite} disabled={loading} className="w-full">
                    {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : '发送邀请'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>姓名</TableHead>
                <TableHead>邮箱</TableHead>
                <TableHead>手机号</TableHead>
                <TableHead>角色</TableHead>
                <TableHead>状态</TableHead>
                <TableHead>负责客户数</TableHead>
                <TableHead>操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {members.map(member => (
                <TableRow key={member.id}>
                  <TableCell className="font-medium">{member.name}</TableCell>
                  <TableCell>{member.email}</TableCell>
                  <TableCell>{member.phone}</TableCell>
                  <TableCell>
                    <Badge variant={member.role === '管理员' ? 'default' : 'outline'}>
                      {member.role}
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <Badge variant={member.status === '活跃' ? 'default' : 'secondary'}>
                      {member.status}
                    </Badge>
                  </TableCell>
                  <TableCell>{member.customers}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button size="sm" variant="ghost" onClick={() => handleEdit(member)}>
                        <Edit className="w-4 h-4" />
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        onClick={() => toggleStatus(member.id)}
                      >
                        {member.status === '活跃' ? '禁用' : '启用'}
                      </Button>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="text-red-500"
                        onClick={() => handleDelete(member.id)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* 角色权限说明 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            角色权限说明
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {roles.map(role => (
              <div key={role.id} className="p-4 bg-muted/10 rounded-lg">
                <div className="font-medium mb-2 flex items-center gap-2">
                  <Badge>{role.name}</Badge>
                </div>
                <div className="text-sm text-muted-foreground">{role.desc}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 编辑成员对话框 */}
      <Dialog open={editDialogOpen} onOpenChange={setEditDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>编辑成员</DialogTitle>
          </DialogHeader>
          {editingMember && (
            <div className="space-y-4 py-4">
              <div>
                <label className="text-sm font-medium">姓名</label>
                <Input
                  value={editingMember.name}
                  onChange={(e) => setEditingMember({ ...editingMember, name: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">邮箱</label>
                <Input
                  value={editingMember.email}
                  onChange={(e) => setEditingMember({ ...editingMember, email: e.target.value })}
                />
              </div>
              <div>
                <label className="text-sm font-medium">角色</label>
                <select
                  className="w-full h-10 rounded-md border bg-background px-3"
                  value={editingMember.role}
                  onChange={(e) => setEditingMember({ ...editingMember, role: e.target.value })}
                >
                  {roles.map(role => (
                    <option key={role.id} value={role.name}>{role.name}</option>
                  ))}
                </select>
              </div>
              <Button onClick={handleSaveEdit} disabled={loading} className="w-full">
                {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : '保存修改'}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}